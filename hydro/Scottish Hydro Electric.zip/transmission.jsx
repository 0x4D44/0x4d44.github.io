// Transmission timeline + diagrams

function TransmissionTimeline({ items }) {
  return (
    <div className="trans-timeline">
      {items.map((it, i) => (
        <div key={i} className={`trans-row trans-${it.icon}`}>
          <div className="trans-year">
            <div className="y">{it.year}</div>
          </div>
          <div className="trans-track">
            <span className="trans-node"></span>
            {i !== items.length - 1 && <span className="trans-line"></span>}
          </div>
          <div className="trans-body">
            <div className="trans-meta">
              <span className="trans-kind">{kindLabel(it.icon)}</span>
              <span className="trans-volt">{it.voltage}</span>
            </div>
            <h3 className="trans-title">{it.title}</h3>
            <p>{it.detail}</p>
          </div>
        </div>
      ))}
    </div>
  );
}

function kindLabel(icon) {
  return ({
    private: 'PRIVATE',
    grid: 'AC GRID',
    rural: 'DISTRIBUTION',
    policy: 'POLICY',
    controversy: 'CONTROVERSY',
    hvdc: 'HVDC'
  })[icon] || icon.toUpperCase();
}

// Pylon scale diagram — relative heights of the voltage levels used in Scotland
function TransmissionDiagram() {
  // Pylon archetypes — voltage, real-world height range, color
  const pylons = [
    { v: "11 kV",   label: "Local distribution (croft)", h: 9,  type: "pole" },
    { v: "33 kV",   label: "Sub-transmission",          h: 13, type: "pole" },
    { v: "132 kV",  label: "National Grid (1926→)",     h: 27, type: "lattice" },
    { v: "275 kV",  label: "Supergrid (1965→)",         h: 38, type: "lattice" },
    { v: "400 kV",  label: "Beauly–Denny (2015→)",      h: 53, type: "lattice" },
    { v: "±525 kV DC", label: "Eastern Green Links",    h: 60, type: "dc" }
  ];
  const maxH = Math.max(...pylons.map(p => p.h));
  const STAGE_H = 220;
  const W = 110;

  return (
    <div className="trans-diagram">
      <div className="trans-diagram-head">
        <div>
          <div className="eyebrow" style={{ marginBottom: 8 }}>Voltage scale, to size</div>
          <p style={{ color: 'var(--ink-mute)', fontSize: 14, margin: 0, maxWidth: '52ch' }}>
            Real pylon heights for each voltage class used in Scotland. The same kilowatt-hour
            travels down all of them — at increasingly violent voltages and increasingly large steel
            towers — before getting stepped down to 230 V for a kettle.
          </p>
        </div>
      </div>
      <div className="trans-diagram-row">
        {pylons.map((p, i) => {
          const scaledH = (p.h / maxH) * STAGE_H;
          return (
            <div key={i} className="trans-pylon-cell">
              <div className="trans-pylon-stage" style={{ height: STAGE_H + 20 }}>
                <svg width={W} height={STAGE_H + 20} viewBox={`0 0 ${W} ${STAGE_H + 20}`}>
                  {/* ground line */}
                  <line x1={0} x2={W} y1={STAGE_H + 14} y2={STAGE_H + 14} stroke="var(--line-strong)" strokeWidth="0.6"/>
                  {/* pylon */}
                  <PylonSVG type={p.type} w={W} h={scaledH} top={STAGE_H + 14 - scaledH} />
                  {/* height label */}
                  <text x={W - 4} y={STAGE_H + 14 - scaledH - 4}
                    textAnchor="end"
                    style={{ fontFamily: 'var(--mono)', fontSize: 9, fill: 'var(--ink-mute)' }}>
                    {p.h} m
                  </text>
                </svg>
              </div>
              <div className="trans-pylon-volt">{p.v}</div>
              <div className="trans-pylon-label">{p.label}</div>
            </div>
          );
        })}
      </div>
    </div>
  );
}

function PylonSVG({ type, w, h, top }) {
  const cx = w / 2;
  const bottom = top + h;
  const stroke = 'oklch(0.74 0.10 230)';

  if (type === 'pole') {
    // Wood pole with crossarm
    return (
      <g>
        <line x1={cx} y1={top} x2={cx} y2={bottom} stroke="oklch(0.55 0.05 70)" strokeWidth="2" />
        <line x1={cx - 12} y1={top + 6} x2={cx + 12} y2={top + 6} stroke="oklch(0.55 0.05 70)" strokeWidth="1.4" />
        {/* insulators */}
        <circle cx={cx - 10} cy={top + 6} r="1.4" fill="#ece5d8"/>
        <circle cx={cx}      cy={top + 6} r="1.4" fill="#ece5d8"/>
        <circle cx={cx + 10} cy={top + 6} r="1.4" fill="#ece5d8"/>
        {/* faint conductor lines fading out */}
        <line x1={0} x2={w} y1={top + 6} y2={top + 6} stroke={stroke} strokeWidth="0.4" opacity="0.4"/>
      </g>
    );
  }

  if (type === 'lattice') {
    // Steel lattice pylon — trapezoidal silhouette + cross-bracing
    const baseHalf = h * 0.22;
    const topHalf  = w * 0.10;
    const crossY1 = top + h * 0.55;
    const crossY2 = top + h * 0.40;
    const armH = 4;
    return (
      <g stroke={stroke} fill="none">
        {/* legs */}
        <line x1={cx - baseHalf} y1={bottom} x2={cx - topHalf} y2={top + h * 0.55} strokeWidth="0.9" />
        <line x1={cx + baseHalf} y1={bottom} x2={cx + topHalf} y2={top + h * 0.55} strokeWidth="0.9" />
        <line x1={cx - topHalf} y1={top + h * 0.55} x2={cx - topHalf} y2={top} strokeWidth="0.9" />
        <line x1={cx + topHalf} y1={top + h * 0.55} x2={cx + topHalf} y2={top} strokeWidth="0.9" />
        {/* cross-bracing X's */}
        {[0.85, 0.7, 0.55, 0.4, 0.25, 0.1].map((f, idx) => {
          const y1 = top + h * f;
          const y2 = top + h * (f + 0.075);
          if (y2 > bottom) return null;
          const leftAtY = (y) => {
            const t = (bottom - y) / h;
            return cx - (topHalf + (baseHalf - topHalf) * Math.min(1, t / 0.45));
          };
          const rightAtY = (y) => {
            const t = (bottom - y) / h;
            return cx + (topHalf + (baseHalf - topHalf) * Math.min(1, t / 0.45));
          };
          return (
            <g key={idx}>
              <line x1={leftAtY(y1)} y1={y1} x2={rightAtY(y2)} y2={y2} strokeWidth="0.4" opacity="0.7" />
              <line x1={rightAtY(y1)} y1={y1} x2={leftAtY(y2)} y2={y2} strokeWidth="0.4" opacity="0.7" />
            </g>
          );
        })}
        {/* arms */}
        <line x1={cx - 20} y1={top + h * 0.15} x2={cx + 20} y2={top + h * 0.15} strokeWidth="0.8" />
        <line x1={cx - 26} y1={top + h * 0.30} x2={cx + 26} y2={top + h * 0.30} strokeWidth="0.8" />
        {/* peak */}
        <line x1={cx} y1={top + h * 0.15} x2={cx} y2={top - 1} strokeWidth="0.6" />
        {/* insulators - small dots */}
        {[
          [cx - 18, top + h * 0.15], [cx, top + h * 0.15], [cx + 18, top + h * 0.15],
          [cx - 24, top + h * 0.30], [cx + 24, top + h * 0.30]
        ].map(([x, y], i) => (
          <circle key={i} cx={x} cy={y + 1.6} r="0.9" fill="#ece5d8" stroke="none" />
        ))}
        {/* conductor lines */}
        {[0.15, 0.30].map((f, i) => (
          <line key={i} x1={0} x2={w} y1={top + h * f + 2} y2={top + h * f + 2} stroke={stroke} strokeWidth="0.3" opacity="0.4" fill="none" />
        ))}
      </g>
    );
  }

  if (type === 'dc') {
    // Subsea HVDC — converter station + cable underwater. Drawn as a chunky block with cable going off-screen.
    const blockW = 28, blockH = h * 0.35;
    return (
      <g>
        {/* converter station */}
        <rect x={cx - blockW / 2} y={bottom - blockH} width={blockW} height={blockH}
              fill="oklch(0.45 0.06 230)" stroke={stroke} strokeWidth="0.5" />
        {/* roof */}
        <rect x={cx - blockW / 2 - 2} y={bottom - blockH - 2} width={blockW + 4} height={3}
              fill={stroke} stroke="none" />
        {/* sea level indicator */}
        <line x1={0} x2={w} y1={bottom + 2} y2={bottom + 2} stroke="oklch(0.55 0.08 230)" strokeWidth="0.4" />
        {/* cable going underwater */}
        <path d={`M ${cx} ${bottom} Q ${cx + 6} ${bottom + 8} ${w} ${bottom + 10}`}
              fill="none" stroke={stroke} strokeWidth="1.2" />
        {/* converter label hint */}
        <text x={cx} y={bottom - blockH / 2} textAnchor="middle"
          style={{ fontFamily: 'var(--mono)', fontSize: 5, fill: '#ece5d8', letterSpacing: '0.1em' }}>
          AC↔DC
        </text>
      </g>
    );
  }
  return null;
}

window.TransmissionTimeline = TransmissionTimeline;
window.TransmissionDiagram = TransmissionDiagram;
