// Scottish Hydro Power - master data file.
// Coordinates are approximate (lat, lon) for the powerhouse / main dam.

window.SCHEMES = [
  {
    id: "fort-augustus",
    name: "Fort Augustus Abbey",
    year: 1890,
    builder: "Benedictine Monks",
    type: "Run-of-river",
    capacity_mw: 0.018,
    head_m: null,
    region: "Loch Ness",
    coord: [57.142, -4.679],
    blurb: "One of the very first hydro-electric schemes in Britain. A small turbine on the River Oich powered the abbey and around 800 villagers. Legend has it the lights dimmed every time the monks played their organ.",
    facts: [
      "Built before the National Grid existed.",
      "Direct-current installation; entirely self-contained.",
      "Predated the much larger Foyers smelter scheme by six years."
    ],
    status: "Decommissioned"
  },
  {
    id: "foyers-original",
    name: "Foyers (British Aluminium)",
    year: 1896,
    builder: "British Aluminium Company",
    type: "Industrial run-of-river",
    capacity_mw: 3.75,
    head_m: 107,
    region: "Loch Ness, east shore",
    coord: [57.245, -4.493],
    blurb: "The first large-scale industrial hydro plant in the UK. Built to power Britain's first aluminium smelter — turning bauxite into aluminium needs vast amounts of cheap electricity, and the falls of Foyers had it on tap.",
    facts: [
      "Used water from Loch Mhor (Loch Garth) dropped to Loch Ness.",
      "Smelter closed 1967; site rebuilt as a pumped-storage station in 1974.",
      "Triggered a wave of aluminium-driven hydro schemes in the Highlands."
    ],
    status: "Replaced by Foyers PS (1974)"
  },
  {
    id: "kinlochleven",
    name: "Kinlochleven",
    year: 1909,
    builder: "North British Aluminium Co.",
    type: "Reservoir / conduit",
    capacity_mw: 24,
    head_m: 290,
    region: "Loch Leven",
    coord: [56.717, -4.967],
    blurb: "Built to feed an aluminium smelter at the head of Loch Leven. The Blackwater Reservoir dam was the largest in Britain when built; the village of Kinlochleven was lit by mains electricity decades before most of Glasgow.",
    facts: [
      "Blackwater Dam: 870 m long, built largely by Irish labourers using hand tools.",
      "Dozens of construction workers are buried in the unmarked navvies' graveyard above the dam.",
      "Kinlochleven was reputedly the first village in the world fully lit by electricity (1908)."
    ],
    status: "Operating (Rio Tinto / Alvance)"
  },
  {
    id: "lochaber",
    name: "Lochaber Scheme",
    year: 1929,
    builder: "British Aluminium Company",
    type: "Reservoir / conduit",
    capacity_mw: 84,
    head_m: 235,
    region: "Fort William",
    coord: [56.819, -5.105],
    blurb: "A heroic act of plumbing: water from Loch Treig and the catchment of the upper Spey is sent through a 24 km tunnel under Ben Nevis to a smelter at Fort William. Still feeding aluminium production today.",
    facts: [
      "24 km Laggan-Treig tunnel: longest of its kind in Britain at the time.",
      "Drops about 235 m at the powerhouse through 5 huge penstock pipes carved up the hillside.",
      "Construction employed >3,000 men; smelter still active a century on."
    ],
    status: "Operating (Alvance)"
  },
  {
    id: "lanark",
    name: "Lanark (Bonnington & Stonebyres)",
    year: 1926,
    builder: "Clyde Valley Electrical Power Co.",
    type: "Run-of-river",
    capacity_mw: 17,
    head_m: 50,
    region: "Falls of Clyde",
    coord: [55.661, -3.781],
    blurb: "The first 'modern' hydro scheme in Scotland — opened in 1926, still generating today under Drax. Uses the famous Falls of Clyde; in fact New Lanark mill village had been water-powered since 1786, just not for electricity.",
    facts: [
      "Two stations: Bonnington (11 MW) and Stonebyres (6 MW).",
      "Among the longest continuously-operating hydro stations in Britain.",
      "Acquired by Drax in 2018 along with Cruachan and Galloway."
    ],
    status: "Operating (Drax)"
  },
  {
    id: "rannoch-tummel-bridge",
    name: "Rannoch & Tummel Bridge",
    year: 1930,
    builder: "Grampian Electricity Supply Co.",
    type: "Reservoir / conduit",
    capacity_mw: 82,
    head_m: 175,
    region: "Perthshire",
    coord: [56.690, -4.275],
    blurb: "Grampian Electricity's flagship pre-war project. Loch Ericht was dammed to feed Rannoch (48 MW); Loch Rannoch then fed Tummel Bridge (34 MW). The pattern of cascading water through several stations defined later NoSHEB design.",
    facts: [
      "Loch Ericht raised by 4.9 m; one of the highest large lochs in Scotland.",
      "Absorbed into the Tummel-Garry scheme by NoSHEB in the 1950s.",
      "Tummel Bridge's 1933 station was rebuilt in the 1950s with extra capacity."
    ],
    status: "Operating (SSE Renewables)"
  },
  {
    id: "galloway",
    name: "Galloway Scheme",
    year: 1935,
    builder: "Galloway Water Power Co. (William McAlpine)",
    type: "Cascade run-of-river",
    capacity_mw: 109,
    head_m: 230,
    region: "Dumfries & Galloway",
    coord: [55.046, -4.226],
    blurb: "A landmark in British civil engineering — the largest run-of-river hydro project ever built in the UK, with five power stations daisy-chained down the Dee and Ken catchments. Its bold modernist architecture (curved white-rendered turbine halls, stylised dams) became the template for everything NoSHEB built afterwards.",
    facts: [
      "Five stations: Kendoon (24 MW), Carsfad (12 MW), Earlstoun (12 MW), Glenlee (24 MW), Tongland (33 MW).",
      "Designed by engineer William Halcrow; architecture by Sir Alexander Gibb.",
      "Built in just five years (1930–35) using direct labour and Irish navvies.",
      "Now Category-A listed for architectural significance."
    ],
    status: "Operating (Drax)"
  },
  {
    id: "morar-nostie",
    name: "Morar & Nostie Bridge",
    year: 1948,
    builder: "NoSHEB",
    type: "Small run-of-river",
    capacity_mw: 0.95,
    head_m: 17,
    region: "Wester Ross / Lochalsh",
    coord: [57.000, -5.730],
    blurb: "NoSHEB's very first stations — tiny, almost ceremonial. The Morar opening was performed by a local widow, Catherine Mackenzie, who reportedly declared 'Let light and power come to the crofts.'",
    facts: [
      "Morar: 0.75 MW. Nostie Bridge: 0.2 MW.",
      "Brought mains electricity to dozens of crofts in Wester Ross for the first time.",
      "Symbolic rather than economic — but vital for political momentum."
    ],
    status: "Operating"
  },
  {
    id: "sloy",
    name: "Loch Sloy",
    year: 1950,
    builder: "NoSHEB",
    type: "High-head reservoir",
    capacity_mw: 152.5,
    head_m: 277,
    region: "Loch Lomond",
    coord: [56.246, -4.762],
    blurb: "The first major NoSHEB scheme to open — opened by the young Queen Elizabeth alongside Tom Johnston in 1950. The Sloy dam raised the loch by 47 m; water tumbles 277 m down four enormous penstocks to a powerhouse on Loch Lomond.",
    facts: [
      "Sloy dam: 357 m long buttress dam, the largest of its type in Britain.",
      "Four 38 MW turbines (later uprated). Largest conventional hydro station in the UK.",
      "Can reach full output in under 5 minutes — used as fast-start backup for the grid.",
      "Penstocks visible from miles away as four white scars on Ben Vorlich."
    ],
    status: "Operating (SSE Renewables)"
  },
  {
    id: "tummel-garry",
    name: "Tummel–Garry Scheme",
    year: 1950,
    builder: "NoSHEB",
    type: "Cascade",
    capacity_mw: 245,
    head_m: 50,
    region: "Perthshire",
    coord: [56.711, -3.731],
    blurb: "The biggest of the early NoSHEB schemes — nine power stations linked by 250 km of tunnels and aqueducts, cascading from Loch Ericht through Rannoch, Tummel and Garry down to the Tay. The famous Pitlochry fish ladder lets salmon climb past the dam in 34 pools.",
    facts: [
      "Stations include Clunie (61 MW), Errochty (75 MW), Pitlochry (15 MW), Rannoch (48 MW).",
      "Authorised 19 November 1945 — first major NoSHEB project approved.",
      "Pitlochry fish ladder: 310 m long, 34 chambers, glass-walled observation room.",
      "Erochty was the last major station opened (1957) — and the last big NoSHEB hydro for 50 years."
    ],
    status: "Operating (SSE Renewables)"
  },
  {
    id: "affric-beauly",
    name: "Affric–Beauly Scheme",
    year: 1952,
    builder: "NoSHEB",
    type: "Cascade",
    capacity_mw: 240,
    head_m: 360,
    region: "Glen Affric / Strathglass",
    coord: [57.395, -4.730],
    blurb: "The scheme that defined NoSHEB. Originally proposed in 1941, defeated in Parliament, then resurrected — became one of the largest hydro complexes in the UK. Six power stations, two huge dams (Mullardoch, Benevean), and 80+ km of tunnels through some of the wildest country in Scotland.",
    facts: [
      "Mullardoch Dam: 220 m long, raises Loch Mullardoch by 36 m — largest mass-gravity dam in Scotland.",
      "Stations: Fasnakyle (66 MW), Mullardoch, Deanie, Culligran, Aigas, Kilmorack.",
      "Sir Edward MacColl, NoSHEB's chief engineer, drove the design.",
      "Glen Affric is now a national nature reserve — the scheme is largely invisible from the glen floor."
    ],
    status: "Operating (SSE Renewables)"
  },
  {
    id: "breadalbane",
    name: "Breadalbane Scheme",
    year: 1961,
    builder: "NoSHEB",
    type: "Cascade",
    capacity_mw: 120,
    head_m: 415,
    region: "Loch Tay / Glen Lyon",
    coord: [56.470, -4.319],
    blurb: "Seven stations across the high country between Loch Tay and Loch Lyon. During construction the Tunnel Tigers set a world record by driving 557 ft (170 m) of tunnel through hard rock in a single week in October 1955.",
    facts: [
      "Stations include Lochay (47 MW), Finlarig (15 MW), Cashlie (10 MW), St Fillans (24 MW), Lednock (3 MW).",
      "Almost 10 miles of tunnel cut in a single year at the St Fillans section.",
      "Lubreoch Dam on Loch Lyon: 56 m high.",
      "Set a world rock-driving record: 557 ft in one week, October 1955."
    ],
    status: "Operating (SSE Renewables)"
  },
  {
    id: "conon",
    name: "Conon Valley Scheme",
    year: 1961,
    builder: "NoSHEB",
    type: "Cascade",
    capacity_mw: 138,
    head_m: 290,
    region: "Ross-shire",
    coord: [57.583, -4.435],
    blurb: "Six stations across the Conon catchment: Mossford, Grudie Bridge, Achanalt, Luichart, Torr Achilty and Orrin. Quietly one of the most productive cascades — most of the water that falls on the Fannichs ends up generating three or four times.",
    facts: [
      "Stations: Mossford (18.7 MW), Grudie Bridge (24 MW), Luichart (24 MW), Torr Achilty (15 MW), Orrin (18 MW), Achanalt (3 MW).",
      "Orrin Dam: 96 m high — the tallest in the scheme.",
      "Output is highly seasonal — most generation happens between October and March."
    ],
    status: "Operating (SSE Renewables)"
  },
  {
    id: "garry-moriston",
    name: "Garry & Moriston Schemes",
    year: 1957,
    builder: "NoSHEB",
    type: "Cascade",
    capacity_mw: 130,
    head_m: 260,
    region: "Great Glen",
    coord: [57.066, -5.014],
    blurb: "Two linked schemes feeding the Great Glen. Glen Garry stations (Quoich, Invergarry, Livishie) and Glen Moriston (Glenmoriston, Ceannacroc) drain a vast area of remote Lochaber and Kintail.",
    facts: [
      "Quoich Dam: 38 m high, holds back the dramatically enlarged Loch Quoich.",
      "Glenmoriston (37 MW) and Ceannacroc (20 MW) sit on the A887.",
      "The schemes flooded the village of Kinlochquoich, displacing the last residents."
    ],
    status: "Operating (SSE Renewables)"
  },
  {
    id: "awe",
    name: "Awe Scheme",
    year: 1963,
    builder: "NoSHEB",
    type: "Cascade",
    capacity_mw: 40,
    head_m: 290,
    region: "Argyll",
    coord: [56.395, -5.082],
    blurb: "Inverawe (25 MW) and Nant (15 MW) — small but strategically placed at the foot of Ben Cruachan. The valley was already being eyed for something far bigger.",
    facts: [
      "Inverawe sits at the head of Loch Etive.",
      "Nant uses water from Loch Nant, dropped 290 m to Loch Awe.",
      "Provided the access roads and infrastructure later used by Cruachan."
    ],
    status: "Operating (SSE Renewables)"
  },
  {
    id: "shin",
    name: "Shin Scheme",
    year: 1959,
    builder: "NoSHEB",
    type: "Cascade",
    capacity_mw: 32,
    head_m: 110,
    region: "Sutherland",
    coord: [57.965, -4.467],
    blurb: "The most northerly hydro cascade — Cassley, Lairg and Shin stations stretch across Sutherland from the high tops down to the Kyle of Sutherland.",
    facts: [
      "Shin (24 MW), Cassley (10 MW), Lairg (3.5 MW).",
      "Loch Shin raised by 11 m and extended 27 km long.",
      "Falls of Shin nearby is famous for leaping Atlantic salmon."
    ],
    status: "Operating (SSE Renewables)"
  },
  {
    id: "cruachan",
    name: "Cruachan — 'The Hollow Mountain'",
    year: 1965,
    builder: "NoSHEB / James Williamson & Partners",
    type: "Pumped storage",
    capacity_mw: 440,
    head_m: 396,
    region: "Argyll, Ben Cruachan",
    coord: [56.397, -5.114],
    blurb: "The world's first reversible-pump-turbine pumped storage station of its scale. The turbine hall is buried 1 km inside Ben Cruachan; the upper reservoir sits 396 m above Loch Awe. It can go from cold to full output (440 MW) in 30 seconds, and provides black-start capability for the National Grid.",
    facts: [
      "Four turbines: 2 × 100 MW (originals), 2 × 120 MW (uprated 2005).",
      "Upper reservoir: 10 million m³, drained via 19 km of catchment tunnels.",
      "Pumps at 167 m³/s; generates at 200 m³/s.",
      "22 hours of continuous generation from full reservoir.",
      "4,000 people on site at peak construction; 36 died building it.",
      "Cost £24.5m; opened 15 October 1965 by Queen Elizabeth II.",
      "Concept designed by Sir Edward MacColl, who died before it opened."
    ],
    status: "Operating (Drax); Cruachan II (600 MW) approved 2023"
  },
  {
    id: "foyers-ps",
    name: "Foyers Pumped Storage",
    year: 1974,
    builder: "NoSHEB",
    type: "Pumped storage",
    capacity_mw: 305,
    head_m: 175,
    region: "Loch Ness, east shore",
    coord: [57.245, -4.493],
    blurb: "Built on the bones of the original 1896 British Aluminium scheme. Loch Mhor sits 175 m above Loch Ness; water is pumped up at night, released by day. Two 152.5 MW reversible units.",
    facts: [
      "Replaced the original Foyers aluminium smelter scheme.",
      "Lower reservoir: Loch Ness itself.",
      "Used for grid balancing and frequency control.",
      "Second of the UK's four pumped-storage stations."
    ],
    status: "Operating (SSE Renewables)"
  },
  {
    id: "glendoe",
    name: "Glendoe",
    year: 2009,
    builder: "SSE (Hochtief)",
    type: "High-head reservoir",
    capacity_mw: 100,
    head_m: 600,
    region: "Monadhliath, above Loch Ness",
    coord: [57.130, -4.628],
    blurb: "The highest head of any UK hydro station — water drops 600 m to a single Pelton turbine. The first major Scottish hydro built in over 50 years, opened by the Queen in June 2009. Famously failed eight months later when the headrace tunnel collapsed.",
    facts: [
      "Single 100 MW Pelton turbine — extremely rare scale for the UK.",
      "Glendoe Dam: 960 m long, 35 m high, on the River Tarff.",
      "8.5 km headrace tunnel + 16 km total tunnels.",
      "August 2009: tunnel collapse blocked 71 m of headrace.",
      "Out of service for 3 years; repair cost £130m.",
      "Litigation between SSE and Hochtief reached the UK Supreme Court."
    ],
    status: "Operating (SSE Renewables)"
  },
  // Planned / under construction
  {
    id: "cruachan-2",
    name: "Cruachan II",
    year: 2030,
    builder: "Drax",
    type: "Pumped storage (planned)",
    capacity_mw: 600,
    head_m: 396,
    region: "Argyll, Ben Cruachan",
    coord: [56.397, -5.110],
    blurb: "A second power station, hollowed out alongside the original Cruachan cavern, sharing the existing upper reservoir. Will more than double the site's output to 1.04 GW. Consented 2023, expected operational 2030.",
    facts: [
      "600 MW additional capacity in a new underground cavern.",
      "First new UK pumped-storage scheme in over 40 years.",
      "Estimated cost £500m+. Designed by Studio Pietrangeli with Cowi.",
      "Will require excavating ~2 million tonnes of rock."
    ],
    status: "Consented (2023)"
  },
  {
    id: "coire-glas",
    name: "Coire Glas",
    year: 2031,
    builder: "SSE Renewables",
    type: "Pumped storage (planned)",
    capacity_mw: 1500,
    head_m: 500,
    region: "Loch Lochy",
    coord: [57.000, -4.870],
    blurb: "The largest pumped-storage scheme proposed in the UK for decades. Loch Lochy is the lower reservoir; a new upper reservoir would be built 500 m above in Coire Glas. Could store ~30 GWh — more than every existing UK pumped-storage station combined.",
    facts: [
      "1.5 GW peak output, ~30 GWh storage (about 24h at full output).",
      "Would more than double UK pumped-storage capacity.",
      "Consented 2020; final investment decision pending market reform.",
      "Upper reservoir would hold ~25 million m³."
    ],
    status: "Consented (2020)"
  },
  {
    id: "red-john",
    name: "Red John",
    year: 2031,
    builder: "Statkraft",
    type: "Pumped storage (planned)",
    capacity_mw: 450,
    head_m: 480,
    region: "Loch Ness, east shore",
    coord: [57.350, -4.470],
    blurb: "Uses Loch Ness as the lower reservoir, with a new artificial upper reservoir at Balchraggan. Consented and acquired by Statkraft in 2022.",
    facts: [
      "450 MW, ~2.8 GWh of storage.",
      "Will join Foyers PS and Glendoe on the shores of Loch Ness.",
      "Construction window dependent on cap-and-floor regulatory regime."
    ],
    status: "Consented (2021)"
  }
];

// Key events / accidents / milestones
window.EVENTS = [
  { year: 1894, kind: "Industry",  title: "British Aluminium Company formed",
    detail: "First UK aluminium smelter company. Triggers Foyers (1896), Kinlochleven (1909), Lochaber (1929)." },
  { year: 1918, kind: "Policy", title: "Snell Committee",
    detail: "First Government review of Scottish water power. Concluded that most of the easy hydro sites had already been identified — wrongly, as it turned out." },
  { year: 1929, kind: "Accident", title: "Blackwater Dam navvies",
    detail: "Decades of construction (1905–1909) and ongoing work left dozens of labourers buried in an unmarked graveyard above Kinlochleven. No exact death toll was ever published." },
  { year: 1941, kind: "Policy", title: "Tom Johnston becomes Secretary of State for Scotland",
    detail: "Within months, sets up the Cooper Committee on Hydro-Electric Development. The Caledonian Water Power bill (1938) and a Glen Affric bill (1941) had both been defeated; Johnston wanted the State, not private capital, to build the schemes." },
  { year: 1943, kind: "Policy", title: "Hydro-Electric Development (Scotland) Act",
    detail: "Creates the North of Scotland Hydro-Electric Board (NoSHEB). Mandate: 'social clause' obliging it to bring electricity to remote glens at uniform tariff — the South subsidises the North." },
  { year: 1948, kind: "Milestone", title: "First NoSHEB stations switched on",
    detail: "Morar and Nostie Bridge (~1 MW combined). 1 in 14 farms and 1 in 100 crofts had mains supply that year." },
  { year: 1950, kind: "Milestone", title: "Loch Sloy opened by the Queen",
    detail: "First large NoSHEB station. By year's end three more (Clunie, Grandtully, Pitlochry) also generating." },
  { year: 1953, kind: "Milestone", title: "300,000 consumers connected",
    detail: "Just five years after Morar, NoSHEB had over 300,000 customers in northern Scotland." },
  { year: 1955, kind: "Engineering", title: "World rock-driving record",
    detail: "Tunnel Tigers at the St Fillans section of Breadalbane drive 557 ft of rock tunnel in one week — a world record. ~10 miles of tunnel cut in a single year." },
  { year: 1955, kind: "Policy", title: "South of Scotland Electricity Board formed",
    detail: "The Conservatives create a parallel southern board. The two Scottish boards report to the Scottish Office, not Westminster's Ministry of Fuel and Power." },
  { year: 1963, kind: "Milestone", title: "1 GW of hydro capacity",
    detail: "NoSHEB's hydro fleet passes one million kilowatts; 50% of consumers now cook with electricity." },
  { year: 1965, kind: "Milestone", title: "Cruachan opened by the Queen (15 Oct)",
    detail: "World's first reversible-pump-turbine pumped storage station at this scale. 36 deaths during construction." },
  { year: 1968, kind: "Accident", title: "January hurricane",
    detail: "Gusts to 118 mph recorded on Tiree and Mull. Massive damage to the grid; rural lines and pylons across the West Highlands flattened." },
  { year: 1974, kind: "Milestone", title: "Foyers re-opens as pumped storage",
    detail: "The original 1896 site is replaced by a 305 MW pumped-storage station using Loch Ness as the lower reservoir." },
  { year: 1990, kind: "Accident", title: "First Scottish Hydro-Electric tunnel collapse",
    detail: "An unlined, unpressurised SHE tunnel collapses in faulted metamorphic rock. Documented by Cameron & Sandilands (ICE, 1996) — a paper that foreshadowed events at Glendoe 19 years later." },
  { year: 1991, kind: "Policy", title: "Privatisation",
    detail: "NoSHEB becomes Scottish Hydro-Electric plc. Floated June 1991. Merges with Southern Electric in 1998 to form SSE." },
  { year: 2001, kind: "Policy", title: "Renewables Obligation",
    detail: "For the first time, hydro stations >10 MW become eligible for renewable incentives. SSE pulls every mothballed NoSHEB scheme off the shelf and reviews them — Glendoe is the only survivor." },
  { year: 2009, kind: "Milestone", title: "Glendoe opened",
    detail: "Queen Elizabeth opens Glendoe in June — first major Scottish hydro in 52 years. 600 m head, single 100 MW Pelton wheel." },
  { year: 2009, kind: "Accident", title: "Glendoe tunnel collapse (4 August)",
    detail: "Eight months after opening, the unlined headrace tunnel collapses near the upper end, blocking 71 m. Operators noted a head reading of 584 m vs designed 600+ m, unusual thumping on 30 June, and a sediment plume on 4 August before realising. Out of service until August 2012. Repairs £130m." },
  { year: 2016, kind: "Policy", title: "Hochtief vs SSE judgment",
    detail: "Lord Woolman rules in Edinburgh that the cause was 'erodible rock' and an operational risk borne by SSE — not contractor negligence." },
  { year: 2018, kind: "Policy", title: "Appeal reverses ruling",
    detail: "Inner House awards SSE £107m+. Hochtief appeals to the UK Supreme Court." },
  { year: 2010, kind: "Engineering", title: "Beauly–Denny consented",
    detail: "After the longest public inquiry in Scottish history, consent given to upgrade the 220 km Highland transmission spine from 132 kV to 400 kV. 615 pylons across contested landscape; the price of unlocking onshore wind." },
  { year: 2020, kind: "Milestone", title: "Coire Glas consented",
    detail: "First UK pumped-storage scheme over 1 GW since the 1980s receives planning consent." },
  { year: 2023, kind: "Milestone", title: "Cruachan II consented",
    detail: "Scottish Government approves Drax's 600 MW expansion of the Hollow Mountain." }
];

// Transmission milestones — how the wires grew
window.TRANSMISSION = [
  {
    year: 1909,
    title: "Aluminium's private grids",
    voltage: "11–33 kV",
    detail: "British Aluminium built its own isolated networks around Foyers, Kinlochleven and (later) Lochaber. Each smelter was an island — no interchange with any neighbour, no public supply.",
    icon: "private"
  },
  {
    year: 1926,
    title: "Lanark joins the National Grid",
    voltage: "132 kV",
    detail: "Central Electricity Board's new 132 kV National Grid reaches the Falls of Clyde. Galloway connects in 1935. Most of the Highlands still has nothing.",
    icon: "grid"
  },
  {
    year: 1947,
    title: "Nationalisation — and the social clause",
    voltage: "—",
    detail: "Electricity Act vests every private supplier into Area Boards. NoSHEB inherits Grampian Electricity's lines, the Galloway network and the lot. Section 1(b) obliges it to keep extending into uneconomic country.",
    icon: "policy"
  },
  {
    year: 1950,
    title: "320 miles of 132 kV in three years",
    voltage: "132 kV",
    detail: "By 1947, NoSHEB has approved 12 schemes AND 320 miles of new 132 kV double-circuit grid. For comparison, the whole of England south of the border had ~3,000 miles of 132 kV already.",
    icon: "grid"
  },
  {
    year: 1955,
    title: "Rural extension — the Hydro Boys",
    voltage: "11 / 33 kV",
    detail: "The wooden-pole 11 kV and 33 kV lines reach into every populated glen. By 1955, 50% of farms and crofts have mains electricity — up from 1 in 14 farms and 1 in 100 crofts in 1948.",
    icon: "rural"
  },
  {
    year: 1965,
    title: "Supergrid — 275 kV reaches Scotland",
    voltage: "275 kV",
    detail: "Hunterston A nuclear (1964), Cockenzie coal (1967) and Cruachan PSH (1965) need bulk transmission. The 275 kV Supergrid is extended north of the Border with stations at Strathaven, Devol Moor and Inverkip.",
    icon: "grid"
  },
  {
    year: 1973,
    title: "400 kV in Scotland",
    voltage: "400 kV",
    detail: "Highest-voltage AC in Britain. Initial Scottish 400 kV corridor links Hunterston, Torness (later), Strathaven and the cross-border interconnector. NoSHEB's territory remains 275 kV / 132 kV for decades.",
    icon: "grid"
  },
  {
    year: 1991,
    title: "Privatisation splits the wires",
    voltage: "—",
    detail: "NoSHEB becomes Scottish Hydro-Electric plc; SSEB splits into ScottishPower (south) and Scottish Nuclear. Transmission is unbundled into separate licensed entities — SHE Transmission and SP Transmission — though physically one synchronous grid.",
    icon: "policy"
  },
  {
    year: 2010,
    title: "Beauly–Denny consented",
    voltage: "400 kV",
    detail: "After a four-year public inquiry — the longest of its kind in Scottish history — consent is granted to upgrade the 220 km Highland spine from 132 kV to 400 kV. Six hundred objections, including from the National Trust for Scotland and the John Muir Trust.",
    icon: "controversy"
  },
  {
    year: 2015,
    title: "Beauly–Denny energised",
    voltage: "400 kV",
    detail: "615 pylons across some of Scotland's most contested landscape. Doubles the export capacity from the Highlands to the central belt — unlocking the wind boom that follows. £820m spend.",
    icon: "grid"
  },
  {
    year: 2018,
    title: "Western HVDC Link",
    voltage: "±600 kV DC",
    detail: "Subsea cable from Hunterston to the Wirral, 2.2 GW capacity, 422 km — the longest HVDC link in the UK at energisation. Bypasses the congested AC interconnector across the border.",
    icon: "hvdc"
  },
  {
    year: 2024,
    title: "Shetland connects",
    voltage: "±320 kV DC",
    detail: "After 50 years of diesel-fired island grids, Shetland is finally joined to the mainland by a 600 MW HVDC cable from Kergord substation to Noss Head. Enables Viking Wind Farm (443 MW) to export south.",
    icon: "hvdc"
  },
  {
    year: 2029,
    title: "Eastern Green Links",
    voltage: "±525 kV DC",
    detail: "EGL1 (Torness → Hawthorn Pit) and EGL2 (Peterhead → Drax) — both 2 GW HVDC subsea links taking offshore wind from north-east Scotland to England's load centres. Under construction. EGL3 and EGL4 in development.",
    icon: "hvdc"
  }
];

// Curious / unique items
window.CURIOSITIES = [
  { title: "The Tunnel Tigers",
    text: "Mostly Irish and Hebridean labourers who blasted the headrace tunnels with hand-held drills and gelignite. Paid up to ten times the wage of a Highland estate labourer. Fights and drinking were endemic. Several Donegal villages — Ranafast, Annagry — sent so many men to Scottish hydro sites that they emptied for the summer." },
  { title: "Architecture as policy",
    text: "Tom Johnston insisted NoSHEB stations be beautiful. Sir Robert Matthew, Harold Tarbolton and Reginald Fairlie designed the dams; turbine halls were white-rendered modernist temples to public power. Almost all are now listed buildings." },
  { title: "The 'social clause'",
    text: "Section 1(b) of the 1943 Act obliged NoSHEB to collaborate with bodies promoting Highland economic development. In practice: uniform tariffs across vast empty country, subsidised by the central belt. A clause of pure socialism, signed off by a Conservative Secretary of State." },
  { title: "Pitlochry fish ladder",
    text: "34 pools and 310 m of climb. Salmon (and the occasional sea trout) ascend it in around 90 minutes. A glass observation chamber lets visitors watch them. A counter in the gate logs every fish — typically 5,000–7,000 per season." },
  { title: "Cruachan as art gallery",
    text: "The visitor centre at Cruachan was originally adorned with a vast Elizabeth Falconer mural depicting the 'Hollow Mountain' workers — a deliberate echo of WPA murals in the US." },
  { title: "Water that generates four times",
    text: "Water falling on the Fannichs can pass through Mossford, Grudie Bridge, Luichart, and Torr Achilty in the Conon scheme before reaching the sea — generating four times in as many hours." },
  { title: "Black start",
    text: "Cruachan and Foyers can both 'black-start' the National Grid — they need no external electricity to begin operating. A handful of stations in Britain can do this, and Scotland is over-represented." },
  { title: "The 1990 dress rehearsal",
    text: "A small Scottish Hydro-Electric tunnel collapsed quietly in 1990 in faulted rock. The same engineer involved — Sandilands — managed the Glendoe build 16 years later. The 1990 paper was dismissed by Lord Woolman as 'irrelevant'." },
  { title: "Net consumer, net useful",
    text: "Cruachan and Foyers are net energy consumers — they use more to pump than they generate. They exist because storing energy is worth more than the round-trip loss; cheap night nuclear once, surplus wind today." },
  { title: "The Hilleary Report",
    text: "Lord Cooper initially called it 'amateurish'. He read it carefully, changed his mind, and his committee produced the report that became the 1943 Act." }
];

// Aluminium-era schemes vs NoSHEB schemes vs modern — used for map coloring
window.ERAS = [
  { id: "pre",     label: "Pre-NoSHEB",     range: [1890, 1942], color: "#b58a4a" },
  { id: "nosheb",  label: "NoSHEB era",     range: [1943, 1989], color: "#5fb4e5" },
  { id: "modern",  label: "Modern / SSE",   range: [1990, 2099], color: "#9a7ad6" }
];
