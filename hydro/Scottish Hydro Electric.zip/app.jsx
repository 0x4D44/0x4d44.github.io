// Main React app
const { useState, useEffect, useRef, useMemo } = React;

const SCHEMES   = window.SCHEMES;
const EVENTS    = window.EVENTS;
const CURIOS    = window.CURIOSITIES;
const ERAS      = window.ERAS;
const TRANSMISSION = window.TRANSMISSION;
const TransmissionTimeline = window.TransmissionTimeline;
const TransmissionDiagram  = window.TransmissionDiagram;

const YEAR_MIN = 1890;
const YEAR_MAX = 2032;

// Util: format MW with thousands sep
const fmt = (n) => {
  if (n == null) return "—";
  if (n < 1) return n.toFixed(2);
  return Math.round(n).toLocaleString();
};

function StatBlock({ n, l, suf }) {
  return (
    <div className="stat">
      <div className="n">{n}{suf && <span style={{ fontSize: '0.45em', marginLeft: 4, color: 'var(--ink-mute)' }}>{suf}</span>}</div>
      <div className="l">{l}</div>
    </div>
  );
}

function HeroDeco() {
  // Decorative contour-style wave SVG
  return (
    <svg className="hero-deco" viewBox="0 0 1200 600" preserveAspectRatio="none">
      <defs>
        <linearGradient id="gradWave" x1="0" x2="0" y1="0" y2="1">
          <stop offset="0%"  stopColor="oklch(0.74 0.10 230)" stopOpacity="0.0" />
          <stop offset="50%" stopColor="oklch(0.74 0.10 230)" stopOpacity="0.5" />
          <stop offset="100%" stopColor="oklch(0.74 0.10 230)" stopOpacity="0.0" />
        </linearGradient>
      </defs>
      {Array.from({ length: 18 }).map((_, i) => {
        const y = 80 + i * 28;
        const path = `M 0 ${y} Q 300 ${y - 18 - (i * 2)} 600 ${y + (i % 3) * 6} T 1200 ${y - i}`;
        return <path key={i} d={path} stroke="url(#gradWave)" strokeWidth="0.6" fill="none" />;
      })}
    </svg>
  );
}

function App() {
  const [year, setYear] = useState(1890);
  const [playing, setPlaying] = useState(false);
  const [selectedId, setSelectedId] = useState('foyers-original');

  // animate playback
  useEffect(() => {
    if (!playing) return;
    const id = setInterval(() => {
      setYear(y => {
        if (y >= YEAR_MAX) { setPlaying(false); return YEAR_MAX; }
        return y + 1;
      });
    }, 220);
    return () => clearInterval(id);
  }, [playing]);

  // When year ticks past a scheme commissioning, auto-select that scheme
  useEffect(() => {
    if (!playing) return;
    const justActivated = SCHEMES.find(s => s.year === year);
    if (justActivated) setSelectedId(justActivated.id);
  }, [year, playing]);

  const selectedScheme = SCHEMES.find(s => s.id === selectedId) || SCHEMES[1];

  // Running totals up to current year
  const tally = useMemo(() => {
    const live = SCHEMES.filter(s => s.year <= year && s.year <= 2025);
    return {
      count: live.length,
      capacity: live.reduce((s, x) => s + (x.capacity_mw || 0), 0)
    };
  }, [year]);

  return (
    <>
      {/* HERO */}
      <header className="hero">
        <HeroDeco />
        <div className="container">
          <div className="hero-grid">
            <div>
              <div className="eyebrow" style={{ marginBottom: 24 }}>
                A history · 1890 → 2030
              </div>
              <h1 className="serif">
                The <em>Hydro</em>:<br/>
                A century of Scottish<br/>water power.
              </h1>
              <div className="hero-stats">
                <StatBlock n="4,000+" l="MW installed today" />
                <StatBlock n="78" l="Major dams" />
                <StatBlock n="54" l="Power stations (1960s)" />
                <StatBlock n="600" l="metres of head at Glendoe" />
              </div>
            </div>
            <div>
              <p className="lede">
                From a Benedictine monastery on Loch Ness, to an aluminium-smelter plumbing job through Ben Nevis, to a 440 MW pumped-storage cavern hollowed out of a mountain — the story of how Scotland turned its rain into electricity.
              </p>
              <p>
                Drag the timeline. Press play. Click a pin on the map. Everything below — the schemes, the schedules, the deaths, the rock falls, the politics — comes from the historical record.
              </p>
            </div>
          </div>
        </div>
      </header>

      {/* MAP SECTION */}
      <section className="section">
        <div className="container">
          <div className="section-head">
            <div>
              <div className="eyebrow">01 · The map</div>
              <h2>Scotland, filling up with turbines.</h2>
            </div>
            <div className="right">
              Each dot is a major scheme, sized by installed capacity. Press play to watch the network grow; click a dot to read the details. Future schemes appear as outlined rings.
            </div>
          </div>

          <div className="map-wrap">
            <div className="map-stage">
              <ScotlandMap
                year={year}
                schemes={SCHEMES}
                selectedId={selectedId}
                onSelect={setSelectedId}
                eras={ERAS}
              />
            </div>

            <div className="map-controls">
              <div>
                <div className="year-counter">YEAR</div>
                <div className="year-display">
                  {year}
                </div>
              </div>

              <div>
                <input type="range" className="scrubber"
                  min={YEAR_MIN} max={YEAR_MAX} step={1}
                  value={year} onChange={e => { setYear(+e.target.value); setPlaying(false); }} />
                <div className="year-counter" style={{ marginTop: 6 }}>
                  {YEAR_MIN} ────────── {YEAR_MAX}
                </div>
              </div>

              <div className="play-row">
                <button className={`btn-play ${playing ? 'paused' : ''}`}
                  onClick={() => {
                    if (year >= YEAR_MAX) setYear(YEAR_MIN);
                    setPlaying(p => !p);
                  }}>
                  {playing ? '❚❚ Pause' : '▶ Play'}
                </button>
                <button className="btn-step" onClick={() => { setYear(YEAR_MIN); setPlaying(false); }}>Reset</button>
                <button className="btn-step" onClick={() => setYear(YEAR_MAX)}>End</button>
              </div>

              <div className="legend">
                {ERAS.map(e => (
                  <div className="row" key={e.id}>
                    <span className="dot" style={{ background: e.color }} />
                    {e.label} ({e.range[0]}–{e.range[1] > 2030 ? 'future' : e.range[1]})
                  </div>
                ))}
                <div className="row">
                  <span className="dot" style={{ background: 'transparent', border: '1.5px dashed #fff' }} />
                  Planned / consented
                </div>
              </div>

              <div className="running-tally">
                <div className="tally">
                  <div className="n">{tally.count}</div>
                  <div className="l">Stations online</div>
                </div>
                <div className="tally">
                  <div className="n">{Math.round(tally.capacity).toLocaleString()}</div>
                  <div className="l">MW capacity</div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* TIMELINE + DETAIL */}
      <section className="section">
        <div className="container">
          <div className="section-head">
            <div>
              <div className="eyebrow">02 · The schemes</div>
              <h2>One hundred and forty years, scheme by scheme.</h2>
            </div>
            <div className="right">
              Each dot below is a commissioned scheme. Hover for the name, click for the full details. Watch the cluster between 1948 and 1965 — what NoSHEB's own historian called the "frenzied years".
            </div>
          </div>

          <Timeline
            schemes={SCHEMES}
            year={year}
            onScrub={setYear}
            onSelect={setSelectedId}
            selectedId={selectedId}
            eras={ERAS}
          />

          <SchemeCard scheme={selectedScheme} />
        </div>
      </section>

      {/* EVENTS / ACCIDENTS */}
      <section className="section">
        <div className="container">
          <div className="section-head">
            <div>
              <div className="eyebrow">03 · Events, politics, accidents</div>
              <h2>The story off the dam wall.</h2>
            </div>
            <div className="right">
              Tunnel collapses, deaths, political battles, Royal openings — colour-coded by kind. The story isn't only the engineering.
            </div>
          </div>

          <div className="events-grid">
            {EVENTS.sort((a, b) => a.year - b.year).map((e, i) => (
              <div key={i} className={`event kind-${e.kind}`}>
                <div className="year-tag">{e.year}</div>
                <div className="kind-tag">{e.kind}</div>
                <h3>{e.title}</h3>
                <p>{e.detail}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* TRANSMISSION */}
      <section className="section">
        <div className="container">
          <div className="section-head">
            <div>
              <div className="eyebrow">04 · The wires</div>
              <h2>How the power got out of the glens.</h2>
            </div>
            <div className="right">
              A turbine is useless without copper. The Scottish transmission story is its own century-long project: from isolated smelter grids in 1909, to a 132 kV state-built spine, to the 400 kV Beauly–Denny corridor, to today's subsea HVDC superhighways carrying offshore wind south.
            </div>
          </div>
          <TransmissionTimeline items={TRANSMISSION} />
          <TransmissionDiagram />
        </div>
      </section>

      {/* CURIOSITIES */}
      <section className="section">
        <div className="container">
          <div className="section-head">
            <div>
              <div className="eyebrow">05 · Things you may not know</div>
              <h2>Anything else interesting.</h2>
            </div>
            <div className="right">
              Tunnel Tigers, the social clause, salmon ladders, an aluminium-driven origin story, and the curious fact that the UK's biggest batteries are wet.
            </div>
          </div>

          <div className="curiosities-grid">
            {CURIOS.map((c, i) => (
              <div key={i} className="curiosity">
                <span className="num">№ {String(i + 1).padStart(2, '0')}</span>
                <h3>{c.title}</h3>
                <p>{c.text}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      <footer>
        <div className="container">
          <div>
            Sources: Drax Heritage, SSE Heritage, Wikipedia (NoSHEB, Cruachan, Glendoe, individual schemes), Peter L. Payne, <em>The Hydro</em> (1988), Rob Cochrane, <em>Power to the People</em> (1985), Hencher's 2019 review of the Glendoe collapse, Cameron &amp; Sandilands ICE 1996, and other public sources.
            <br/><br/>
            Built as a research data-dump. Figures are best public estimates; minor schemes (run-of-river under 5 MW, micro-hydro, etc.) are omitted.
          </div>
        </div>
      </footer>
    </>
  );
}

// Scheme detail card
function SchemeCard({ scheme }) {
  if (!scheme) return null;
  const pct = Math.min(100, (scheme.capacity_mw / 1500) * 100);
  return (
    <div className="scheme-card" data-comment-anchor="scheme-detail">
      <div>
        <div className="scheme-meta">
          {scheme.year} · {scheme.builder} · {scheme.region}
        </div>
        <h3>{scheme.name}</h3>
        <p className="scheme-blurb">{scheme.blurb}</p>

        <div className="facts">
          <ul>
            {scheme.facts.map((f, i) => <li key={i}>{f}</li>)}
          </ul>
        </div>
      </div>

      <div>
        <div className="scheme-specs">
          <div className="spec">
            <div className="v">{fmt(scheme.capacity_mw)}<span style={{ fontFamily: 'var(--mono)', fontSize: 12, marginLeft: 4, color: 'var(--ink-mute)' }}>MW</span></div>
            <div className="l">Installed capacity</div>
            <div className="cap-bar"><span style={{ width: `${pct}%` }}></span></div>
          </div>
          <div className="spec">
            <div className="v">{scheme.head_m ? scheme.head_m : '—'}<span style={{ fontFamily: 'var(--mono)', fontSize: 12, marginLeft: 4, color: 'var(--ink-mute)' }}>m</span></div>
            <div className="l">Hydraulic head</div>
          </div>
          <div className="spec">
            <div className="v" style={{ fontSize: 16, fontFamily: 'var(--mono)', color: 'var(--ink)' }}>{scheme.type}</div>
            <div className="l" style={{ marginTop: 12 }}>Type</div>
          </div>
          <div className="spec">
            <div className="v" style={{ fontSize: 16, fontFamily: 'var(--mono)', color: 'var(--ink)' }}>{scheme.status}</div>
            <div className="l" style={{ marginTop: 12 }}>Status</div>
          </div>
        </div>

        {/* Coordinates */}
        <div style={{ marginTop: 24, fontFamily: 'var(--mono)', fontSize: 11, color: 'var(--ink-dim)', letterSpacing: '0.06em' }}>
          ◉ {scheme.coord[0].toFixed(3)}°N, {Math.abs(scheme.coord[1]).toFixed(3)}°W
        </div>
      </div>
    </div>
  );
}

ReactDOM.createRoot(document.getElementById('root')).render(<App />);
