// Interactive timeline strip
const { useMemo } = React;

function Timeline({ schemes, year, onScrub, onSelect, selectedId, eras }) {
  const min = 1890;
  const max = 2032;
  const span = max - min;

  // Compute jitter for scheme dots so coincident years don't overlap
  const dots = useMemo(() => {
    const byYear = {};
    return schemes.map((s) => {
      const k = s.year;
      byYear[k] = (byYear[k] || 0) + 1;
      // y-offset depending on how many schemes share that year
      const idx = byYear[k] - 1;
      return { ...s, _idx: idx };
    });
  }, [schemes]);

  const eraOf = (y) => {
    if (y < 1943) return eras[0];
    if (y < 1990) return eras[1];
    return eras[2];
  };

  const decadeTicks = [];
  for (let y = 1890; y <= 2030; y += 10) decadeTicks.push(y);

  return (
    <div className="timeline-wrap">
      <div className="timeline-axis">
        {decadeTicks.map(t => (
          <div key={t}
            className={`timeline-tick ${t % 20 === 0 ? 'major' : ''}`}
            style={{ left: `${((t - min) / span) * 100}%` }}>
            {t % 20 === 0 && (
              <div className="timeline-tick-label" style={{ left: 0 }}>{t}</div>
            )}
          </div>
        ))}
        {/* Era bands as faint coloured backgrounds */}
        {eras.map(e => {
          const [a, b] = e.range;
          const left = Math.max(0, ((a - min) / span) * 100);
          const right = Math.min(100, ((Math.min(b, max) - min) / span) * 100);
          return (
            <div key={e.id}
              style={{
                position: 'absolute', top: 0, bottom: 0,
                left: `${left}%`, width: `${right - left}%`,
                background: e.color, opacity: 0.04,
                pointerEvents: 'none'
              }} />
          );
        })}

        {/* Current-year cursor */}
        <div style={{
          position: 'absolute', top: -8, bottom: -8,
          left: `${((year - min) / span) * 100}%`,
          width: 1, background: '#ece5d8', opacity: 0.6
        }} />

        {/* Scheme dots */}
        {dots.map(s => {
          const left = ((s.year - min) / span) * 100;
          const era = eraOf(s.year);
          const active = selectedId === s.id;
          return (
            <div
              key={s.id}
              className={`timeline-dot ${active ? 'active' : ''}`}
              onClick={() => onSelect(s.id)}
              style={{
                left: `${left}%`,
                top: `${50 + (s._idx * 14) - 14}%`,
                background: s.year > 2025 ? 'transparent' : era.color,
                border: s.year > 2025 ? `1.5px dashed ${era.color}` : 'none'
              }}>
              <span className="tt">{s.year} — {s.name}</span>
            </div>
          );
        })}
      </div>
    </div>
  );
}

window.Timeline = Timeline;
