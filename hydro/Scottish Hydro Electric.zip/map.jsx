// Scotland map projection + outline + pin rendering
// Coordinate system: SVG viewBox 0 0 100 125
//   1° latitude  → 29 units of y
//   1° longitude → 16 units of x   (mid-lat correction at ~56.5°N)
//   lat_max = 58.85, lon_min = -7.10

const LAT_MAX = 58.85;
const LON_MIN = -7.10;
const SCALE_LAT = 28.5; // y units per degree latitude
const SCALE_LON = 16;   // x units per degree longitude (cos(56.5°))

function project([lat, lon]) {
  return [
    (lon - LON_MIN) * SCALE_LON,
    (LAT_MAX - lat) * SCALE_LAT
  ];
}

// Mainland Scotland (clockwise from SW) — hand-traced approximation.
const SCOTLAND_OUTLINE = [
  [54.66, -4.95],  // Mull of Galloway
  [54.83, -5.03],  // Luce Bay
  [54.86, -5.20],  //
  [55.00, -5.05],  // Stranraer
  [55.20, -5.45],  // Loch Ryan north
  [55.30, -5.83],  // Mull of Kintyre
  [55.45, -5.80],  // Kintyre west
  [55.60, -5.62],  //
  [55.85, -5.65],  // Tarbert
  [55.90, -5.40],  // Kennacraig area
  [56.05, -5.62],  // Knapdale
  [56.20, -5.55],  // Crinan
  [56.40, -5.75],  // Loch Linnhe mouth (Lismore approx)
  [56.55, -5.95],  //
  [56.65, -6.10],  // Morvern
  [56.73, -6.21],  // Ardnamurchan Point
  [56.85, -6.05],  //
  [57.00, -5.83],  // Sound of Arisaig
  [57.10, -5.95],  // Mallaig
  [57.30, -5.70],  // Glenelg
  [57.40, -5.85],  // Loch Alsh
  [57.60, -5.55],  // Applecross peninsula
  [57.75, -5.80],  // Loch Torridon
  [57.85, -5.45],  // Gairloch
  [57.95, -5.50],  // Loch Ewe
  [58.05, -5.35],  // Ullapool
  [58.15, -5.20],  //
  [58.30, -5.10],  // Assynt
  [58.42, -5.05],  //
  [58.55, -5.05],  // Kinlochbervie
  [58.62, -5.00],  // Cape Wrath
  [58.65, -4.65],  //
  [58.55, -4.45],  // Loch Eriboll mouth
  [58.55, -4.20],  //
  [58.57, -4.05],  // Strathy Point
  [58.63, -3.60],  // Dunnet Bay
  [58.67, -3.30],  // Dunnet Head
  [58.62, -3.07],  // Duncansby Head / John o' Groats
  [58.44, -3.10],  // Wick
  [58.27, -3.27],  // Lybster
  [58.12, -3.65],  // Helmsdale
  [57.95, -3.85],  //
  [57.88, -3.78],  // Tarbat Ness
  [57.70, -3.78],  // Cromarty Firth mouth
  [57.66, -3.45],  // Buckie / Spey Bay
  [57.70, -2.95],  // Banff
  [57.66, -2.20],  // Fraserburgh / Buchan Ness
  [57.50, -1.78],  // Peterhead
  [57.30, -1.95],  //
  [57.15, -2.10],  // Aberdeen
  [56.96, -2.21],  // Stonehaven
  [56.75, -2.40],  //
  [56.71, -2.47],  // Montrose
  [56.55, -2.65],  // Arbroath
  [56.46, -2.97],  // Dundee / Tay
  [56.34, -2.79],  // St Andrews
  [56.28, -2.58],  // Fife Ness
  [56.18, -2.65],  //
  [56.03, -3.10],  // Edinburgh approach
  [55.95, -3.19],  // Edinburgh
  [55.97, -2.55],  // Dunbar
  [55.95, -2.30],  // St Abbs
  [55.77, -2.00],  // Berwick
  [55.55, -2.10],  // Cheviot border
  [55.10, -3.05],  // Gretna / Solway
  [54.97, -3.40],  // Annan
  [54.86, -3.85],  // Dumfries Solway
  [54.82, -4.05],  // Kirkcudbright
  [54.70, -4.65],  // Wigtown
  [54.66, -4.85]   // close
];

// Wee islands / hints, drawn as soft polygons
const HEBRIDES_HINTS = [
  // Lewis & Harris (very rough)
  [[58.20, -6.30], [58.50, -6.40], [58.50, -6.80], [58.10, -7.05], [57.90, -6.95], [57.85, -6.70], [58.00, -6.40]],
  // Skye (rough)
  [[57.42, -5.85], [57.60, -6.10], [57.65, -6.40], [57.40, -6.65], [57.20, -6.50], [57.20, -6.10]],
  // Mull (rough)
  [[56.50, -5.75], [56.65, -5.95], [56.65, -6.30], [56.40, -6.30], [56.30, -5.95]],
  // Orkney (rough)
  [[58.90, -3.30], [59.10, -3.00], [59.00, -2.60], [58.85, -2.80]],
  // Islay (rough)
  [[55.85, -6.05], [55.95, -6.40], [55.75, -6.50], [55.65, -6.25], [55.70, -6.05]]
];

function pathFromOutline(pts) {
  return pts.map((p, i) => {
    const [x, y] = project(p);
    return `${i === 0 ? 'M' : 'L'} ${x.toFixed(2)} ${y.toFixed(2)}`;
  }).join(' ') + ' Z';
}

const SCOTLAND_PATH = pathFromOutline(SCOTLAND_OUTLINE);
const HEBRIDES_PATHS = HEBRIDES_HINTS.map(pathFromOutline);

// Major lochs to suggest the geography (drawn as elongated blobs / lines)
// Approximated as poly-lines projected and drawn with stroke.
const LOCHS = [
  { name: 'Loch Ness',   pts: [[57.10, -4.74], [57.30, -4.45]] },
  { name: 'Loch Lomond', pts: [[56.05, -4.65], [56.30, -4.62]] },
  { name: 'Loch Awe',    pts: [[56.27, -5.30], [56.45, -5.05]] },
  { name: 'Loch Tay',    pts: [[56.50, -4.30], [56.55, -3.97]] },
  { name: 'Loch Linnhe', pts: [[56.45, -5.50], [56.70, -5.10]] },
  { name: 'Loch Shin',   pts: [[57.95, -4.55], [58.15, -4.42]] },
  { name: 'Loch Ericht', pts: [[56.75, -4.45], [56.90, -4.30]] },
  { name: 'Loch Mullardoch', pts: [[57.36, -5.00], [57.40, -4.78]] },
  { name: 'Loch Lochy',  pts: [[56.93, -4.92], [57.05, -4.80]] }
];

// Tom Johnston quote: small text on the map
function ScotlandMap({ year, schemes, selectedId, onSelect, eras }) {
  // Group schemes by their visibility window (year cutoff)
  const visible = schemes.filter(s => s.year <= year);

  const eraOf = (y) => {
    if (y < 1943) return eras[0];
    if (y < 1990) return eras[1];
    return eras[2];
  };

  return (
    <svg viewBox="0 0 100 125" preserveAspectRatio="xMidYMid meet">
      <defs>
        <filter id="pin-glow" x="-50%" y="-50%" width="200%" height="200%">
          <feGaussianBlur stdDeviation="0.8" />
        </filter>
        <radialGradient id="pin-grad" cx="0.5" cy="0.5" r="0.5">
          <stop offset="0%" stopColor="#fff" stopOpacity="0.9" />
          <stop offset="100%" stopColor="#fff" stopOpacity="0" />
        </radialGradient>
      </defs>

      {/* Grid lines (degrees of latitude as faint horizontal references) */}
      {[55, 56, 57, 58].map(lat => (
        <line key={'lat' + lat}
          x1={0} x2={100}
          y1={(LAT_MAX - lat) * SCALE_LAT}
          y2={(LAT_MAX - lat) * SCALE_LAT}
          className="grid-line" />
      ))}
      {[-6, -4, -2].map(lon => (
        <line key={'lon' + lon}
          x1={(lon - LON_MIN) * SCALE_LON}
          x2={(lon - LON_MIN) * SCALE_LON}
          y1={0} y2={125}
          className="grid-line" />
      ))}

      {/* Mainland fill */}
      <path d={SCOTLAND_PATH} className="scotland-fill" />
      {/* Outline (separate so it can be stroked over fill) */}
      <path d={SCOTLAND_PATH} className="scotland-outline" />

      {/* Islands as hints */}
      {HEBRIDES_PATHS.map((d, i) => (
        <g key={'isle' + i}>
          <path d={d} className="scotland-fill" />
          <path d={d} className="scotland-outline" />
        </g>
      ))}

      {/* Lochs */}
      {LOCHS.map((l, i) => {
        const [a, b] = l.pts.map(project);
        return (
          <line key={'loch' + i}
            x1={a[0]} y1={a[1]} x2={b[0]} y2={b[1]}
            stroke="oklch(0.55 0.08 230)"
            strokeWidth="0.9"
            strokeLinecap="round"
            opacity="0.6" />
        );
      })}

      {/* Grid degree labels */}
      <text x="1" y="3" className="pin-label" fill="#5e6166">58°N</text>
      <text x="1" y={(LAT_MAX - 57) * SCALE_LAT - 0.5} className="pin-label" fill="#5e6166">57°N</text>
      <text x="1" y={(LAT_MAX - 56) * SCALE_LAT - 0.5} className="pin-label" fill="#5e6166">56°N</text>
      <text x="1" y={(LAT_MAX - 55) * SCALE_LAT - 0.5} className="pin-label" fill="#5e6166">55°N</text>

      {/* Scheme pins */}
      {schemes.map(s => {
        const [x, y] = project(s.coord);
        const isVisible = s.year <= year;
        const isFuture  = s.year > 2025;
        const era = eraOf(s.year);
        const active = selectedId === s.id;
        // Size pin by capacity (sqrt scaling)
        const r = Math.max(0.8, Math.min(3.6, Math.sqrt(Math.max(s.capacity_mw, 1)) * 0.18));
        return (
          <g key={s.id}
             style={{ opacity: isVisible ? 1 : 0 }}
             onClick={() => onSelect(s.id)}>
            {/* glow */}
            {(active || s.year === year) && (
              <circle cx={x} cy={y} r={r * 2.2} fill={era.color} opacity="0.3">
                <animate attributeName="r" from={r * 1.8} to={r * 3.6} dur="1.6s" repeatCount="indefinite" />
                <animate attributeName="opacity" from="0.5" to="0" dur="1.6s" repeatCount="indefinite" />
              </circle>
            )}
            <circle cx={x} cy={y} r={r}
              className="pin"
              fill={isFuture ? 'none' : era.color}
              stroke={era.color}
              strokeWidth={isFuture ? 0.5 : 0}
              strokeDasharray={isFuture ? "0.6 0.6" : null}
            />
            {/* label, shown for active */}
            {active && (
              <text x={x + r + 1.5} y={y + 0.8}
                className="pin-label active"
                style={{ fontSize: '2.2px' }}>
                {s.name}
              </text>
            )}
          </g>
        );
      })}

      {/* Tom Johnston quote — only after 1943 */}
      {year >= 1943 && (
        <g style={{ transition: 'opacity 800ms' }} opacity={year >= 1943 ? 1 : 0}>
          <text x="50" y="120" textAnchor="middle"
            style={{ fontFamily: 'var(--serif)', fontStyle: 'italic', fontSize: '2.4px', fill: 'var(--ink-mute)' }}>
            "Let light and power come to the crofts."
          </text>
          <text x="50" y="123" textAnchor="middle"
            style={{ fontFamily: 'var(--mono)', fontSize: '1.8px', fill: 'var(--ink-dim)', letterSpacing: '0.15em' }}>
            — CATHERINE MACKENZIE, MORAR, 1948
          </text>
        </g>
      )}
    </svg>
  );
}

window.ScotlandMap = ScotlandMap;
