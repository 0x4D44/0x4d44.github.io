/* eslint-disable */
// readex — why + how it works

const Why = () => {
  const problems = [
    {
      title: "The chrome problem",
      body: "Real pages aren't articles — they're articles wrapped in nav, share widgets, cookie banners, related-content rails, and comments. Most extractors strip some of that. readex strips all of it, by design.",
      tag: "boilerplate",
    },
    {
      title: "The long-tail problem",
      body: "SEC filings, regulator publications, multilingual news, low-template blogs, hub/index pages — these defeat single-algorithm extractors. The cascade was designed exactly for that tail.",
      tag: "edge cases",
    },
    {
      title: "The parity problem",
      body: "If you port an algorithm, you have to prove you ported it. readex is gated by a differential harness that runs every release against Mozilla Readability (Node) and Trafilatura (Python).",
      tag: "trust",
    },
    {
      title: "The dependency problem",
      body: "Four runtime dependencies. Every one pinned to an exact version, with a documented “parser-equivalence fence” so an html5ever bump can’t silently shift DOM semantics under you.",
      tag: "embeddability",
    },
  ];

  return (
    <section id="why" className="section">
      <div className="shell">
        <SectionHeader
          eyebrow="02 · why it exists"
          title={<>One crate. <em style={{ fontStyle: "italic", color: "var(--accent)" }}>Three</em> well-validated algorithms.</>}
          lede="There are already half a dozen HTML extractors on crates.io. readex exists because the interesting failures live in the long tail — and because porting an algorithm without proving it doesn't really count."
        />

        <div style={{ display: "grid", gridTemplateColumns: "repeat(2, 1fr)", gap: 1, background: "var(--rule)", border: "1px solid var(--rule)", borderRadius: 10, overflow: "hidden" }} className="prob-grid">
          {problems.map((p) => (
            <div key={p.title} style={{ background: "var(--bg)", padding: "28px 28px 32px" }}>
              <div style={{
                fontFamily: "var(--mono)", fontSize: 11, color: "var(--ink-3)",
                letterSpacing: "0.08em", textTransform: "uppercase",
              }}>{p.tag}</div>
              <h3 style={{ fontFamily: "var(--serif)", fontWeight: 400, fontSize: 28, marginTop: 8, lineHeight: 1.1 }}>{p.title}</h3>
              <p style={{ marginTop: 14, color: "var(--ink-2)", fontSize: 15, lineHeight: 1.6, textWrap: "pretty" }}>{p.body}</p>
            </div>
          ))}
        </div>

        {/* comparison table */}
        <div style={{ marginTop: 64 }}>
          <div className="eyebrow" style={{ marginBottom: 18 }}>vs. the obvious alternatives</div>
          <ComparisonTable />
        </div>
      </div>
    </section>
  );
};

const ComparisonTable = () => {
  const rows = [
    ["algorithms",       ["Readability + Trafilatura + htmldate", "Readability only", "DOM-centric (different family)"]],
    ["metadata fields",  ["~15 fields", "title + summary", "body text only"]],
    ["output formats",   ["text · HTML · Markdown · TXT · JSON · CSV · XML · TEI", "text only", "text only"]],
    ["differential tests", ["51-URL + 50k broad sweep", "—", "—"]],
    ["parser pin",       ["exact — html5ever 0.39.0", "—", "—"]],
    ["date extraction",  ["yes (htmldate port)", "—", "—"]],
    ["comments",         ["yes (Reddit / vBulletin / …)", "—", "—"]],
    ["edition · MSRV",   ["2024 · 1.85", "2018 · older", "2021 · older"]],
  ];
  const heads = ["", "readex", "readability", "dom_content_extraction"];

  return (
    <div style={{ overflowX: "auto", border: "1px solid var(--rule)", borderRadius: 10 }}>
      <table style={{ width: "100%", borderCollapse: "collapse", fontSize: 13 }}>
        <thead>
          <tr>
            {heads.map((h, i) => (
              <th key={i} style={{
                textAlign: "left", padding: "14px 18px",
                borderBottom: "1px solid var(--rule)",
                fontFamily: "var(--mono)", fontSize: 11, fontWeight: 500,
                color: i === 1 ? "var(--accent-2)" : "var(--ink-3)",
                textTransform: "uppercase", letterSpacing: "0.08em",
                background: i === 1 ? "var(--accent-soft)" : "var(--bg-2)",
              }}>{h}</th>
            ))}
          </tr>
        </thead>
        <tbody>
          {rows.map((row, ri) => (
            <tr key={ri}>
              <td style={{
                padding: "14px 18px",
                fontFamily: "var(--mono)", fontSize: 12, color: "var(--ink-3)",
                borderBottom: "1px solid var(--rule)",
                background: "var(--bg-2)",
                width: 160,
              }}>{row[0]}</td>
              {row[1].map((v, vi) => (
                <td key={vi} style={{
                  padding: "14px 18px",
                  borderBottom: "1px solid var(--rule)",
                  borderLeft: "1px solid var(--rule)",
                  color: vi === 0 ? "var(--ink)" : "var(--ink-3)",
                  background: vi === 0 ? "color-mix(in oklch, var(--accent-soft) 30%, transparent)" : "transparent",
                  fontFamily: vi === 0 ? "var(--sans)" : "var(--mono)",
                  fontSize: vi === 0 ? 13 : 12,
                  fontWeight: vi === 0 ? 500 : 400,
                  width: "27%",
                }}>{v}</td>
              ))}
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
};

Object.assign(window, { Why });
