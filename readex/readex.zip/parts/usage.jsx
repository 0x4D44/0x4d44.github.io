/* eslint-disable */
// readex — usage & code examples

const USAGE_TABS = [
  {
    id: "default",
    label: "extract",
    sig: "extract(html, base_url?) → Result<Extracted>",
    blurb: "The one you'll reach for first. Defaults to the full Trafilatura cascade, returns every metadata field readex can recover.",
    code: `use readex::{extract, Extracted};

let html  = std::fs::read_to_string("page.html")?;
let base  = Some("https://example.com/news/bridge");

let Extracted { title, byline, text, language, published_time, .. } =
    extract(&html, base)?;

println!("title:  {}", title.as_deref().unwrap_or("—"));
println!("byline: {}", byline.as_deref().unwrap_or("—"));
println!("words:  {}", text.split_whitespace().count());`,
  },
  {
    id: "options",
    label: "extract_with",
    sig: "extract_with(html, base_url?, &Options)",
    blurb: "Same engine, configurable knobs. Opt into sanitised HTML, set a minimum word-count threshold, or request a YAML metadata header.",
    code: `use readex::{extract_with, Options};

let opts = Options {
    include_sanitised_html: true,
    min_word_count: 80,
    emit_yaml_header: true,
    ..Options::default()
};

let result = extract_with(&html, None, &opts)?;

// extract(html, base) == extract_with(html, base, &Options::default())
// — that invariant is pinned by a unit test, not parallel maintenance.`,
  },
  {
    id: "markdown",
    label: "→ markdown",
    sig: "extract_to_markdown(html, base_url?)",
    blurb: "Body rendered as Markdown — Trafilatura's output_format=\"markdown\". Headings, lists, blockquotes, code, links, images, footnotes.",
    code: `use readex::extract_to_markdown;

let md = extract_to_markdown(&html, None)?;
std::fs::write("article.md", md)?;

// for a YAML front-matter header, use extract_with with
// Options { emit_yaml_header: true, .. } and the markdown sink.`,
  },
  {
    id: "txt",
    label: "→ txt",
    sig: "extract_to_txt(html, base_url?)",
    blurb: "Plain-text body. Trafilatura's output_format=\"txt\" — no structural markup, just the words.",
    code: `use readex::extract_to_txt;

let plain = extract_to_txt(&html, None)?;
// 1 paragraph per blank-line-separated block.`,
  },
  {
    id: "structured",
    label: "→ json · xml · tei",
    sig: "extract_to_{json,csv,xml,tei}",
    blurb: "Structured output for downstream pipelines. TEI is the only one with 51/51 parity against upstream Trafilatura on the locked corpus.",
    code: `use readex::{extract_to_json, extract_to_tei};

let j = extract_to_json(&html, None)?;     // serde_json::Value
let t = extract_to_tei(&html, None)?;      // <TEI>…</TEI> string

// also: extract_to_csv, extract_to_xml.`,
  },
  {
    id: "rdy",
    label: "extract_via_readability",
    sig: "extract_via_readability(html, base_url?)",
    blurb: "Forces the M2 Mozilla-Readability path — older, simpler, no cascade. Useful when you specifically need Readability.js's output shape.",
    code: `use readex::extract_via_readability;

// Bypasses the cascade. Returns the same Extracted shape but with
// only Readability's flag-sieve scoring driving the body selection.
let r = extract_via_readability(&html, None)?;`,
  },
];

const Usage = () => {
  const [tab, setTab] = React.useState("default");
  const cur = USAGE_TABS.find((t) => t.id === tab);
  return (
    <section id="use" className="section">
      <div className="shell">
        <SectionHeader
          eyebrow="04 · how you use it"
          title="A small, careful surface."
          lede="Six public entry points. One Options struct. extract == extract_with(&Options::default()) — guaranteed by construction, not by parallel maintenance."
        />

        {/* install */}
        <div className="card sunk" style={{ padding: "20px 24px", marginBottom: 32 }}>
          <div className="eyebrow" style={{ marginBottom: 10 }}>install</div>
          <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 16 }} className="install-grid">
            <pre className="code" style={{ background: "var(--ink)", margin: 0 }}>{`# Cargo.toml
[dependencies]
readex = "0.19"`}</pre>
            <pre className="code" style={{ background: "var(--ink)", margin: 0 }}>{`# or
$ cargo add readex@0.19`}</pre>
          </div>
        </div>

        {/* tabs */}
        <div style={{
          display: "flex", flexWrap: "wrap", gap: 0,
          borderBottom: "1px solid var(--rule)", marginBottom: 0,
        }}>
          {USAGE_TABS.map((t) => (
            <button
              key={t.id}
              onClick={() => setTab(t.id)}
              style={{
                background: "transparent",
                border: "none",
                borderBottom: "2px solid " + (tab === t.id ? "var(--accent)" : "transparent"),
                padding: "12px 18px",
                fontFamily: "var(--mono)",
                fontSize: 13,
                color: tab === t.id ? "var(--ink)" : "var(--ink-3)",
                cursor: "pointer",
                marginBottom: -1,
              }}
            >{t.label}</button>
          ))}
        </div>

        <div style={{ display: "grid", gridTemplateColumns: "1fr 1.4fr", gap: 28, marginTop: 32 }} className="use-grid">
          <div>
            <div style={{ fontFamily: "var(--mono)", fontSize: 11, color: "var(--ink-3)", textTransform: "uppercase", letterSpacing: "0.08em" }}>
              signature
            </div>
            <code style={{
              display: "block", marginTop: 8, padding: "12px 14px",
              background: "var(--bg-2)", border: "1px solid var(--rule)",
              borderRadius: 6, fontSize: 13, color: "var(--accent-2)", lineHeight: 1.5,
            }}>{cur.sig}</code>
            <p style={{ marginTop: 22, color: "var(--ink-2)", fontSize: 15, lineHeight: 1.6, textWrap: "pretty" }}>
              {cur.blurb}
            </p>
          </div>
          <RustCode>{cur.code}</RustCode>
        </div>

        {/* Extracted struct shape */}
        <div style={{ marginTop: 96 }}>
          <Eyebrow>the Extracted struct</Eyebrow>
          <h3 style={{
            fontFamily: "var(--serif)", fontWeight: 400, fontSize: 36, marginTop: 12,
            letterSpacing: "-0.02em",
          }}>~15 fields, all populated when the page makes them recoverable.</h3>
          <ExtractedFields />
        </div>
      </div>
    </section>
  );
};

const FIELDS = [
  { name: "title",            ty: "Option<String>",    note: "from <title>, <h1>, or og:title precedence" },
  { name: "byline",           ty: "Option<String>",    note: "author meta, itemprop, JSON-LD, or class hints" },
  { name: "text",             ty: "String",            note: "body — cascade winner after dedup + sanitize" },
  { name: "excerpt",          ty: "Option<String>",    note: "meta description or first ~180 chars" },
  { name: "site_name",        ty: "Option<String>",    note: "og:site_name" },
  { name: "language",         ty: "Option<String>",    note: "<html lang> or content-language" },
  { name: "published_time",   ty: "Option<DateTime>",  note: "htmldate precedence — meta, JSON-LD, URL, body" },
  { name: "modified_time",    ty: "Option<DateTime>",  note: "article:modified_time or itemprop" },
  { name: "categories",       ty: "Vec<String>",       note: "JSON-LD or article:section" },
  { name: "tags",             ty: "Vec<String>",       note: "article:tag, meta keywords, rel=tag" },
  { name: "image",            ty: "Option<String>",    note: "og:image, twitter:image, JSON-LD image" },
  { name: "license",          ty: "Option<String>",    note: "rel=license or meta" },
  { name: "canonical_url",    ty: "Option<String>",    note: "rel=canonical" },
  { name: "hostname",         ty: "Option<String>",    note: "from base_url" },
  { name: "word_count",       ty: "usize",             note: "the library's own count — see docs" },
  { name: "comments",         ty: "String",            note: "Reddit / vBulletin / Disqus-class" },
  { name: "sanitised_html",   ty: "Option<String>",    note: "with Options::include_sanitised_html" },
];

const ExtractedFields = () => (
  <div style={{ marginTop: 24, border: "1px solid var(--rule)", borderRadius: 10, overflow: "hidden" }}>
    <div style={{
      padding: "10px 16px",
      background: "var(--bg-2)", borderBottom: "1px solid var(--rule)",
      fontFamily: "var(--mono)", fontSize: 12, color: "var(--ink-3)",
    }}>pub struct Extracted</div>
    <div style={{ background: "var(--bg)" }}>
      {FIELDS.map((f, i) => (
        <div key={f.name} style={{
          display: "grid",
          gridTemplateColumns: "200px 200px 1fr",
          gap: 16, padding: "10px 16px",
          borderTop: i === 0 ? "none" : "1px solid var(--rule)",
          fontFamily: "var(--mono)", fontSize: 13,
          alignItems: "baseline",
        }}>
          <span style={{ color: "var(--ink)" }}>{f.name}</span>
          <span style={{ color: "var(--accent-2)" }}>{f.ty}</span>
          <span style={{ color: "var(--ink-3)", fontFamily: "var(--sans)", fontSize: 13 }}>{f.note}</span>
        </div>
      ))}
    </div>
  </div>
);

Object.assign(window, { Usage });
