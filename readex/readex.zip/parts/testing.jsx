/* eslint-disable */
// readex — testing & community

const GATES = [
  { name: "Trafilatura · Markdown",        corpus: "51 URLs",  pass: 48, total: 51, note: "41 substantive + 7 allowlist", color: "oklch(60% 0.16 50)" },
  { name: "Trafilatura · TXT",             corpus: "51 URLs",  pass: 45, total: 51, note: "45 substantive + 5 allowlist + 1 deferred", color: "oklch(60% 0.16 50)" },
  { name: "Trafilatura · TEI",             corpus: "51 URLs",  pass: 51, total: 51, note: "39 substantive + 12 allowlist", color: "oklch(60% 0.16 50)" },
  { name: "Mozilla Readability · textContent", corpus: "51 URLs", pass: 50, total: 51, note: "byte-equivalent vs. jsdom", color: "oklch(60% 0.13 320)" },
  { name: "Parser equivalence · rcdom vs jsdom", corpus: "51 URLs", pass: 51, total: 51, note: "byte-equivalent DOM", color: "oklch(60% 0.13 240)" },
];

const Counter = ({ to, suffix }) => {
  const [n, setN] = React.useState(0);
  const ref = React.useRef(null);
  React.useEffect(() => {
    if (!ref.current) return;
    const io = new IntersectionObserver((entries) => {
      if (entries[0].isIntersecting) {
        const start = performance.now();
        const dur = 1200;
        const animate = (t) => {
          const p = Math.min(1, (t - start) / dur);
          const eased = 1 - Math.pow(1 - p, 3);
          setN(Math.round(eased * to));
          if (p < 1) requestAnimationFrame(animate);
        };
        requestAnimationFrame(animate);
        io.disconnect();
      }
    }, { threshold: 0.4 });
    io.observe(ref.current);
    return () => io.disconnect();
  }, [to]);
  return <span ref={ref}>{n.toLocaleString()}{suffix || ""}</span>;
};

const Testing = () => {
  return (
    <section id="testing" className="section" style={{ background: "var(--ink)", color: "var(--bg)" }}>
      <style>{`
        #testing .eyebrow { color: oklch(80% 0.02 70); }
        #testing .eyebrow::before { background: var(--accent); }
        #testing .section-title, #testing .section-lede, #testing h3, #testing a { color: var(--bg); }
        #testing .section-lede { color: oklch(85% 0.01 70); }
        #testing .card { background: oklch(22% 0.012 60); border-color: oklch(30% 0.015 60); }
        #testing .rule { background: oklch(30% 0.015 60); }
      `}</style>
      <div className="shell">
        <SectionHeader
          eyebrow="05 · how it's tested"
          title="Differential, not aspirational."
          lede="Every release runs every benchmark URL through readex, Mozilla Readability (via Node), and Trafilatura (via Python) in parallel — and scores agreement across token sequences and metadata fields."
        />

        {/* big numbers */}
        <div style={{ display: "grid", gridTemplateColumns: "repeat(4, 1fr)", gap: 0, marginBottom: 64, borderTop: "1px solid oklch(30% 0.015 60)", borderBottom: "1px solid oklch(30% 0.015 60)" }} className="stats-grid">
          <BigStat label="benchmark URLs" value={<Counter to={51} />} sub="locked corpus · committed in repo" />
          <BigStat label="broad sweep" value={<><Counter to={50} suffix="K" /></>} sub="Common Crawl pages per release" />
          <BigStat label="oracles" value={<Counter to={3} />} sub="readex · Readability (JS) · Trafilatura (Py)" />
          <BigStat label="runtime deps" value={<Counter to={4} />} sub="all pinned exactly" />
        </div>

        {/* parity gates */}
        <div style={{ marginBottom: 56 }}>
          <h3 style={{ fontFamily: "var(--serif)", fontWeight: 400, fontSize: 32, letterSpacing: "-0.02em" }}>
            Parity verdicts <span style={{ color: "var(--accent)", fontFamily: "var(--mono)", fontSize: 14, verticalAlign: "middle" }}>· as of 0.19.0</span>
          </h3>

          <div style={{ marginTop: 28, display: "flex", flexDirection: "column", gap: 12 }}>
            {GATES.map((g, i) => {
              const pct = (g.pass / g.total) * 100;
              return (
                <div key={g.name} className="card" style={{ padding: "18px 22px" }}>
                  <div style={{ display: "grid", gridTemplateColumns: "1.4fr auto 1.6fr auto", gap: 18, alignItems: "center" }} className="gate-row">
                    <div>
                      <div style={{ fontSize: 15 }}>{g.name}</div>
                      <div style={{ fontFamily: "var(--mono)", fontSize: 11, color: "oklch(70% 0.015 70)", marginTop: 4 }}>
                        {g.corpus}
                      </div>
                    </div>
                    <div style={{ fontFamily: "var(--mono)", fontSize: 22, color: "var(--bg)", whiteSpace: "nowrap" }}>
                      <span style={{ color: g.color }}>{g.pass}</span>
                      <span style={{ opacity: 0.5, margin: "0 4px" }}>/</span>
                      <span>{g.total}</span>
                    </div>
                    <div style={{
                      height: 6, background: "oklch(28% 0.015 60)", borderRadius: 999, overflow: "hidden",
                    }}>
                      <div style={{
                        height: "100%",
                        width: pct + "%",
                        background: g.color,
                        borderRadius: 999,
                        transition: "width 800ms ease " + (i * 100) + "ms",
                      }} />
                    </div>
                    <div style={{ fontFamily: "var(--mono)", fontSize: 11, color: "oklch(72% 0.02 70)", textAlign: "right" }}>
                      {g.note}
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        </div>

        {/* the doctrine */}
        <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 24 }} className="doc-grid">
          <Doctrine
            tag="ALLOWLIST"
            title="Documented divergences."
            body="When readex and an upstream genuinely disagree, the page goes on an allowlist with one Markdown file per fixture under wrk_docs/m{5,7}-allowlist/ explaining exactly why."
          />
          <Doctrine
            tag="PARSER FENCE"
            title="html5ever is pinned hard."
            body="html5ever, markup5ever_rcdom, tendril, web_atoms — all = (exact) version pins. Any bump must re-run the parser-equivalence BLOCKER gate before it lands."
          />
          <Doctrine
            tag="BASELINE"
            title="One declared host. One committed file."
            body="Native libxml2/ICU can't be byte-pinned across machines. The committed baseline is valid only on the declared reproducibility host; everywhere else, runs are advisory."
          />
          <Doctrine
            tag="BUG-E2"
            title="“Found little” is success."
            body="An honestly-empty extraction is a valid Ok with empty text — never an error and never NotImplemented. The public extract contract is byte-stable on that boundary."
          />
        </div>
      </div>
    </section>
  );
};

const BigStat = ({ label, value, sub }) => (
  <div style={{
    padding: "32px 28px",
    borderLeft: "1px solid oklch(30% 0.015 60)",
  }}>
    <div style={{
      fontFamily: "var(--mono)", fontSize: 11, color: "oklch(72% 0.02 70)",
      letterSpacing: "0.08em", textTransform: "uppercase",
    }}>{label}</div>
    <div style={{
      fontFamily: "var(--serif)", fontSize: 64, lineHeight: 1, marginTop: 14,
      letterSpacing: "-0.02em", color: "var(--bg)",
    }}>{value}</div>
    <div style={{
      marginTop: 14, fontFamily: "var(--mono)", fontSize: 11,
      color: "oklch(70% 0.02 70)",
    }}>{sub}</div>
  </div>
);

const Doctrine = ({ tag, title, body }) => (
  <div className="card" style={{ padding: "24px 26px" }}>
    <div style={{ fontFamily: "var(--mono)", fontSize: 11, color: "var(--accent)", letterSpacing: "0.08em" }}>{tag}</div>
    <h4 style={{ fontFamily: "var(--serif)", fontWeight: 400, fontSize: 22, marginTop: 8, lineHeight: 1.15 }}>{title}</h4>
    <p style={{ marginTop: 12, fontSize: 14, lineHeight: 1.6, color: "oklch(82% 0.012 70)" }}>{body}</p>
  </div>
);

Object.assign(window, { Testing });
