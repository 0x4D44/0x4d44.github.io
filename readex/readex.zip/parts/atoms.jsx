/* eslint-disable */
// readex — shared small components

const Brand = () => (
  <a className="brand" href="#top">
    <div className="brand-mark">r</div>
    <span className="brand-name"><b>readex</b></span>
    <span className="brand-version">v0.19.2</span>
  </a>
);

const Nav = () => (
  <nav className="nav">
    <div className="nav-inner">
      <Brand />
      <div className="nav-links">
        <a href="#demo">demo</a>
        <a href="#why">why</a>
        <a href="#how">how it works</a>
        <a href="#use">use</a>
        <a href="#testing">testing</a>
        <a href="#lineage">lineage</a>
      </div>
    </div>
  </nav>
);

const Eyebrow = ({ children }) => (
  <div className="eyebrow">{children}</div>
);

const Chip = ({ children, tone }) => (
  <span className={"chip " + (tone || "")}><span className="dot" />{children}</span>
);

// minimal Rust syntax highlighter via regex — good enough for marketing snippets
function highlightRust(src) {
  const escape = (s) => s.replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;");
  let s = escape(src);
  // comments
  s = s.replace(/(\/\/[^\n]*)/g, '<span class="com">$1</span>');
  // strings (incl. raw r#"..."#)
  s = s.replace(/(r#?&quot;[\s\S]*?&quot;#?|&quot;[^&]*?&quot;)/g, '<span class="str">$1</span>');
  // attributes #[...]
  s = s.replace(/(#\[[^\]]+\])/g, '<span class="pp">$1</span>');
  // keywords
  const kws = ["use","let","fn","pub","mut","const","struct","enum","impl","trait","match","if","else","for","in","loop","while","return","mod","as","Some","None","Ok","Err","true","false","crate","self","Self","ref","where","async","await","move"];
  s = s.replace(new RegExp("\\b(" + kws.join("|") + ")\\b", "g"), '<span class="kw">$1</span>');
  // numbers
  s = s.replace(/\b(\d+(?:\.\d+)?)\b/g, '<span class="num">$1</span>');
  // types — TitleCased identifiers
  s = s.replace(/\b([A-Z][a-zA-Z0-9_]*)\b/g, '<span class="ty">$1</span>');
  // function calls
  s = s.replace(/\b([a-z_][a-zA-Z0-9_]*)(?=\s*\()/g, '<span class="fn">$1</span>');
  return s;
}

const RustCode = ({ children, lang }) => (
  <pre
    className="code"
    dangerouslySetInnerHTML={{ __html: lang === "toml" || lang === "txt" ? children : highlightRust(children) }}
  />
);

const SectionHeader = ({ eyebrow, title, lede }) => (
  <header style={{ marginBottom: 56 }}>
    <Eyebrow>{eyebrow}</Eyebrow>
    <h2 className="section-title">{title}</h2>
    {lede && <p className="section-lede">{lede}</p>}
  </header>
);

Object.assign(window, { Brand, Nav, Eyebrow, Chip, RustCode, SectionHeader, highlightRust });
