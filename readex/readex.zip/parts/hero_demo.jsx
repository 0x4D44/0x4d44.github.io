/* eslint-disable */
// readex — hero & live demo

const Hero = () => (
  <section id="top" className="hero shell">
    <Eyebrow>HTML main-content extraction · for Rust</Eyebrow>
    <h1>
      Give it raw HTML.<br />
      Get the <span className="accent">article.</span>
    </h1>
    <p className="hero-sub">
      Title, body, byline, language, dates, and a dozen other fields —
      from any messy webpage. No network. No JavaScript. No surprises.
    </p>

    <div style={{ display: "flex", gap: 12, marginTop: 40, flexWrap: "wrap" }}>
      <a className="btn" href="#demo" style={{ textDecoration: "none" }}>
        try the live demo
        <span style={{ opacity: 0.6 }}>↓</span>
      </a>
      <a className="btn ghost" href="#use" style={{ textDecoration: "none" }}>
        <code style={{ fontSize: 12 }}>cargo add readex</code>
      </a>
    </div>

    <dl className="hero-meta">
      <div><dt>crate</dt><dd>readex 0.19.2</dd></div>
      <div><dt>edition</dt><dd>Rust 2024 · MSRV 1.85</dd></div>
      <div><dt>license</dt><dd>MIT or Apache‑2.0</dd></div>
      <div><dt>deps (runtime)</dt><dd>4 — all pinned exactly</dd></div>
    </dl>
  </section>
);

/* ───────────────────────── live demo ──────────────────────── */

const SAMPLES = {
  "news article": `<html lang="en">
  <head>
    <title>Why the bridge collapsed — The Daily Example</title>
    <meta property="og:site_name" content="The Daily Example">
    <meta name="author" content="Jane Reporter">
    <meta property="article:published_time" content="2026-05-24T09:30:00Z">
  </head>
  <body>
    <nav><a href="/">Home</a> <a href="/news">News</a></nav>
    <aside class="cookie-banner">
      We use cookies to enhance your experience. <button>Accept all</button>
    </aside>
    <article>
      <h1>Why the bridge collapsed</h1>
      <p class="byline">By Jane Reporter, 24 May 2026</p>
      <p>Investigators arrived on site shortly after dawn and began sampling
         the steelwork for fatigue cracks.</p>
      <p>The bridge, opened in 1972, had been scheduled for inspection next
         month. Engineers say the failure mode is consistent with corrosion
         at the western anchorage.</p>
      <p>Local residents reported a low rumble several minutes before the
         span gave way. No casualties have been confirmed.</p>
    </article>
    <section class="comments">
      <h3>Comments (412)</h3>
      <p>"Knew this would happen" — anonymous</p>
    </section>
    <footer>© 2026 The Daily Example</footer>
  </body>
</html>`,
  "blog post": `<!doctype html>
<html>
<head>
  <title>On writing Rust by feel · marl.dev</title>
  <meta name="author" content="Marl Vandenheim">
  <meta property="article:published_time" content="2026-03-11">
</head>
<body>
  <header class="site-header">
    <a href="/">marl.dev</a>
    <nav><a>posts</a> <a>about</a> <a>rss</a></nav>
  </header>
  <main>
    <h1>On writing Rust by feel</h1>
    <p>After enough years with the language you stop reaching for the
       borrow checker; it reaches for you. The compiler errors become
       conversation, not interrogation.</p>
    <p>I want to talk about three things I learned writing readex: how
       to trust deterministic ports, why pinning matters more than people
       think, and the unreasonable joy of a parser equivalence fence.</p>
    <h2>Determinism is a feature</h2>
    <p>Most extractors hide their non-determinism behind a smile. readex
       does not. Every flag-sieve retry re-parses the original bytes.</p>
  </main>
  <aside class="newsletter">
    <h3>Subscribe</h3>
    <form><input placeholder="you@example.com"><button>Join</button></form>
  </aside>
  <footer>© marl 2026 · built with hugo</footer>
</body>
</html>`,
  "regulator filing": `<html>
<head>
  <title>FORM 10-K — Acme Industries Inc.</title>
</head>
<body>
  <div class="header-strip">Skip to content · Accessibility · Print</div>
  <nav>Filings · Insiders · Holdings · Definitions</nav>
  <h1>FORM 10-K</h1>
  <h2>Annual Report Pursuant to Section 13 or 15(d)</h2>
  <p>For the fiscal year ended December 31, 2025</p>
  <h3>Item 1. Business</h3>
  <p>Acme Industries Inc. (the "Company") designs, manufactures and
     services rotary-wing transport platforms for industrial customers.
     The Company was incorporated in Delaware in 1956 and maintains its
     principal executive offices in Toledo, Ohio.</p>
  <p>During fiscal 2025 the Company derived approximately 64% of revenue
     from its Industrial Lift segment and the balance from Services.</p>
  <h3>Item 1A. Risk Factors</h3>
  <p>Our business is subject to a range of risks, many of which are
     outside of our control. These include commodity-price exposure on
     specialty alloys, single-source supplier concentration on rotor
     bearings, and regulatory action under FAA Part 27.</p>
  <footer>EDGAR · SEC · Privacy · Contact</footer>
</body>
</html>`,
};

// fake but plausible extractor — emulates what readex actually returns
function fakeExtract(html) {
  const pick = (re) => { const m = html.match(re); return m ? m[1].trim() : null; };
  const strip = (s) => s.replace(/<[^>]+>/g, "").replace(/\s+/g, " ").trim();

  const title = pick(/<title[^>]*>([\s\S]*?)<\/title>/i)?.split(/[—|·–]/)[0].trim() || null;
  const byline = pick(/<meta\s+name=["']author["']\s+content=["']([^"']+)["']/i);
  const site = pick(/<meta\s+property=["']og:site_name["']\s+content=["']([^"']+)["']/i);
  const date = pick(/<meta\s+property=["']article:published_time["']\s+content=["']([^"']+)["']/i);
  const lang = pick(/<html[^>]*\blang=["']([^"']+)["']/i);

  // pull <article> or <main> bodies, paragraph by paragraph
  let bodyRoot = html.match(/<article[\s\S]*?<\/article>/i)?.[0]
            || html.match(/<main[\s\S]*?<\/main>/i)?.[0]
            || html;

  // strip cookie banners, comments, nav, aside, footer, header chrome
  bodyRoot = bodyRoot
    .replace(/<nav[\s\S]*?<\/nav>/gi, "")
    .replace(/<aside[\s\S]*?<\/aside>/gi, "")
    .replace(/<footer[\s\S]*?<\/footer>/gi, "")
    .replace(/<header[\s\S]*?<\/header>/gi, "")
    .replace(/<section[^>]*class=["']comments["'][\s\S]*?<\/section>/gi, "")
    .replace(/<form[\s\S]*?<\/form>/gi, "");

  const paragraphs = [...bodyRoot.matchAll(/<p[^>]*>([\s\S]*?)<\/p>/gi)]
    .map((m) => strip(m[1]))
    .filter((p) => p && p.length > 24 && !/^by\s+/i.test(p));

  const text = paragraphs.join("\n\n");
  const words = text.split(/\s+/).filter(Boolean).length;

  return {
    title,
    byline,
    site_name: site,
    language: lang,
    published_time: date,
    word_count: words,
    text,
    excerpt: text.slice(0, 180) + (text.length > 180 ? "…" : ""),
    paragraphs,
  };
}

const FieldRow = ({ k, v, hl }) => (
  <div style={{
    display: "grid",
    gridTemplateColumns: "150px 1fr",
    gap: 16,
    padding: "10px 0",
    borderBottom: "1px solid var(--rule)",
    fontFamily: "var(--mono)",
    fontSize: 13,
    alignItems: "baseline",
  }}>
    <div style={{ color: "var(--ink-3)" }}>{k}</div>
    <div style={{ color: v == null ? "var(--ink-3)" : (hl ? "var(--accent-2)" : "var(--ink)") }}>
      {v == null ? <i style={{ opacity: 0.6 }}>None</i> : (
        typeof v === "string" && v.length > 90 ? v.slice(0, 90) + "…" : v
      )}
    </div>
  </div>
);

const LiveDemo = () => {
  const [sample, setSample] = React.useState("news article");
  const [html, setHtml] = React.useState(SAMPLES["news article"]);
  const [running, setRunning] = React.useState(false);
  const [phase, setPhase] = React.useState(null);
  const [result, setResult] = React.useState(null);

  React.useEffect(() => { setHtml(SAMPLES[sample]); setResult(null); }, [sample]);

  const run = async () => {
    setRunning(true);
    setResult(null);
    const steps = [
      ["parse", "html5ever parsing into rcdom", 280],
      ["clean", "tree_cleaning · convert_tags", 240],
      ["cascade", "own → readability_fork → jusText", 420],
      ["arbiter", "7-branch arbiter · dedup gate", 240],
      ["metadata", "OG · meta · JSON-LD · htmldate", 280],
    ];
    for (const [k, _l, ms] of steps) {
      setPhase(k);
      await new Promise((r) => setTimeout(r, ms));
    }
    setResult(fakeExtract(html));
    setPhase(null);
    setRunning(false);
  };

  return (
    <section id="demo" className="section">
      <div className="shell">
        <SectionHeader
          eyebrow="01 · live demo"
          title="Watch it extract."
          lede="Pick a sample (or paste your own HTML) and run it through the cascade. The output is what readex would return."
        />

        <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 24 }} className="demo-grid">
          {/* LEFT — input */}
          <div className="card" style={{ display: "flex", flexDirection: "column" }}>
            <div style={{
              display: "flex", justifyContent: "space-between", alignItems: "center",
              padding: "12px 16px", borderBottom: "1px solid var(--rule)",
            }}>
              <div style={{ display: "flex", gap: 8, alignItems: "center", fontFamily: "var(--mono)", fontSize: 12, color: "var(--ink-3)" }}>
                <span style={{ width: 8, height: 8, borderRadius: 99, background: "var(--accent)" }} />
                input.html
              </div>
              <div style={{ display: "flex", gap: 6 }}>
                {Object.keys(SAMPLES).map((k) => (
                  <button
                    key={k}
                    onClick={() => setSample(k)}
                    style={{
                      fontFamily: "var(--mono)", fontSize: 11, padding: "4px 9px",
                      border: "1px solid " + (sample === k ? "var(--ink)" : "var(--rule-2)"),
                      background: sample === k ? "var(--ink)" : "transparent",
                      color: sample === k ? "var(--bg)" : "var(--ink-2)",
                      borderRadius: 999, cursor: "pointer",
                    }}
                  >{k}</button>
                ))}
              </div>
            </div>
            <textarea
              value={html}
              onChange={(e) => setHtml(e.target.value)}
              spellCheck={false}
              style={{
                flex: 1,
                minHeight: 380,
                resize: "vertical",
                border: "none",
                background: "transparent",
                padding: "16px",
                fontFamily: "var(--mono)",
                fontSize: 12,
                lineHeight: 1.55,
                color: "var(--ink-2)",
                outline: "none",
                width: "100%",
              }}
            />
            <div style={{
              display: "flex", justifyContent: "space-between", alignItems: "center",
              padding: "10px 16px", borderTop: "1px solid var(--rule)",
              fontFamily: "var(--mono)", fontSize: 11, color: "var(--ink-3)",
            }}>
              <span>{html.length.toLocaleString()} bytes · {html.split("\n").length} lines</span>
              <button
                className="btn"
                onClick={run}
                disabled={running}
                style={{ opacity: running ? 0.6 : 1 }}
              >
                {running ? "extracting…" : "→ extract(html)"}
              </button>
            </div>
          </div>

          {/* RIGHT — output */}
          <div className="card" style={{ display: "flex", flexDirection: "column", minHeight: 480 }}>
            <div style={{
              padding: "12px 16px", borderBottom: "1px solid var(--rule)",
              fontFamily: "var(--mono)", fontSize: 12, color: "var(--ink-3)",
              display: "flex", justifyContent: "space-between",
            }}>
              <span><span style={{ color: "var(--accent)" }}>{">"}</span> Extracted</span>
              <span>{result ? `${result.word_count.toLocaleString()} words` : ""}</span>
            </div>

            {/* phase pipeline */}
            <div style={{ padding: "16px", borderBottom: "1px solid var(--rule)", background: "var(--bg-2)" }}>
              <PhaseTracker active={phase} done={!!result} />
            </div>

            <div style={{ padding: "8px 16px", flex: 1, overflowY: "auto" }}>
              {result ? (
                <>
                  <FieldRow k="title" v={result.title} hl />
                  <FieldRow k="byline" v={result.byline} />
                  <FieldRow k="site_name" v={result.site_name} />
                  <FieldRow k="language" v={result.language} />
                  <FieldRow k="published_time" v={result.published_time} />
                  <FieldRow k="word_count" v={result.word_count} />
                  <FieldRow k="excerpt" v={result.excerpt} />
                  <div style={{ marginTop: 18, fontFamily: "var(--mono)", fontSize: 12, color: "var(--ink-3)" }}>
                    body text ({result.paragraphs.length} paragraphs)
                  </div>
                  <div style={{
                    marginTop: 8, padding: "12px 14px", borderRadius: 6,
                    background: "var(--bg-2)", fontSize: 14, lineHeight: 1.55,
                    fontFamily: "var(--serif)", maxHeight: 220, overflowY: "auto",
                  }}>
                    {result.paragraphs.map((p, i) => <p key={i} style={{ margin: "0 0 10px" }}>{p}</p>)}
                  </div>
                </>
              ) : (
                <div style={{
                  height: "100%", display: "grid", placeItems: "center",
                  fontFamily: "var(--mono)", fontSize: 13, color: "var(--ink-3)",
                  padding: 32, textAlign: "center",
                }}>
                  {running
                    ? "running cascade…"
                    : "press → extract(html) to run"}
                </div>
              )}
            </div>
          </div>
        </div>

        <p style={{
          marginTop: 18, fontFamily: "var(--mono)", fontSize: 12,
          color: "var(--ink-3)", maxWidth: 64 + "ch",
        }}>
          // this preview runs an in-browser approximation. the real crate uses an
          html5ever DOM, the full Trafilatura cascade, and the htmldate precedence
          rules — same shape of output, with the differential gates behind it.
        </p>
      </div>
    </section>
  );
};

const PhaseTracker = ({ active, done }) => {
  const phases = [
    ["parse",     "parse"],
    ["clean",     "clean"],
    ["cascade",   "cascade"],
    ["arbiter",   "arbiter"],
    ["metadata",  "metadata"],
  ];
  return (
    <div style={{ display: "flex", gap: 0 }}>
      {phases.map(([k, label], i) => {
        const isActive = active === k;
        const order = phases.findIndex(([kk]) => kk === active);
        const isPast = (order > -1 && i < order) || done;
        return (
          <div key={k} style={{ flex: 1, display: "flex", alignItems: "center", gap: 8 }}>
            <div style={{
              width: 22, height: 22, borderRadius: 999,
              background: isActive ? "var(--accent)" : (isPast ? "var(--ink)" : "var(--bg)"),
              border: "1px solid " + (isActive || isPast ? "transparent" : "var(--rule-2)"),
              color: isActive || isPast ? "var(--bg)" : "var(--ink-3)",
              display: "grid", placeItems: "center",
              fontFamily: "var(--mono)", fontSize: 10,
              transition: "all 180ms ease",
            }}>{i + 1}</div>
            <div style={{
              fontFamily: "var(--mono)", fontSize: 11,
              color: isActive ? "var(--accent-2)" : (isPast ? "var(--ink)" : "var(--ink-3)"),
            }}>{label}</div>
            {i < phases.length - 1 && (
              <div style={{
                flex: 1, height: 1,
                background: isPast ? "var(--ink)" : "var(--rule-2)",
                margin: "0 8px",
                transition: "all 220ms ease",
              }} />
            )}
          </div>
        );
      })}
    </div>
  );
};

Object.assign(window, { Hero, LiveDemo });
