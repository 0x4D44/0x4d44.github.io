/* eslint-disable */
// readex — lineage, scope, footer

const Lineage = () => {
  const projects = [
    {
      name: "Mozilla Readability",
      origin: "JavaScript · Firefox Reader View",
      role: "Article-scoring core",
      detail: "The full _grabArticle / _prepArticle / flag-sieve pipeline is preserved in readex's M2 port. Every retry attempt re-parses the original bytes, matching Readability.js's page.innerHTML = pageCacheHtml reset.",
      url: "github.com/mozilla/readability",
      hue: 320,
    },
    {
      name: "Trafilatura",
      origin: "Python · Adrien Barbaresi",
      role: "The cascade itself",
      detail: "The own → readability_fork → jusText cascade — plus the 7-branch arbiter, the dedup gate, the sanitize post-pass, and the OG/JSON-LD/itemprop/URL metadata harvest.",
      url: "trafilatura.readthedocs.io",
      hue: 50,
    },
    {
      name: "htmldate",
      origin: "Python · Adrien Barbaresi",
      role: "Publication-date extraction",
      detail: "Meta-tag, JSON-LD, URL, and body precedence — the same rule ordering as upstream, validated by the same fixtures.",
      url: "htmldate.readthedocs.io",
      hue: 80,
    },
  ];
  return (
    <section id="lineage" className="section">
      <div className="shell">
        <SectionHeader
          eyebrow="06 · community & lineage"
          title={<>Standing on three sets of shoulders.</>}
          lede="readex is a clean-room reimplementation in Rust. The upstream projects aren't vendored — they're the differential-test oracles. That's the whole point of the harness."
        />

        <div style={{ display: "flex", flexDirection: "column", gap: 16 }}>
          {projects.map((p) => (
            <article key={p.name} style={{
              border: "1px solid var(--rule)",
              borderRadius: 10,
              padding: "28px 32px",
              background: "var(--bg)",
              display: "grid",
              gridTemplateColumns: "auto 1fr",
              gap: 28,
            }} className="lineage-row">
              <div style={{
                width: 84, height: 84, borderRadius: 12,
                background: `oklch(94% 0.04 ${p.hue})`,
                border: `1px solid oklch(80% 0.08 ${p.hue})`,
                display: "grid", placeItems: "center",
                fontFamily: "var(--serif)", fontSize: 40, fontStyle: "italic",
                color: `oklch(45% 0.13 ${p.hue})`,
              }}>{p.name[0]}</div>
              <div>
                <div style={{ display: "flex", justifyContent: "space-between", alignItems: "baseline", gap: 16, flexWrap: "wrap" }}>
                  <h3 style={{ fontFamily: "var(--serif)", fontWeight: 400, fontSize: 28, letterSpacing: "-0.015em" }}>{p.name}</h3>
                  <span style={{ fontFamily: "var(--mono)", fontSize: 11, color: "var(--ink-3)" }}>{p.origin}</span>
                </div>
                <div style={{ marginTop: 4, fontFamily: "var(--mono)", fontSize: 12, color: `oklch(45% 0.13 ${p.hue})`, letterSpacing: "0.04em", textTransform: "uppercase" }}>
                  role: {p.role}
                </div>
                <p style={{ marginTop: 14, color: "var(--ink-2)", fontSize: 15, lineHeight: 1.6, maxWidth: "62ch", textWrap: "pretty" }}>{p.detail}</p>
                <div style={{ marginTop: 14, fontFamily: "var(--mono)", fontSize: 12, color: "var(--ink-3)" }}>
                  ↗ {p.url}
                </div>
              </div>
            </article>
          ))}
        </div>

        {/* out of scope */}
        <div style={{ marginTop: 96 }}>
          <div className="eyebrow" style={{ marginBottom: 12 }}>out of scope · by design</div>
          <p style={{ fontFamily: "var(--serif)", fontSize: 28, color: "var(--ink-2)", lineHeight: 1.3, maxWidth: "44ch", marginTop: 0, marginBottom: 32 }}>
            These boundaries keep the crate sync, dependency-light, and easy to embed.
          </p>
          <div style={{ display: "grid", gridTemplateColumns: "repeat(4, 1fr)", gap: 16 }} className="scope-grid">
            {[
              ["network fetching", "the caller owns HTTP, redirects, SSRF guarding, encoding detection"],
              ["JS rendering", "if the page needs JS to render, run a headless browser upstream"],
              ["PDF extraction", "HTML only — there are excellent PDF crates elsewhere"],
              ["streaming", "the document is parsed at once; not a chunked-input API"],
            ].map(([k, v]) => (
              <div key={k} style={{ borderTop: "1px solid var(--rule-2)", paddingTop: 14 }}>
                <div style={{ fontFamily: "var(--mono)", fontSize: 11, color: "var(--accent)", letterSpacing: "0.08em", textTransform: "uppercase" }}>not</div>
                <h4 style={{ marginTop: 6, fontWeight: 500, fontSize: 16, color: "var(--ink)" }}>{k}</h4>
                <p style={{ marginTop: 8, fontSize: 13, color: "var(--ink-3)", lineHeight: 1.55, textWrap: "pretty" }}>{v}</p>
              </div>
            ))}
          </div>
        </div>

        {/* contribute */}
        <div style={{
          marginTop: 96,
          padding: "40px 44px",
          background: "var(--bg-2)",
          border: "1px solid var(--rule)",
          borderRadius: 12,
          display: "grid",
          gridTemplateColumns: "1.6fr 1fr",
          gap: 32,
        }} className="contrib">
          <div>
            <Eyebrow>contributing</Eyebrow>
            <h3 style={{ fontFamily: "var(--serif)", fontWeight: 400, fontSize: 36, letterSpacing: "-0.02em", marginTop: 12, lineHeight: 1.05 }}>
              Found a page where readex disagrees with both upstreams?
            </h3>
            <p style={{ marginTop: 16, color: "var(--ink-2)", fontSize: 16, lineHeight: 1.55, maxWidth: "52ch", textWrap: "pretty" }}>
              File an issue with the URL or HTML — the harness will pick it up. For non-trivial PRs, please open an issue first to sketch intent; the parity gate is the cheapest path through review once approach is settled.
            </p>
          </div>
          <div style={{ display: "flex", flexDirection: "column", gap: 8 }}>
            <Resource k="repo"        v="github.com/0x4D44/readex" />
            <Resource k="docs"        v="docs.rs/readex" />
            <Resource k="crate"       v="crates.io/crates/readex" />
            <Resource k="license"     v="MIT or Apache-2.0" />
            <Resource k="author"      v="Martin Davidson" />
            <Resource k="MSRV"        v="Rust 1.85 · 2024 edition" />
          </div>
        </div>
      </div>
    </section>
  );
};

const Resource = ({ k, v }) => (
  <div style={{
    display: "grid", gridTemplateColumns: "80px 1fr", gap: 12,
    padding: "8px 0",
    borderBottom: "1px solid var(--rule)",
    fontFamily: "var(--mono)", fontSize: 13,
  }}>
    <span style={{ color: "var(--ink-3)" }}>{k}</span>
    <span style={{ color: "var(--ink)" }}>{v}</span>
  </div>
);

const Footer = () => (
  <footer className="footer">
    <div className="shell">
      <div className="row">
        <div>
          <Brand />
          <p style={{ marginTop: 14, maxWidth: "44ch", fontFamily: "var(--sans)", fontSize: 13, color: "var(--ink-3)", lineHeight: 1.55 }}>
            HTML main-content extraction for Rust. Ports of Mozilla Readability, Trafilatura, and htmldate. MIT or Apache-2.0.
          </p>
        </div>
        <div style={{ display: "grid", gridTemplateColumns: "repeat(3, auto)", gap: 48 }}>
          <FooterCol title="crate" links={[["docs.rs/readex", "#"], ["crates.io", "#"], ["changelog", "#"]]} />
          <FooterCol title="repo"  links={[["github", "#"], ["issues", "#"], ["releases", "#"]]} />
          <FooterCol title="upstreams" links={[["Readability", "#"], ["Trafilatura", "#"], ["htmldate", "#"]]} />
        </div>
      </div>
      <div style={{ marginTop: 56, paddingTop: 24, borderTop: "1px solid var(--rule)", display: "flex", justifyContent: "space-between", flexWrap: "wrap", gap: 12 }}>
        <span>© 2026 · readex contributors</span>
        <span>page rendered with HTML5, css grid, and a small amount of regex</span>
      </div>
    </div>
  </footer>
);

const FooterCol = ({ title, links }) => (
  <div>
    <div style={{ fontFamily: "var(--mono)", fontSize: 11, color: "var(--ink-3)", letterSpacing: "0.08em", textTransform: "uppercase", marginBottom: 10 }}>{title}</div>
    <div style={{ display: "flex", flexDirection: "column", gap: 6 }}>
      {links.map(([l, href]) => <a key={l} href={href}>{l}</a>)}
    </div>
  </div>
);

Object.assign(window, { Lineage, Footer });
