/* eslint-disable */
// readex — how it works: the cascade

const CASCADE = [
  {
    id: "parse",
    label: "html5ever parse",
    short: "01",
    sub: "tendril → rcdom",
    body: "Pinned to exactly html5ever 0.39.0 + markup5ever_rcdom 0.39.0. Any parser bump has to pass a separate parity-equivalence fence vs. jsdom before it can land.",
    detail: "tree_cleaning() strips scripts, styles, and known-noise classes before scoring; convert_tags() normalises spans, br-runs, and inline image markup so downstream scorers see the same DOM shape Trafilatura does.",
    code: `<span class="com">// crate-internal — Stage 0</span>\n<span class="kw">let</span> dom = html5ever::<span class="fn">parse_document</span>(<span class="ty">RcDom</span>::<span class="fn">default</span>(), opts)\n    .<span class="fn">one</span>(html);\n<span class="fn">tree_cleaning</span>(&dom);\n<span class="fn">convert_tags</span>(&dom);`,
    color: "oklch(60% 0.13 240)",
  },
  {
    id: "own",
    label: "Trafilatura · own",
    short: "02a",
    sub: "XPath cascade",
    body: "First branch of the cascade. Trafilatura's own algorithm — an XPath-driven walk over the cleaned DOM, picking up structured news and blog templates fast and faithfully.",
    detail: "Backed by xpath_engine.rs (a Rust port of the upstream lxml XPath set) and main_extractor.rs. Hits on ~70% of well-structured pages; misses politely so the next branch can try.",
    code: `<span class="kw">let</span> own = trafilatura::own::<span class="fn">extract</span>(&dom, &cfg);\n<span class="kw">if</span> own.<span class="fn">is_acceptable</span>() {\n    <span class="kw">return</span> <span class="ty">Ok</span>(own);\n}`,
    color: "oklch(60% 0.16 50)",
  },
  {
    id: "readability_fork",
    label: "Readability fork",
    short: "02b",
    sub: "_grabArticle",
    body: "Second branch. The full Mozilla Readability _grabArticle / _prepArticle pipeline — scoring, candidate selection, sibling-append, the FLAG_* sieve, and the longest-text fallback.",
    detail: "Ported clean-room from Readability.js. Every retry attempt re-parses the original bytes (the page.innerHTML = pageCacheHtml reset). _markDataTables uses a JS-faithful parse_int_js so EDGAR / HMRC financial tables survive.",
    code: `<span class="kw">let</span> rdy = trafilatura::readability_fork::<span class="fn">extract</span>(&dom)\n    .<span class="fn">filter</span>(|r| r.<span class="fn">word_count</span>() >= cfg.min_words);`,
    color: "oklch(60% 0.13 320)",
  },
  {
    id: "justext",
    label: "jusText",
    short: "02c",
    sub: "stoplist scoring",
    body: "Third branch. Per-paragraph classification using language-specific stoplists. Catches the long tail — low-template blogs, regulator pages, multilingual corpora — where structure-based scoring gives up.",
    detail: "Bundles the upstream jusText stoplists per language in justext_stoplists/. A paragraph is good / near-good / short / bad depending on stopword density and link density; near-good is rescued by neighbours.",
    code: `<span class="kw">let</span> jt = trafilatura::justext::<span class="fn">extract</span>(&dom, lang);\n<span class="com">// long-tail rescue</span>`,
    color: "oklch(60% 0.12 150)",
  },
  {
    id: "arbiter",
    label: "7-branch arbiter",
    short: "03",
    sub: "dedup + sanitize",
    body: "Picks the best of the three branches by a 7-rule arbiter (length thresholds, paragraph counts, oracle-aware tie-breaks), then runs the dedup gate and a sanitize post-pass.",
    detail: "Same arbiter ordering as Trafilatura's bare_extraction_with_cascade. Deduplication is exact-on-paragraph + near-duplicate via the upstream LRU; sanitize cleans empty wrappers without re-scoring.",
    code: `<span class="kw">let</span> winner = <span class="fn">arbiter</span>(own, rdy, jt, &cfg);\n<span class="kw">let</span> body = winner\n    .<span class="fn">dedupe</span>()\n    .<span class="fn">sanitize</span>();`,
    color: "oklch(55% 0.16 30)",
  },
  {
    id: "metadata",
    label: "metadata + htmldate",
    short: "04",
    sub: "OG · JSON-LD · URL",
    body: "Separate pass. Pulls OpenGraph, meta-name, itemprop, JSON-LD, and URL-derived fields. Publication date routes through the htmldate port, with the same precedence rules as upstream.",
    detail: "metadata.rs · metadata_jsonld.rs · metadata_url.rs · htmldate/core.rs. Categories, tags, license, image, hostname, language all land here. Comments (Reddit / vBulletin / Disqus-class) extracted in parallel.",
    code: `<span class="kw">let</span> meta = metadata::<span class="fn">extract_metadata</span>(&dom, base_url);\n<span class="kw">let</span> date = htmldate::<span class="fn">find_date</span>(&dom, &meta);`,
    color: "oklch(58% 0.13 80)",
  },
];

const Cascade = () => {
  const [active, setActive] = React.useState("own");
  const [auto, setAuto] = React.useState(true);

  React.useEffect(() => {
    if (!auto) return;
    const id = setInterval(() => {
      setActive((cur) => {
        const i = CASCADE.findIndex((c) => c.id === cur);
        return CASCADE[(i + 1) % CASCADE.length].id;
      });
    }, 3600);
    return () => clearInterval(id);
  }, [auto]);

  const cur = CASCADE.find((c) => c.id === active);

  return (
    <section id="how" className="section" style={{ background: "var(--bg-2)" }}>
      <div className="shell">
        <SectionHeader
          eyebrow="03 · how it works"
          title="The cascade."
          lede="readex doesn't pick one algorithm — it runs three, in a fixed order, and arbitrates between them. Click a stage to inspect it."
        />

        <div style={{ display: "grid", gridTemplateColumns: "1fr 1.3fr", gap: 28 }} className="cascade-grid">
          {/* LEFT — pipeline column */}
          <div style={{ display: "flex", flexDirection: "column", gap: 8 }}>
            {CASCADE.map((c, i) => {
              const isActive = c.id === active;
              return (
                <button
                  key={c.id}
                  onClick={() => { setActive(c.id); setAuto(false); }}
                  style={{
                    textAlign: "left",
                    cursor: "pointer",
                    background: isActive ? "var(--bg)" : "transparent",
                    border: "1px solid " + (isActive ? c.color : "var(--rule)"),
                    borderLeft: "3px solid " + (isActive ? c.color : "var(--rule-2)"),
                    borderRadius: 8,
                    padding: "14px 16px",
                    display: "grid",
                    gridTemplateColumns: "44px 1fr",
                    gap: 14,
                    alignItems: "center",
                    transition: "all 180ms ease",
                    boxShadow: isActive ? "0 4px 18px -10px " + c.color : "none",
                  }}
                >
                  <div style={{
                    width: 44, height: 44, borderRadius: 8,
                    background: isActive ? c.color : "var(--bg)",
                    color: isActive ? "var(--bg)" : "var(--ink-2)",
                    border: "1px solid " + (isActive ? "transparent" : "var(--rule-2)"),
                    fontFamily: "var(--mono)", fontSize: 12,
                    display: "grid", placeItems: "center",
                    transition: "all 180ms ease",
                  }}>{c.short}</div>
                  <div>
                    <div style={{ fontSize: 15, color: "var(--ink)", fontWeight: 500 }}>{c.label}</div>
                    <div style={{ fontFamily: "var(--mono)", fontSize: 11, color: "var(--ink-3)", marginTop: 2 }}>
                      {c.sub}
                    </div>
                  </div>
                </button>
              );
            })}

            <div style={{
              marginTop: 12, padding: "10px 14px",
              border: "1px dashed var(--rule-2)", borderRadius: 8,
              fontFamily: "var(--mono)", fontSize: 11, color: "var(--ink-3)",
              display: "flex", alignItems: "center", justifyContent: "space-between",
            }}>
              <span>{auto ? "auto-cycling stages…" : "manual"}</span>
              <button
                onClick={() => setAuto((a) => !a)}
                style={{
                  border: "1px solid var(--rule-2)", background: "transparent",
                  padding: "4px 8px", borderRadius: 4, cursor: "pointer",
                  fontFamily: "var(--mono)", fontSize: 11, color: "var(--ink-2)",
                }}
              >{auto ? "pause" : "resume"}</button>
            </div>
          </div>

          {/* RIGHT — detail panel */}
          <div className="card" style={{ padding: "32px 36px", minHeight: 480, position: "relative", overflow: "hidden" }}>
            <div style={{
              position: "absolute", top: 0, left: 0, right: 0, height: 3,
              background: cur.color, transition: "background 200ms ease",
            }} />
            <div style={{ display: "flex", alignItems: "baseline", gap: 12 }}>
              <span style={{
                fontFamily: "var(--mono)", fontSize: 12, color: cur.color, letterSpacing: "0.08em",
              }}>STAGE {cur.short}</span>
              <span style={{ fontFamily: "var(--mono)", fontSize: 11, color: "var(--ink-3)" }}>· {cur.sub}</span>
            </div>
            <h3 style={{
              fontFamily: "var(--serif)", fontWeight: 400, fontSize: 44, marginTop: 6,
              letterSpacing: "-0.02em", lineHeight: 1,
            }}>{cur.label}</h3>
            <p style={{ marginTop: 24, fontSize: 17, lineHeight: 1.55, color: "var(--ink-2)", textWrap: "pretty" }}>
              {cur.body}
            </p>
            <p style={{ marginTop: 16, fontSize: 14, lineHeight: 1.65, color: "var(--ink-3)" }}>
              {cur.detail}
            </p>

            <pre className="code" style={{ marginTop: 28 }}
              dangerouslySetInnerHTML={{ __html: cur.code }}
            />
          </div>
        </div>

        {/* Flow visualization */}
        <FlowDiagram active={active} setActive={(id) => { setActive(id); setAuto(false); }} />
      </div>
    </section>
  );
};

const FlowDiagram = ({ active, setActive }) => {
  // Visual: input → parse → 3 parallel branches → arbiter → metadata → output
  const w = 920, h = 220;
  const cx = w / 2;
  return (
    <div style={{ marginTop: 64, overflowX: "auto" }}>
      <div className="eyebrow" style={{ marginBottom: 14 }}>data flow</div>
      <svg viewBox={`0 0 ${w} ${h}`} style={{ width: "100%", maxWidth: w, display: "block" }}>
        {/* defs */}
        <defs>
          <marker id="arrow" viewBox="0 0 10 10" refX="8" refY="5" markerWidth="6" markerHeight="6" orient="auto">
            <path d="M0,0 L10,5 L0,10 z" fill="oklch(50% 0.02 60)" />
          </marker>
        </defs>

        {/* input box */}
        <Box x={20} y={90} w={90} h={40} label="html: &str" mono active={false} />

        {/* parse */}
        <FlowNode x={140} y={90} w={110} h={40} id="parse" label="parse + clean" active={active} setActive={setActive} />

        {/* branches */}
        <FlowNode x={300} y={30}  w={120} h={40} id="own"               label="own (XPath)"     active={active} setActive={setActive} />
        <FlowNode x={300} y={90}  w={120} h={40} id="readability_fork"  label="readability_fork" active={active} setActive={setActive} />
        <FlowNode x={300} y={150} w={120} h={40} id="justext"           label="jusText"          active={active} setActive={setActive} />

        {/* arbiter */}
        <FlowNode x={470} y={90} w={120} h={40} id="arbiter" label="7-arbiter" active={active} setActive={setActive} />

        {/* metadata */}
        <FlowNode x={640} y={90} w={140} h={40} id="metadata" label="metadata + date" active={active} setActive={setActive} />

        {/* output */}
        <Box x={820} y={90} w={80} h={40} label="Extracted" mono active={false} />

        {/* connectors */}
        <Line x1={110} y1={110} x2={140} y2={110} />
        <Line x1={250} y1={110} x2={300} y2={50}  curve />
        <Line x1={250} y1={110} x2={300} y2={110} />
        <Line x1={250} y1={110} x2={300} y2={170} curve />
        <Line x1={420} y1={50}  x2={470} y2={110} curve />
        <Line x1={420} y1={110} x2={470} y2={110} />
        <Line x1={420} y1={170} x2={470} y2={110} curve />
        <Line x1={590} y1={110} x2={640} y2={110} />
        <Line x1={780} y1={110} x2={820} y2={110} />
      </svg>
    </div>
  );
};

const Box = ({ x, y, w, h, label }) => (
  <g>
    <rect x={x} y={y} width={w} height={h} rx={6}
      fill="var(--bg)" stroke="var(--rule-2)" strokeWidth="1" />
    <text x={x + w / 2} y={y + h / 2 + 4} textAnchor="middle"
      style={{ fontFamily: "var(--mono)", fontSize: 11, fill: "var(--ink-2)" }}>{label}</text>
  </g>
);

const FlowNode = ({ x, y, w, h, id, label, active, setActive }) => {
  const isActive = id === active;
  const cur = CASCADE.find((c) => c.id === id);
  const color = cur ? cur.color : "var(--ink)";
  return (
    <g style={{ cursor: "pointer" }} onClick={() => setActive(id)}>
      <rect x={x} y={y} width={w} height={h} rx={6}
        fill={isActive ? color : "var(--bg)"}
        stroke={isActive ? color : "var(--rule-2)"}
        strokeWidth={isActive ? 0 : 1}
        style={{ transition: "all 220ms ease" }} />
      <text x={x + w / 2} y={y + h / 2 + 4} textAnchor="middle"
        style={{
          fontFamily: "var(--mono)", fontSize: 11,
          fill: isActive ? "var(--bg)" : "var(--ink)",
          transition: "fill 220ms ease",
        }}>{label}</text>
    </g>
  );
};

const Line = ({ x1, y1, x2, y2, curve }) => {
  if (curve) {
    const mx = (x1 + x2) / 2;
    return <path d={`M${x1},${y1} C${mx},${y1} ${mx},${y2} ${x2},${y2}`}
      stroke="oklch(50% 0.02 60)" strokeWidth="1" fill="none" markerEnd="url(#arrow)" />;
  }
  return <line x1={x1} y1={y1} x2={x2} y2={y2}
    stroke="oklch(50% 0.02 60)" strokeWidth="1" markerEnd="url(#arrow)" />;
};

Object.assign(window, { Cascade });
