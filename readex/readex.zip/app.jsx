/* eslint-disable */
// readex — root

const App = () => (
  <>
    <Nav />
    <Hero />
    <LiveDemo />
    <Why />
    <Cascade />
    <Usage />
    <Testing />
    <Lineage />
    <Footer />
  </>
);

const root = ReactDOM.createRoot(document.getElementById("root"));
root.render(<App />);
