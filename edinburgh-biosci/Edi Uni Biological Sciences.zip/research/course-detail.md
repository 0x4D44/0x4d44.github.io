# Course detail + student commentary (distilled, cited)

## BIOLOGY 1A: VARIATION — BILG08020 · Semester 1 · 20 cr · SCQF 8
Organiser: Dr Patrick Walsh. Textbook: Campbell, *Biology: A Global Approach* (11th ed).
**Themes:** genetic basis of heredity · genotype → phenotype · mutation as the source of variation · evolution & natural selection · maintenance of variation · species & speciation · the Tree of Life · animal & plant diversity · form & function. Trained in scientific method, experimental design, data interpretation, presentation, statistics. Explicitly designed to ease the **transition to university**; weekly workshops fold in community-building, compassionate values, mental-health & wellbeing.
**The "no hard facts" ethos:** "Teaching staff will not always present hard facts; sometimes they present an unproven hypothesis, or questions not yet answered."
**Skills:** Excel + **Python**; basic microbiology; field observation & measurement.
**Assessment (official band: Written Exam 25% / Coursework 55% / Practical Exam 20%):**
- Portfolio 25% · Online quizzes 30% · Lab report 20% · Open-book exam 25%
- To pass: exam ≥40%, portfolio ≥40%, lab report ≥40%, **attend ≥4 of 6 practicals**, ≥40% overall.
- Exam: 120 min, **Main Diet S1 (December)**; resit August.
- **This is the ONLY core course with a real written exam.**

## BIOLOGY 1B: LIFE — BILG08021 · Semester 1 · 20 cr
Organiser: Prof Heather McQueen. Co-req: must also take 1A.
**Themes:** the molecular basis of life & the **Central Dogma** · structure & function · information flow · transformations of energy & matter · complexity of biological systems · heavy emphasis on **DNA** and the organisation, division & growth of the **cell**. Structured around "big questions" in biology.
**Assessment: Written Exam 0% / Coursework 90% / Practical Exam 10%. NO written exam.**
- Practical Competency Test (10%) · Portfolio · Two-Part Assessment + Weekly Quizzes (combined) · Group Submissions + Creative Submission + Peerwise (combined). Must pass each strand.
- Hours: Lectures 29h, Practical/Workshop/Studio 54h, Online 17h (total 200h).
- Feedback is "dialogic" — continuous, from staff & demonstrators, peer review, quiz feedback.

## BIOLOGY 1C: DISCOVERY — BILG08022 · Semester 2 · 20 cr
Organiser: Dr David Radford. Co-req: 1A + 1B. Keywords: anti-microbial, antibiotic.
**THE ANTIBIOTIC HUNT.** An extended practical project to **discover potentially novel antibiotics**. First half: labs teach techniques. Second half: an **"open lab"** where students apply techniques to a real research question — *does my chosen sample contain antibiotic activity, and is it likely to be novel?* Lectures/workshops give the theory of antimicrobial resistance and "deeper principles of life." Output: a **poster** + a **scientific paper**.
**Assessment: 0% exam / 100% coursework.**
- Quizzes 10% · **Poster (group) 20%** · **Scientific Paper (individual) 45%** · Portfolio (individual) 25%. Pass ICA ≥40% and portfolio ≥40%.
**Skills:** record-keeping, group-work, programming & modelling, scientific communication.

## BIOLOGY 1D: ENVIRONMENT — BILG08023 · Semester 2 · 20 cr
Co-req: 1A + 1B. Theme (from title + programme + the EES degree using it): organisms **in their environment** — ecology, whole-organism & field biology, biodiversity, sampling & measurement. This is the course that leans on **fieldwork**: Royal Botanic Garden Edinburgh, local woodland, the beach, Edinburgh Zoo — recording ideas/observations/results/conclusions.
**Assessment:** in-course / coursework-led (portfolio + fieldwork records/reports + quizzes), in keeping with 1B & 1C (little or no written exam). *(Exact % weightings shift year to year — verify on DRPS cxbilg08023; TODO confirm next turn.)*

## RECOMMENDED OPTIONS
- **Biological Chemistry 1A** (CHEM08022, S1) + **1B** (CHEM08023, S2). No Advanced Higher Chem → take both; strong school chem → 1B alone may suffice. ~3h lab every 2 weeks + weekly tutorial.
- Year 1 is the BEST year for an outside course (any school) if timetable allows.

## THE PATTERN THAT MATTERS (key insight for the labwork guide)
Three of the four core courses are **coursework-/portfolio-/lab-driven with little or no written exam**. You cannot "exam your way" out of practical work here — your grade lives in portfolios, lab reports, posters, a scientific paper, and practical competency. Attendance at practicals is a hard gate (1A: ≥4 of 6). BUT: the lab work is heavily **group-based**, the assessed *outputs* are mostly **writing & analysis** (paper, report, portfolio, data) — which is good news for a theory-leaning brain. The thinking/writing is where the marks are.

---

# STUDENT COMMENTARY (real themes, for honest "Voices" section — synthesize, don't fabricate named quotes)
Sources: Edinburgh Student Stories blog, The Student Room, StudentCrowd, EDUopinions, The Uni Guide, Discover Uni/NSS.

**Liked / positives**
- Flexibility prized: don't specialise too early; all 12 specialisms stay open if you pass. "Choose courses that are new and exciting."
- Staff passionate, approachable, easy to contact (NSS + reviews). Subject made engaging, intellectually stimulating, ideas explored in depth (NSS 2024-25, n=365, 71%).
- Practicals & tutorials "well organised and varied"; "a lot of freedom with course choices."
- Strong community; welcoming; "rarely get homesick." BioPALs peer support well regarded.
- Group work in labs builds friendships + workplace-style collaboration.

**Disliked / criticisms / warnings**
- **"1st year is a bit of a doss if you did maths/sciences at A-level or Highers"** — workload ≈ final year of school, sometimes easier, for strong science applicants. Some wish they'd entered Year 2 directly.
- Very **broad** first year; content can feel **redundant/overlapping** between Y1 and Y2, and re-treads school material across different entry qualifications.
- Some find it **"too memorisation-based"** / less rigorous than expected (mixed views).
- Every lecturer "has their own style, which can throw you off a bit in first year."
- **King's Buildings is a trek** from the central area / town — "based at King's and who can be bothered going there." Logistics & commute are a real grumble.
- Heavy **independent learning** is a step up — "challenging at times."
- The flipped-classroom **interactive sessions** (watch/prep beforehand, discuss in person) catch people out who skip the prep.
- Open days can feel dull/uninformative — judge the course, not the open day.
- Wider context: recent university **budget cuts / strikes** colour some reviews (not Y1-specific).

**Practical "be ready for"**
- ~9 lectures/week S1 (≈3 per module) + 1 × 3h biology practical/week + tutorials; chemistry ≈3h lab every 2 wks + weekly tutorial; a few maths/stats labs.
- Lots of NEW lab techniques, health & safety, new equipment — focus on understanding the technique + the underlying biology, not just the result.
- Numeracy for biologists taught in lectures; Excel + Python coding from the start.
- DO THE PREP for interactive sessions. Communicate in group labs — "two pairs of eyes are better than one."
- Think careers EARLY: societies, CV, summer studentships (esp. before/after Y3 if eyeing a PhD).

**Entry (context):** AAA–ABB; A-level Biology B + Chemistry B, grade A in one of Bio/Chem/Maths/Physics. Top 5 UK / top 20 world (QS 2026).
