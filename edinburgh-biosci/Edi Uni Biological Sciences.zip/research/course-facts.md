# Edinburgh — Biological Sciences BSc (Hons), Year 1 — Research notes

Source: official University of Edinburgh pages (study.ed.ac.uk programme page; biology.ed.ac.uk course options; DRPS). Distilled May 2026.

## Programme shape
- UCAS C100. BSc (Hons), 3 or 4 years, full-time. Taught at **King's Buildings** campus (science & engineering hub, 100+ yrs history).
- **Years 1 & 2 are "pre-honours"** — every Biological Sciences student does the same core, regardless of which of the 12 specialisms they applied to.
- 120 credits/year = 60 credits/semester. Usually **3 courses per semester, 6 over the year**.
- At the end of Year 2 you pick ONE of 12 honours specialisms.
- Top 5 in UK / top 20 in world for biological sciences (QS 2026).

## The 12 honours specialisms (chosen later, but Year 1 samples all)
Biochemistry · Biotechnology · Cell Biology · Development, Regeneration & Stem Cells · Ecology · Evolutionary Biology · Genetics · Immunology · Molecular Biology · Molecular Genetics · Plant Science · Zoology. (Plus Biological Sciences with Management, and the 5-yr MBiol integrated masters.)

## Year 1 COMPULSORY courses (4 × 20 credits = 80 credits)
All coded BILG, SCQF Level 8:
- **Biology 1A: Variation** (BILG08020) — Semester 1
- **Biology 1B: Life** (BILG08021) — Semester 1
- **Biology 1C: Discovery** (BILG08022) — Semester 2
- **Biology 1D: Environment** (BILG08023) — Semester 2

The 1A–1D structure is the "broad base" — between them they touch all 12 subject areas before you specialise. Themes (from programme + course aims): 1A Variation ≈ genetics, variation, evolution, inheritance; 1B Life ≈ cells, molecules, biochemistry of life, how life works at molecular/cellular scale; 1C Discovery ≈ how biological discoveries are made, research skills, the scientific method, data; 1D Environment ≈ ecology, organisms in their environment, whole-organism & field biology.

## Year 1 RECOMMENDED option courses (40 credits)
- **Biological Chemistry 1A** (CHEM08022) — Semester 1
- **Biological Chemistry 1B** (CHEM08023) — Semester 2
- Guidance: chemistry underpins biology. No Advanced Higher Chemistry (or equiv)? Take BOTH 1A and 1B. Strong school chemistry? Just 1B may be enough.
- You CAN take other outside courses instead (Year 1 is the best year for outside courses) — must avoid timetable clashes, be right level, meet prerequisites. Discuss with Student Adviser / Cohort Lead in Welcome Week.
- With Management students take Global Challenges for Business + The Business of Edinburgh instead of Biological Chemistry.

## How it's taught (deliberately NOT lecture-heavy)
"Moved away from the traditional emphasis on lectures" → more facilitated self-directed learning, reflection, practical & workshop classes. Class types mixed each week:
- **Interactive lectures** — pre-work to engage with + reflect on, then in-person participation/discussion (Wooclap etc.).
- **Practical classes** — teaching labs, individual/pairs/small groups, lab coats + materials provided, demonstrators present. Steps given in advance to read.
- **Workshops** — smaller, informal, skills focus: ethics & social issues, academic writing, creative idea presentation, data analysis, coding, scientific software. In workshop rooms or computer labs.
- **Tutorials** — usually only in later years (maybe in Y1 via outside courses).

### Example practical experiments (Y1-ish)
microscopy of specimens · dissections · using microbes to explore evolution · exploring how cells communicate · DNA analysis and insertion into a plasmid.

### Fieldwork in Year 1
Day / half-day trips built into compulsory courses: Royal Botanic Garden Edinburgh, local woodland, the beach, Edinburgh Zoo. Records ideas/observations/results/conclusions.

## Key skills Year 1 explicitly builds
hypothesis development & experimental design · data evaluation & analysis · introductory **coding** · communicating ideas orally & in writing · student-led investigative projects · self-reflection (a **reflective portfolio** runs through the core courses; e.g. write a mock internship application).

## Assessment (mix of in-course + exams; some collaborative)
regular quizzes · group or individual practical reports · problem-solving questions · scientific paper analysis · oral & visual presentations · scientific writing. Final-year has a research project/dissertation (not Y1).

## Sample Year 1 Semester 1 timetable (2025-26)
- **Mon** 9:00 Biol Chem 1A lecture · 10:00–13:00 Biol Chem practical · 14:10 Biology 1A interactive · 15:10 Biology 1B interactive
- **Tue** 10:00–12:00 Biology 1B workshop · 15:10–17:00 Biology 1B interactive
- **Wed** 9:00 Biol Chem 1A lecture · 10:00–13:00 Biology 1B practical
- **Thu** 14:10–17:00 Biology 1A practical
- **Fri** 9:00 Biol Chem 1A lecture · 10:00–12:00 Biology 1A workshop · 14:10 Biology 1A interactive · 15:10 Biol Chem 1A tutorial
(Practical/tutorial/workshop slots run in multiple slots; auto-assigned; some weeks vary / alternate.)

## Support & community
- Each student assigned a **Student Adviser** (first point of contact).
- **BioPALs** — peer-assisted learning; senior students run study sessions for the core Y1 courses + topics like finding internships / flats.
- **Nucleus Building** — heart of King's Buildings: 'turn and learn' lecture theatre, group teaching studios, study space, cafes, shop.
- Buildings: Ashworth (traditional lecture theatres), James Clerk Maxwell Building (modern labs).
- Cost extras: up to £150/yr books; residential field trips £300/trip from 2026/7 (Y1 trips are day trips, free-ish).

## Careers / why it matters
Transferable skills (problem solving, quantitative reasoning, communication, collaboration, time management). Graduates → research (MSc/PhD), lab/industry/conservation, teaching/medicine/vet/law (graduate-entry Medicine possible with 2:1+), science policy (govt/NGO/charity), science communication, finance/management.

## TODO research (next turn — fetch DRPS per-course pages)
- drps.ed.ac.uk/current/dpt/cxbilg08020.htm (1A Variation) — summary, syllabus, assessment %
- ...08021 (1B Life), ...08022 (1C Discovery), ...08023 (1D Environment)
- Student commentary: The Student Room, Reddit r/Edinburgh_University, Unifrog/Whatuni reviews, NSS scores.
- "I hate labwork" angle: how theory-leaning students cope — which courses are most lab-heavy, weighting of lab vs exam, workarounds.
