/* Sections B: A Week in the Life · Assessment · I-Hate-Labwork Survival Guide */
const { useState: useStateB } = React;

function Timetable() {
  const tt = window.BIO.timetable;
  const keys = Object.keys(tt.types);
  const [on, setOn] = useStateB(() => new Set(keys));
  const [sel, setSel] = useStateB(null);
  const toggle = (k) => {
    setOn((prev) => {
      const n = new Set(prev);
      n.has(k) ? n.delete(k) : n.add(k);
      return n;
    });
  };
  const selType = sel ? tt.types[sel] : null;
  return (
    <section className="section" id="week">
      <div className="wrap">
        <SecIntro
          kicker="03 — A week in the life"
          title="Semester 1, hour by hour."
          lead="A real sample first-year timetable. Notice the rhythm: a few traditional 9am chemistry lectures, but mostly interactive sessions, workshops and long practical blocks. Tap a class to see what that type actually involves — or filter by type."
        />

        <Reveal>
          <div className="tt-filters">
            {keys.map((k) => (
              <button key={k} className={on.has(k) ? "" : "off"} onClick={() => toggle(k)}>
                <span className="sw" style={{ background: tt.types[k].c }} />
                {tt.types[k].label}
              </button>
            ))}
          </div>

          <div className="ttgrid">
            {tt.days.map((day) => (
              <div className="ttcol" key={day}>
                <div className="tt__day">{day}</div>
                {tt.grid[day].length === 0 && <div className="tt__empty" />}
                {tt.grid[day].map((b, i) => {
                  const ty = tt.types[b.k];
                  const dim = !on.has(b.k);
                  return (
                    <button
                      key={i}
                      className={`tt__block ${dim ? "dim" : ""}`}
                      style={{ background: ty.c }}
                      onClick={() => setSel(b.k)}
                    >
                      <span className="tt__bk">{b.h}</span>
                      <span className="tt__bt">{b.t}</span>
                      <span className="tt__bk">{ty.label}</span>
                    </button>
                  );
                })}
              </div>
            ))}
          </div>

          {selType ? (
            <div className="callout" style={{ "--accent": selType.c, marginTop: 24 }}>
              <b style={{ color: selType.c }}>{selType.label}</b>
              {selType.desc}
            </div>
          ) : (
            <p className="tt-note">
              Tip — practical, workshop and tutorial slots run in several slots each week; you're auto-assigned to one.
              Some classes run fortnightly. First-year students typically have ~9 lectures a week across their three courses.
            </p>
          )}
        </Reveal>
      </div>
      <style>{`
        .ttgrid{display:grid;grid-template-columns:repeat(5,1fr);gap:8px;}
        .ttcol{display:flex;flex-direction:column;gap:8px;}
        @media(max-width:760px){.ttgrid{grid-template-columns:1fr;gap:6px;}
          .ttcol{margin-bottom:10px;}}
      `}</style>
    </section>
  );
}

function Assessment() {
  const diet = [
    { nm: "Reflective portfolio", who: "1A · 1B · 1C · 1D", d: "A running record of your learning and growth — the spine of the whole core year.", c: "var(--forest-2)" },
    { nm: "Scientific paper", who: "1C", d: "Write up your antibiotic project like a real researcher. 45% of the course.", c: "var(--c-1c)" },
    { nm: "Lab report", who: "1A", d: "Turn an experiment into a structured, evidenced write-up.", c: "var(--c-1a)" },
    { nm: "Online quizzes", who: "1A · 1B · 1C", d: "Frequent, low-stakes checks that keep you honest week to week.", c: "var(--c-1d)" },
    { nm: "Poster (group)", who: "1C", d: "Present your findings visually — collaboration, marked.", c: "var(--c-1c)" },
    { nm: "Practical competency", who: "1B", d: "A hands-on test that you can do the core lab techniques.", c: "var(--c-1b)" },
    { nm: "Open-book exam", who: "1A", d: "The year's one written exam — 120 minutes, December.", c: "var(--ink)" },
    { nm: "Fieldwork records", who: "1D", d: "Observations and data gathered out in the field, then analysed.", c: "var(--c-1d)" },
  ];
  return (
    <section className="section" id="assess" style={{ background: "var(--paper-2)" }}>
      <div className="wrap">
        <SecIntro
          kicker="04 — How you're really marked"
          title="Forget the three-hour exam hall."
          lead="Edinburgh's core year is overwhelmingly continuous assessment. That changes everything about how you should play it — and it's the single most important thing to understand before September."
        />

        <Reveal>
          <div className="ass-head">
            <div className="ass-stat">
              <div className="stat__n" style={{ color: "var(--c-1a)" }}>1<span style={{ fontSize: ".4em" }}> / 4</span></div>
              <div className="stat__l">core courses with a written exam</div>
            </div>
            <div className="ass-stat">
              <div className="stat__n" style={{ color: "var(--c-1b)" }}>100%</div>
              <div className="stat__l">continuous assessment in 1B, 1C &amp; 1D</div>
            </div>
            <div className="ass-stat">
              <div className="stat__n" style={{ color: "var(--c-1c)" }}>45%</div>
              <div className="stat__l">of 1C is a single scientific paper</div>
            </div>
          </div>
        </Reveal>

        <Reveal style={{ marginTop: 38 }}>
          <div className="minihd">The assessment diet you'll meet</div>
          <div className="ass-grid">
            {diet.map((a, i) => (
              <div className="card" key={i} style={{ borderLeft: `3px solid ${a.c}` }}>
                <div style={{ display: "flex", justifyContent: "space-between", alignItems: "baseline", gap: 10 }}>
                  <h4 style={{ fontSize: "1.18rem" }}>{a.nm}</h4>
                  <span className="mono" style={{ fontSize: ".62rem", color: "var(--sage)", whiteSpace: "nowrap" }}>{a.who}</span>
                </div>
                <p style={{ margin: "8px 0 0", fontSize: ".9rem", color: "var(--ink-soft)" }}>{a.d}</p>
              </div>
            ))}
          </div>
        </Reveal>

        <Reveal style={{ marginTop: 30 }}>
          <div className="callout" style={{ "--accent": "var(--c-1b)", background: "var(--paper)", fontSize: "1.05rem" }}>
            <b>The takeaway</b>
            You can't cram your way through this year — but you also can't be saved or sunk by one bad afternoon.
            The marks are spread across writing, analysis and reflection done <em>over time</em>. Steady, organised effort beats last-minute brilliance.
          </div>
        </Reveal>
      </div>
      <style>{`
        .ass-head{display:grid;grid-template-columns:repeat(3,1fr);gap:18px;}
        .ass-stat{background:var(--paper);border:1px solid var(--line);border-radius:var(--r);padding:24px;}
        .ass-grid{display:grid;grid-template-columns:repeat(4,1fr);gap:14px;margin-top:14px;}
        @media(max-width:900px){.ass-grid{grid-template-columns:repeat(2,1fr);}}
        @media(max-width:680px){.ass-head{grid-template-columns:1fr;}.ass-grid{grid-template-columns:1fr;}}
      `}</style>
    </section>
  );
}

function SurvivalGuide() {
  const g = window.BIO;
  return (
    <section className="section section--dark" id="labwork">
      <div className="wrap">
        <Reveal className="surv-hd">
          <div className="eyebrow-row">
            <span className="kicker">05 — Survival kit</span>
            <span className="rule" />
          </div>
          <h2 className="h2" style={{ color: "var(--paper)" }}>
            The “I Hate Labwork”<br /><em style={{ color: "var(--lime)" }}>survival guide.</em>
          </h2>
          <p className="lead">
            Some people light up at a pipette. Others would rather wrestle an idea than a centrifuge.
            Good news: this degree has far more room for the second type than the prospectus lets on.
            Here's how a theory-first brain not only survives the practical year — but quietly thrives.
          </p>
        </Reveal>

        <Reveal>
          <div className="minihd" style={{ color: "#A9BCA2" }}>How bench-heavy is each core course, really?</div>
          <div className="gauge">
            {g.gauges.map((x, i) => (
              <div className="gcard" key={i}>
                <div className="gcard__lab">{x.nm}</div>
                <div className="gcard__nm" style={{ color: x.c }}>{x.lab}%</div>
                <div className="meter"><div className="meter__fill" style={{ width: x.lab + "%", background: x.c }} /></div>
                <div className="gcard__cap">{x.cap}</div>
              </div>
            ))}
          </div>
          <p className="mono" style={{ fontSize: ".7rem", color: "#8FA288", marginTop: -10 }}>
            ▲ Time at the bench, roughly. Note how little of it converts directly into marks.
          </p>
        </Reveal>

        <Reveal style={{ marginTop: 44 }}>
          <div className="truth">
            <div className="truth__a">
              <span className="kicker" style={{ color: "#A9BCA2" }}>The myth</span>
              <h3 style={{ color: "var(--paper)", marginTop: 12 }}>{g.truth.myth}</h3>
            </div>
            <div className="truth__b">
              <span className="kicker" style={{ color: "var(--forest)" }}>The reality</span>
              <p style={{ margin: "12px 0 0", fontSize: "1.02rem", lineHeight: 1.5 }}>{g.truth.reality}</p>
            </div>
          </div>
        </Reveal>

        <Reveal style={{ marginTop: 44 }}>
          <div className="minihd" style={{ color: "#A9BCA2" }}>Six tactics that actually work</div>
          <div className="tactics">
            {g.tactics.map((t, i) => (
              <div className="tactic" key={i}>
                <div className="tactic__n">{t.n}</div>
                <h4>{t.h}</h4>
                <p>{t.d}</p>
                <span className="tactic__tag">{t.tag}</span>
              </div>
            ))}
          </div>
        </Reveal>
      </div>
    </section>
  );
}

Object.assign(window, { Timetable, Assessment, SurvivalGuide });
