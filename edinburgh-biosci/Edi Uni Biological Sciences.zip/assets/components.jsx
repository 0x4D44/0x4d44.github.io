/* Shared components + hooks. Exported to window for cross-file use. */
const { useState, useEffect, useRef, useCallback } = React;

/* Reveal on scroll */
function Reveal({ children, className = "", as = "div", style }) {
  const ref = useRef(null);
  const [seen, setSeen] = useState(false);
  useEffect(() => {
    const el = ref.current;
    if (!el) return;
    // Show immediately if already in (or near) the viewport on mount.
    const r = el.getBoundingClientRect();
    if (r.top < window.innerHeight * 0.92) { setSeen(true); return; }
    if (typeof IntersectionObserver === "undefined") { setSeen(true); return; }
    const io = new IntersectionObserver(
      ([e]) => { if (e.isIntersecting) { setSeen(true); io.disconnect(); } },
      { threshold: 0.12, rootMargin: "0px 0px -8% 0px" }
    );
    io.observe(el);
    // Safety net: never leave content invisible.
    const t = setTimeout(() => setSeen(true), 1200);
    return () => { io.disconnect(); clearTimeout(t); };
  }, []);
  const Tag = as;
  return (
    <Tag ref={ref} style={style} className={`reveal ${seen ? "in" : ""} ${className}`}>
      {children}
    </Tag>
  );
}

/* Section eyebrow + heading block */
function SecIntro({ kicker, title, lead, dark }) {
  return (
    <Reveal className="sec-intro">
      <div className="eyebrow-row">
        <span className="kicker">{kicker}</span>
        <span className="rule" />
      </div>
      <h2 className="h2" dangerouslySetInnerHTML={{ __html: title }} />
      {lead && <p className="lead">{lead}</p>}
    </Reveal>
  );
}

/* Assessment stacked bar + legend */
function AssessmentBar({ items, accent }) {
  return (
    <div>
      <div className="abar">
        {items.map((s, i) => (
          <div key={i} className="abar__seg" style={{ flex: s.pct, background: s.c }} title={`${s.l} — ${s.pct}%`}>
            {s.pct >= 18 ? `${s.pct}%` : ""}
          </div>
        ))}
      </div>
      <div className="aleg">
        {items.map((s, i) => (
          <div key={i} className="aleg__row">
            <span className="aleg__sw" style={{ background: s.c }} />
            <span>{s.l}</span>
            <span className="aleg__pct">{s.pct}%</span>
          </div>
        ))}
      </div>
    </div>
  );
}

/* Scroll-spy: returns id of section currently in view */
function useScrollSpy(ids) {
  const [active, setActive] = useState(ids[0]);
  useEffect(() => {
    const handler = () => {
      const y = window.scrollY + window.innerHeight * 0.35;
      let cur = ids[0];
      for (const id of ids) {
        const el = document.getElementById(id);
        if (el && el.offsetTop <= y) cur = id;
      }
      setActive(cur);
    };
    handler();
    window.addEventListener("scroll", handler, { passive: true });
    return () => window.removeEventListener("scroll", handler);
  }, [ids.join(",")]);
  return active;
}

const NAV = [
  { id: "top", label: "Top" },
  { id: "shape", label: "The Year" },
  { id: "courses", label: "Core Courses" },
  { id: "week", label: "A Week" },
  { id: "assess", label: "Assessment" },
  { id: "labwork", label: "Labwork Guide" },
  { id: "voices", label: "Voices" },
  { id: "prep", label: "Prep" },
  { id: "paths", label: "12 Paths" },
];

function Nav() {
  const [open, setOpen] = useState(false);
  const active = useScrollSpy(NAV.map((n) => n.id));
  const go = (e, id) => {
    e.preventDefault();
    setOpen(false);
    const el = document.getElementById(id);
    if (el) window.scrollTo({ top: id === "top" ? 0 : el.offsetTop - 60, behavior: "smooth" });
  };
  return (
    <nav className="nav">
      <a href="#top" onClick={(e) => go(e, "top")} className="nav__brand" style={{ textDecoration: "none", color: "inherit" }}>
        <span className="dot" />
        BIOSCI · YEAR ONE
      </a>
      <button className="nav__burger" onClick={() => setOpen((o) => !o)}>
        {open ? "CLOSE" : "MENU"}
      </button>
      <div className={`nav__links ${open ? "open" : ""}`}>
        {NAV.slice(1).map((n) => (
          <a key={n.id} href={`#${n.id}`} onClick={(e) => go(e, n.id)} className={active === n.id ? "active" : ""}>
            {n.label}
          </a>
        ))}
      </div>
    </nav>
  );
}

Object.assign(window, { Reveal, SecIntro, AssessmentBar, useScrollSpy, Nav, NAV });
