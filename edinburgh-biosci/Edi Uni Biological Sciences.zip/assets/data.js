/* =========================================================================
   DATA — Edinburgh Biological Sciences, Year 1.
   All facts sourced from official UoE pages (study.ed.ac.uk, biology.ed.ac.uk,
   DRPS course catalogue 2026/27) + student commentary (Student Stories blog,
   The Student Room, StudentCrowd, EDUopinions, NSS/Discover Uni).
   ========================================================================= */
window.BIO = {

  stats: [
    { n: "4", l: "Compulsory core courses" },
    { n: "120", l: "Credits across the year" },
    { n: "12", l: "Specialisms kept open" },
    { n: "Top 5", l: "In the UK (QS 2026)" },
  ],

  courses: [
    {
      id: "1a", code: "BILG08020", num: "1A", name: "Variation",
      sem: "Semester 1", hue: "var(--c-1a)",
      latin: "the origin of difference",
      tagline: "Where life's diversity comes from — and the only core course with a real exam.",
      lead: "The genetic engine of life. How heredity works, how mutation feeds variation, and how natural selection shapes everything from a single gene to the whole Tree of Life. It's also deliberately built to ease you into university — workshops fold in community-building and wellbeing alongside the science.",
      themes: [
        "Genetic basis of heredity; genotype → phenotype",
        "Mutation as the raw source of variation",
        "Evolution, natural selection & how variation is maintained",
        "Species, speciation & the Tree of Life",
        "Animal & plant diversity — form and function",
        "The scientific method, experimental design & statistics",
      ],
      doing: "Field trips and practicals teach you to observe, measure and keep a proper research record. You'll start coding in Excel and Python for 'numeracy for biologists'. Expect lecturers to hand you an unproven hypothesis rather than a tidy fact — and ask you what you'd do about it.",
      organiser: "Dr Patrick Walsh",
      assessment: [
        { l: "Online quizzes", pct: 30, c: "var(--c-1a)" },
        { l: "Portfolio", pct: 25, c: "var(--forest-2)" },
        { l: "Open-book exam", pct: 25, c: "var(--ink)" },
        { l: "Lab report", pct: 20, c: "var(--c-1c)" },
      ],
      gates: "Pass gates: exam ≥40%, portfolio ≥40%, lab report ≥40%, attend ≥4 of 6 practicals, ≥40% overall. The December exam is 120 minutes.",
      flag: { t: "The exam one", d: "1A is the single core course with a traditional written exam (open-book, December). If exams are your comfort zone, this is the one that rewards it." },
    },
    {
      id: "1b", code: "BILG08021", num: "1B", name: "Life",
      sem: "Semester 1", hue: "var(--c-1b)",
      latin: "the molecular machine",
      tagline: "Life at molecular scale — and not a single written exam in sight.",
      lead: "Structured around the 'big questions' of biology, Life zooms into DNA, the Central Dogma and the cell. How is information stored and read? How do cells build, divide and grow? How does matter and energy move through living systems? It runs alongside 1A and shares its textbook.",
      themes: [
        "The molecular basis of life & the Central Dogma",
        "DNA: structure, replication, information flow",
        "The cell — organisation, division and growth",
        "Energy & matter transformations in living systems",
        "Structure and function, from molecule to organism",
        "The complexity of biological systems",
      ],
      doing: "Heavy on practicals and workshops (54 hours of them). Feedback is 'dialogic' — a constant back-and-forth with staff, demonstrators and peers via quizzes, peer review and Peerwise. You build a portfolio as you go rather than cramming for a finale.",
      organiser: "Prof Heather McQueen",
      assessment: [
        { l: "Coursework (portfolio, quizzes, group & creative work)", pct: 90, c: "var(--c-1b)" },
        { l: "Practical competency test", pct: 10, c: "var(--ink)" },
      ],
      gates: "No written exam (0%). You must separately pass the portfolio, the practical competency test, the two-part assessment + weekly quizzes, and the group/creative/Peerwise strand.",
      flag: { t: "Zero exams", d: "100% continuous. Brilliant if you hate exam halls — but it means there's nowhere to hide: every week quietly counts toward your grade." },
    },
    {
      id: "1c", code: "BILG08022", num: "1C", name: "Discovery",
      sem: "Semester 2", hue: "var(--c-1c)",
      latin: "the hunt for new antibiotics",
      tagline: "A real research project: go hunting for a brand-new antibiotic.",
      lead: "The standout of the year. You run an extended project to discover a potentially novel antibiotic. The first half of the labs teaches the techniques; the second half is an 'open lab' where you apply them to your own research question — does my sample show antibiotic activity, and is it likely to be new? It ends the way real science does: a poster and a scientific paper.",
      themes: [
        "Antimicrobial resistance — why it's one of biology's big problems",
        "An extended, open-ended discovery project",
        "Lab techniques, then applying them to your own question",
        "Record-keeping & reproducible research",
        "Programming & modelling your data",
        "Scientific communication: poster + paper",
      ],
      doing: "This is biology done for real, not from a recipe. You collect environmental samples, screen them, and follow the result wherever it goes. The marks live in how you think and write it up — a 45% individual scientific paper is the centrepiece.",
      organiser: "Dr David Radford",
      assessment: [
        { l: "Scientific paper (individual)", pct: 45, c: "var(--c-1c)" },
        { l: "Portfolio (individual)", pct: 25, c: "var(--forest-2)" },
        { l: "Poster (group)", pct: 20, c: "var(--c-1d)" },
        { l: "Quizzes", pct: 10, c: "var(--ink)" },
      ],
      gates: "100% in-course assessment, no exam. You must pass the in-course assessment (≥40%) and the portfolio (≥40%).",
      flag: { t: "Where writers win", d: "The biggest single chunk of marks (45%) is a written scientific paper. Strong at structuring an argument? This course is built for you." },
    },
    {
      id: "1d", code: "BILG08023", num: "1D", name: "Environment",
      sem: "Semester 2", hue: "var(--c-1d)",
      latin: "life in its place",
      tagline: "Out of the lab and into the field — ecology, organisms and their world.",
      lead: "Environment widens the lens from molecules to whole organisms and ecosystems. How do living things interact with each other and their surroundings? This is the most field-driven core course — expect trips to the Royal Botanic Garden, local woodland, the beach and Edinburgh Zoo, learning to sample, measure and record like an ecologist.",
      themes: [
        "Organisms in their environment — ecology in practice",
        "Biodiversity, sampling & field measurement",
        "Interactions: competition, adaptation, populations",
        "Whole-organism biology across the kingdoms",
        "Recording observations, results & conclusions",
        "Connecting field data back to biological theory",
      ],
      doing: "The fieldwork course. You'll be outdoors at Edinburgh's living laboratories — the Botanics, the coast, the Zoo — building the observational discipline that underpins ecology, then turning what you gather into analysis.",
      organiser: "School of Biological Sciences",
      assessment: [
        { l: "Coursework, fieldwork records & portfolio", pct: 100, c: "var(--c-1d)" },
      ],
      gates: "In-course assessed, built around fieldwork, data analysis and a portfolio (in keeping with 1B & 1C). Exact weightings shift year to year — confirm on the DRPS course page when you enrol.",
      flag: { t: "Fresh air, real records", d: "The least lab-bench-bound core course — but the field notebook IS the assessment. Theory people often warm to it once they see it's about pattern-spotting and analysis." },
    },
  ],

  // Sample Year 1, Semester 1 timetable (official, 2025-26). type keys map to legend.
  timetable: {
    days: ["Mon", "Tue", "Wed", "Thu", "Fri"],
    types: {
      interactive: { label: "Interactive session", c: "var(--c-1b)", desc: "Flipped classroom: watch/read prep beforehand, then discuss, question and apply it in person. Skip the prep and you'll be lost." },
      workshop: { label: "Workshop", c: "var(--c-1c)", desc: "Small, informal, skills-focused — ethics, academic writing, data analysis, coding, presenting ideas. Lots of group work." },
      practical: { label: "Practical / lab", c: "var(--c-1a)", desc: "Teaching lab in pairs or small groups. Steps given in advance; lab coats and demonstrators provided. ~3 hours." },
      lecture: { label: "Lecture", c: "var(--c-1d)", desc: "Often interactive, with digital tools. Biological Chemistry keeps the more traditional 9am lecture slot." },
      tutorial: { label: "Tutorial", c: "var(--forest-2)", desc: "Smaller group, problem-solving and discussion — mostly attached to your chemistry / outside courses in Year 1." },
    },
    // each cell: {t:title, k:typeKey, h:hourLabel}
    grid: {
      Mon: [
        { t: "Biological Chemistry 1A", k: "lecture", h: "09:00" },
        { t: "Biological Chemistry", k: "practical", h: "10:00–13:00" },
        { t: "Biology 1A: Variation", k: "interactive", h: "14:10" },
        { t: "Biology 1B: Life", k: "interactive", h: "15:10" },
      ],
      Tue: [
        { t: "Biology 1B: Life", k: "workshop", h: "10:00–12:00" },
        { t: "Biology 1B: Life", k: "interactive", h: "15:10–17:00" },
      ],
      Wed: [
        { t: "Biological Chemistry 1A", k: "lecture", h: "09:00" },
        { t: "Biology 1B: Life", k: "practical", h: "10:00–13:00" },
      ],
      Thu: [
        { t: "Biology 1A: Variation", k: "practical", h: "14:10–17:00" },
      ],
      Fri: [
        { t: "Biological Chemistry 1A", k: "lecture", h: "09:00" },
        { t: "Biology 1A: Variation", k: "workshop", h: "10:00–12:00" },
        { t: "Biology 1A: Variation", k: "interactive", h: "14:10" },
        { t: "Biological Chemistry 1A", k: "tutorial", h: "15:10" },
      ],
    },
  },

  // 'lab intensity' gauges per course for the survival guide
  gauges: [
    { nm: "1A Variation", lab: 45, c: "var(--c-1a)", cap: "Some practicals + field trips, but balanced by an exam and quizzes." },
    { nm: "1B Life", lab: 70, c: "var(--c-1b)", cap: "54 hrs of practicals/workshops — hands-on, but graded on write-ups." },
    { nm: "1C Discovery", lab: 85, c: "var(--c-1c)", cap: "An entire lab-based project — yet 70% of marks are writing." },
    { nm: "1D Environment", lab: 40, c: "var(--c-1d)", cap: "Fieldwork over bench-work; it's notebooks and analysis, not pipettes." },
  ],

  tactics: [
    { n: "Tactic 01", h: "The marks live in the write-up", d: "Across the core year, most of your grade comes from papers, portfolios, posters and reports — not from pipetting accuracy. The lab is where you gather; the marks are won at the desk. Lean into that.", tag: "Reframe" },
    { n: "Tactic 02", h: "Be the brains of the bench pair", d: "Labs are deliberately group work. Pair up with someone who loves the hands-on bit, and own the design, the data analysis and the writing. Both of you play to type — and it's encouraged, not cheating.", tag: "Strategy" },
    { n: "Tactic 03", h: "Attendance is a hard gate, not a grade", d: "You must show up (1A needs ≥4 of 6 practicals). But turning up ≠ being graded on dexterity. Clear the attendance bar, then pour your energy into the assessed thinking.", tag: "Logistics" },
    { n: "Tactic 04", h: "Do the prep — religiously", d: "Interactive sessions are flipped: the real learning is the reading you do first. Theory-minded students who prep walk in already ahead. It's the closest thing to 'studying your way through'.", tag: "Habit" },
    { n: "Tactic 05", h: "Befriend code early", d: "Excel and Python show up from week one. For a theory brain this is friendly territory — modelling and stats reward logic, not steady hands. Get comfortable and a chunk of the year becomes a strength.", tag: "Skill" },
    { n: "Tactic 06", h: "Aim toward the theory specialisms", d: "By the end of Year 2 you choose your path. Genetics, Biochemistry, Molecular Biology and Evolutionary Biology lean conceptual; Ecology, Zoology and Plant Science lean field/lab. Year 1 keeps every door open — pick with your strengths in mind.", tag: "Long game" },
  ],

  truth: {
    myth: "“I'll just power through the labs and ace the exams.”",
    reality: "Three of the four core courses have NO written exam. You can't exam your way out of the practical year — but you also don't need steady hands to win it. The assessed output is overwhelmingly analysis and scientific writing. A theory-leaning student who writes well and preps hard is, quietly, in the perfect position.",
  },

  voices: [
    { t: "1st year is a bit of a doss if you did maths or sciences at A-level or Highers — the workload felt about the same as my last year of school.", who: "4th-year, Molecular Genetics", tone: "warn", src: "The Student Room" },
    { t: "The staff are genuinely passionate and approachable — but every lecturer has their own style, which can throw you off a bit in first year.", who: "BSc student", tone: "mixed", src: "StudentCrowd" },
    { t: "There's a big focus on group work in the labs and workshops. Two pairs of eyes really are better than one.", who: "1st-year, Biological Sciences", tone: "like", src: "Edinburgh Student Stories" },
    { t: "Coming to Edinburgh has been one of the best decisions of my life. The people are so welcoming you rarely get homesick.", who: "BSc student", tone: "like", src: "StudentCrowd" },
    { t: "First year felt very broad — and some content gets repeated between first and second year.", who: "MBiol student", tone: "warn", src: "The Uni Guide" },
    { t: "Highly interactive, with lots of hands-on experience — but there's a lot of independent learning, which can be challenging at times.", who: "Biotechnology student", tone: "mixed", src: "EDUopinions" },
    { t: "Practicals and tutorials are well organised and varied, and there's a lot of freedom with course choices.", who: "Biochemistry student", tone: "like", src: "StudentCrowd" },
    { t: "Everything's based at King's Buildings — and it's a fair trek from the centre of town. Factor the commute in.", who: "BSc student", tone: "warn", src: "StudentCrowd" },
    { t: "Watch pre-recorded material and take notes before each interactive session — the in-person time is for questions and examples, not first contact with the topic.", who: "Senior student", tone: "tip", src: "Edinburgh Student Stories" },
    { t: "Think about careers sooner than you'd expect — join societies, build your CV, and look at summer studentships early.", who: "4th-year, Molecular Genetics", tone: "tip", src: "The Student Room" },
    { t: "Staff make the subject engaging and the course is intellectually stimulating — lots of chances to explore ideas in depth.", who: "Final-year survey (NSS 2024–25)", tone: "like", src: "Discover Uni / NSS" },
    { t: "Focus on understanding the lab techniques and the basic biology — not just getting a 'right' answer out of the experiment.", who: "1st-year, Biological Sciences", tone: "tip", src: "Edinburgh Student Stories" },
  ],

  prep: [
    { t: "Brush up the Central Dogma", d: "DNA → RNA → protein. 1B leans on it hard from week one." },
    { t: "Get the Campbell textbook", d: "‘Biology: A Global Approach’, 11th ed — the core text across 1A, 1B and 1C. Library copies exist." },
    { t: "Try a little Python", d: "A free intro course over summer makes 'numeracy for biologists' feel like a head start, not a shock." },
    { t: "Refresh basic chemistry", d: "If you didn't do Advanced Higher / A-level Chem, take both Biological Chemistry 1A & 1B — it underpins everything." },
    { t: "Sort King's Buildings logistics", d: "Most teaching is at King's, not central campus. Plan the bus route and budget the commute time." },
    { t: "Pack for fieldwork", d: "1D goes outdoors — waterproofs and sturdy shoes for the Botanics, the coast and beyond." },
    { t: "Practise reading a paper", d: "Skim one open-access biology paper. Noticing structure (intro/methods/results) pays off fast in 1C." },
    { t: "Plan to actually attend", d: "Practical attendance is a hard pass/fail gate (1A: ≥4 of 6). Treat labs as non-negotiable from day one." },
  ],

  paths: [
    { n: "01", nm: "Biochemistry", d: "Life's chemistry, at the molecular level.", lean: "theory" },
    { n: "02", nm: "Biotechnology", d: "Engineering biology for real-world use.", lean: "mix" },
    { n: "03", nm: "Cell Biology", d: "How cells build, signal and divide.", lean: "mix" },
    { n: "04", nm: "Dev, Regen & Stem Cells", d: "From single cell to whole organism.", lean: "mix" },
    { n: "05", nm: "Ecology", d: "Organisms, populations and ecosystems.", lean: "field" },
    { n: "06", nm: "Evolutionary Biology", d: "The deep history and logic of life.", lean: "theory" },
    { n: "07", nm: "Genetics", d: "Genes, inheritance and variation.", lean: "theory" },
    { n: "08", nm: "Immunology", d: "How bodies defend themselves.", lean: "mix" },
    { n: "09", nm: "Molecular Biology", d: "The machinery of DNA and proteins.", lean: "theory" },
    { n: "10", nm: "Molecular Genetics", d: "Genes read at molecular resolution.", lean: "theory" },
    { n: "11", nm: "Plant Science", d: "The biology that feeds the planet.", lean: "field" },
    { n: "12", nm: "Zoology", d: "Animal form, function and behaviour.", lean: "field" },
  ],

  careers: [
    { h: "Research", items: ["MSc / PhD study", "Lab & field research", "Research institutes"] },
    { h: "Industry", items: ["Biotech & pharma", "Lab technician roles", "Conservation"] },
    { h: "Professions", items: ["Graduate-entry Medicine", "Veterinary medicine", "Teaching, law"] },
    { h: "Beyond the bench", items: ["Science policy & NGOs", "Science communication", "Finance & management"] },
  ],
};
