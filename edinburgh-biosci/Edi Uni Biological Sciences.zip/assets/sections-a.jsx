/* Sections A: Hero · Shape of the year · Course explorer */
const { useState: useStateA, useEffect: useEffectA } = React;

function Hero() {
  return (
    <header className="hero" id="top">
      <div className="hero__grain" />
      <div className="hero__taxon" aria-hidden="true">
        Animalia<br />Plantae<br />Fungi<br />Protista<br />Bacteria<br />Archaea
      </div>
      <div className="wrap">
        <Reveal>
          <span className="kicker hero__kick">University of Edinburgh · School of Biological Sciences</span>
          <h1>
            First Year,<br />decoded —<br /><span className="it">Biological Sciences.</span>
          </h1>
          <p className="hero__sub">
            A field guide to the year ahead: the four core courses, what you'll actually
            <em> do</em> each week, how you're really marked, and an honest survival kit for
            anyone who'd rather think than pipette.
          </p>
          <div className="hero__meta">
            <span><b>4</b> core courses</span>
            <span><b>120</b> credits</span>
            <span><b>2</b> semesters</span>
            <span><b>King's Buildings</b> campus</span>
          </div>
        </Reveal>
      </div>
      <a href="#shape" className="hero__scroll" onClick={(e) => { e.preventDefault(); document.getElementById("shape").scrollIntoView({ behavior: "smooth" }); }}>
        <span>Begin</span>
        <span className="ln" />
      </a>
    </header>
  );
}

function Shape() {
  return (
    <section className="section" id="shape">
      <div className="wrap">
        <SecIntro
          kicker="01 — The shape of the year"
          title="One shared foundation,<br/>twelve futures kept open."
          lead="Every Biological Sciences student — whichever specialism they applied to — studies the same core in Years 1 and 2. Pass it, and all twelve honours paths stay open. Year 1 is deliberately broad: a guided tour of the whole of biology before you commit."
        />
        <Reveal>
          <div className="stats">
            {window.BIO.stats.map((s, i) => (
              <div className="stat" key={i}>
                <div className="stat__n">{s.n}</div>
                <div className="stat__l">{s.l}</div>
              </div>
            ))}
          </div>
        </Reveal>

        <Reveal style={{ marginTop: 40 }}>
          <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 26 }} className="shape-cols">
            <div className="card card--raise">
              <div className="minihd" style={{ "--accent": "var(--c-1b)" }}>How it's taught</div>
              <p style={{ margin: 0, fontSize: ".98rem" }}>
                Edinburgh has deliberately moved away from lecture halls full of note-taking.
                Expect <b>interactive (flipped) sessions</b>, hands-on <b>practicals</b>,
                skills <b>workshops</b> and a running <b>reflective portfolio</b>. Most weeks
                you'll work in <b>groups</b>, and you'll start <b>coding</b> almost immediately.
              </p>
            </div>
            <div className="card card--raise">
              <div className="minihd" style={{ "--accent": "var(--c-1c)" }}>The structure</div>
              <p style={{ margin: 0, fontSize: ".98rem" }}>
                120 credits a year, split 60 / 60 across two semesters — usually
                <b> three courses each semester</b>. Four are compulsory Biology cores
                (1A–1D, 20 credits each). The other 40 credits are <b>recommended as
                Biological Chemistry</b>, or an outside course of your choosing.
              </p>
            </div>
          </div>
        </Reveal>
      </div>
      <style>{`@media(max-width:760px){.shape-cols{grid-template-columns:1fr !important;}}`}</style>
    </section>
  );
}

function CourseExplorer() {
  const courses = window.BIO.courses;
  const [active, setActive] = useStateA("1a");
  const c = courses.find((x) => x.id === active);
  return (
    <section className="section section--dark" id="courses">
      <div className="wrap">
        <SecIntro
          dark
          kicker="02 — The four cores"
          title="Biology 1A · 1B · 1C · 1D"
          lead="Four 20-credit courses, taken by every student. Between them they sweep across genetics, molecules, cells, discovery science and ecology — sampling all twelve specialisms before you ever choose one. Pick a course to open it up."
        />
        <Reveal>
          <div className="exp">
            <div className="exp__list">
              {courses.map((co) => (
                <button
                  key={co.id}
                  className={`exp__item ${active === co.id ? "active" : ""}`}
                  onClick={() => setActive(co.id)}
                >
                  <span className="exp__num" style={{ background: co.hue }}>{co.num}</span>
                  <span>
                    <span className="exp__nm">{co.name}</span>
                    <span className="exp__sub">{co.sem} · {co.code}</span>
                  </span>
                </button>
              ))}
            </div>
            <div className="exp__detail" key={c.id} style={{ "--accent": c.hue }}>
              <div className="detail__top">
                <div>
                  <span className="kicker" style={{ color: c.hue }}>Biology {c.num}</span>
                  <h3 className="detail__title">
                    {c.name}
                    <em>{c.latin}</em>
                  </h3>
                </div>
                <div className="speclabel" style={{ minWidth: 190 }}>
                  <div className="hd">Specimen card</div>
                  <dl className="bd">
                    <dt>Code</dt><dd>{c.code}</dd>
                    <dt>Credits</dt><dd>20 · SCQF 8</dd>
                    <dt>When</dt><dd>{c.sem}</dd>
                    <dt>Lead</dt><dd>{c.organiser}</dd>
                  </dl>
                </div>
              </div>
              <p className="detail__lead">{c.lead}</p>

              <div className="detail__grid">
                <div>
                  <div className="minihd">What it covers</div>
                  <ul className="tlist" style={{ "--accent": c.hue }}>
                    {c.themes.map((t, i) => <li key={i}>{t}</li>)}
                  </ul>
                  <div className="minihd" style={{ marginTop: 24 }}>What you'll actually do</div>
                  <p style={{ fontSize: ".96rem", color: "var(--ink-soft)", margin: 0 }}>{c.doing}</p>
                </div>
                <div>
                  <div className="minihd">How you're assessed</div>
                  <AssessmentBar items={c.assessment} />
                  <p className="mono" style={{ fontSize: ".74rem", color: "var(--sage)", marginTop: 14, lineHeight: 1.6 }}>{c.gates}</p>
                  <div className="callout" style={{ "--accent": c.hue }}>
                    <b>{c.flag.t}</b>
                    {c.flag.d}
                  </div>
                </div>
              </div>
            </div>
          </div>
        </Reveal>

        <Reveal style={{ marginTop: 26 }}>
          <div className="card" style={{ background: "rgba(255,255,255,.04)", borderColor: "rgba(255,255,255,.16)", color: "var(--paper)" }}>
            <div className="minihd" style={{ color: "#A9BCA2" }}>The other 40 credits — Biological Chemistry</div>
            <p style={{ margin: 0, color: "#D6E0CF", fontSize: ".98rem" }}>
              Chemistry underpins most of biology, so the School recommends <b className="lat" style={{ fontStyle: "normal", color: "var(--lime)" }}>Biological Chemistry 1A &amp; 1B</b> (CHEM08022 / CHEM08023).
              No Advanced Higher / A-level Chemistry? Take both. Strong school chemistry? <b style={{ color: "var(--lime)" }}>1B alone</b> may be enough.
              Year 1 is also the best time to try a genuinely <b style={{ color: "var(--lime)" }}>outside course</b> from anywhere in the University — if the timetable allows.
            </p>
          </div>
        </Reveal>
      </div>
    </section>
  );
}

Object.assign(window, { Hero, Shape, CourseExplorer });
