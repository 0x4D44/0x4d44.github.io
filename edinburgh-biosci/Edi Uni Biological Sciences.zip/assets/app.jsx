/* Root app — composes the field guide in order. */
function App() {
  return (
    <React.Fragment>
      <Nav />
      <Hero />
      <Shape />
      <CourseExplorer />
      <Timetable />
      <Assessment />
      <SurvivalGuide />
      <Voices />
      <Prep />
      <Paths />
      <Careers />
      <Closing />
    </React.Fragment>
  );
}
ReactDOM.createRoot(document.getElementById("root")).render(<App />);
