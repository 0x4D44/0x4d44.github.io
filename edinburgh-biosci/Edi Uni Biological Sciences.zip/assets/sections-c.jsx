/* Sections C: Voices · Prep checklist · 12 Paths · Careers · Closing */
const { useState: useStateC, useEffect: useEffectC } = React;

const TONES = {
  like: { c: "var(--c-1b)", label: "Liked it" },
  warn: { c: "var(--c-1a)", label: "Be warned" },
  tip:  { c: "var(--c-1c)", label: "Insider tip" },
  mixed:{ c: "var(--c-1d)", label: "Mixed" },
};

function Voices() {
  const v = window.BIO.voices;
  const [filter, setFilter] = useStateC("all");
  const cats = [["all", "Everything"], ["like", "Liked it"], ["warn", "Be warned"], ["tip", "Insider tips"], ["mixed", "Mixed"]];
  return (
    <section className="section" id="voices">
      <div className="wrap">
        <SecIntro
          kicker="06 — Voices from the cohort"
          title="What students actually say."
          lead="Honest themes gathered from Edinburgh student blogs, The Student Room, StudentCrowd, EDUopinions and the National Student Survey — the praise, the grumbles and the tips, unfiltered."
        />
        <Reveal>
          <div className="voices-filter">
            {cats.map(([k, lab]) => (
              <button key={k} className={`chip ${filter === k ? "" : ""}`} onClick={() => setFilter(k)}
                style={filter === k ? { background: "var(--ink)", color: "var(--paper)", borderColor: "var(--ink)", cursor: "pointer" } : { cursor: "pointer", background: "transparent" }}>
                {k !== "all" && <span className="sw" style={{ background: TONES[k].c, width: 8, height: 8, borderRadius: "50%" }} />}
                {lab}
              </button>
            ))}
          </div>
          <div className="vmasonry">
            {v.map((q, i) => {
              const tn = TONES[q.tone];
              const hide = filter !== "all" && filter !== q.tone;
              return (
                <figure className={`quote ${hide ? "hide" : ""}`} key={i}>
                  <div className="quote__txt">{q.t}”</div>
                  <figcaption className="quote__meta">
                    <span className="quote__dot" style={{ background: tn.c }} />
                    {q.who} · <span style={{ color: tn.c }}>{q.src}</span>
                  </figcaption>
                </figure>
              );
            })}
          </div>
        </Reveal>
      </div>
    </section>
  );
}

function Prep() {
  const items = window.BIO.prep;
  const KEY = "edi_biosci_prep_v1";
  const [done, setDone] = useStateC(() => {
    try { return new Set(JSON.parse(localStorage.getItem(KEY) || "[]")); } catch (e) { return new Set(); }
  });
  useEffectC(() => {
    try { localStorage.setItem(KEY, JSON.stringify([...done])); } catch (e) {}
  }, [done]);
  const toggle = (i) => setDone((p) => { const n = new Set(p); n.has(i) ? n.delete(i) : n.add(i); return n; });
  const pct = Math.round((done.size / items.length) * 100);
  return (
    <section className="section" id="prep" style={{ background: "var(--paper-2)" }}>
      <div className="wrap">
        <SecIntro
          kicker="07 — Before September"
          title="A head-start checklist."
          lead="None of this is required — but each one turns a week-one shock into a week-one shrug. Tick them off; your progress saves on this device."
        />
        <Reveal>
          <div style={{ display: "flex", alignItems: "center", gap: 16, marginBottom: 8 }}>
            <div className="prep-bar" style={{ flex: 1, margin: 0 }}>
              <div className="prep-bar__fill" style={{ width: pct + "%" }} />
            </div>
            <span className="mono" style={{ fontSize: ".8rem", color: "var(--sage)", whiteSpace: "nowrap" }}>{done.size}/{items.length} done</span>
          </div>
          <div className="prep" style={{ marginTop: 22 }}>
            {items.map((it, i) => (
              <button key={i} className={`check ${done.has(i) ? "done" : ""}`} onClick={() => toggle(i)}>
                <span className="check__box">{done.has(i) ? "✓" : ""}</span>
                <span>
                  <span className="check__t">{it.t}</span>
                  <span className="check__d" style={{ display: "block" }}>{it.d}</span>
                </span>
              </button>
            ))}
          </div>
        </Reveal>
      </div>
    </section>
  );
}

function Paths() {
  const p = window.BIO.paths;
  const [lean, setLean] = useStateC("all");
  const leans = [["all", "All twelve"], ["theory", "Lean theory"], ["mix", "Balanced"], ["field", "Lean field / lab"]];
  const leanColor = { theory: "var(--c-1b)", mix: "var(--c-1c)", field: "var(--c-1d)" };
  return (
    <section className="section section--dark" id="paths">
      <div className="wrap">
        <SecIntro
          dark
          kicker="08 — Where it leads"
          title="Twelve specialisms, one choice at the end of Year 2."
          lead="You don't pick yet — Year 1 keeps every door open. But it's worth knowing the terrain. Some paths lean conceptual, some lean hands-on and field-based. Filter to see which might suit a theory-first mind."
        />
        <Reveal>
          <div className="voices-filter" style={{ marginBottom: 22 }}>
            {leans.map(([k, lab]) => (
              <button key={k} className="chip" onClick={() => setLean(k)}
                style={lean === k
                  ? { background: "var(--lime)", color: "var(--forest)", borderColor: "var(--lime)", cursor: "pointer" }
                  : { background: "transparent", color: "var(--paper)", borderColor: "rgba(255,255,255,.25)", cursor: "pointer" }}>
                {k !== "all" && <span className="sw" style={{ background: leanColor[k], width: 8, height: 8, borderRadius: "50%" }} />}
                {lab}
              </button>
            ))}
          </div>
          <div className="paths">
            {p.map((x) => {
              const faded = lean !== "all" && lean !== x.lean;
              return (
                <div className="path" key={x.n} style={{ opacity: faded ? 0.28 : 1, transition: "opacity .3s" }}>
                  <span className="path__n">{x.n} · {x.lean === "theory" ? "Theory" : x.lean === "field" ? "Field/Lab" : "Balanced"}</span>
                  <h4>{x.nm}</h4>
                  <div className="path__d">{x.d}</div>
                  <span style={{ position: "absolute", right: 18, bottom: 16, width: 9, height: 9, borderRadius: "50%", background: leanColor[x.lean] }} />
                </div>
              );
            })}
          </div>
        </Reveal>
      </div>
    </section>
  );
}

function Careers() {
  const c = window.BIO.careers;
  return (
    <section className="section" id="careers">
      <div className="wrap">
        <SecIntro
          kicker="09 — After the degree"
          title="A biology degree opens more doors than benches."
          lead="The skills — analysis, quantitative reasoning, communication, collaboration — travel a long way. Edinburgh graduates fan out across research, industry, the professions and well beyond."
        />
        <Reveal>
          <div className="careers">
            {c.map((col, i) => (
              <div className="career" key={i}>
                <h4>{col.h}</h4>
                <ul>{col.items.map((it, j) => <li key={j}>{it}</li>)}</ul>
              </div>
            ))}
          </div>
        </Reveal>
      </div>
    </section>
  );
}

function Closing() {
  return (
    <section className="section closing">
      <div className="wrap">
        <Reveal>
          <span className="kicker" style={{ color: "var(--lime)" }}>One last thing</span>
          <h2 style={{ marginTop: 18 }}>
            Go in <em>curious</em>, not perfect.
          </h2>
          <p className="lead" style={{ maxWidth: "54ch", margin: "0 auto", color: "#D6E0CF" }}>
            The whole year is built to ease you in — community-first workshops, peer mentors (BioPALs),
            advisers, and assessment spread kindly across the weeks. Do the prep, lean into the group work,
            and let the writing carry your strengths. Whichever kind of scientist you are, there's a path here for you.
          </p>
          <div className="signoff">Welcome to King's Buildings.</div>
        </Reveal>
      </div>
      <footer className="footer">
        <div className="wrap">
          Sources: University of Edinburgh — study.ed.ac.uk, School of Biological Sciences (biology.ed.ac.uk),
          DRPS Course Catalogue 2026/27 · student commentary from Edinburgh Student Stories, The Student Room,
          StudentCrowd, EDUopinions and the National Student Survey (Discover Uni).<br />
          An unofficial field guide, made with care. Course details can change year to year — always confirm on the official pages when you enrol.
        </div>
      </footer>
    </section>
  );
}

Object.assign(window, { Voices, Prep, Paths, Careers, Closing });
