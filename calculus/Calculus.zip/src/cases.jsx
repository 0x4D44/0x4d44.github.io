/* eslint-disable no-undef */
// Engineering case studies — each a small SVG glyph + equation + prose.

const RocketIcon = () => (
  <svg className="case-icon" viewBox="0 0 200 110" preserveAspectRatio="xMidYMid meet">
    {/* grid backing */}
    <rect width="200" height="110" fill="none" />
    {/* trajectory arc */}
    <path d="M 15 95 Q 70 95 100 50 T 185 15"
          stroke="rgba(20,32,46,0.4)" strokeWidth="1.2"
          strokeDasharray="3 4" fill="none" />
    {/* exhaust plume */}
    <path d="M 138 38 L 158 60 L 132 52 L 150 70 L 128 60 Z"
          fill="#d94e1f" opacity="0.85" />
    {/* rocket body */}
    <g transform="translate(120 30) rotate(-40)">
      <rect x="0" y="-6" width="36" height="12" fill="#14202e" />
      <polygon points="36,-6 48,0 36,6" fill="#14202e" />
      <rect x="6" y="-9" width="6" height="3" fill="#d94e1f" />
      <polygon points="0,-6 -6,-12 0,-2" fill="#14202e" />
      <polygon points="0,6 -6,12 0,2" fill="#14202e" />
    </g>
    {/* mass marker */}
    <text x="20" y="100" fontFamily="JetBrains Mono" fontSize="9" fill="rgba(20,32,46,0.5)">m₀</text>
    <text x="170" y="32" fontFamily="JetBrains Mono" fontSize="9" fill="rgba(20,32,46,0.5)">m_f</text>
  </svg>
);

const CapIcon = () => (
  <svg className="case-icon" viewBox="0 0 200 110" preserveAspectRatio="xMidYMid meet">
    {/* circuit lines */}
    <path d="M 20 55 H 80 M 120 55 H 180" stroke="#14202e" strokeWidth="1.8" fill="none" />
    {/* capacitor plates */}
    <line x1="85" y1="30" x2="85" y2="80" stroke="#14202e" strokeWidth="3" />
    <line x1="115" y1="30" x2="115" y2="80" stroke="#14202e" strokeWidth="3" />
    {/* charge flow arrows */}
    <path d="M 35 45 L 50 45 L 47 42 M 50 45 L 47 48" stroke="#d94e1f" strokeWidth="1.6" fill="none" />
    <path d="M 150 45 L 165 45 L 162 42 M 165 45 L 162 48" stroke="#d94e1f" strokeWidth="1.6" fill="none" />
    {/* voltage curve overlaid */}
    <path d="M 25 95 Q 60 95 100 75 T 180 65"
          stroke="#d94e1f" strokeWidth="1.6" fill="none" />
    <text x="22" y="98" fontFamily="JetBrains Mono" fontSize="9" fill="rgba(20,32,46,0.55)">V(t)</text>
  </svg>
);

const BeamIcon = () => (
  <svg className="case-icon" viewBox="0 0 200 110" preserveAspectRatio="xMidYMid meet">
    {/* supports */}
    <polygon points="20,80 30,68 40,80" fill="#14202e" />
    <polygon points="160,80 170,68 180,80" fill="#14202e" />
    <line x1="14" y1="80" x2="46" y2="80" stroke="#14202e" strokeWidth="2" />
    <line x1="154" y1="80" x2="186" y2="80" stroke="#14202e" strokeWidth="2" />
    {/* hatched ground */}
    {[0,1,2,3,4,5,6,7].map(i => (
      <line key={"l"+i} x1={14+i*4} y1="84" x2={10+i*4} y2="92" stroke="#14202e" strokeWidth="1"/>
    ))}
    {[0,1,2,3,4,5,6,7].map(i => (
      <line key={"r"+i} x1={154+i*4} y1="84" x2={150+i*4} y2="92" stroke="#14202e" strokeWidth="1"/>
    ))}
    {/* deflected beam (cubic-ish curve) */}
    <path d="M 30 68 Q 100 95 170 68" stroke="#14202e" strokeWidth="3" fill="none" />
    {/* original beam outline */}
    <line x1="30" y1="68" x2="170" y2="68" stroke="rgba(20,32,46,0.25)" strokeDasharray="3 3" />
    {/* load arrow */}
    <path d="M 100 20 V 50 L 96 46 M 100 50 L 104 46" stroke="#d94e1f" strokeWidth="2" fill="none" />
    <text x="106" y="32" fontFamily="JetBrains Mono" fontSize="9" fill="#d94e1f">w(x)</text>
  </svg>
);

const PIDIcon = () => (
  <svg className="case-icon" viewBox="0 0 200 110" preserveAspectRatio="xMidYMid meet">
    {/* setpoint line */}
    <line x1="15" y1="48" x2="185" y2="48" stroke="rgba(20,32,46,0.4)" strokeDasharray="4 4" />
    <text x="15" y="42" fontFamily="JetBrains Mono" fontSize="9" fill="rgba(20,32,46,0.55)">setpoint</text>
    {/* response curve — overshoots then settles */}
    <path d="M 15 95 Q 45 95 65 30 Q 80 18 95 55 Q 115 70 130 45 Q 150 38 185 48"
          stroke="#d94e1f" strokeWidth="2" fill="none" />
    {/* error ticks */}
    {[60, 90, 120].map(x => (
      <line key={x} x1={x} y1="48" x2={x} y2={x===60?30:x===90?55:45}
            stroke="rgba(20,32,46,0.35)" strokeWidth="1" />
    ))}
  </svg>
);

const DescentIcon = () => (
  <svg className="case-icon" viewBox="0 0 200 110" preserveAspectRatio="xMidYMid meet">
    {/* loss surface (parabola-ish) */}
    <path d="M 20 25 Q 100 130 180 25"
          stroke="#14202e" strokeWidth="2" fill="none" />
    {/* descending balls */}
    {[
      {x:42, y:55, r:5},
      {x:62, y:75, r:5},
      {x:82, y:88, r:5},
      {x:100, y:90, r:7},
    ].map((b,i) => (
      <circle key={i} cx={b.x} cy={b.y} r={b.r}
              fill={i===3?"#d94e1f":"rgba(217,78,31,"+(0.25+i*0.2)+")"}
              stroke="#f1ebde" strokeWidth="1.5"/>
    ))}
    {/* gradient arrows */}
    <path d="M 42 65 L 60 80 L 58 76 M 60 80 L 56 80" stroke="rgba(20,32,46,0.5)" strokeWidth="1" fill="none"/>
    <text x="105" y="105" fontFamily="JetBrains Mono" fontSize="9" fill="rgba(20,32,46,0.55)">minimum</text>
  </svg>
);

const DragIcon = () => (
  <svg className="case-icon" viewBox="0 0 200 110" preserveAspectRatio="xMidYMid meet">
    {/* parachute */}
    <path d="M 60 45 Q 100 15 140 45" stroke="#14202e" strokeWidth="2" fill="rgba(217,78,31,0.18)" />
    <line x1="60" y1="45" x2="100" y2="80" stroke="#14202e" strokeWidth="1" />
    <line x1="80" y1="35" x2="100" y2="80" stroke="#14202e" strokeWidth="1" />
    <line x1="100" y1="32" x2="100" y2="80" stroke="#14202e" strokeWidth="1" />
    <line x1="120" y1="35" x2="100" y2="80" stroke="#14202e" strokeWidth="1" />
    <line x1="140" y1="45" x2="100" y2="80" stroke="#14202e" strokeWidth="1" />
    {/* person */}
    <circle cx="100" cy="84" r="4" fill="#14202e" />
    <line x1="100" y1="88" x2="100" y2="98" stroke="#14202e" strokeWidth="2" />
    {/* drag arrows up */}
    <path d="M 50 95 L 50 75 L 47 78 M 50 75 L 53 78" stroke="#d94e1f" strokeWidth="1.6" fill="none"/>
    <path d="M 150 95 L 150 75 L 147 78 M 150 75 L 153 78" stroke="#d94e1f" strokeWidth="1.6" fill="none"/>
    {/* gravity */}
    <path d="M 165 30 L 165 50 L 162 47 M 165 50 L 168 47" stroke="rgba(20,32,46,0.5)" strokeWidth="1.4" fill="none"/>
    <text x="170" y="42" fontFamily="JetBrains Mono" fontSize="9" fill="rgba(20,32,46,0.55)">mg</text>
  </svg>
);

const CASES = [
  {
    num: "01",
    icon: RocketIcon,
    title: <>How <em>rockets</em> climb out of gravity</>,
    eq: <>Δv = v<sub>e</sub> · ln(m₀ / m<sub>f</sub>)</>,
    body: <>
      Tsiolkovsky's rocket equation comes from integrating thrust over time
      while mass keeps falling. Every kilogram of propellant burned changes
      the mass, which changes the acceleration, which changes the velocity —
      a tangled feedback that calculus straightens out into a single log.
      It's why Falcon&nbsp;9 first stages are mostly fuel.
    </>,
  },
  {
    num: "02",
    icon: CapIcon,
    title: <>Why your phone needs <em>capacitors</em></>,
    eq: <><span className="v">I</span> = C · dV/dt</>,
    body: <>
      A capacitor's current is the derivative of its voltage. Smooth power?
      Big capacitor. Sharp clock edge? Small capacitor. Every PCB on Earth
      is a calligraphy of derivatives — inductors integrate current, resistors
      hold the line, and silicon decides which derivative wins.
    </>,
  },
  {
    num: "03",
    icon: BeamIcon,
    title: <>Why <em>bridges</em> don't sag</>,
    eq: <>EI · d⁴y/dx⁴ = w(x)</>,
    body: <>
      Structural engineers integrate distributed load <em>four times</em>
      to get a beam's deflection: load → shear → moment → slope → shape.
      Each integration adds one unknown — usually pinned by a boundary
      condition at a support. Get one wrong and the floor starts to bounce.
    </>,
  },
  {
    num: "04",
    icon: PIDIcon,
    title: <>How <em>cruise control</em> holds the line</>,
    eq: <>u(t) = K<sub>p</sub>·e + K<sub>i</sub>·∫e + K<sub>d</sub>·de/dt</>,
    body: <>
      PID controllers are calculus condensed to three knobs. <em>P</em> reacts
      to the current error. <em>I</em> integrates past error to kill steady-state
      drift. <em>D</em> anticipates the future from the slope. Tune those three
      and you control thermostats, drones, espresso machines, hospital ventilators.
    </>,
  },
  {
    num: "05",
    icon: DescentIcon,
    title: <>How <em>AI</em> learns anything</>,
    eq: <>θ ← θ − η · ∇L(θ)</>,
    body: <>
      Training a neural network is rolling downhill on a billion-dimensional
      derivative. The gradient ∇L points uphill in loss-space; step the
      opposite way; repeat a few trillion times. Backpropagation is the
      chain rule wearing a hoodie. GPT, Stable Diffusion, your car's
      lane-keeping — all of it.
    </>,
  },
  {
    num: "06",
    icon: DragIcon,
    title: <>Why <em>skydivers</em> stop accelerating</>,
    eq: <>m · dv/dt = mg − k·v²</>,
    body: <>
      A falling body's velocity is a differential equation: gravity adds
      speed, drag subtracts proportional to v². The two cancel at terminal
      velocity. Calculus tells you when, how fast, and how soon to pop the
      chute. The same equation, retuned, designs car spoilers and wind
      turbines.
    </>,
  },
];

function Cases() {
  return (
    <div className="cases">
      {CASES.map(c => {
        const Icon = c.icon;
        return (
          <article className="case" key={c.num}>
            <Icon />
            <div className="case-num">CASE {c.num}</div>
            <h4>{c.title}</h4>
            <code className="eq">{c.eq}</code>
            <p>{c.body}</p>
          </article>
        );
      })}
    </div>
  );
}

Object.assign(window, { Cases });
