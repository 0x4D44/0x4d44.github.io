/* eslint-disable no-undef */
// Interactive demos: HeroSimulator, DerivativeLab, IntegralLab
// All share a logical→SVG coordinate helper.

const { useState, useEffect, useRef, useMemo } = React;

// Logical chart space: x ∈ [0,10], y ∈ [0,5]
const CW = 600, CH = 450;
const PAD_L = 40, PAD_R = 20, PAD_T = 20, PAD_B = 36;
const XS = (CW - PAD_L - PAD_R) / 10;       // x scale
const YS = (CH - PAD_T - PAD_B) / 5;        // y scale
const sx = (x) => PAD_L + x * XS;
const sy = (y) => CH - PAD_B - y * YS;

// Numeric derivative
const deriv = (f, x, h = 0.001) => (f(x + h) - f(x - h)) / (2 * h);

// Definite integral by trapezoid (high resolution, treated as truth)
const trueIntegral = (f, a = 0, b = 10, n = 4000) => {
  const dx = (b - a) / n;
  let s = (f(a) + f(b)) / 2;
  for (let i = 1; i < n; i++) s += f(a + i * dx);
  return s * dx;
};

// Curve catalogue
const CURVES = {
  sine:  { label: "sin", expr: "2 + 1.2·sin(0.7x)",
           f: (x) => 2 + 1.2 * Math.sin(0.7 * x) },
  cubic: { label: "cubic", expr: "0.015(x−2)(x−5)(x−8) + 2.5",
           f: (x) => 0.015 * (x - 2) * (x - 5) * (x - 8) + 2.5 },
  hill:  { label: "parabola", expr: "3.6 − 0.12(x−5)²",
           f: (x) => 3.6 - 0.12 * (x - 5) ** 2 },
};

const AREA_CURVES = {
  bump: { label: "bump",  expr: "0.6 + 2·e^(−((x−5)/2)²)",
          f: (x) => 0.6 + 2 * Math.exp(-(((x - 5) / 2) ** 2)) },
  ramp: { label: "ramp",  expr: "0.4 + 0.3x",
          f: (x) => 0.4 + 0.3 * x },
  wave: { label: "wave",  expr: "2 + sin(0.8x)",
          f: (x) => 2 + Math.sin(0.8 * x) },
};

// Build path "d" string for a function over [0,10]
function pathFor(f, samples = 240) {
  let d = "";
  for (let i = 0; i <= samples; i++) {
    const x = (i / samples) * 10;
    const y = Math.max(0, Math.min(5, f(x)));
    d += (i === 0 ? "M" : "L") + sx(x).toFixed(1) + "," + sy(y).toFixed(1) + " ";
  }
  return d;
}

// ── Reusable axes / grid ───────────────────────────────────
function Axes({ showYAxis = true, tickedX = true }) {
  const xTicks = [0, 2, 4, 6, 8, 10];
  const yTicks = [0, 1, 2, 3, 4, 5];
  return (
    <g>
      {/* gridlines */}
      {xTicks.map(t => (
        <line key={"vx"+t} x1={sx(t)} y1={sy(0)} x2={sx(t)} y2={sy(5)}
              stroke="rgba(20,32,46,0.06)" strokeWidth="1" />
      ))}
      {yTicks.map(t => (
        <line key={"hy"+t} x1={sx(0)} y1={sy(t)} x2={sx(10)} y2={sy(t)}
              stroke="rgba(20,32,46,0.06)" strokeWidth="1" />
      ))}
      {/* axes */}
      <line x1={sx(0)} y1={sy(0)} x2={sx(10)} y2={sy(0)}
            stroke="rgba(20,32,46,0.35)" strokeWidth="1" />
      {showYAxis && (
        <line x1={sx(0)} y1={sy(0)} x2={sx(0)} y2={sy(5)}
              stroke="rgba(20,32,46,0.35)" strokeWidth="1" />
      )}
      {/* tick labels */}
      {tickedX && xTicks.map(t => (
        <text key={"lx"+t} x={sx(t)} y={sy(0)+18} fontFamily="JetBrains Mono"
              fontSize="10" fill="rgba(20,32,46,0.5)" textAnchor="middle">{t}</text>
      ))}
      {showYAxis && yTicks.filter(t => t > 0).map(t => (
        <text key={"ly"+t} x={sx(0)-8} y={sy(t)+3} fontFamily="JetBrains Mono"
              fontSize="10" fill="rgba(20,32,46,0.5)" textAnchor="end">{t}</text>
      ))}
    </g>
  );
}

// ── Hero auto-play simulator ───────────────────────────────
function HeroSimulator() {
  const [t, setT] = useState(0);
  const raf = useRef();
  const last = useRef(performance.now());

  useEffect(() => {
    const tick = (now) => {
      const dt = (now - last.current) / 1000;
      last.current = now;
      setT(prev => (prev + dt * 0.45) % (Math.PI * 4));
      raf.current = requestAnimationFrame(tick);
    };
    raf.current = requestAnimationFrame(tick);
    return () => cancelAnimationFrame(raf.current);
  }, []);

  // The curve: f(x) = 2 + 1.2 sin(0.7x)  — derivative: 0.84 cos(0.7x)
  const f  = (x) => 2 + 1.2 * Math.sin(0.7 * x);
  const df = (x) => 0.84 * Math.cos(0.7 * x);

  const x  = (Math.sin(t) + 1) * 5;     // oscillate 0..10
  const y  = f(x);
  const m  = df(x);                     // slope

  // tangent segment ±1.2 in x
  const xa = Math.max(0, x - 1.4);
  const xb = Math.min(10, x + 1.4);
  const ya = y + m * (xa - x);
  const yb = y + m * (xb - x);

  return (
    <div className="hero-stage">
      <span className="stage-label">FIG. 01 · POSITION OVER TIME</span>
      <svg viewBox={`0 0 ${CW} ${CH}`} preserveAspectRatio="xMidYMid meet">
        <Axes />
        {/* the curve */}
        <path d={pathFor(f)} stroke="#14202e" strokeWidth="2"
              fill="none" strokeLinecap="round" />
        {/* shaded area under curve up to x */}
        <path d={pathFor((u) => u <= x ? f(u) : 0, 200) + ` L${sx(x)},${sy(0)} L${sx(0)},${sy(0)} Z`}
              fill="rgba(217,78,31,0.10)" />
        {/* tangent */}
        <line x1={sx(xa)} y1={sy(ya)} x2={sx(xb)} y2={sy(yb)}
              stroke="#d94e1f" strokeWidth="2" strokeLinecap="round" />
        {/* drop line */}
        <line x1={sx(x)} y1={sy(0)} x2={sx(x)} y2={sy(y)}
              stroke="rgba(20,32,46,0.3)" strokeWidth="1" strokeDasharray="3 4" />
        {/* moving point */}
        <circle cx={sx(x)} cy={sy(y)} r="7" fill="#d94e1f" stroke="#f1ebde" strokeWidth="2" />
        {/* axis labels */}
        <text x={sx(10)} y={sy(0)+30} fontFamily="JetBrains Mono" fontSize="10"
              fill="rgba(20,32,46,0.6)" textAnchor="end">time (s) →</text>
        <text x={sx(0)+6} y={sy(5)-6} fontFamily="JetBrains Mono" fontSize="10"
              fill="rgba(20,32,46,0.6)">↑ position (m)</text>
      </svg>
      <div className="stage-readout">
        x = <b>{x.toFixed(2)}</b>&nbsp;&nbsp;f(x) = <b>{y.toFixed(2)}</b><br/>
        slope <span style={{opacity:.55}}>(velocity)</span> = <b>{m.toFixed(2)}</b> m/s
      </div>
    </div>
  );
}

// ── Derivative Lab ─────────────────────────────────────────
function DerivativeLab() {
  const [xPos, setXPos] = useState(3.2);
  const [fnKey, setFnKey] = useState("sine");
  const svgRef = useRef(null);
  const dragging = useRef(false);

  const f = CURVES[fnKey].f;
  const y = f(xPos);
  const m = deriv(f, xPos);

  // tangent segment width: longer for visibility, but clip to chart
  const span = 1.6;
  const xa = Math.max(0, xPos - span);
  const xb = Math.min(10, xPos + span);
  const ya = y + m * (xa - xPos);
  const yb = y + m * (xb - xPos);

  const handle = (clientX) => {
    const r = svgRef.current.getBoundingClientRect();
    const px = (clientX - r.left) * (CW / r.width);
    const x = Math.max(0.05, Math.min(9.95, (px - PAD_L) / XS));
    setXPos(x);
  };
  const down = (e) => { dragging.current = true; handle(e.clientX); };
  const move = (e) => { if (dragging.current) handle(e.clientX); };
  const up   = () => { dragging.current = false; };

  useEffect(() => {
    window.addEventListener("mousemove", move);
    window.addEventListener("mouseup", up);
    return () => {
      window.removeEventListener("mousemove", move);
      window.removeEventListener("mouseup", up);
    };
  }, []);

  // velocity interpretation
  const slopeWord = m > 0.05 ? "rising"
                : m < -0.05 ? "falling"
                : "flat — a peak, valley, or plateau";

  return (
    <div className="lab">
      <div className="lab-header">
        <h3>Lab I &middot; <em>The tangent at a point</em></h3>
        <span className="lab-tag">Drag the dot</span>
      </div>
      <div className="lab-body">
        <div className="lab-canvas">
          <svg ref={svgRef} viewBox={`0 0 ${CW} ${CH}`}
               onMouseDown={down}
               preserveAspectRatio="xMidYMid meet">
            <Axes />
            <path d={pathFor(f)} stroke="#14202e" strokeWidth="2.2"
                  fill="none" strokeLinecap="round" />
            <line x1={sx(xa)} y1={sy(ya)} x2={sx(xb)} y2={sy(yb)}
                  stroke="#d94e1f" strokeWidth="2.4" strokeLinecap="round" />
            {/* slope triangle */}
            <line x1={sx(xPos)} y1={sy(y)} x2={sx(xPos+1)} y2={sy(y)}
                  stroke="#d94e1f" strokeWidth="1" strokeDasharray="3 3" opacity="0.7"/>
            <line x1={sx(xPos+1)} y1={sy(y)} x2={sx(xPos+1)} y2={sy(y+m)}
                  stroke="#d94e1f" strokeWidth="1" strokeDasharray="3 3" opacity="0.7"/>
            <text x={sx(xPos+1)+6} y={sy(y + m/2)+4} fontFamily="JetBrains Mono"
                  fontSize="11" fill="#d94e1f">Δy = {m.toFixed(2)}</text>
            <text x={sx(xPos+0.5)} y={sy(y)+14} fontFamily="JetBrains Mono"
                  fontSize="11" fill="#d94e1f" textAnchor="middle">Δx = 1</text>
            {/* the dot */}
            <circle cx={sx(xPos)} cy={sy(y)} r="9" fill="#d94e1f"
                    stroke="#f1ebde" strokeWidth="3" style={{cursor:"ew-resize"}} />
          </svg>
        </div>

        <div className="lab-controls">
          <div className="chips">
            {Object.entries(CURVES).map(([k, c]) => (
              <span key={k}
                    className={"chip" + (k === fnKey ? " active" : "")}
                    onClick={() => setFnKey(k)}>
                {c.label}
              </span>
            ))}
          </div>
          <div className="lab-readout">
            <div className="row"><span className="key">f(x)</span>
              <span style={{opacity:.85}}>{CURVES[fnKey].expr}</span></div>
            <div className="row"><span className="key">x</span>
              <span className="val">{xPos.toFixed(2)}</span></div>
            <div className="row"><span className="key">f(x)</span>
              <span className="val">{y.toFixed(2)}</span></div>
            <div className="row"><span className="key">f′(x) <small>· slope</small></span>
              <span className="val">{m.toFixed(2)}</span></div>
          </div>
          <p className="lab-explain">
            The orange line is the <em>tangent</em> — it kisses the curve
            at one point. Its slope is the <em>derivative</em>, written
            f′(x) or df/dx. Right now the curve is <em>{slopeWord}</em>.
            If x were time and f(x) were a car's position, that slope would
            be the car's speedometer reading at this exact instant.
          </p>
        </div>
      </div>
    </div>
  );
}

// ── Integral Lab ───────────────────────────────────────────
function IntegralLab() {
  const [n, setN] = useState(8);
  const [mode, setMode] = useState("mid"); // left | mid | right
  const [fnKey, setFnKey] = useState("bump");

  const f = AREA_CURVES[fnKey].f;
  const dx = 10 / n;

  const rects = useMemo(() => {
    const arr = [];
    for (let i = 0; i < n; i++) {
      const x0 = i * dx;
      const sampleX = mode === "left" ? x0
                    : mode === "right" ? x0 + dx
                    : x0 + dx / 2;
      const h = Math.max(0, f(sampleX));
      arr.push({ x0, x1: x0 + dx, h });
    }
    return arr;
  }, [n, mode, fnKey]);

  const sum = rects.reduce((a, r) => a + r.h * dx, 0);
  const truth = useMemo(() => trueIntegral(f), [fnKey]);
  const err = sum - truth;

  return (
    <div className="lab">
      <div className="lab-header">
        <h3>Lab II &middot; <em>Adding up infinite slices</em></h3>
        <span className="lab-tag">Slide n →</span>
      </div>
      <div className="lab-body">
        <div className="lab-canvas">
          <svg viewBox={`0 0 ${CW} ${CH}`} preserveAspectRatio="xMidYMid meet">
            <Axes />
            {/* rectangles */}
            {rects.map((r, i) => (
              <rect key={i}
                    x={sx(r.x0)} y={sy(r.h)}
                    width={sx(r.x1) - sx(r.x0)}
                    height={sy(0) - sy(r.h)}
                    fill="rgba(47,111,94,0.22)"
                    stroke="rgba(47,111,94,0.9)"
                    strokeWidth="1" />
            ))}
            {/* the curve over top */}
            <path d={pathFor(f)} stroke="#14202e" strokeWidth="2.2"
                  fill="none" strokeLinecap="round" />
            <text x={sx(10)} y={sy(0)+30} fontFamily="JetBrains Mono" fontSize="10"
                  fill="rgba(20,32,46,0.6)" textAnchor="end">x →</text>
          </svg>
        </div>

        <div className="lab-controls">
          <div className="chips">
            {Object.entries(AREA_CURVES).map(([k, c]) => (
              <span key={k} className={"chip" + (k === fnKey ? " active" : "")}
                    onClick={() => setFnKey(k)}>{c.label}</span>
            ))}
          </div>
          <div className="slider-row">
            <div className="slabel">
              <span>rectangles (n)</span>
              <b>{n}</b>
            </div>
            <input className="slider" type="range" min="1" max="80" value={n}
                   onChange={e => setN(+e.target.value)} />
          </div>
          <div className="chips">
            {["left","mid","right"].map(k => (
              <span key={k} className={"chip" + (k === mode ? " active" : "")}
                    onClick={() => setMode(k)}>{k}</span>
            ))}
          </div>
          <div className="lab-readout">
            <div className="row"><span className="key">estimate</span>
              <span className="val teal">{sum.toFixed(3)}</span></div>
            <div className="row"><span className="key">true area</span>
              <span className="val">{truth.toFixed(3)}</span></div>
            <div className="row"><span className="key">error</span>
              <span className="val" style={{opacity:.75}}>
                {(err >= 0 ? "+" : "") + err.toFixed(3)}
              </span></div>
          </div>
          <p className="lab-explain">
            Slice the area into <em>n</em> rectangles, add them up. As
            n &rarr; ∞, the error vanishes and you have the exact area
            under the curve — the <em>integral</em>, written ∫f(x)dx.
            If f(x) is your car's speed, the area under it from 0 to 10
            is the <em>distance traveled</em>. Same trick: charge on a
            capacitor, fuel burned by a rocket, total stress in a beam.
          </p>
        </div>
      </div>
    </div>
  );
}

Object.assign(window, { HeroSimulator, DerivativeLab, IntegralLab });
