/* eslint-disable no-undef */
// Calculus quiz — 7 questions, feedback after each, score at the end.

const { useState } = React;

const QUESTIONS = [
  {
    stem: <>If your position is <code>x(t)</code>, what does the derivative <code>dx/dt</code> read on the dashboard?</>,
    opts: [
      "Total distance traveled",
      "Your speedometer at this instant",
      "Fuel efficiency",
      "Curvature of the road",
    ],
    correct: 1,
    feedback: <>The derivative of position is velocity — exactly what a speedometer shows. <b>Distance</b> would come from the integral (area under velocity).</>,
  },
  {
    stem: <>A capacitor is held at a steady 5&nbsp;V. The current flowing through it is…</>,
    opts: [
      "5 amps",
      "Zero",
      "Increasing linearly",
      "Infinite",
    ],
    correct: 1,
    feedback: <>For a capacitor, <code>I = C·dV/dt</code>. Constant voltage means <code>dV/dt = 0</code>, so no current. This is exactly why capacitors <em>block DC</em> and let AC pass.</>,
  },
  {
    stem: <>A car's velocity climbs from 0 to 20 m/s over 10 s, then falls back to 0 over the next 10 s. How far did it travel?</>,
    opts: [
      "100 m",
      "200 m",
      "400 m",
      "20 m",
    ],
    correct: 1,
    feedback: <>Distance is the integral of velocity — the <em>area under the curve</em>. The v(t) graph is a triangle of base 20 s and height 20 m/s: area = ½·20·20 = <b>200&nbsp;m</b>.</>,
  },
  {
    stem: <>For <code>f(x) = x²</code>, what is <code>f′(3)</code>?</>,
    opts: ["9", "6", "3", "1"],
    correct: 1,
    feedback: <>The power rule: <code>d/dx(x²) = 2x</code>, so <code>f′(3) = 6</code>. Geometrically, the parabola is rising at a rate of 6 units per unit at x = 3.</>,
  },
  {
    stem: <>Your control system overshoots its target and oscillates before settling. Which PID term most likely needs more weight?</>,
    opts: [
      "P — proportional",
      "I — integral",
      "D — derivative",
      "None — raise the setpoint",
    ],
    correct: 2,
    feedback: <>The <em>D</em> term reacts to the <em>rate</em> the error is changing. Crank it up and the controller starts braking <em>before</em> it reaches the target — the derivative is predicting the future.</>,
  },
  {
    stem: <>A curve has a flat (horizontal) tangent at a point. That point is a…</>,
    opts: [
      "Discontinuity",
      "Vertical asymptote",
      "Local maximum, minimum, or saddle",
      "Inflection point, always",
    ],
    correct: 2,
    feedback: <>Where <code>f′(x) = 0</code>, the function momentarily stops rising or falling — a peak, valley, or saddle. Every optimization problem in engineering (least drag, max torque, min cost) is hunting these zeros.</>,
  },
  {
    stem: <>You integrate a car's <em>acceleration</em> with respect to time. You get…</>,
    opts: [
      "Position",
      "Velocity",
      "Jerk",
      "Distance squared",
    ],
    correct: 1,
    feedback: <>Integration is the inverse of differentiation. <code>a → ∫ → v → ∫ → x</code>. Each climb up the ladder undoes one derivative — the <em>Fundamental Theorem of Calculus</em> in action.</>,
  },
];

const VERDICTS = [
  { min: 0, line: "Just getting limber.",   sub: "Scroll back up — the labs above do most of the heavy lifting." },
  { min: 3, line: "Engineering apprentice.", sub: "You've got the shape of it. A few more pages of practice and the calculus is yours." },
  { min: 5, line: "Ready for the toolbox.",  sub: "Solid intuition. Pick a project — a circuit, a control loop, a falling body — and start applying it." },
  { min: 7, line: "Newton would nod.",       sub: "You're not just doing calculus, you're thinking with it. Go build something that moves." },
];

function Quiz() {
  const [i, setI] = useState(0);
  const [picked, setPicked] = useState(null);
  const [score, setScore] = useState(0);
  const [done, setDone] = useState(false);

  const q = QUESTIONS[i];

  const pick = (j) => {
    if (picked !== null) return;
    setPicked(j);
    if (j === q.correct) setScore(s => s + 1);
  };

  const next = () => {
    if (i + 1 >= QUESTIONS.length) {
      setDone(true);
    } else {
      setI(i + 1);
      setPicked(null);
    }
  };

  const reset = () => {
    setI(0); setPicked(null); setScore(0); setDone(false);
  };

  if (done) {
    const v = [...VERDICTS].reverse().find(v => score >= v.min);
    return (
      <div className="quiz">
        <div className="quiz-end">
          <div className="eyebrow">FINAL SCORE</div>
          <div className="score">{score}<span style={{opacity:.3}}>/{QUESTIONS.length}</span></div>
          <div className="verdict">{v.line}</div>
          <div className="verdict-sub">{v.sub}</div>
          <button className="btn ghost" style={{marginTop:24}} onClick={reset}>
            Try again
          </button>
        </div>
      </div>
    );
  }

  const letters = ["A","B","C","D"];

  return (
    <div className="quiz">
      <div className="quiz-progress">
        {QUESTIONS.map((_, idx) => (
          <div key={idx} className={
            "pip" + (idx < i ? " done" : idx === i ? " cur" : "")
          } />
        ))}
      </div>
      <div className="q-num">QUESTION {String(i+1).padStart(2,"0")} / {String(QUESTIONS.length).padStart(2,"0")}</div>
      <div className="q-stem">{q.stem}</div>
      <div className="q-opts">
        {q.opts.map((o, j) => {
          let cls = "q-opt";
          if (picked !== null) {
            if (j === q.correct) cls += " correct";
            else if (j === picked) cls += " wrong";
            else cls += " disabled";
          }
          return (
            <button key={j} className={cls} onClick={() => pick(j)}>
              <span className="letter">{letters[j]}</span>
              <span>{o}</span>
            </button>
          );
        })}
      </div>
      {picked !== null && (
        <div className={"q-feedback" + (picked === q.correct ? " right" : "")}>
          <b>{picked === q.correct ? "Right." : "Not quite."}</b>{" "}{q.feedback}
        </div>
      )}
      {picked !== null && (
        <div className="q-actions">
          <div className="q-num">
            score so far · <b style={{color:"var(--ink)"}}>{score}/{i+1}</b>
          </div>
          <button className="btn" onClick={next}>
            {i + 1 === QUESTIONS.length ? "See final score →" : "Next question →"}
          </button>
        </div>
      )}
    </div>
  );
}

Object.assign(window, { Quiz });
