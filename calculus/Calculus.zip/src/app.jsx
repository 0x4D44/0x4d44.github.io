/* eslint-disable no-undef */
// Top-level app — orchestrates the field guide.

const { useState, useEffect } = React;

const TWEAK_DEFAULTS = /*EDITMODE-BEGIN*/{
  "accent": "#d94e1f",
  "showGrid": true,
  "showLabs": true
}/*EDITMODE-END*/;

function App() {
  const [t, setTweak] = useTweaks(TWEAK_DEFAULTS);

  // Live CSS variable overrides from tweaks
  useEffect(() => {
    const root = document.documentElement;
    root.style.setProperty("--accent", t.accent);
    // make accent-pale follow it
    const m = t.accent.match(/^#([0-9a-f]{6})$/i);
    if (m) {
      const r = parseInt(m[1].slice(0,2), 16);
      const g = parseInt(m[1].slice(2,4), 16);
      const b = parseInt(m[1].slice(4,6), 16);
      root.style.setProperty("--accent-pale", `rgba(${r},${g},${b},0.12)`);
    }
    document.body.style.backgroundImage = t.showGrid
      ? `linear-gradient(rgba(20,32,46,0.065) 1px, transparent 1px),
         linear-gradient(90deg, rgba(20,32,46,0.065) 1px, transparent 1px)`
      : "none";
  }, [t.accent, t.showGrid]);

  return (
    <>
      <header className="topbar">
        <div className="topbar-inner">
          <div className="brand">
            <span className="brand-mark"></span>
            <span>FIELD GUIDE №01 · CALCULUS</span>
          </div>
          <nav>
            <a href="#big-idea">Big idea</a>
            <a href="#labs">Labs</a>
            <a href="#field">In the field</a>
            <a href="#quiz">Quiz</a>
          </nav>
        </div>
      </header>

      {/* ── HERO ── */}
      <section className="hero">
        <div className="wrap">
          <div className="hero-meta">
            <span className="dot"></span>
            <span>An interactive field guide</span>
            <span style={{opacity:.5}}>·</span>
            <span>Reading time ≈ 12 min</span>
          </div>
          <div className="hero-grid">
            <div>
              <h1 className="display">
                The calculus<br/>
                of things <span className="underline-mark">that move</span>.
              </h1>
              <p className="hero-lede">
                Slopes, areas, and the two simple ideas that engineers use
                to land rockets, hold bridges up, and keep your phone charged.
              </p>
            </div>
            <HeroSimulator />
          </div>

          <div className="kpi-row">
            <div className="kpi">
              <div className="n">~350 <span className="u">yrs</span></div>
              <div className="k">Since Newton &amp; Leibniz quarreled over it</div>
            </div>
            <div className="kpi">
              <div className="n">2 <span className="u">ideas</span></div>
              <div className="k">The derivative · the integral</div>
            </div>
            <div className="kpi">
              <div className="n">∞ <span className="u">uses</span></div>
              <div className="k">Every engineered thing that changes</div>
            </div>
          </div>
        </div>
      </section>

      {/* ── BIG IDEA ── */}
      <section id="big-idea" className="section-rule">
        <div className="wrap">
          <div className="section-head">
            <div className="eyebrow">PART I &nbsp;·&nbsp; THE TWO IDEAS</div>
            <h2 className="display">Two questions about change. That's all calculus is.</h2>
          </div>

          <div className="prose" style={{maxWidth: "62ch", marginBottom: 56}}>
            <p>
              Look at anything an engineer designs and you'll find <b>two recurring questions</b>.
              <em> How fast is this thing changing right now?</em> And <em>how much has it
              piled up over time?</em>
            </p>
            <p>
              These are calculus. The first question is answered by the <b>derivative</b>;
              the second, by the <b>integral</b>. Every formula on the next 50 pages is
              the same two ideas wearing different costumes.
            </p>
          </div>

          <div className="idea-split">
            <div className="idea">
              <div className="ord">I.</div>
              <h3 className="display">The <em>slope</em><br/>at a single instant.</h3>
              <p>
                Pick any moment in time. How fast is the thing changing <em>right then</em>?
                Not the average over the last hour — the rate <b>this exact tick</b>.
                That's the derivative.
              </p>
              <span className="symbol">f ′(x) &nbsp;=&nbsp; df/dx &nbsp;=&nbsp; lim<sub>h→0</sub> [ f(x+h) − f(x) ] / h</span>
              <p style={{fontSize: 14, color: "var(--muted)"}}>
                Speedometer. Heart rate. Marginal cost. The pressure climbing on a valve.
              </p>
            </div>
            <div className="idea">
              <div className="ord">II.</div>
              <h3 className="display">The <em>area</em><br/>under everything.</h3>
              <p>
                Now run the question in reverse. Given a rate at every instant,
                how much have we accumulated? Add up infinitely many infinitely-thin
                slivers. That's the integral.
              </p>
              <span className="symbol">∫<sub>a</sub><sup>b</sup> f(x) dx &nbsp;=&nbsp; lim<sub>n→∞</sub> Σ f(x<sub>i</sub>) · Δx</span>
              <p style={{fontSize: 14, color: "var(--muted)"}}>
                Distance from speed. Charge from current. Total stress on a beam.
              </p>
            </div>
          </div>

          <div className="pull">
            "If you can sketch it, you can take its derivative.<br/>
            If you can shade it, you can take its integral."
          </div>
        </div>
      </section>

      {/* ── LABS ── */}
      <section id="labs" className="section-rule">
        <div className="wrap">
          <div className="section-head">
            <div className="eyebrow">PART II &nbsp;·&nbsp; HANDS-ON</div>
            <h2 className="display">Two labs. Play with them.</h2>
          </div>

          <div className="prose" style={{maxWidth:"62ch", marginBottom: 16}}>
            <p>
              Reading about calculus is like reading about swimming. Drag the
              dot. Slide the slider. The intuition is in your fingertips.
            </p>
          </div>

          <DerivativeLab />

          <div className="prose" style={{maxWidth:"62ch", margin: "64px auto 0"}}>
            <p style={{fontSize: 15, color: "var(--ink-soft)"}}>
              <span className="annot">Notice:</span> at the top of a hill the
              tangent is flat — slope&nbsp;=&nbsp;0. That's how engineers
              find <b>maxima and minima</b>. Drop calculus on a function and
              ask where its derivative equals zero. Out come the answers to
              "what beam thickness minimizes weight?", "what voltage gives
              peak efficiency?", "what wing angle minimizes drag?"
            </p>
          </div>

          <IntegralLab />

          <div className="prose" style={{maxWidth:"62ch", margin: "64px auto 0"}}>
            <p style={{fontSize: 15, color: "var(--ink-soft)"}}>
              <span className="annot">Notice:</span> with just 8 rectangles
              the estimate is rough. Crank n past 30 and it's nearly exact.
              That's the magic of <b>taking a limit</b>: an infinite sum of
              infinitely thin slices converges to a finite, exact number.
              It bothered mathematicians for two centuries. Engineers just
              shrugged and used it.
            </p>
          </div>
        </div>
      </section>

      {/* ── FUNDAMENTAL THEOREM ── */}
      <section className="section-rule">
        <div className="wrap-narrow fundamental">
          <div className="eyebrow" style={{marginBottom: 16}}>PART III &nbsp;·&nbsp; THE TWIST</div>
          <h2 className="display" style={{fontSize: "clamp(40px,5vw,68px)", marginBottom: 8}}>
            The two ideas are <em style={{color:"var(--accent)"}}>secretly the same idea.</em>
          </h2>
          <div className="eq-big">
            <span style={{fontStyle:"normal", fontFamily:"JetBrains Mono", fontSize:"0.6em"}}>d/dx</span>
            <span> ∫<sub>a</sub><sup>x</sup> f(t) dt</span>
            <span className="op"> = </span>
            <span style={{fontStyle:"italic"}}>f(x)</span>
          </div>
          <p style={{color:"var(--ink-2)", fontSize:18, maxWidth:"54ch", margin:"0 auto"}}>
            Integrate a function, then differentiate the result — you get the
            original back. They are <b>inverse operations</b>. This is the
            <em> Fundamental Theorem of Calculus</em>, and it's the reason
            every textbook problem you ever solved actually worked.
          </p>
          <p style={{color:"var(--muted)", fontSize:14, marginTop:32, fontFamily:"JetBrains Mono", letterSpacing:".1em"}}>
            VELOCITY  →  ∫  →  POSITION  →  d/dt  →  VELOCITY
          </p>
        </div>
      </section>

      {/* ── CASES ── */}
      <section id="field" className="section-rule">
        <div className="wrap">
          <div className="section-head">
            <div className="eyebrow">PART IV &nbsp;·&nbsp; IN THE FIELD</div>
            <h2 className="display">Six places engineers reach for it.</h2>
          </div>
          <Cases />
        </div>
      </section>

      {/* ── QUIZ ── */}
      <section id="quiz" className="section-rule">
        <div className="wrap-narrow">
          <div className="section-head">
            <div className="eyebrow">PART V &nbsp;·&nbsp; CHECK YOURSELF</div>
            <h2 className="display" style={{fontSize:"clamp(36px,4.8vw,56px)"}}>
              Seven questions. No calculator needed.
            </h2>
          </div>
          <Quiz />
        </div>
      </section>

      {/* ── FOOTER ── */}
      <footer>
        <div className="wrap" style={{display:"flex", justifyContent:"space-between", flexWrap:"wrap", gap:24, width:"100%"}}>
          <div className="colophon">
            Set in Instrument Serif, Geist &amp; JetBrains Mono.
            Curves rendered live in your browser. No equations were
            harmed in the making of this guide.
          </div>
          <div style={{textAlign:"right"}}>
            FIELD GUIDE №01<br/>
            CALCULUS · v1.0
          </div>
        </div>
      </footer>

      <TweaksPanel title="Tweaks">
        <TweakSection label="Look" />
        <TweakColor label="Accent" value={t.accent}
                    options={["#d94e1f", "#2f6f5e", "#3b5cb3", "#a14fb8", "#1a1a1a"]}
                    onChange={v => setTweak("accent", v)} />
        <TweakToggle label="Graph paper" value={t.showGrid}
                     onChange={v => setTweak("showGrid", v)} />
      </TweaksPanel>
    </>
  );
}

ReactDOM.createRoot(document.getElementById("root")).render(<App />);
