// app.jsx — Token Predictor
// Streams pre-tokenized LLM responses at a user-controlled toks/sec rate.

const { useState, useEffect, useRef, useMemo, useCallback } = React;

const TWEAK_DEFAULTS = /*EDITMODE-BEGIN*/{
  "accent": "#E89D4A",
  "highlightTokens": true,
  "scale": "log",
  "showTokenBoundaries": true
}/*EDITMODE-END*/;

// ─── Slider scale helpers ────────────────────────────────────────────────
// Log scale: position 0..1000 ↔ value 1..2000 toks/s.
const SLIDER_MAX = 1000;
const TOK_MIN = 1;
const TOK_MAX = 2000;
function posToToks(pos, scale) {
  if (scale === "linear") {
    return Math.round(TOK_MIN + (pos / SLIDER_MAX) * (TOK_MAX - TOK_MIN));
  }
  const lo = Math.log(TOK_MIN), hi = Math.log(TOK_MAX);
  return Math.round(Math.exp(lo + (pos / SLIDER_MAX) * (hi - lo)));
}
function toksToPos(toks, scale) {
  if (scale === "linear") {
    return ((toks - TOK_MIN) / (TOK_MAX - TOK_MIN)) * SLIDER_MAX;
  }
  const lo = Math.log(TOK_MIN), hi = Math.log(TOK_MAX);
  return ((Math.log(toks) - lo) / (hi - lo)) * SLIDER_MAX;
}

// ─── Stream hook ─────────────────────────────────────────────────────────
// Streams `tokens` at `rate` toks/sec into a buffer. Each emitted token also
// stamps a `t` so we can flash highlights on recent ones. Loops indefinitely
// while `running` is true; rate changes apply live.
const MAX_VISIBLE_TOKENS = 600;

function useTokenStream(tokens, rate, running, resetKey) {
  const [emitted, setEmitted] = useState([]); // {tok, t, k}
  const [totalCount, setTotalCount] = useState(0);
  const idxRef = useRef(0);
  const keyRef = useRef(0);
  const rafRef = useRef(null);
  const accRef = useRef(0);
  const lastRef = useRef(0);
  const rateRef = useRef(rate);
  rateRef.current = rate;

  // Reset on prompt change or manual restart
  useEffect(() => {
    idxRef.current = 0;
    accRef.current = 0;
    lastRef.current = 0;
    keyRef.current = 0;
    setEmitted([]);
    setTotalCount(0);
  }, [tokens, resetKey]);

  useEffect(() => {
    if (!running) {
      cancelAnimationFrame(rafRef.current);
      lastRef.current = 0;
      return;
    }
    const step = (now) => {
      if (!lastRef.current) lastRef.current = now;
      const dt = (now - lastRef.current) / 1000;
      lastRef.current = now;
      accRef.current += dt * rateRef.current;

      // Safety cap: at huge rates the rAF could in theory deliver dozens of
      // tokens per frame; allow that, but avoid runaway if tab was hidden.
      let n = Math.floor(accRef.current);
      if (n > 800) n = 800;
      if (n > 0) {
        accRef.current -= n;
        const chunk = new Array(n);
        for (let i = 0; i < n; i++) {
          chunk[i] = { tok: tokens[idxRef.current], t: now, k: keyRef.current++ };
          idxRef.current = (idxRef.current + 1) % tokens.length;
        }
        setTotalCount((c) => c + n);
        setEmitted((prev) => {
          const next = prev.length + n > MAX_VISIBLE_TOKENS
            ? prev.concat(chunk).slice(-MAX_VISIBLE_TOKENS)
            : prev.concat(chunk);
          return next;
        });
      }
      rafRef.current = requestAnimationFrame(step);
    };
    rafRef.current = requestAnimationFrame(step);
    return () => cancelAnimationFrame(rafRef.current);
  }, [tokens, running]);

  return { emitted, totalCount };
}

// ─── Token render ────────────────────────────────────────────────────────
function TokenStream({ emitted, highlight, boundaries, accent }) {
  const containerRef = useRef(null);
  useEffect(() => {
    const el = containerRef.current;
    if (el) el.scrollTop = el.scrollHeight;
  }, [emitted]);

  const now = performance.now();
  return (
    <div ref={containerRef} className="stream">
      {emitted.map((e, i) => {
        const age = now - e.t;
        const fresh = highlight && age < 600;
        const intensity = fresh ? Math.max(0, 1 - age / 600) : 0;
        const style = {
          background: boundaries
            ? `rgba(232, 157, 74, ${0.06 + intensity * 0.35})`
            : intensity > 0
              ? `rgba(232, 157, 74, ${intensity * 0.35})`
              : "transparent",
          color: intensity > 0.4 ? accent : undefined,
          outline: boundaries ? "0.5px solid rgba(232, 157, 74, 0.12)" : "none",
          outlineOffset: boundaries ? "0" : undefined,
          borderRadius: "2px",
          transition: "background 220ms linear, color 220ms linear",
        };
        return (
          <span key={e.k} className="tok" style={style}>
            {e.tok.replace(/\n/g, "\n")}
          </span>
        );
      })}
      <span className="caret" />
    </div>
  );
}

// ─── Slider with tick markers ────────────────────────────────────────────
function SpeedSlider({ value, onChange, scale, presets }) {
  const pos = toksToPos(value, scale);
  return (
    <div className="slider-wrap">
      <div className="slider-track">
        <div className="slider-fill" style={{ width: `${(pos / SLIDER_MAX) * 100}%` }} />
        {presets.map((p, i) => {
          const left = (toksToPos(p.value, scale) / SLIDER_MAX) * 100;
          const stagger = i % 2 === 1;
          return (
            <button
              key={p.label}
              className={`tick ${stagger ? "tick-low" : ""}`}
              style={{ left: `${left}%` }}
              onClick={() => onChange(p.value)}
              title={`${p.label} — ${p.value} toks/s · ${p.note}`}
            >
              <span className="tick-line" />
              <span className="tick-label">{p.label}</span>
              <span className="tick-val">{p.value}</span>
            </button>
          );
        })}
        <input
          type="range"
          min={0}
          max={SLIDER_MAX}
          value={pos}
          onChange={(e) => onChange(posToToks(+e.target.value, scale))}
          className="slider-input"
        />
        <div className="slider-thumb" style={{ left: `${(pos / SLIDER_MAX) * 100}%` }} />
      </div>
    </div>
  );
}

// ─── Stats ──────────────────────────────────────────────────────────────
function Stats({ totalCount, rate, startTime, running }) {
  const [now, setNow] = useState(performance.now());
  useEffect(() => {
    if (!running || !startTime) return;
    const id = setInterval(() => setNow(performance.now()), 80);
    return () => clearInterval(id);
  }, [running, startTime]);

  const elapsed = startTime ? (now - startTime) / 1000 : 0;
  const actualRate = elapsed > 0 ? totalCount / elapsed : 0;
  const msPerTok = rate > 0 ? 1000 / rate : 0;

  return (
    <div className="stats">
      <div className="stat">
        <div className="stat-label">tokens</div>
        <div className="stat-val">{totalCount.toLocaleString()}</div>
      </div>
      <div className="stat">
        <div className="stat-label">elapsed</div>
        <div className="stat-val">{elapsed.toFixed(2)}<span className="dim">s</span></div>
      </div>
      <div className="stat">
        <div className="stat-label">ms / token</div>
        <div className="stat-val">{msPerTok < 1 ? msPerTok.toFixed(2) : msPerTok.toFixed(msPerTok < 10 ? 1 : 0)}</div>
      </div>
      <div className="stat">
        <div className="stat-label">measured</div>
        <div className="stat-val">
          {actualRate.toFixed(actualRate < 10 ? 1 : 0)}<span className="dim"> t/s</span>
        </div>
      </div>
    </div>
  );
}

// ─── Single generator panel ──────────────────────────────────────────────
function Generator({ tokens, rate, running, resetKey, label, accent, highlight, boundaries }) {
  const { emitted, totalCount } = useTokenStream(tokens, rate, running, resetKey);
  const startRef = useRef(null);
  useEffect(() => {
    // Reset elapsed clock when tokens or resetKey change
    startRef.current = running ? performance.now() : null;
  }, [tokens, resetKey]);
  useEffect(() => {
    if (running && !startRef.current) startRef.current = performance.now();
  }, [running]);

  return (
    <div className="gen">
      {label && (
        <div className="gen-label">
          <span>{label}</span>
          <span className="gen-rate">{rate.toLocaleString()} toks/s</span>
        </div>
      )}
      <TokenStream
        emitted={emitted}
        highlight={highlight}
        boundaries={boundaries}
        accent={accent}
      />
      <Stats totalCount={totalCount} rate={rate} startTime={startRef.current} running={running} />
    </div>
  );
}

// ─── Root app ────────────────────────────────────────────────────────────
function App() {
  const [t, setTweak] = useTweaks(TWEAK_DEFAULTS);
  const [promptId, setPromptId] = useState(window.PROMPTS[0].id);
  const [rate, setRate] = useState(45);
  const [rateB, setRateB] = useState(280);
  const [raceMode, setRaceMode] = useState(false);
  const [running, setRunning] = useState(true); // streams forever by default
  const [resetKey, setResetKey] = useState(0);

  const prompt = window.PROMPTS.find((p) => p.id === promptId);

  const togglePlay = () => setRunning((r) => !r);
  const restart = () => setResetKey((k) => k + 1);

  // Apply accent to CSS var
  useEffect(() => {
    document.documentElement.style.setProperty("--accent", t.accent);
  }, [t.accent]);

  return (
    <div className="app">
      <header className="hdr">
        <div className="brand">
          <span className="dot" />
          <span className="brand-name">token predictor</span>
        </div>
        <div className="tagline">
          a visceral look at how fast an LLM actually generates text
        </div>
      </header>

      <section className="controls">
        <div className="row">
          <div className="row-label">prompt</div>
          <div className="prompt-pills">
            {window.PROMPTS.map((p) => (
              <button
                key={p.id}
                className={`pill ${p.id === promptId ? "on" : ""}`}
                onClick={() => { setPromptId(p.id); restart(); }}
              >
                {p.label}
              </button>
            ))}
          </div>
        </div>

        <div className="row">
          <div className="row-label">
            speed
            <span className="row-sub">{raceMode ? "A vs B" : "toks per second"}</span>
          </div>
          <div className="speed-stack">
            <div className="speed-readout">
              <div className="big-num">
                {rate}<span className="big-unit">toks/s</span>
              </div>
              {raceMode && (
                <div className="big-num alt">
                  {rateB}<span className="big-unit">toks/s</span>
                </div>
              )}
            </div>
            <SpeedSlider value={rate} onChange={setRate} scale={t.scale} presets={window.SPEED_PRESETS} />
            {raceMode && (
              <SpeedSlider value={rateB} onChange={setRateB} scale={t.scale} presets={window.SPEED_PRESETS} />
            )}
          </div>
        </div>

        <div className="row actions">
          <button className="primary" onClick={togglePlay}>
            {running ? "❚❚ pause" : "▶ play"}
          </button>
          <button className="ghost" onClick={restart}>↻ restart</button>
          <button
            className={`ghost ${raceMode ? "on" : ""}`}
            onClick={() => { setRaceMode((r) => !r); restart(); }}
          >
            {raceMode ? "✓ race mode" : "race mode"}
          </button>
        </div>
      </section>

      <section className="output">
        {!raceMode ? (
          <Generator
            tokens={prompt.tokens}
            rate={rate}
            running={running}
            resetKey={resetKey}
            accent={t.accent}
            highlight={t.highlightTokens}
            boundaries={t.showTokenBoundaries}
          />
        ) : (
          <div className="race">
            <Generator
              tokens={prompt.tokens}
              rate={rate}
              running={running}
              resetKey={resetKey}
              label="A"
              accent={t.accent}
              highlight={t.highlightTokens}
              boundaries={t.showTokenBoundaries}
            />
            <Generator
              tokens={prompt.tokens}
              rate={rateB}
              running={running}
              resetKey={resetKey}
              label="B"
              accent={t.accent}
              highlight={t.highlightTokens}
              boundaries={t.showTokenBoundaries}
            />
          </div>
        )}
      </section>

      <footer className="foot">
        <div className="user-q"><span className="prompt-arrow">›</span> {prompt.prompt}</div>
        <div className="legend">
          <span>{prompt.tokens.length} tokens · loops continuously</span>
          <span>·</span>
          <span>drag the slider to change rate live</span>
          <span>·</span>
          <span>tokenization approximates GPT-style BPE</span>
        </div>
      </footer>

      <TweaksPanel>
        <TweakSection label="Display" />
        <TweakColor
          label="Accent"
          value={t.accent}
          options={["#E89D4A", "#7FD8A6", "#9AB9FF", "#E2748A", "#D9D2C5"]}
          onChange={(v) => setTweak("accent", v)}
        />
        <TweakToggle
          label="Flash on arrival"
          value={t.highlightTokens}
          onChange={(v) => setTweak("highlightTokens", v)}
        />
        <TweakToggle
          label="Show token boundaries"
          value={t.showTokenBoundaries}
          onChange={(v) => setTweak("showTokenBoundaries", v)}
        />
        <TweakSection label="Slider" />
        <TweakRadio
          label="Scale"
          value={t.scale}
          options={["log", "linear"]}
          onChange={(v) => setTweak("scale", v)}
        />
      </TweaksPanel>
    </div>
  );
}

ReactDOM.createRoot(document.getElementById("root")).render(<App />);
