/* global React, ReactDOM */
const { useState: useS, useEffect: useE } = React;

function Chapter({ num, kicker, children }) {
  return (
    <section className="chapter">
      <div className="chapter-rail">
        <div className="num">{num}</div>
        <div className="kicker">{kicker}</div>
      </div>
      <div className="chapter-body">{children}</div>
    </section>
  );
}

function Fig({ id, title, caption, children }) {
  return (
    <figure className="diagram">
      <div className="head">
        <span className="id">{id}</span>
        <span>{title}</span>
      </div>
      <div className="stage">{children}</div>
      {caption && <figcaption><b>{id}.</b> <span>{caption}</span></figcaption>}
    </figure>
  );
}

function App() {
  return (
    <div className="page">
      {/* ============ MASTHEAD ============ */}
      <header className="masthead">
        <div className="left">
          <span className="tag">A technical primer · 1902 – 1975</span>
          <h1 className="title">Mercury<br/><em>arc</em> rectifiers</h1>
        </div>
        <div className="right">
          <div><b>SUBJECT</b> &nbsp; AC → DC conversion</div>
          <div><b>ERA</b> &nbsp; mid-century power electronics</div>
          <div><b>EXAMPLE</b> &nbsp; BR Class 81 – 85 locomotives</div>
          <div><b>STATUS</b> &nbsp; obsolete · 1975</div>
        </div>
      </header>

      <div className="subhead">
        <p className="lede">
          A pool of liquid metal, a few milligrams of glowing vapour, and a graphite rod. For sixty years, this was how the world made <em>big</em> DC out of AC — including the locomotives that first pulled passengers under 25 kV catenary on the West Coast Main Line.
        </p>
        <div className="meta">
          <div className="row"><span className="k">Invented</span><span>P. Cooper Hewitt, 1902</span></div>
          <div className="row"><span className="k">Peak use</span><span>1925 – 1965 · traction + HVDC</span></div>
          <div className="row"><span className="k">Replaced by</span><span>Si thyristors, c. 1970</span></div>
          <div className="row"><span className="k">Read time</span><span>≈ 15 min · 7 diagrams</span></div>
        </div>
      </div>

      {/* ============ HERO ============ */}
      <Chapter num="00" kicker="Cold open">
        <h2>The valve that <em>cannot</em> wear out — until it does, spectacularly.</h2>
        <p className="lead">
          You are looking at a glass bulb the size of an office bin. The pool at the bottom is several kilograms of pure mercury. Above it, a brilliant white spot smaller than a peppercorn skitters across the surface at random — it is locally at 4 000 °C, the same temperature as the surface of a sunspot. The whole tube glows pale blue-violet from the ionised vapour, and quietly converts a thousand amps of 50 Hz alternating current into clean DC. There are no moving parts you can see, no filaments to burn out. It will run, in principle, forever.
        </p>
        <Fig id="FIG. 01" title="Mercury arc rectifier · operating state" caption="A single-anode glass bulb. The four side arms would each carry an anode in a polyphase version. Mercury vapour pressure is set by the coolest point on the glass — keep the dome cool and the pool warm and the device sits stably at ≈ 7 mPa.">
          <HeroArc />
        </Fig>
        <p>
          The catch — and there are several — is that <em className="term">in principle</em> is doing heavy lifting in that sentence. The mercury arc rectifier is one of the most physically <em className="term">elegant</em> machines ever built, and one of the most operationally <em className="term">temperamental</em>. It needs coddling. It needs warming up. It is filled with several kilograms of a potent neurotoxin held back from atmosphere only by glass. Every so often it changes its mind and tries to short its 25 kV supply through itself. None of this kept it out of front-line service for fifty years, because the alternatives were worse.
        </p>
      </Chapter>

      {/* ============ THE PROBLEM ============ */}
      <Chapter num="01" kicker="The problem">
        <h2>Why a railway needs <em>so much</em> rectification, all at once.</h2>
        <p>
          AC is cheap to transmit; DC is what makes a traction motor turn. The series-wound DC motor was the workhorse of electric railways from the 1890s onward — high starting torque, dead simple speed control by varying voltage, no synchronisation problems. So every electrified railway needs to convert from grid AC to motor DC somewhere. The question is <em className="term">where</em>.
        </p>
        <p>
          Before WWII, the trick was usually to do the conversion at the substation — turning a section of grid into a DC busbar — and feed the locomotives at 1.5 kV or 3 kV DC through a third rail or overhead wire. Simple locos, complicated substations every few miles. But DC line losses are vicious. To electrify a route the length of the West Coast Main Line at 1.5 kV DC, you'd need a substation every 5 km, each one humming with rotary converters or mercury arc rectifiers the size of a small car.
        </p>
        <p>
          The post-war answer was <em className="term">25 kV AC at industrial frequency</em>, fed off the public grid through ordinary transformers. Sub-stations every 60 km instead of every 5. The catch: you've just moved the rectification problem onto the locomotive. Each loco must now carry, in the space between the wheels and the cab roof, enough rectifying capacity to feed four DC traction motors at full power — roughly 3 MW continuous, 5 MW peak. In 1959, that meant mercury.
        </p>
        <div className="spec-grid">
          <div className="cell"><div className="k">Catenary</div><div className="v">25<span className="u">kV AC</span></div></div>
          <div className="cell"><div className="k">DC bus</div><div className="v">≈ 1 000<span className="u">V</span></div></div>
          <div className="cell"><div className="k">Continuous</div><div className="v">1 100<span className="u">A</span></div></div>
          <div className="cell"><div className="k">Class 81 power</div><div className="v">3 380<span className="u">hp</span></div></div>
        </div>
      </Chapter>

      {/* ============ HOW IT WORKS ============ */}
      <Chapter num="02" kicker="The principle">
        <h2>An <em>asymmetry</em> in cold cathode physics.</h2>
        <p>
          Inside a sealed envelope, evacuated and then back-filled with low-pressure mercury vapour, sit two kinds of electrode. At the bottom, a pool of liquid mercury. Above it, one or more graphite rods. Strike an arc between them and something curious happens: the arc only carries current in one direction.
        </p>
        <p>
          The mechanism is asymmetric electron emission. Liquid mercury, once a cathode spot has been established on it, is an extravagantly good emitter — ionic bombardment locally heats a sub-millimetre patch to thousands of degrees, and electrons boil off freely. Graphite, by contrast, emits almost nothing even when red-hot. So electrons can flow easily from mercury <em className="term">to</em> graphite, but not back. Apply 50 Hz AC across the gap and only the positive-going half-cycles get through. That is rectification.
        </p>
        <p>
          For a single-phase, single-anode tube this gives you choppy half-wave DC and the arc has to re-ignite every cycle. Real devices use <em className="term">six anodes</em> fed from a 3-phase transformer (3 phases × 2 half-cycles). At any instant, exactly one anode is at the highest potential — that anode conducts; the other five sit blocked. As the phases rotate, the arc <em className="term">commutates</em> — hands off — from one anode to the next, six times per cycle, while the cathode spot just sits there.
        </p>
        <Fig
          id="FIG. 02"
          title="Six-anode commutation · 6-pulse rectification"
          caption="The arc visibly transfers from one anode to the next as each phase reaches its instantaneous maximum. The DC envelope is the upper boundary of the three rectified phases — much smoother than a single-phase rectifier, which is why locomotive designs always used at least 6 (and often 12) phases.">
          <CommutationDiagram />
        </Fig>
        <div className="callout">
          <div className="sym">⚡</div>
          <div className="body">
            <div className="label">Why this matters</div>
            <p>The cathode pool never has to be "switched". The <em>arc itself</em> finds the path of least resistance — which is whichever anode happens to be most positive. The rectifier needs no active control, no timing circuit, no gate driver. It is a pure piece of plasma physics.</p>
          </div>
        </div>
      </Chapter>

      {/* ============ ANATOMY ============ */}
      <Chapter num="03" kicker="Anatomy">
        <h2>Eight pieces, one of them <em>alive</em>.</h2>
        <p>
          The classic British design — Hackbridge-Hewittic, Metropolitan-Vickers, English Electric variants — is a glass envelope perhaps a metre tall with up to six side arms. Click any numbered node below to see what each part does.
        </p>
        <Fig
          id="FIG. 03"
          title="Cross-section · interactive"
          caption="The cathode spot dances continuously on the mercury surface; everything else is static. The condensation dome and the pool together form a closed loop — vaporised mercury rises, cools, runs back, and is re-evaporated.">
          <AnatomyDiagram />
        </Fig>
        <h3>The two clever ideas</h3>
        <p>
          First: the cathode is a <em className="term">liquid</em>. Solid cathodes erode — the emitting surface degrades and the device gradually dies. A pool, by contrast, replenishes itself; the mercury that boils off the spot recondenses on the dome and trickles back. The cathode is essentially eternal.
        </p>
        <p>
          Second: at the operating vapour pressure (around 7 millipascals, set by maintaining the envelope at ≈ 40 °C), the mean free path of an electron is large compared to the anode-cathode gap. There's enough gas to carry an arc, but not enough to make the device behave like a normal gas-filled tube limited by space-charge. The result: very low arc voltage drop — typically 20–30 V — at currents that would melt any vacuum tube. That low drop is what makes the device <em className="term">efficient</em>. A 1 000 A loco rectifier dissipates only ≈ 25 kW as heat, against several megawatts of throughput. 99% efficient, in steady state.
        </p>
      </Chapter>

      {/* ============ STARTUP ============ */}
      <Chapter num="04" kicker="Starting it up">
        <h2>Coaxing the spot to <em>appear</em>.</h2>
        <p>
          Cold, a mercury arc rectifier is just a bottle of inert liquid and some carbon rods. There is no thermionic filament to switch on. The arc has to be <em className="term">struck</em> — bootstrapped into existence from nothing — and then handed off, in sequence, from a seed circuit to a holding circuit to the main anodes. The whole choreography takes about five seconds from a warm tube.
        </p>
        <Fig
          id="FIG. 04"
          title="Ignition sequence · step-through"
          caption="Click any step in the panel, or hit Auto-run to watch the cycle. The mechanism shown is the dipped-electrode style used in glass-bulb units; large steel-tank loco rectifiers used a solenoid-pulled magnetic plunger that achieved the same thing without breaking the vacuum.">
          <StartupDiagram />
        </Fig>
        <h3>What goes wrong at startup</h3>
        <p>
          Plenty. If the bulb is too cold, vapour pressure is too low and the seed arc won't propagate — you get a flash at the ignitor and nothing else. If too warm (the envelope above ≈ 60 °C), pressure climbs, the arc gets unstable and is prone to arc-back as soon as load comes on. Class 81 drivers reported routine 15-minute warm-up holds at Crewe in winter before a loco could be moved off shed.
        </p>
        <p>
          The ignitor itself is fragile. The dipping electrode pulls through liquid mercury thousands of times per shift; vibration accelerates wear; the magnetic plunger sticks. When it fails, the locomotive can deliver no DC at all — every locomotive carried two parallel rectifier tanks partly so the train could limp home on one.
        </p>
      </Chapter>

      {/* ============ SIZE ============ */}
      <Chapter num="05" kicker="Size & power">
        <h2>Why high power means <em>physically large</em>.</h2>
        <p>
          The conducting cathode spot is microscopic. The plasma column carrying the current is a few millimetres across. So why does a 1 500 A rectifier need to be the size of a domestic fridge? Two reasons, both having nothing to do with the current path itself.
        </p>
        <p>
          <strong>Voltage standoff.</strong> The envelope has to hold off the inverse peak voltage of the AC supply across vapour that is, by design, conductive enough to support an arc. The only thing preventing back-conduction is the asymmetry of the cathode. Make the gap shorter and the back-fire probability rises; make it longer and you can hold off more volts. Distance scales roughly linearly with peak voltage.
        </p>
        <p>
          <strong>Thermal management.</strong> The cathode pool dissipates ≈ 25 V × I as heat directly into the mercury. At 1 500 A that's 37 kW — into a few kilograms of liquid metal. Without continuous condensation back to the pool, the vapour pressure runs away and the tube fails. The condensing surface area, and the cooling jacket around it, sets the size of the bulb. <em className="term">Triple the current, you have to roughly double every linear dimension</em> and add forced cooling.
        </p>
        <Fig
          id="FIG. 05"
          title="Scaling · current vs envelope size"
          caption="Drag the slider to see how envelope geometry follows the current rating. Below 500 A, a sealed glass bulb with natural air cooling will do. Above ≈ 1 kA, you need a steel tank with bolt-on insulator necks (so anodes can be replaced) and a water jacket. Above ≈ 2 kA you abandon the single-tank design entirely and stack multiple lower-current valves in series.">
          <ScalingDiagram />
        </Fig>
        <div className="callout">
          <div className="sym">§</div>
          <div className="body">
            <div className="label">For comparison</div>
            <p>A modern thyristor stack delivering the same 1 500 A DC is about the size of a shoebox. The improvement in power density between 1960 and 1980 was roughly a factor of 200 — comparable to the transistor-replacing-the-vacuum-tube revolution one decade earlier, but for kilowatts instead of microwatts.</p>
          </div>
        </div>
      </Chapter>

      {/* ============ THE LOCO ============ */}
      <Chapter num="06" kicker="The locomotive">
        <h2>One tonne of glass and graphite, between the cab and the bogies.</h2>
        <p>
          The Class 81 — the AL1 — was the first new 25 kV AC locomotive on British Railways, delivered November 1959. Internally it followed a layout shared by the Classes 81, 82, 83 and 84 (only Class 85 was different, using germanium then silicon). The pantograph sits at the rear of the loco; the air-blast circuit breaker is just inside the roof; the main transformer hangs below the floor; and the rectifiers sit in the centre of the locomotive body, two parallel steel tanks fed from six secondary taps on the transformer.
        </p>
        <Fig
          id="FIG. 06"
          title="Class 81 (AL1) · schematic side elevation"
          caption="A simplified side view — not to internal layout scale. The two rectifier tanks are roughly central, both for weight distribution and to keep the high-voltage AC side close to the transformer. Each tank carried 6 main anodes; loss of one anode reduced the loco to ⅚ rating but it kept moving.">
          <LocoBayDiagram />
        </Fig>
        <p>
          The Class 81 — and all the AL1–AL4 designs — used <em className="term">tap-change control</em> on the AC side of the transformer rather than chopping the DC. Notches 1 through 38 on the driver's controller selected different secondary tap combinations, varying the AC voltage fed to the rectifiers and thus the DC bus voltage. This put the switching wear onto a robust oil-immersed tap changer rather than onto the rectifier itself, which simply rectified whatever AC it was given.
        </p>
        <p>
          It also meant the rectifier never had to be turned on and off in service. Once the loco was running, the spot stayed lit. Stop in a passing loop, brake to rest — the excitation arc kept the cathode warm and the main arcs picked up as soon as the driver took a notch. Only at shed-down, or after a fault trip, did the tube go cold.
        </p>
      </Chapter>

      {/* ============ FAILURE MODES ============ */}
      <Chapter num="07" kicker="Failure modes">
        <h2>The valve that, occasionally, <em>tries to kill itself</em>.</h2>
        <p>
          Mercury arc rectifiers fail in distinctive and dramatic ways. The Class 81–84 fleet became notorious for unreliability not because they were badly built — they weren't — but because the underlying physics has many ways to go wrong. The two main failure modes:
        </p>
        <Fig
          id="FIG. 07"
          title="Normal vs arc-back vs quench"
          caption="Arc-back (also called backfire) is the killer. An anode that should be blocking starts conducting in reverse, turning the rectifier into a near-short across the AC supply. Tens of kA flow within milliseconds. The vacuum circuit breaker has to trip before the transformer windings or the glass envelope fail.">
          <ArcBackDiagram />
        </Fig>
        <div className="callout hot">
          <div className="sym">!</div>
          <div className="body">
            <div className="label">The Class 81 / 82 / 83 / 84 reliability problem</div>
            <p>From the late 1960s the original mercury arc rectifiers on the AL1 – AL4 fleets were progressively replaced with silicon stacks. Several locos suffered fires traced to rectifier faults; whole sub-classes were stored for years awaiting conversion. The Class 84s — North British design — were the worst, repeatedly stored, and were largely out of front-line service by the mid-1970s despite being only ten years old.</p>
          </div>
        </div>
        <h3>Mechanical stressors</h3>
        <p>
          A railway locomotive is a deeply hostile environment for a glass bottle of mercury. Mechanical vibration disturbs the cathode spot — at worst, splashing pool mercury onto the anode stems where it can briefly bridge the gap and trigger an arc-back. Sudden lateral acceleration on points and crossovers does the same. Steel-tank designs tolerated this better than glass, which is part of why the loco rectifiers were tanks. But even steel tanks needed shock-mounted, level installations and could not be rotated through more than a few degrees.
        </p>
        <p>
          Cooling-air loss was catastrophic. A blower failure on a working locomotive meant the envelope temperature climbed, vapour pressure climbed with it, the arc destabilised, and the operator had perhaps thirty seconds before an arc-back or worse. Several documented Class 81/82/84 fires originated this way.
        </p>
      </Chapter>

      {/* ============ DANGERS ============ */}
      <Chapter num="08" kicker="Dangers">
        <h2>Three different ways a mercury rectifier can hurt you.</h2>
        <h3>1 · Mercury vapour</h3>
        <p>
          The tube holds several kilograms of elemental mercury at low pressure. Catastrophic glass failure releases all of it as droplets and vapour into the locomotive body. Acute exposure causes respiratory damage; chronic low-level exposure — common around poorly-maintained installations — causes tremor, cognitive impairment, and kidney damage. Substation crews working around mercury rectifiers in the 1930s-50s suffered well-documented occupational poisoning. Modern decommissioning of surviving units is treated as hazardous-waste work, with bulbs transported in straw-lined crates and atmosphere-controlled disposal.
        </p>
        <h3>2 · Hard ultraviolet</h3>
        <p>
          The mercury arc emits intense short-wave UV — including the 254 nm germicidal line — across the entire visible-blue glow. Looking into an unshielded operating rectifier for more than a few seconds produces photo-keratitis (arc-eye) the same as a welding arc. The glass envelope itself blocks most of it, but viewing windows on steel tanks were always darkened, and operators carried tinted goggles. The pretty blue glow you see in photographs is, in person, painfully bright.
        </p>
        <h3>3 · High voltage and high energy</h3>
        <p>
          The rectifier sits between 25 kV AC and 1 kV DC busbars carrying upwards of 1 000 A. An arc-back fault can dump megajoules into the surrounding cabinet in milliseconds. Maintenance required full lockout: pantograph down, earthing stick onto the high-voltage bus, mercury pool grounded, and ten minutes to let any residual vapour ionisation die away.
        </p>
        <div className="callout">
          <div className="sym">⚕</div>
          <div className="body">
            <div className="label">Why decommissioning is painful</div>
            <p>A surviving mercury arc rectifier — like the Hackbridge-Hewittic units at Kempton Steam Museum, recovered from the Royal Opera House — has to be moved in pieces, with the glass bulbs separated and individually crated. The mercury is treated as Special Waste. There is no safe way to scrap one in a single piece; even apparently empty bulbs retain enough mercury to require hazmat handling.</p>
          </div>
        </div>
      </Chapter>

      {/* ============ PROS / CONS ============ */}
      <Chapter num="09" kicker="Verdict">
        <h2>What was good, what wasn't.</h2>
        <div className="pc-grid">
          <div className="col pros">
            <h4>↑ Strengths</h4>
            <ul>
              <li><strong>Eternal cathode.</strong> Self-renewing liquid pool; no filament; no electrode erosion. Some HVDC tubes ran 30 years continuously.</li>
              <li><strong>Very low forward drop.</strong> 20-30 V arc loss at any current, so 99% efficient in steady state.</li>
              <li><strong>Massive overload tolerance.</strong> The plasma column doesn't care about brief peaks; you can pull 3× rated current for seconds without damage.</li>
              <li><strong>Naturally polyphase.</strong> One tank handles 6 or 12 phases — no need for individual diode strings.</li>
              <li><strong>Grid control possible.</strong> Add a mesh between cathode and anode and you get a controllable rectifier — basis for early HVDC and motor drives.</li>
            </ul>
          </div>
          <div className="col cons">
            <h4>↓ Weaknesses</h4>
            <ul>
              <li><strong>Arc-back faults.</strong> Random, dramatic, and the main reliability problem. Required a fast circuit breaker on the AC side and elaborate grid-bias schemes to suppress.</li>
              <li><strong>Slow startup.</strong> Five seconds warm; thirty seconds to several minutes cold. No instant-on.</li>
              <li><strong>Temperature window.</strong> Stable operation only across a narrow envelope temperature range. Heaters, blowers, lagging — all needed.</li>
              <li><strong>Mercury hazard.</strong> Toxic at every life stage: operation, maintenance, transport, disposal.</li>
              <li><strong>Mechanical fragility.</strong> Glass envelopes and vibration are a bad pairing. Loco rectifiers used steel, but the ignitor mechanism still wore out.</li>
              <li><strong>Volume and weight.</strong> Tens of times bigger than the silicon stacks that replaced them.</li>
            </ul>
          </div>
        </div>
      </Chapter>

      {/* ============ LEGACY ============ */}
      <Chapter num="10" kicker="Legacy">
        <h2>How it ended.</h2>
        <p>
          The shift was not gradual. The first commercial silicon power diodes appeared around 1957; by 1962 they were robust enough for railway service; by 1965 they were obviously the future. The Class 85, last of the British prototype AC locos, was built in 1961 with germanium rectifiers and finished its production run with silicon. The Class 86 (1965 onwards) was silicon throughout. The earlier mercury-rectifier locos were progressively rebuilt during the 1970s — Class 83 went into store between 1967 and 1971 awaiting conversion. Class 84 never recovered; most were withdrawn outright.
        </p>
        <p>
          Mercury hung on longest in HVDC transmission, where the ability to handle quarter-megavolt blocking voltage in a single device was hard to match. The Inter-Island link in New Zealand and the Kingsnorth-to-London link both used mercury valves into the early 1970s. The last new mercury-arc HVDC installation was Cahora Bassa in Mozambique, commissioned 1979 — and even it was retrofitted with thyristors during refurbishment.
        </p>
        <p>
          What survives in museums — the Hackbridge-Hewittic units at Kempton, a Class 84 rectifier once on display at the National Railway Museum, a handful of preserved AC locos at Barrow Hill — is mostly silent, dark glass and graphite. To see one actually struck and running, in 2026, requires a specialist restoration crew, a hazmat plan, and a willingness to flinch when the cathode spot lights up.
        </p>
        <p>
          It is hard, looking back, to argue that the silicon thyristor wasn't a better invention. But the mercury arc rectifier remains one of the most aesthetically satisfying pieces of electrical engineering ever made — a machine whose principle of operation you can see, glowing, through its own envelope. There is no equivalent visible drama in a sealed semiconductor module. We got better at making electricity; we lost a certain kind of beauty doing it.
        </p>
      </Chapter>

      {/* ============ COLOPHON ============ */}
      <div className="colophon">
        <div>
          <div><b>Sources</b></div>
          <div>Wikipedia · IET <em>Electric Railways, 1880–1990</em> · The AC Locomotive Group · Kempton Steam Museum · electricstuff.co.uk · radiomuseum.org</div>
        </div>
        <div style={{ textAlign: "right" }}>
          <div><b>Mercury Arc Rectifiers</b> — A Technical Primer</div>
          <div>Typeset in Instrument Serif · Geist · JetBrains Mono</div>
        </div>
      </div>
    </div>
  );
}

ReactDOM.createRoot(document.getElementById("root")).render(<App />);
