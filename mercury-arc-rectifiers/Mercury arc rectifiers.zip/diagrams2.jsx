/* global React */
const { useState: useState2, useEffect: useEffect2, useRef: useRef2, useMemo: useMemo2 } = React;

/* ============================================================
   D-05  SCALING  — power vs envelope size
   ============================================================ */
function ScalingDiagram() {
  // 3 reference rigs to interpolate between
  const RIGS = [
    { label: "Substation glass bulb", curr: 100,  vDC: 600,  height: 1.4, type: "glass" },
    { label: "Industrial glass-bulb", curr: 500,  vDC: 600,  type: "glass" },
    { label: "Loco rectifier (steel)", curr: 1500, vDC: 850,  type: "steel" },
    { label: "HVDC valve hall",       curr: 2000, vDC: 250000, type: "hvdc" },
  ];
  const [curr, setCurr] = useState2(1500);
  // size scales roughly with sqrt of current; height in metres
  const heightM = 0.5 + Math.pow(curr / 100, 0.55) * 0.18;
  const widthM  = heightM * 0.65;
  const isSteel = curr >= 700;
  const isHVDC  = curr >= 1800;

  // SVG layout: human reference at 1.75 m, scale: 1m = 60 px
  const SCALE = 50;
  const groundY = 320;
  const W = 720, H = 380;

  const personH = 1.75;
  const personPx = personH * SCALE;
  const envPx = heightM * SCALE;
  const envWPx = widthM * SCALE;

  // approximate cooling needed (kW dissipated)
  const lossKW = (curr * 25) / 1000; // ~25 V arc drop
  // mercury mass scales with anode count and footprint
  const mercuryKg = Math.max(2, Math.pow(curr / 100, 0.7) * 1.4);

  return (
    <div>
      <div className="stage" style={{ padding: 16, background: "var(--paper-2)" }}>
        <svg viewBox={`0 0 ${W} ${H}`} style={{ width: "100%", height: "auto", display: "block" }}>
          {/* ground rule */}
          <line x1="20" y1={groundY} x2={W - 20} y2={groundY} stroke="#15171c" strokeWidth="1" />
          {Array.from({ length: 30 }).map((_, i) => (
            <line key={i} x1={20 + i * 24} y1={groundY} x2={20 + i * 24 + 8} y2={groundY + 6} stroke="#15171c" strokeWidth="0.6" />
          ))}
          {/* metre marks */}
          {[0, 1, 2, 3, 4].map((m) => (
            <g key={m}>
              <line x1={W - 20} y1={groundY - m * SCALE} x2={W - 14} y2={groundY - m * SCALE} stroke="#15171c" strokeWidth="0.8" />
              <text x={W - 10} y={groundY - m * SCALE + 3} fontFamily="JetBrains Mono, monospace" fontSize="9" fill="#5a5648">{m} m</text>
            </g>
          ))}
          {/* person silhouette */}
          <g transform={`translate(80 ${groundY})`}>
            <ellipse cx="0" cy={-personPx + 8} rx="11" ry="13" fill="#2a2e36" />
            <path d={`M -16 ${-personPx + 24} L -16 ${-personPx * 0.55} L -10 ${-personPx * 0.55} L -10 ${-3} L -3 ${-3} L -3 ${-personPx * 0.55} L 3 ${-personPx * 0.55} L 3 ${-3} L 10 ${-3} L 10 ${-personPx * 0.55} L 16 ${-personPx * 0.55} L 16 ${-personPx + 24} Z`}
              fill="#2a2e36" />
            <text x="0" y="20" textAnchor="middle" fontFamily="JetBrains Mono, monospace" fontSize="9" fill="#5a5648">1.75 m operator</text>
          </g>

          {/* envelope rendering */}
          <g transform={`translate(360 ${groundY})`}>
            {isHVDC ? (
              // HVDC: stacked multi-anode mercury arc valve column
              <>
                {[0, 1, 2, 3].map((i) => {
                  const segH = envPx / 4;
                  const y = -segH * (i + 1) + 4;
                  return (
                    <g key={i}>
                      <ellipse cx="0" cy={y + segH * 0.5} rx={envWPx * 0.55} ry={segH * 0.4}
                        fill="url(#glassEnvelope)" stroke="#15171c" strokeWidth="1" />
                      <ellipse cx="0" cy={y + segH * 0.5} rx={envWPx * 0.25} ry={segH * 0.2}
                        fill="url(#arcGlow)" opacity="0.65" />
                    </g>
                  );
                })}
                <rect x={-envWPx * 0.7} y={-envPx - 14} width={envWPx * 1.4} height="10" fill="#2a2e36" />
                <rect x={-envWPx * 0.7} y={-4} width={envWPx * 1.4} height="10" fill="#2a2e36" />
              </>
            ) : isSteel ? (
              // Steel tank — squat cylinder w/ insulator necks on top
              <>
                <rect x={-envWPx * 0.7} y={-envPx} width={envWPx * 1.4} height={envPx} rx="14"
                  fill="#cfc6ad" stroke="#15171c" strokeWidth="1.2" />
                <rect x={-envWPx * 0.7} y={-envPx} width={envWPx * 1.4} height="8" fill="url(#hatch)" opacity="0.5" />
                {/* anode necks */}
                {[-3, -1, 1, 3].map((i) => (
                  <g key={i}>
                    <rect x={i * envWPx * 0.18 - 4} y={-envPx - 24} width="8" height="24" fill="#cfc6ad" stroke="#15171c" strokeWidth="0.8" />
                    <rect x={i * envWPx * 0.18 - 5} y={-envPx - 30} width="10" height="6" fill="#1f1c14" />
                  </g>
                ))}
                {/* cooling jacket */}
                <line x1={-envWPx * 0.7 - 4} y1={-envPx * 0.7} x2={-envWPx * 0.7 - 12} y2={-envPx * 0.7} stroke="#2a6fdb" strokeWidth="1.5" />
                <line x1={envWPx * 0.7 + 4} y1={-envPx * 0.3} x2={envWPx * 0.7 + 12} y2={-envPx * 0.3} stroke="#2a6fdb" strokeWidth="1.5" />
                <text x={-envWPx * 0.7 - 50} y={-envPx * 0.7 + 3} fontFamily="JetBrains Mono, monospace" fontSize="8" fill="#2a6fdb">H₂O in</text>
                <text x={envWPx * 0.7 + 16} y={-envPx * 0.3 + 3} fontFamily="JetBrains Mono, monospace" fontSize="8" fill="#2a6fdb">H₂O out</text>
                {/* internal glow */}
                <ellipse cx="0" cy={-envPx * 0.5} rx={envWPx * 0.4} ry={envPx * 0.3} fill="url(#arcGlow)" opacity="0.45" />
              </>
            ) : (
              // Glass bulb
              <>
                <path d={`M 0 ${-envPx}
                          C ${envWPx * 0.9} ${-envPx}, ${envWPx * 1.1} ${-envPx * 0.55}, ${envWPx * 1.1} ${-envPx * 0.35}
                          C ${envWPx * 1.1} ${-envPx * 0.1}, ${envWPx * 0.4} 0, 0 0
                          C ${-envWPx * 0.4} 0, ${-envWPx * 1.1} ${-envPx * 0.1}, ${-envWPx * 1.1} ${-envPx * 0.35}
                          C ${-envWPx * 1.1} ${-envPx * 0.55}, ${-envWPx * 0.9} ${-envPx}, 0 ${-envPx} Z`}
                  fill="url(#glassEnvelope)" stroke="#15171c" strokeWidth="1.2" />
                {/* anode arms */}
                {[-1, 1].map((i) => (
                  <g key={i}>
                    <ellipse cx={i * envWPx * 0.55} cy={-envPx * 0.5} rx={envWPx * 0.18} ry={envPx * 0.16}
                      fill="url(#glassEnvelope)" stroke="#15171c" strokeWidth="0.8" />
                  </g>
                ))}
                <ellipse cx="0" cy={-2} rx={envWPx * 0.8} ry="4" fill="url(#mercuryPool)" />
                <ellipse cx="0" cy={-envPx * 0.4} rx={envWPx * 0.5} ry={envPx * 0.3} fill="url(#arcGlow)" opacity="0.5" />
              </>
            )}
            {/* base */}
            <rect x={-envWPx * 0.8} y="-4" width={envWPx * 1.6} height="10" fill="#2a2e36" />
            {/* height tick */}
            <line x1={envWPx * 0.8 + 14} y1="0" x2={envWPx * 0.8 + 14} y2={-envPx} stroke="#5a5648" strokeWidth="0.6" />
            <line x1={envWPx * 0.8 + 10} y1="0" x2={envWPx * 0.8 + 18} y2="0" stroke="#5a5648" strokeWidth="0.6" />
            <line x1={envWPx * 0.8 + 10} y1={-envPx} x2={envWPx * 0.8 + 18} y2={-envPx} stroke="#5a5648" strokeWidth="0.6" />
            <text x={envWPx * 0.8 + 22} y={-envPx / 2 + 3} fontFamily="JetBrains Mono, monospace" fontSize="9" fill="#5a5648">{heightM.toFixed(2)} m</text>
          </g>

          {/* ArcDefs needs to live somewhere */}
          <defs>
            <radialGradient id="arcGlow2" cx="50%" cy="50%" r="50%">
              <stop offset="0%" stopColor="#f3eaff" stopOpacity="1" />
              <stop offset="40%" stopColor="#b794ff" stopOpacity="0.8" />
              <stop offset="100%" stopColor="#3a2480" stopOpacity="0" />
            </radialGradient>
          </defs>

          {/* type label */}
          <text x={W - 24} y="34" textAnchor="end" fontFamily="Instrument Serif, serif" fontSize="22" fill="#15171c">
            {isHVDC ? "Multi-stack HVDC valve" : isSteel ? "Steel-tank rectifier" : "Glass-bulb rectifier"}
          </text>
          <text x={W - 24} y="50" textAnchor="end" fontFamily="JetBrains Mono, monospace" fontSize="10" fill="#5a5648">
            {isHVDC ? "Pearl Harbor / Kingsnorth-class" : isSteel ? "BR Class 81–84 era" : "1920s–50s sub-station"}
          </text>
        </svg>
      </div>

      <div className="controls" style={{ flexWrap: "wrap" }}>
        <span className="ctl-label">DC current</span>
        <input className="slider" type="range" min="50" max="2000" step="10"
          value={curr} onChange={(e) => setCurr(parseInt(e.target.value))} />
        <span className="mono" style={{ fontSize: 13, color: "var(--ink)", fontWeight: 600, minWidth: 70 }}>{curr.toLocaleString()} A</span>
      </div>

      <div className="spec-grid">
        <div className="cell">
          <div className="k">Envelope height</div>
          <div className="v">{heightM.toFixed(2)}<span className="u">m</span></div>
        </div>
        <div className="cell">
          <div className="k">Mercury charge</div>
          <div className="v">{mercuryKg.toFixed(1)}<span className="u">kg</span></div>
        </div>
        <div className="cell">
          <div className="k">Arc-loss heat</div>
          <div className="v">{lossKW.toFixed(1)}<span className="u">kW</span></div>
        </div>
        <div className="cell">
          <div className="k">Cooling</div>
          <div className="v" style={{ fontSize: 20 }}>{curr < 300 ? "Natural" : curr < 800 ? "Forced air" : "Water jacket"}</div>
        </div>
      </div>
      <div style={{ fontSize: 13, color: "var(--ink-3)", marginTop: 4 }}>
        Why so big? The cathode spot is &lt;1 mm² — but you need <b style={{color:"var(--ink)"}}>distance</b>: enough mean free path through the rarefied vapour to stop a back-fire jumping the wrong way, and enough surface area on the envelope to condense the boiling mercury back into the pool faster than it evaporates. Triple the current, double the linear dimensions.
      </div>
    </div>
  );
}

/* ============================================================
   D-06  LOCO BAY  — Class 81/84 side elevation
   ============================================================ */
function LocoBayDiagram() {
  const [active, setActive] = useState2("rect");
  const PARTS = [
    { id: "pant", x: 410, y: 38, name: "Pantograph", note: "25 kV AC from overhead catenary" },
    { id: "vcb",  x: 470, y: 70, name: "Vacuum circuit breaker", note: "Primary protection — opens at fault current in < 30 ms" },
    { id: "tx",   x: 350, y: 130, name: "Main transformer", note: "25 kV → 6-phase tapped LV; ≈ 5 t of iron and oil, the heaviest single item" },
    { id: "rect", x: 220, y: 130, name: "Mercury arc rectifier", note: "Two steel-tank units in parallel. 6-phase AC in, smoothed DC out. ~1100 A continuous." },
    { id: "react", x: 130, y: 130, name: "Smoothing reactor", note: "Iron-cored choke; absorbs 6-pulse ripple before the DC reaches the motors" },
    { id: "tm",   x: 60,  y: 195, name: "DC traction motors (×4)", note: "Series-wound. Field weakening, tap-change on transformer = speed control" },
    { id: "cool", x: 285, y: 175, name: "Blower / oil cooling", note: "Forced air over rectifier tanks. Loss of cooling = arc instability = trouble" },
  ];
  const cur = PARTS.find((p) => p.id === active);
  return (
    <div>
      <div className="stage" style={{ padding: 0, background: "var(--paper)" }}>
        <svg viewBox="0 0 560 280" style={{ width: "100%", height: "auto", display: "block" }}>
          {/* catenary */}
          <line x1="40" y1="20" x2="520" y2="20" stroke="#15171c" strokeWidth="0.8" strokeDasharray="2 3" />
          <text x="46" y="14" fontFamily="JetBrains Mono, monospace" fontSize="9" fill="#5a5648">25 kV 50 Hz CATENARY</text>
          {/* pantograph */}
          <line x1="410" y1="20" x2="410" y2="38" stroke="#15171c" strokeWidth="1.2" />
          <polyline points="380,60 410,38 440,60" stroke="#15171c" strokeWidth="1.4" fill="none" />
          <polyline points="380,80 410,60 440,80" stroke="#15171c" strokeWidth="1.4" fill="none" />
          <line x1="410" y1="80" x2="410" y2="92" stroke="#15171c" strokeWidth="1.2" />
          {/* loco body */}
          <path d="M 30 215 L 40 200 L 60 200 L 60 92 L 540 92 L 540 200 L 520 200 L 530 215 Z"
            fill="#e3dcc8" stroke="#15171c" strokeWidth="1.4" />
          {/* cab windows */}
          <rect x="74" y="100" width="40" height="22" fill="#cfc6ad" stroke="#15171c" strokeWidth="0.8" />
          <rect x="486" y="100" width="40" height="22" fill="#cfc6ad" stroke="#15171c" strokeWidth="0.8" />
          {/* internal partitions */}
          <line x1="115" y1="92" x2="115" y2="180" stroke="#5a5648" strokeWidth="0.4" strokeDasharray="3 2" />
          <line x1="175" y1="92" x2="175" y2="180" stroke="#5a5648" strokeWidth="0.4" strokeDasharray="3 2" />
          <line x1="285" y1="92" x2="285" y2="180" stroke="#5a5648" strokeWidth="0.4" strokeDasharray="3 2" />
          <line x1="425" y1="92" x2="425" y2="180" stroke="#5a5648" strokeWidth="0.4" strokeDasharray="3 2" />

          {/* transformer */}
          <rect x="295" y="105" width="120" height="80" fill="#cfc6ad" stroke="#15171c" strokeWidth="1" />
          <text x="355" y="150" textAnchor="middle" fontFamily="Instrument Serif, serif" fontSize="13" fill="#15171c">TX</text>
          <line x1="305" y1="115" x2="405" y2="115" stroke="#15171c" strokeWidth="0.4" />
          <line x1="305" y1="175" x2="405" y2="175" stroke="#15171c" strokeWidth="0.4" />

          {/* rectifier — two tanks */}
          {[185, 245].map((rx, i) => (
            <g key={i}>
              <rect x={rx} y="110" width="40" height="70" rx="6" fill="#cfc6ad" stroke="#15171c" strokeWidth="1" />
              <rect x={rx} y="110" width="40" height="6" fill="url(#hatch)" opacity="0.4" />
              {/* anode necks */}
              {[0, 1, 2].map((j) => (
                <rect key={j} x={rx + 8 + j * 12} y="100" width="6" height="14" fill="#1f1c14" />
              ))}
              {/* glow */}
              <ellipse cx={rx + 20} cy="145" rx="12" ry="18" fill="#b794ff" opacity={active === "rect" ? 0.65 : 0.35} />
            </g>
          ))}

          {/* smoothing reactor */}
          <rect x="120" y="120" width="48" height="60" fill="#cfc6ad" stroke="#15171c" strokeWidth="1" />
          <text x="144" y="158" textAnchor="middle" fontFamily="Instrument Serif, serif" fontSize="11" fill="#15171c">L</text>
          {/* coil hint */}
          {[0, 1, 2, 3].map((i) => (
            <ellipse key={i} cx="144" cy={130 + i * 12} rx="14" ry="2" fill="none" stroke="#5a5648" strokeWidth="0.5" />
          ))}

          {/* DC bus to motors */}
          <line x1="65" y1="190" x2="540" y2="190" stroke="#15171c" strokeWidth="0.6" strokeDasharray="2 3" />
          {/* bogies / wheels / motors */}
          {[80, 150, 410, 480].map((wx, i) => (
            <g key={i}>
              <circle cx={wx} cy="215" r="14" fill="#cfc6ad" stroke="#15171c" strokeWidth="1.2" />
              <circle cx={wx} cy="215" r="6" fill="#1f1c14" />
              {/* motor */}
              <rect x={wx - 8} y="200" width="16" height="10" fill="#3a382f" />
            </g>
          ))}
          {/* rails */}
          <line x1="20" y1="232" x2="540" y2="232" stroke="#15171c" strokeWidth="1.4" />
          {/* ground hatch */}
          {Array.from({ length: 40 }).map((_, i) => (
            <line key={i} x1={20 + i * 13} y1="232" x2={26 + i * 13} y2="240" stroke="#5a5648" strokeWidth="0.5" />
          ))}

          {/* hotspot markers */}
          {PARTS.map((p) => (
            <g key={p.id} onClick={() => setActive(p.id)} style={{ cursor: "pointer" }}>
              <circle cx={p.x} cy={p.y} r={active === p.id ? 10 : 8}
                fill={active === p.id ? "#c0392b" : "#f1ece1"}
                stroke={active === p.id ? "#c0392b" : "#15171c"} strokeWidth="1.2" />
              <circle cx={p.x} cy={p.y} r="2.5" fill={active === p.id ? "#f1ece1" : "#15171c"} />
            </g>
          ))}

          {/* spec text */}
          <text x="20" y="266" fontFamily="JetBrains Mono, monospace" fontSize="9" fill="#5a5648">
            CLASS 81 (AL1) · 25 kV AC · 3 380 hp · 1 110 A DC continuous to 4 series-wound traction motors
          </text>
        </svg>
      </div>
      <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr 1fr 1fr", borderTop: "1px solid var(--rule)" }}>
        {PARTS.map((p) => (
          <div key={p.id}
            onClick={() => setActive(p.id)}
            style={{
              padding: "10px 12px",
              borderRight: "1px solid var(--rule)",
              borderBottom: "1px solid var(--rule)",
              background: active === p.id ? "var(--paper-3)" : "transparent",
              cursor: "pointer",
              fontFamily: "JetBrains Mono, monospace",
              fontSize: 10,
              color: active === p.id ? "var(--hot)" : "var(--ink-3)",
              textTransform: "uppercase",
              letterSpacing: "0.08em",
              transition: "all 0.15s"
            }}>
            {p.name}
          </div>
        ))}
      </div>
      <div style={{ padding: "14px 18px", fontSize: 14, color: "var(--ink-2)", background: "var(--paper-2)", lineHeight: 1.5 }}>
        <b className="serif" style={{ fontSize: 17, color: "var(--ink)" }}>{cur.name}.</b>{" "}{cur.note}
      </div>
    </div>
  );
}

/* ============================================================
   D-07  ARCBACK  — failure-mode animation
   ============================================================ */
function ArcBackDiagram() {
  const [mode, setMode] = useState2("normal"); // normal | arcback | quench
  const t = useClock(true, 1);
  const cx = 200;
  // current direction indicator
  const flip = mode === "arcback";
  const [sx, sy] = cathodeSpotPos(t, cx, 240, 16);

  return (
    <div>
      <div className="stage" style={{ display: "grid", gridTemplateColumns: "1fr 280px" }}>
        <div style={{ padding: 12 }}>
          <svg viewBox="0 0 400 320" style={{ width: "100%", height: "auto", display: "block" }}>
            <defs>
              <radialGradient id="arcGlow3" cx="50%" cy="50%" r="50%">
                <stop offset="0%" stopColor="#f3eaff" stopOpacity="1" />
                <stop offset="40%" stopColor="#b794ff" stopOpacity="0.7" />
                <stop offset="100%" stopColor="#3a2480" stopOpacity="0" />
              </radialGradient>
              <radialGradient id="arcGlowHot" cx="50%" cy="50%" r="50%">
                <stop offset="0%" stopColor="#fff8e0" stopOpacity="1" />
                <stop offset="35%" stopColor="#ff8a3a" stopOpacity="0.85" />
                <stop offset="100%" stopColor="#5a1010" stopOpacity="0" />
              </radialGradient>
              <radialGradient id="poolGrad" cx="50%" cy="20%" r="80%">
                <stop offset="0%" stopColor="#e6e3da" />
                <stop offset="55%" stopColor="#8a8678" />
                <stop offset="100%" stopColor="#3a382f" />
              </radialGradient>
            </defs>
            {/* tank */}
            <rect x="50" y="40" width="300" height="220" rx="14" fill="#cfc6ad" stroke="#15171c" strokeWidth="1.4" />
            {/* anodes */}
            {[100, 200, 300].map((ax, i) => (
              <g key={i}>
                <line x1={ax} y1="40" x2={ax} y2="100" stroke="#15171c" strokeWidth="2.5" />
                <rect x={ax - 6} y="22" width="12" height="22" fill="#1f1c14" />
                <text x={ax} y="18" textAnchor="middle" fontFamily="JetBrains Mono, monospace" fontSize="10" fill="#5a5648">A{i + 1}</text>
                <circle cx={ax} cy="100" r="6" fill={mode === "arcback" && i === 1 ? "#c0392b" : "#3a382f"} />
              </g>
            ))}
            {/* pool */}
            <ellipse cx={cx} cy="250" rx="135" ry="8" fill="url(#poolGrad)" />
            <text x="65" y="278" fontFamily="JetBrains Mono, monospace" fontSize="9" fill="#5a5648">CATHODE POOL</text>

            {/* NORMAL */}
            {mode === "normal" && (
              <>
                <ellipse cx={sx} cy="240" rx="18" ry="9" fill="#fffaf0" opacity="0.95" />
                {[100, 200, 300].map((ax, i) => {
                  const on = Math.floor(t * 1.5) % 3 === i;
                  return (
                    <path key={i} d={jaggedArc(sx, sy, ax, 100, 9, 3, t + i)}
                      stroke={on ? "#f3eaff" : "#7c5cff"}
                      strokeWidth={on ? 1.6 : 0.6}
                      fill="none" opacity={on ? 1 : 0.3} />
                  );
                })}
                <ellipse cx="200" cy="170" rx="120" ry="90" fill="url(#arcGlow3)" opacity="0.25" />
                {/* electron arrow up */}
                <g fontFamily="JetBrains Mono, monospace" fontSize="9" fill="#1f8a5b">
                  <line x1="370" y1="220" x2="370" y2="80" stroke="#1f8a5b" strokeWidth="1.2" markerEnd="url(#arrUp)" />
                  <text x="376" y="150">e⁻ flow</text>
                  <text x="376" y="162">↑ to anode</text>
                </g>
                <defs>
                  <marker id="arrUp" viewBox="0 0 10 10" refX="5" refY="2" markerWidth="6" markerHeight="6" orient="auto">
                    <path d="M 0 8 L 5 0 L 10 8 Z" fill="#1f8a5b" />
                  </marker>
                </defs>
              </>
            )}

            {/* ARCBACK */}
            {mode === "arcback" && (
              <>
                {/* angry orange flash */}
                <ellipse cx="200" cy="160" rx="200" ry="160" fill="url(#arcGlowHot)" opacity="0.6" />
                <ellipse cx={sx} cy="240" rx="22" ry="11" fill="#fff8e0" opacity="0.95" />
                {/* runaway arc to A2 — fat, jagged, hot */}
                <path d={jaggedArc(sx, sy, 200, 100, 14, 12, t * 1.6)}
                  stroke="#fff8e0" strokeWidth="3" fill="none" />
                <path d={jaggedArc(sx, sy, 200, 100, 18, 16, t * 2.1)}
                  stroke="#ff8a3a" strokeWidth="6" fill="none" opacity="0.6" style={{ mixBlendMode: "screen" }} />
                {/* current arrow DOWNWARDS = wrong direction */}
                <defs>
                  <marker id="arrDn" viewBox="0 0 10 10" refX="5" refY="8" markerWidth="6" markerHeight="6" orient="auto">
                    <path d="M 0 0 L 5 8 L 10 0 Z" fill="#c0392b" />
                  </marker>
                </defs>
                <g>
                  <line x1="370" y1="80" x2="370" y2="220" stroke="#c0392b" strokeWidth="1.4" markerEnd="url(#arrDn)" />
                  <text x="376" y="150" fontFamily="JetBrains Mono, monospace" fontSize="9" fill="#c0392b">REVERSE</text>
                  <text x="376" y="162" fontFamily="JetBrains Mono, monospace" fontSize="9" fill="#c0392b">↓ short to</text>
                  <text x="376" y="174" fontFamily="JetBrains Mono, monospace" fontSize="9" fill="#c0392b">  HV side</text>
                </g>
                {/* warning */}
                <g transform="translate(60 286)">
                  <rect x="0" y="0" width="220" height="20" fill="#c0392b" />
                  <text x="6" y="14" fontFamily="JetBrains Mono, monospace" fontSize="10" fill="#f1ece1" fontWeight="700">▲ ARC-BACK · TRIP THE VCB NOW</text>
                </g>
              </>
            )}

            {/* QUENCH */}
            {mode === "quench" && (
              <>
                {/* dim, mercury condensing */}
                <ellipse cx="200" cy="170" rx="120" ry="90" fill="url(#arcGlow3)" opacity="0.08" />
                <ellipse cx={cx} cy="240" rx="12" ry="6" fill="#dad6c9" opacity="0.6" />
                {/* drops */}
                {Array.from({ length: 12 }).map((_, i) => {
                  const x = 60 + i * 26;
                  const phase = (t * 60 + i * 17) % 200;
                  return (
                    <circle key={i} cx={x} cy={50 + phase} r="1.5" fill="#8a8678" opacity={phase > 180 ? 0 : 0.7} />
                  );
                })}
                <g fontFamily="JetBrains Mono, monospace" fontSize="9" fill="#5a5648">
                  <text x="60" y="285">cathode spot extinguished · Hg vapour condensing · re-ignite required</text>
                </g>
              </>
            )}
          </svg>
        </div>
        <div style={{ borderLeft: "1px solid var(--rule)", padding: 18, fontSize: 14, lineHeight: 1.5 }}>
          {mode === "normal" && (
            <>
              <div className="mono smallcaps" style={{ color: "var(--ink-3)", marginBottom: 6 }}>State · Normal Rectification</div>
              <div className="serif" style={{ fontSize: 20, marginBottom: 8 }}>Electrons up. Ions down.</div>
              <p style={{ margin: 0, color: "var(--ink-2)" }}>The cathode pool supplies electrons that race up to whichever anode is positive at that instant. Positive mercury ions drift back down to the pool, regenerating the spot. Arc voltage drop is steady at 20–30 V.</p>
            </>
          )}
          {mode === "arcback" && (
            <>
              <div className="mono smallcaps" style={{ color: "var(--hot)", marginBottom: 6 }}>Fault · Arc-back / Backfire</div>
              <div className="serif" style={{ fontSize: 20, marginBottom: 8, color: "var(--hot)" }}>The valve runs backwards.</div>
              <p style={{ margin: 0, color: "var(--ink-2)" }}>An anode that should be blocking — because its phase has gone negative — instead ionises and conducts. Now the rectifier is a dead short across the AC side. Currents of tens of kA flow in milliseconds. The main vacuum circuit breaker must trip before the transformer windings melt or the glass shatters.</p>
              <p style={{ margin: "8px 0 0", color: "var(--ink-3)", fontSize: 13 }}>Triggered by: anode overheating, residual ionisation, glass impurities, mechanical vibration disturbing the cathode spot — basically anything that lets vapour conduct when it shouldn't. The single biggest reliability headache of the Class 81-84.</p>
            </>
          )}
          {mode === "quench" && (
            <>
              <div className="mono smallcaps" style={{ color: "var(--ink-3)", marginBottom: 6 }}>Fault · Arc Quench</div>
              <div className="serif" style={{ fontSize: 20, marginBottom: 8 }}>The spot goes out.</div>
              <p style={{ margin: 0, color: "var(--ink-2)" }}>If load current falls below the holding minimum (~3-5 A) the cathode spot loses its energy budget and dies. The whole valve cools, vapour condenses, and the tube must be re-ignited from scratch — locomotive coasts dead until restart completes.</p>
            </>
          )}
        </div>
      </div>
      <div className="controls">
        <span className="ctl-label">Mode</span>
        <button className="btn" data-active={mode === "normal"} onClick={() => setMode("normal")}>Normal</button>
        <button className="btn hot" data-active={mode === "arcback"} onClick={() => setMode("arcback")}>Arc-back</button>
        <button className="btn" data-active={mode === "quench"} onClick={() => setMode("quench")}>Quench</button>
      </div>
    </div>
  );
}

Object.assign(window, { ScalingDiagram, LocoBayDiagram, ArcBackDiagram });
