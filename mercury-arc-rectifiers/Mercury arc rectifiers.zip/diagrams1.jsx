/* global React */
const { useState, useEffect, useRef, useMemo } = React;

/* ============================================================
   Shared primitives
   ============================================================ */

// rAF-driven clock that gives a time in seconds, paused when `playing`=false
function useClock(playing, speed = 1) {
  const [t, setT] = useState(0);
  const last = useRef(performance.now());
  useEffect(() => {
    if (!playing) return;
    let raf;
    const tick = (now) => {
      const dt = Math.max(0, (now - last.current) / 1000);
      last.current = now;
      setT((prev) => prev + dt * speed);
      raf = requestAnimationFrame(tick);
    };
    last.current = performance.now();
    raf = requestAnimationFrame(tick);
    return () => cancelAnimationFrame(raf);
  }, [playing, speed]);
  return t;
}

// jittery cathode spot using sinusoidal wobble
function cathodeSpotPos(t, cx, cy, range = 22) {
  const x = cx + Math.sin(t * 7.3) * range + Math.sin(t * 13.1) * (range * 0.4);
  const y = cy + Math.sin(t * 5.7) * 1.4 + Math.sin(t * 19) * 0.8;
  return [x, y];
}

// reusable defs for arc glow
function ArcDefs() {
  return (
    <defs>
      <radialGradient id="arcGlow" cx="50%" cy="50%" r="50%">
        <stop offset="0%"   stopColor="#f3eaff" stopOpacity="1" />
        <stop offset="30%"  stopColor="#b794ff" stopOpacity="0.9" />
        <stop offset="65%"  stopColor="#7c5cff" stopOpacity="0.45" />
        <stop offset="100%" stopColor="#3a2480" stopOpacity="0" />
      </radialGradient>
      <radialGradient id="cathodeGlow" cx="50%" cy="50%" r="50%">
        <stop offset="0%" stopColor="#ffffff" stopOpacity="1" />
        <stop offset="40%" stopColor="#d8c8ff" stopOpacity="0.9" />
        <stop offset="100%" stopColor="#7c5cff" stopOpacity="0" />
      </radialGradient>
      <radialGradient id="mercuryPool" cx="50%" cy="20%" r="80%">
        <stop offset="0%" stopColor="#e6e3da" />
        <stop offset="55%" stopColor="#8a8678" />
        <stop offset="100%" stopColor="#3a382f" />
      </radialGradient>
      <linearGradient id="glassEnvelope" x1="0" y1="0" x2="0" y2="1">
        <stop offset="0%" stopColor="#e8e2cf" stopOpacity="0.85" />
        <stop offset="100%" stopColor="#c7bf9f" stopOpacity="0.55" />
      </linearGradient>
      <pattern id="hatch" patternUnits="userSpaceOnUse" width="6" height="6" patternTransform="rotate(45)">
        <line x1="0" y1="0" x2="0" y2="6" stroke="#5a5648" strokeWidth="0.8" />
      </pattern>
    </defs>
  );
}

// curved arc path between two points
function arcPath(x1, y1, x2, y2, bowness = 0.25) {
  const mx = (x1 + x2) / 2;
  const my = (y1 + y2) / 2;
  // perpendicular offset
  const dx = x2 - x1, dy = y2 - y1;
  const len = Math.hypot(dx, dy);
  const ox = -dy / len * len * bowness;
  const oy =  dx / len * len * bowness;
  return `M ${x1} ${y1} Q ${mx + ox * 0.3} ${my + oy * 0.3} ${x2} ${y2}`;
}

// jagged lightning-style arc between two points
function jaggedArc(x1, y1, x2, y2, segments = 8, jitter = 6, seed = 0) {
  const pts = [[x1, y1]];
  for (let i = 1; i < segments; i++) {
    const t = i / segments;
    const px = x1 + (x2 - x1) * t;
    const py = y1 + (y2 - y1) * t;
    const r = Math.sin(seed * 1.7 + i * 2.3) * jitter;
    const ang = Math.atan2(y2 - y1, x2 - x1) + Math.PI / 2;
    pts.push([px + Math.cos(ang) * r, py + Math.sin(ang) * r]);
  }
  pts.push([x2, y2]);
  return "M " + pts.map((p) => p.join(" ")).join(" L ");
}

/* ============================================================
   D-01  HERO  — single-bulb glow with dancing cathode spot
   ============================================================ */
function HeroArc() {
  const t = useClock(true, 1);
  const [sx, sy] = cathodeSpotPos(t, 250, 312);
  const arcTop = [250, 120];
  const arcBranches = [
    [120, 200],
    [380, 200],
    [165, 260],
    [335, 260],
  ];
  const flick = 0.85 + 0.15 * Math.sin(t * 31);
  return (
    <svg viewBox="0 0 500 380" style={{ width: "100%", height: "auto", display: "block" }}>
      <ArcDefs />
      {/* glass envelope silhouette */}
      <path
        d="M 250 30
           C 360 30, 430 110, 430 200
           C 430 270, 380 320, 320 330
           L 320 350
           L 180 350
           L 180 330
           C 120 320, 70 270, 70 200
           C 70 110, 140 30, 250 30 Z"
        fill="url(#glassEnvelope)" stroke="#15171c" strokeWidth="1.4"
      />
      {/* anode arms */}
      {arcBranches.map(([ax, ay], i) => (
        <g key={i}>
          <line x1={ax} y1={ay} x2={ax + (ax < 250 ? -30 : 30)} y2={ay - 20} stroke="#15171c" strokeWidth="2" />
          <circle cx={ax + (ax < 250 ? -30 : 30)} cy={ay - 20} r="6" fill="#3a382f" />
        </g>
      ))}
      {/* mercury pool */}
      <ellipse cx="250" cy="318" rx="110" ry="14" fill="url(#mercuryPool)" />
      <ellipse cx="250" cy="316" rx="106" ry="3" fill="#dad6c9" opacity="0.5" />
      {/* central diffuse arc glow */}
      <ellipse cx="250" cy="220" rx="160" ry="180" fill="url(#arcGlow)" opacity={0.55 * flick} />
      <ellipse cx="250" cy="260" rx="90" ry="100"  fill="url(#arcGlow)" opacity={0.75 * flick} />
      {/* arcs to anodes */}
      {[arcTop, ...arcBranches].map(([ax, ay], i) => (
        <path key={i}
          d={jaggedArc(sx, sy, ax, ay, 10, 5, t + i * 1.7)}
          stroke="#f3eaff" strokeWidth={1.2} fill="none" opacity={0.7 * flick}
          style={{ mixBlendMode: "screen" }}
        />
      ))}
      {/* cathode spot */}
      <circle cx={sx} cy={sy - 4} r="14" fill="url(#cathodeGlow)" opacity={flick} />
      <circle cx={sx} cy={sy - 4} r="3" fill="#ffffff" />
      {/* annotation */}
      <g fontFamily="JetBrains Mono, monospace" fontSize="10" fill="#5a5648">
        <line x1={sx + 14} y1={sy - 4} x2="400" y2="340" stroke="#5a5648" strokeWidth="0.6" />
        <text x="408" y="342">CATHODE SPOT</text>
        <text x="408" y="354" fill="#8a8678">4 000 °C · &lt; 1 mm²</text>
        <line x1="430" y1="200" x2="475" y2="170" stroke="#5a5648" strokeWidth="0.6" />
        <text x="408" y="160">ENVELOPE</text>
        <text x="408" y="172" fill="#8a8678">≈ 7 mPa Hg vapour</text>
        <line x1="350" y1="318" x2="475" y2="295" stroke="#5a5648" strokeWidth="0.6" />
        <text x="408" y="286">POOL</text>
        <text x="408" y="298" fill="#8a8678">liquid Hg, 40 °C</text>
      </g>
    </svg>
  );
}

/* ============================================================
   D-02  ANATOMY  — labeled cross-section with hotspots
   ============================================================ */
const ANATOMY_PARTS = [
  { id: "envelope", n: "01", name: "Glass envelope", x: 430, y: 100,
    desc: "Evacuated borosilicate bulb. Operating pressure ≈ 7 mPa, dictated by the temperature of the coolest spot — the limiting factor for glass designs." },
  { id: "anode",    n: "02", name: "Graphite anode (×6)", x: 90, y: 180,
    desc: "One arm per phase. Graphite barely emits electrons, even when red-hot — this is the asymmetry that gives rectification." },
  { id: "grid",     n: "03", name: "Control grid",  x: 165, y: 230,
    desc: "Wire mesh in the anode neck. A negative bias holds the anode off until you want it to fire — the basis of grid-controlled converters and HVDC valves." },
  { id: "spot",     n: "04", name: "Cathode spot",  x: 250, y: 310,
    desc: "≤ 1 mm² brilliant white spot dancing on the mercury surface, sustained by ionic bombardment. The actual electron emitter." },
  { id: "pool",     n: "05", name: "Mercury pool",   x: 250, y: 330,
    desc: "5–25 kg of liquid mercury, self-renewing. Evaporates at the spot; the dome condenses it; it drips back. The cathode never wears out." },
  { id: "ignition", n: "06", name: "Ignition electrode", x: 320, y: 320,
    desc: "Solenoid-actuated dipper. Plunges into the pool, pulls out, and the inductive collapse strikes the seed arc." },
  { id: "excite",   n: "07", name: "Excitation anodes", x: 215, y: 340,
    desc: "Two small auxiliary anodes carrying a constant ≈ 5 A holding current that keeps the cathode spot alive between main-anode firings." },
  { id: "dome",     n: "08", name: "Condensation dome", x: 250, y: 60,
    desc: "Cool upper surface where vaporised mercury condenses and trickles back. The whole tube is an internal distillation column." },
];

function AnatomyDiagram() {
  const [active, setActive] = useState("spot");
  const t = useClock(true);
  const [sx, sy] = cathodeSpotPos(t, 250, 316, 18);
  return (
    <div style={{ display: "grid", gridTemplateColumns: "1fr 280px", minHeight: 460 }}>
      <div className="stage" style={{ position: "relative" }}>
        <svg viewBox="0 0 500 440" style={{ width: "100%", height: "auto", display: "block" }}>
          <ArcDefs />
          {/* outer envelope */}
          <path
            d="M 250 30
               C 370 30, 440 110, 440 200
               C 440 280, 380 330, 320 340
               L 320 360
               L 180 360
               L 180 340
               C 120 330, 60 280, 60 200
               C 60 110, 130 30, 250 30 Z"
            fill="url(#glassEnvelope)" stroke="#15171c" strokeWidth="1.4"
          />
          {/* dome highlight */}
          <ellipse cx="250" cy="58" rx="100" ry="20" fill="#fffaf0" opacity="0.35" />
          {/* anode arms (6) */}
          {[
            [70, 180, -30, -10], [430, 180, 30, -10],
            [95, 260, -28, 8], [405, 260, 28, 8],
            [130, 320, -22, 22], [370, 320, 22, 22],
          ].map(([ax, ay, ox, oy], i) => (
            <g key={i}>
              <ellipse cx={ax} cy={ay} rx="22" ry="34" fill="#cfc6ad" stroke="#15171c" strokeWidth="1" />
              <line x1={ax} y1={ay - 30} x2={ax + ox} y2={ay - 30 + oy} stroke="#15171c" strokeWidth="1.4" />
              <rect x={ax - 5} y={ay - 18} width="10" height="28" fill="#1f1c14" stroke="#15171c" strokeWidth="0.6" />
              {/* grid mesh */}
              <line x1={ax - 14} y1={ay + 18} x2={ax + 14} y2={ay + 18} stroke="#15171c" strokeWidth="0.6" />
              <line x1={ax - 12} y1={ay + 21} x2={ax + 12} y2={ay + 21} stroke="#15171c" strokeWidth="0.6" />
              {/* faint arc to cathode spot */}
              <path d={jaggedArc(sx, sy, ax, ay + 10, 8, 3, t + i * 1.3)}
                stroke="#b794ff" strokeWidth="0.8" fill="none" opacity="0.45" />
            </g>
          ))}
          {/* mercury pool */}
          <ellipse cx="250" cy="334" rx="130" ry="12" fill="url(#mercuryPool)" />
          <ellipse cx="250" cy="331" rx="124" ry="3" fill="#dad6c9" opacity="0.55" />
          {/* ignition electrode */}
          <line x1="320" y1="200" x2="320" y2="328" stroke="#15171c" strokeWidth="2" />
          <rect x="316" y="195" width="8" height="14" fill="#1f1c14" />
          <line x1="320" y1="160" x2="360" y2="120" stroke="#15171c" strokeWidth="1" strokeDasharray="2 2" />
          <text x="362" y="118" fontFamily="JetBrains Mono, monospace" fontSize="9" fill="#5a5648">SOLENOID</text>
          {/* excitation anodes (small ones near pool) */}
          <rect x="215" y="318" width="6" height="14" fill="#1f1c14" />
          <rect x="279" y="318" width="6" height="14" fill="#1f1c14" />
          {/* cathode spot glow */}
          <ellipse cx={sx} cy={sy - 4} rx="22" ry="14" fill="url(#cathodeGlow)" opacity="0.9" />
          <circle cx={sx} cy={sy - 4} r="2.5" fill="#ffffff" />
          {/* central diffuse glow */}
          <ellipse cx="250" cy="240" rx="180" ry="160" fill="url(#arcGlow)" opacity="0.25" />
          {/* connection legs at bottom */}
          <rect x="180" y="360" width="140" height="6" fill="#2a2e36" />
          <line x1="200" y1="366" x2="200" y2="395" stroke="#15171c" strokeWidth="2" />
          <line x1="300" y1="366" x2="300" y2="395" stroke="#15171c" strokeWidth="2" />
          <text x="190" y="408" fontFamily="JetBrains Mono, monospace" fontSize="9" fill="#5a5648">DC −</text>
          <text x="290" y="408" fontFamily="JetBrains Mono, monospace" fontSize="9" fill="#5a5648">DC +</text>

          {/* hotspot markers */}
          {ANATOMY_PARTS.map((p) => {
            const isActive = active === p.id;
            return (
              <g key={p.id} onClick={() => setActive(p.id)} style={{ cursor: "pointer" }}>
                <circle cx={p.x} cy={p.y} r={isActive ? 13 : 10}
                  fill={isActive ? "#15171c" : "#f1ece1"}
                  stroke="#15171c" strokeWidth="1.2" />
                <text x={p.x} y={p.y + 3} textAnchor="middle"
                  fontFamily="JetBrains Mono, monospace" fontSize="9"
                  fill={isActive ? "#f1ece1" : "#15171c"}>{p.n}</text>
              </g>
            );
          })}

          {/* active part callout line */}
          {(() => {
            const p = ANATOMY_PARTS.find((x) => x.id === active);
            if (!p) return null;
            return (
              <g>
                <line x1={p.x} y1={p.y} x2={p.x > 250 ? p.x + 40 : p.x - 40} y2={p.y - 30}
                  stroke="#c0392b" strokeWidth="1" />
                <circle cx={p.x > 250 ? p.x + 40 : p.x - 40} cy={p.y - 30} r="3" fill="#c0392b" />
              </g>
            );
          })()}
        </svg>
      </div>
      <ul className="hotspots" style={{ borderLeft: "1px solid var(--rule)" }}>
        {ANATOMY_PARTS.map((p) => (
          <li key={p.id}
            data-active={active === p.id}
            onClick={() => setActive(p.id)}>
            <span className="n">{p.n}</span>
            <span>
              <div className="nm">{p.name}</div>
              {active === p.id && <div className="d">{p.desc}</div>}
            </span>
          </li>
        ))}
      </ul>
    </div>
  );
}

/* ============================================================
   D-03  COMMUTATION  — six-anode arc handoff
   ============================================================ */
function CommutationDiagram() {
  const [playing, setPlaying] = useState(true);
  const [speed, setSpeed] = useState(0.6);
  const t = useClock(playing, speed);
  const cx = 240, cy = 250, R = 130;
  // 6 anodes equally spaced around top half
  const anodes = useMemo(() => {
    return Array.from({ length: 6 }).map((_, i) => {
      const ang = -Math.PI + (Math.PI / 6) + (i / 6) * Math.PI;
      return {
        x: cx + Math.cos(ang) * R,
        y: cy + Math.sin(ang) * R * 0.95,
        i,
        phase: i,
      };
    });
  }, []);
  // 3-phase, 6-pulse: active anode index = floor((t * 6) % 6)
  const pos = (t * 1.2) % 1; // 0..1 each cycle
  const active = Math.floor(pos * 6);
  const subT = (pos * 6) - active;
  const [sx, sy] = cathodeSpotPos(t, cx, cy + 60, 18);

  // sine waves for the side plot
  const W = 200, H = 90;
  const waves = useMemo(() => {
    const path = (phase) => {
      let d = "";
      for (let i = 0; i <= 60; i++) {
        const x = (i / 60) * W;
        const y = H / 2 + Math.sin((i / 60) * Math.PI * 4 + phase) * (H * 0.4);
        d += (i === 0 ? "M " : "L ") + x + " " + y + " ";
      }
      return d;
    };
    return [path(0), path(-Math.PI * 2 / 3), path(-Math.PI * 4 / 3)];
  }, []);

  // marker on waveform
  const markerX = ((t * 1.2) % 1) * W;

  return (
    <div>
      <div className="stage" style={{ display: "grid", gridTemplateColumns: "1.4fr 1fr", gap: 0 }}>
        <svg viewBox="0 0 520 420" style={{ width: "100%", height: "auto", display: "block" }}>
          <ArcDefs />
          {/* steel tank silhouette */}
          <rect x="60" y="80" width="360" height="270" rx="20" fill="#cfc6ad" stroke="#15171c" strokeWidth="1.4" />
          <rect x="60" y="80" width="360" height="14" fill="url(#hatch)" opacity="0.4" />
          <text x="70" y="74" fontFamily="JetBrains Mono, monospace" fontSize="9" fill="#5a5648">STEEL TANK · WATER-COOLED · ¼ ATM</text>

          {/* anodes */}
          {anodes.map((a) => {
            const isOn = a.i === active;
            return (
              <g key={a.i}>
                <line x1={a.x} y1="80" x2={a.x} y2={a.y} stroke="#15171c" strokeWidth="2.5" />
                <rect x={a.x - 6} y="60" width="12" height="22" fill="#1f1c14" stroke="#15171c" />
                <text x={a.x} y="54" textAnchor="middle"
                  fontFamily="JetBrains Mono, monospace" fontSize="10"
                  fill={isOn ? "#c0392b" : "#5a5648"}
                  fontWeight={isOn ? 700 : 400}>
                  A{a.i + 1}
                </text>
                {/* anode tip */}
                <circle cx={a.x} cy={a.y} r="6" fill={isOn ? "#c0392b" : "#3a382f"} />
              </g>
            );
          })}

          {/* mercury pool */}
          <ellipse cx={cx} cy="340" rx="160" ry="8" fill="url(#mercuryPool)" />
          <text x="120" y="368" fontFamily="JetBrains Mono, monospace" fontSize="9" fill="#5a5648">MERCURY POOL · CATHODE</text>

          {/* faint arcs to ALL anodes (excitation glow) */}
          {anodes.map((a, i) => (
            <path key={"f" + i}
              d={jaggedArc(sx, sy, a.x, a.y, 9, 3, t + i)}
              stroke="#7c5cff" strokeWidth="0.6" fill="none" opacity="0.18" />
          ))}
          {/* central glow */}
          <ellipse cx={cx} cy="200" rx="180" ry="140" fill="url(#arcGlow)" opacity="0.18" />

          {/* BRIGHT main arc to active anode (fading in/out for commutation) */}
          {(() => {
            const a = anodes[active];
            const next = anodes[(active + 1) % 6];
            // crossfade for last 15% of step
            const fadeIn = subT < 0.15 ? subT / 0.15 : 1;
            const fadeOut = subT > 0.85 ? (1 - (subT - 0.85) / 0.15) : 1;
            return (
              <g>
                <path d={jaggedArc(sx, sy, a.x, a.y, 10, 5, t)}
                  stroke="#f3eaff" strokeWidth="2" fill="none" opacity={fadeOut} />
                <path d={jaggedArc(sx, sy, a.x, a.y, 14, 8, t * 1.3)}
                  stroke="#b794ff" strokeWidth="4" fill="none" opacity={0.45 * fadeOut} style={{ mixBlendMode: "screen" }} />
                {/* overlap arc to next */}
                {subT > 0.85 && (
                  <path d={jaggedArc(sx, sy, next.x, next.y, 10, 5, t + 1)}
                    stroke="#f3eaff" strokeWidth="1.4" fill="none" opacity={(subT - 0.85) / 0.15 * 0.8} />
                )}
              </g>
            );
          })()}

          {/* cathode spot */}
          <ellipse cx={sx} cy={335} rx="20" ry="10" fill="url(#cathodeGlow)" opacity="0.95" />
          <circle cx={sx} cy="334" r="2.5" fill="#ffffff" />

          {/* DC output bus */}
          <line x1="60" y1="370" x2="20" y2="370" stroke="#15171c" strokeWidth="2" />
          <line x1="420" y1="370" x2="460" y2="370" stroke="#15171c" strokeWidth="2" />
          <text x="22" y="385" fontFamily="JetBrains Mono, monospace" fontSize="9" fill="#5a5648">DC+ (anodes via Y)</text>
          <text x="380" y="385" fontFamily="JetBrains Mono, monospace" fontSize="9" fill="#5a5648">DC− (cathode)</text>
        </svg>

        {/* side panel — phase plot */}
        <div style={{ borderLeft: "1px solid var(--rule)", padding: "16px", background: "var(--paper)" }}>
          <div className="smallcaps mono" style={{ color: "var(--ink-3)", marginBottom: 8 }}>3-Φ INPUT · 6-PULSE OUTPUT</div>
          <svg viewBox={`0 0 ${W} ${H + 50}`} style={{ width: "100%", height: "auto", display: "block" }}>
            <line x1="0" y1={H / 2} x2={W} y2={H / 2} stroke="#cfc6ad" strokeWidth="0.5" />
            {/* phase waves */}
            <path d={waves[0]} stroke="#c0392b" strokeWidth="1" fill="none" opacity="0.55" />
            <path d={waves[1]} stroke="#2a6fdb" strokeWidth="1" fill="none" opacity="0.55" />
            <path d={waves[2]} stroke="#1f8a5b" strokeWidth="1" fill="none" opacity="0.55" />
            {/* envelope = max of all phases = 6-pulse rectified */}
            <path
              d={(() => {
                let d = "";
                for (let i = 0; i <= 120; i++) {
                  const x = (i / 120) * W;
                  const ph = (i / 120) * Math.PI * 4;
                  const v = Math.max(
                    Math.sin(ph),
                    Math.sin(ph - Math.PI * 2 / 3),
                    Math.sin(ph - Math.PI * 4 / 3)
                  );
                  const y = H / 2 - v * (H * 0.4);
                  d += (i === 0 ? "M " : "L ") + x + " " + y + " ";
                }
                return d;
              })()}
              stroke="#15171c" strokeWidth="1.5" fill="none"
            />
            {/* playhead */}
            <line x1={markerX} y1="0" x2={markerX} y2={H} stroke="#c0392b" strokeWidth="1" strokeDasharray="2 2" />
            <circle cx={markerX} cy={H / 2 - Math.max(
              Math.sin((markerX / W) * Math.PI * 4),
              Math.sin((markerX / W) * Math.PI * 4 - Math.PI * 2 / 3),
              Math.sin((markerX / W) * Math.PI * 4 - Math.PI * 4 / 3)
            ) * (H * 0.4)} r="3" fill="#c0392b" />
            <text x="2" y={H + 14} fontFamily="JetBrains Mono, monospace" fontSize="8" fill="#5a5648">t →</text>
            <text x="2" y={H + 26} fontFamily="JetBrains Mono, monospace" fontSize="8" fill="#c0392b">— V_dc envelope = max(φ1,φ2,φ3)</text>
            <text x="2" y={H + 38} fontFamily="JetBrains Mono, monospace" fontSize="8" fill="#5a5648">ripple ≈ 4.2 % peak-to-peak</text>
          </svg>
          <div style={{ marginTop: 14, fontSize: 13, color: "var(--ink-3)", lineHeight: 1.4 }}>
            At every instant <b style={{color:"var(--ink)"}}>only the anode at the highest instantaneous voltage</b> can sustain the arc. The cathode spot stays put; the arc commutates from anode to anode six times per mains cycle.
          </div>
        </div>
      </div>

      <div className="controls">
        <span className="ctl-label">Animation</span>
        <button className="btn" onClick={() => setPlaying((p) => !p)} data-active={playing}>
          {playing ? "⏸  Pause" : "▶  Play"}
        </button>
        <span className="ctl-label" style={{ marginLeft: 12 }}>Speed</span>
        <input className="slider" type="range" min="0.1" max="2" step="0.05"
          value={speed} onChange={(e) => setSpeed(parseFloat(e.target.value))} />
        <span className="mono" style={{ fontSize: 11, color: "var(--ink-3)" }}>{speed.toFixed(2)}×</span>
        <span className="ctl-label" style={{ marginLeft: 12 }}>Conducting anode</span>
        <span className="mono" style={{ fontSize: 12, color: "var(--hot)", fontWeight: 700 }}>A{active + 1}</span>
      </div>
    </div>
  );
}

/* ============================================================
   D-04  STARTUP SEQUENCE  — 6-step stepper
   ============================================================ */
const STARTUP_STEPS = [
  { id: 0, t: "T−0 s",   ttl: "Cold / inert", body: "Tank is at ambient. Mercury sits as a still liquid pool. Pressure ≈ 10⁻³ Pa — far below conducting density. No path between anodes and cathode." },
  { id: 1, t: "T+0 s",   ttl: "Vacuum & blower check", body: "Forepump and diffusion pump verify vacuum. Air-blast or oil-cooling circulators come up. Excitation transformer energises but no current yet flows." },
  { id: 2, t: "T+2 s",   ttl: "Ignition plunge", body: "A solenoid pulls the ignition electrode down through the mercury. A small current (~30 A) flows through the closed inductive circuit, building flux." },
  { id: 3, t: "T+2.3 s", ttl: "Withdraw — arc strikes", body: "As the electrode lifts free of the pool, the inductor's collapsing field forces the current to keep flowing — a high-voltage transient bridges the gap and ionises mercury vapour. The cathode spot is born." },
  { id: 4, t: "T+3 s",   ttl: "Excitation anodes take over", body: "Two small auxiliary anodes draw a constant ≈ 5 A holding current. The cathode spot is now self-sustaining; ionic bombardment maintains its 4 000 °C temperature." },
  { id: 5, t: "T+5 s",   ttl: "Main anodes commutate", body: "Grids unblanked. The six main anodes pick up the arc in rotation. Output DC ramps up; the locomotive can now take load. Total startup ≈ 5 s once warm; ≈ 30 s from cold." },
];

function StartupDiagram() {
  const [step, setStep] = useState(0);
  const [auto, setAuto] = useState(false);
  const t = useClock(true);
  useEffect(() => {
    if (!auto) return;
    const id = setInterval(() => setStep((s) => (s + 1) % STARTUP_STEPS.length), 2200);
    return () => clearInterval(id);
  }, [auto]);

  const cx = 200, poolY = 280;
  // ignition electrode descends in step 2, withdraws in 3
  const igY = step <= 1 ? 200 : step === 2 ? 282 : step === 3 ? 250 : 220;
  const showSeedArc = step === 3;
  const showExciteArc = step >= 4;
  const showMainArcs = step >= 5;
  const [sx, sy] = step >= 3 ? cathodeSpotPos(t, cx, poolY, 14) : [cx, poolY];

  return (
    <div>
      <div style={{ display: "grid", gridTemplateColumns: "1fr 320px" }}>
        <div className="stage" style={{ position: "relative", padding: 12 }}>
          <svg viewBox="0 0 400 360" style={{ width: "100%", height: "auto", display: "block" }}>
            <ArcDefs />
            {/* bulb */}
            <path d="M 200 30 C 320 30, 370 130, 370 200 C 370 270, 320 320, 260 325 L 140 325 C 80 320, 30 270, 30 200 C 30 130, 80 30, 200 30 Z"
              fill="url(#glassEnvelope)" stroke="#15171c" strokeWidth="1.2" />
            {/* main anodes */}
            {[80, 160, 240, 320].map((ax, i) => (
              <g key={i}>
                <line x1={ax} y1="65" x2={ax} y2="100" stroke="#15171c" strokeWidth="1.6" />
                <rect x={ax - 5} y="50" width="10" height="18" fill="#1f1c14" />
                <circle cx={ax} cy="100" r="5" fill="#3a382f" />
              </g>
            ))}
            {/* excitation anodes */}
            <rect x={cx - 30} y="260" width="6" height="14" fill="#1f1c14" />
            <rect x={cx + 24} y="260" width="6" height="14" fill="#1f1c14" />
            {/* ignition electrode */}
            <g style={{ transition: "transform 0.6s cubic-bezier(.5,.1,.3,1)" }}>
              <line x1={cx + 60} y1="80" x2={cx + 60} y2={igY} stroke="#15171c" strokeWidth="2" />
              <rect x={cx + 56} y="60" width="8" height="22" fill="#1f1c14" />
              <text x={cx + 70} y="76" fontFamily="JetBrains Mono, monospace" fontSize="9" fill="#5a5648">SOLENOID</text>
            </g>
            {/* mercury pool */}
            <ellipse cx={cx} cy={poolY + 5} rx="120" ry="9" fill="url(#mercuryPool)" />
            <ellipse cx={cx} cy={poolY + 3} rx="116" ry="2.5" fill="#dad6c9" opacity="0.5" />
            {/* spot */}
            {step >= 3 && (
              <>
                <ellipse cx={sx} cy={sy - 2} rx="18" ry="10" fill="url(#cathodeGlow)" opacity="0.95" />
                <circle cx={sx} cy={sy - 2} r="2.5" fill="#ffffff" />
              </>
            )}
            {/* seed arc */}
            {showSeedArc && (
              <path d={jaggedArc(cx + 60, igY, cx, poolY, 8, 3, t)}
                stroke="#f3eaff" strokeWidth="1.6" fill="none" />
            )}
            {/* excitation arc */}
            {showExciteArc && (
              <>
                <path d={jaggedArc(sx, sy, cx - 27, 275, 6, 2, t)} stroke="#b794ff" strokeWidth="1.4" fill="none" opacity="0.9" />
                <path d={jaggedArc(sx, sy, cx + 27, 275, 6, 2, t + 1)} stroke="#b794ff" strokeWidth="1.4" fill="none" opacity="0.9" />
              </>
            )}
            {/* main arcs */}
            {showMainArcs && [80, 160, 240, 320].map((ax, i) => (
              <path key={i} d={jaggedArc(sx, sy, ax, 100, 10, 4, t + i)}
                stroke={i === Math.floor(t * 2) % 4 ? "#f3eaff" : "#7c5cff"}
                strokeWidth={i === Math.floor(t * 2) % 4 ? 1.6 : 0.6}
                fill="none" opacity={i === Math.floor(t * 2) % 4 ? 1 : 0.3} />
            ))}
            {/* central glow appears from step 4 */}
            {step >= 4 && (
              <ellipse cx={cx} cy="200" rx="150" ry="130" fill="url(#arcGlow)" opacity={step === 4 ? 0.18 : 0.35} />
            )}
          </svg>
        </div>
        <div style={{ borderLeft: "1px solid var(--rule)", padding: 0 }}>
          {STARTUP_STEPS.map((s) => (
            <div key={s.id}
              onClick={() => { setStep(s.id); setAuto(false); }}
              style={{
                padding: "12px 16px",
                borderBottom: "1px dotted var(--rule)",
                cursor: "pointer",
                background: step === s.id ? "var(--paper-3)" : "transparent",
                opacity: step === s.id ? 1 : 0.65,
                transition: "all 0.2s"
              }}>
              <div style={{ display: "flex", justifyContent: "space-between", alignItems: "baseline", gap: 12 }}>
                <span className="mono" style={{ fontSize: 10, color: "var(--ink-3)", textTransform: "uppercase", letterSpacing: "0.1em" }}>STEP {s.id + 1} / {STARTUP_STEPS.length}</span>
                <span className="mono" style={{ fontSize: 10, color: step === s.id ? "var(--hot)" : "var(--ink-3)" }}>{s.t}</span>
              </div>
              <div className="serif" style={{ fontSize: 18, marginTop: 2, color: "var(--ink)" }}>{s.ttl}</div>
              {step === s.id && (
                <div style={{ fontSize: 13, color: "var(--ink-3)", marginTop: 6, lineHeight: 1.45 }}>{s.body}</div>
              )}
            </div>
          ))}
        </div>
      </div>
      <div className="controls">
        <button className="btn" onClick={() => setStep((s) => Math.max(0, s - 1))}>← Prev</button>
        <button className="btn" onClick={() => setStep((s) => Math.min(STARTUP_STEPS.length - 1, s + 1))}>Next →</button>
        <button className="btn" onClick={() => { setAuto(!auto); }} data-active={auto}>
          {auto ? "■ Stop auto" : "▶ Auto-run"}
        </button>
        <span className="ctl-label" style={{ marginLeft: 12 }}>State</span>
        <span className="mono" style={{ fontSize: 12, color: "var(--ink)" }}>{STARTUP_STEPS[step].ttl}</span>
      </div>
    </div>
  );
}

Object.assign(window, {
  HeroArc, AnatomyDiagram, CommutationDiagram, StartupDiagram,
});
