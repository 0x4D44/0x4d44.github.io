// Chapter 06 — Family. Languages on a timeline, plus a comparison table.
// Click a language to see how Rust compares to it.

const LANGS = [
  { id:"c",     name:"C",      y:1972, color:"#9b8579", desc:"The mother tongue. UNIX, every OS kernel, every embedded device. Unsafe by default; fast forever.",
    vsRust:{ speed:"≈ equal", safety:"Rust wins decisively — C lets you do anything, including UAF.", ergonomics:"C is simpler to start; Rust is harder, but composes." } },
  { id:"cpp",   name:"C++",    y:1985, color:"#b87c5a", desc:"Bjarne Stroustrup's answer: C with classes, then templates, then everything else. Powerful and labyrinthine.",
    vsRust:{ speed:"≈ equal", safety:"Rust prevents whole classes of bugs C++ cannot.", ergonomics:"C++ has more features and more footguns. Rust has fewer, sharper tools." } },
  { id:"python",name:"Python", y:1991, color:"#dea584", desc:"Readable, batteries-included, slow. The language that ate scripting, glue code, and now ML.",
    vsRust:{ speed:"Rust is 10–100× faster for CPU work.", safety:"Both safe; Python catches errors at runtime, Rust at compile time.", ergonomics:"Python wins on prototyping; Rust wins on shipping." } },
  { id:"java",  name:"Java",   y:1995, color:"#e3a857", desc:"The OOP juggernaut. JVM, garbage collected, write once / debug everywhere. Still the enterprise default.",
    vsRust:{ speed:"Rust is faster, especially for tail latency (no GC pauses).", safety:"Both memory-safe; Rust extends to data races.", ergonomics:"Java is more familiar; Rust composes better with low-level work." } },
  { id:"js",    name:"JS",     y:1995, color:"#f0d97a", desc:"The accident that ate the web. Single-threaded, dynamically typed, ubiquitous.",
    vsRust:{ speed:"Rust is faster, but JS is good enough for UI.", safety:"Memory safe by GC; Rust catches more at compile time.", ergonomics:"JS is reach-anyone; Rust is reach-correctness." } },
  { id:"haskell",name:"Haskell",y:1990, color:"#c084d9", desc:"Pure functional, lazy, mathematically rigorous. The language Rust quietly borrowed traits, ADTs, and pattern matching from.",
    vsRust:{ speed:"Rust is faster and more predictable.", safety:"Both type-strict; different flavors.", ergonomics:"Haskell is purer; Rust is more practical for systems." } },
  { id:"go",    name:"Go",     y:2009, color:"#5fc7d4", desc:"Google's answer to C++'s complexity: small language, GC, goroutines, fast builds. Optimized for big teams.",
    vsRust:{ speed:"Rust is faster and avoids GC pauses; Go compiles faster.", safety:"Rust prevents data races; Go does not (but discourages them).", ergonomics:"Go is easier to learn; Rust gives more power and safety." } },
  { id:"swift", name:"Swift",  y:2014, color:"#e35a4a", desc:"Apple's reset of Objective-C. ARC instead of GC, value types, similar safety goals — confined to the Apple ecosystem.",
    vsRust:{ speed:"≈ equal", safety:"Comparable, different mechanisms (ARC vs ownership).", ergonomics:"Swift has nicer UI APIs; Rust has wider reach." } },
  { id:"rust",  name:"Rust",   y:2010, color:"var(--rust)", desc:"You are here.", isRust:true },
  { id:"zig",   name:"Zig",    y:2016, color:"#f7b03a", desc:"A newer challenger from Andrew Kelley: aim for C's simplicity with safer defaults and compile-time programming. No borrow checker.",
    vsRust:{ speed:"≈ equal", safety:"Rust is stricter; Zig trusts the programmer more.", ergonomics:"Zig is simpler; Rust is more rigorous." } },
];

function Family() {
  const [selected, setSelected] = useState("c");
  const sel = LANGS.find(l => l.id === selected);
  const minY = 1970, maxY = 2026;
  const pct = (y) => ((y - minY) / (maxY - minY)) * 100;

  return (
    <section className="chap" id="family" style={{maxWidth:'1400px'}}>
      <div className="chap-tag">
        <span className="num">06</span>
        <span className="label">Family · Rust's place in the lineage</span>
      </div>
      <div className="rule"></div>

      <div style={{display:'grid', gridTemplateColumns:'1.4fr 1fr', gap:'40px', alignItems:'end', marginTop:'48px', marginBottom:'40px'}}>
        <h2 className="head" style={{margin:0}}>A late entry<br/>to a <em>fifty-year</em> argument.</h2>
        <p className="lede">Click a language to put Rust in conversation with it. Same axes (speed, safety, ergonomics) — different answers.</p>
      </div>

      {/* Lang timeline */}
      <div style={{position:'relative', height:'170px', margin:'48px 0 56px'}}>
        {/* baseline */}
        <div style={{position:'absolute', left:0, right:0, top:'88px', height:'1px', background:'var(--line)'}} />
        {/* decade ticks */}
        {[1970,1980,1990,2000,2010,2020,2030].map(y => (
          <div key={y} style={{position:'absolute', left:`${pct(y)}%`, top:'82px', transform:'translateX(-50%)'}}>
            <div style={{width:'1px', height:'12px', background:'var(--line)'}} />
            <div style={{position:'absolute', top:'18px', left:'50%', transform:'translateX(-50%)', fontFamily:"'JetBrains Mono',monospace", fontSize:'10px', color:'var(--ink-3)', letterSpacing:'0.14em'}}>{y}</div>
          </div>
        ))}
        {/* Lang dots — alternate above/below based on YEAR order so close neighbours don't collide */}
        {(() => {
          const byYear = [...LANGS].sort((a,b) => a.y - b.y);
          const yearOrder = new Map(byYear.map((l, idx) => [l.id, idx]));
          return LANGS.map((l) => {
          const isSel = l.id === selected;
          const above = (yearOrder.get(l.id) % 2) === 0;
          const dy = above ? -36 : 36;
          return (
            <button key={l.id} onClick={() => setSelected(l.id)} style={{
              position:'absolute', left:`${pct(l.y)}%`, top:'88px', transform:'translate(-50%, -50%)',
              width: isSel ? '28px' : (l.isRust ? '22px' : '14px'),
              height: isSel ? '28px' : (l.isRust ? '22px' : '14px'),
              borderRadius:'50%',
              background: l.color, border:'2px solid var(--bg)',
              cursor:'pointer', padding:0, transition:'all .2s',
              boxShadow: isSel ? `0 0 0 4px rgba(227,90,28,0.25)` : (l.isRust ? `0 0 18px rgba(227,90,28,0.45)` : 'none'),
              zIndex: isSel ? 5 : (l.isRust ? 3 : 1),
            }} aria-label={l.name}>
              <span style={{
                position:'absolute', left:'50%', top: `${dy}px`, transform:'translateX(-50%)',
                fontFamily:"'Instrument Serif',serif", fontStyle: isSel?'italic':'normal',
                fontSize: isSel ? '24px' : (l.isRust ? '20px' : '16px'),
                color: isSel ? l.color : (l.isRust ? 'var(--rust)' : 'var(--ink-2)'),
                whiteSpace:'nowrap', pointerEvents:'none',
              }}>{l.name}</span>
              <span style={{
                position:'absolute', left:'50%', top: `${dy + (above?-16:18)}px`, transform:'translateX(-50%)',
                fontFamily:"'JetBrains Mono',monospace", fontSize:'10px',
                color:'var(--ink-3)', letterSpacing:'0.12em',
                whiteSpace:'nowrap', pointerEvents:'none',
              }}>{l.y}</span>
            </button>
          );
        });
        })()}
      </div>

      {/* Selected card */}
      {sel.isRust ? (
        <div style={{textAlign:'center', padding:'60px 20px', background:'var(--bg-2)', border:'1px solid var(--line)', borderRadius:'6px'}}>
          <div style={{fontFamily:"'Instrument Serif', serif", fontStyle:'italic', fontSize:'80px', color:'var(--rust)'}}>You are here.</div>
          <p style={{color:'var(--ink-2)', maxWidth:'56ch', margin:'12px auto 0'}}>Pick another language above to compare.</p>
        </div>
      ) : (
        <div style={{display:'grid', gridTemplateColumns:'1fr 2fr', gap:'40px', alignItems:'start'}}>
          <div>
            <div style={{display:'flex', alignItems:'baseline', gap:'18px', marginBottom:'14px'}}>
              <div style={{width:'24px', height:'24px', borderRadius:'50%', background: sel.color}} />
              <div>
                <h3 style={{margin:0, fontFamily:"'Instrument Serif',serif", fontWeight:400, fontSize:'56px', lineHeight:1, color: sel.color}}>{sel.name}</h3>
                <div style={{fontFamily:"'JetBrains Mono',monospace", fontSize:'11px', color:'var(--ink-3)', letterSpacing:'0.18em', marginTop:'4px'}}>BORN {sel.y} · {sel.y < 2010 ? `${2026-sel.y} YEARS BEFORE TODAY` : `${sel.y - 2010} YEARS AFTER RUST`}</div>
              </div>
            </div>
            <p style={{color:'var(--ink-2)', lineHeight:1.65, fontSize:'15px'}}>{sel.desc}</p>
          </div>

          <div style={{display:'flex', flexDirection:'column', gap:'2px', border:'1px solid var(--line)', borderRadius:'4px', overflow:'hidden'}}>
            {[
              { axis:"Speed", val: sel.vsRust.speed },
              { axis:"Safety", val: sel.vsRust.safety },
              { axis:"Ergonomics", val: sel.vsRust.ergonomics },
            ].map((row, i) => (
              <div key={i} style={{display:'grid', gridTemplateColumns:'140px 1fr', gap:'24px', padding:'18px 24px', background:'var(--bg-2)', alignItems:'center'}}>
                <div className="small-caps" style={{color: sel.color}}>{row.axis}</div>
                <div style={{color:'var(--ink-2)', fontSize:'15px', lineHeight:1.5}}>{row.val}</div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Same task, different languages */}
      <div style={{marginTop:'80px'}}>
        <div className="small-caps" style={{color:'var(--rust)', marginBottom:'18px'}}>Same task · four languages</div>
        <div style={{fontFamily:"'Instrument Serif',serif", fontSize:'32px', fontStyle:'italic', marginBottom:'24px'}}>
          "Read a file, return its bytes, fail loudly on error."
        </div>
        <div style={{display:'grid', gridTemplateColumns:'repeat(4, 1fr)', gap:'12px'}}>
          {SAMPLES.map(s => (
            <div key={s.lang} style={{background:'#0e0a07', border:'1px solid var(--line)', borderRadius:'4px', overflow:'hidden'}}>
              <div style={{padding:'10px 14px', borderBottom:'1px solid var(--line-soft)', display:'flex', justifyContent:'space-between', alignItems:'center', background:'var(--bg-2)'}}>
                <span style={{fontFamily:"'Instrument Serif',serif", fontStyle:'italic', color: s.color, fontSize:'18px'}}>{s.lang}</span>
                <span style={{fontFamily:"'JetBrains Mono',monospace", fontSize:'10px', color:'var(--ink-3)'}}>{s.tag}</span>
              </div>
              <pre style={{margin:0, padding:'14px 16px', fontFamily:"'JetBrains Mono',monospace", fontSize:'11.5px', lineHeight:1.55, color:'var(--cream)', overflowX:'auto', minHeight:'170px'}}>
                <code dangerouslySetInnerHTML={{ __html: highlight(s.code) }} />
              </pre>
            </div>
          ))}
        </div>
        <p style={{marginTop:'18px', color:'var(--ink-3)', fontSize:'13px', maxWidth:'80ch', lineHeight:1.55}}>
          Note Rust's signature: <span className="mono" style={{color:'var(--cream)'}}>Result&lt;Vec&lt;u8&gt;, io::Error&gt;</span>. The error case is part of the type. You cannot pretend it doesn't exist.
        </p>
      </div>
    </section>
  );
}

const SAMPLES = [
  { lang:"C", color:"#9b8579", tag:"errno",
    code: `FILE *f = fopen(path, "rb");
if (!f) return NULL;
fseek(f, 0, SEEK_END);
long n = ftell(f);
rewind(f);
char *buf = malloc(n);
fread(buf, 1, n, f);
fclose(f);
return buf;  // who frees this?` },
  { lang:"Python", color:"#dea584", tag:"raises",
    code: `def read(path):
    with open(path, "rb") as f:
        return f.read()
# Errors raise — caller must
# remember to catch them, or
# the program dies at runtime.` },
  { lang:"Go", color:"#5fc7d4", tag:"err pair",
    code: `func read(p string) ([]byte, error) {
    return os.ReadFile(p)
}
// Caller writes:
b, err := read(p)
if err != nil {
    return err
}` },
  { lang:"Rust", color:"var(--rust)", tag:"Result<T,E>",
    code: `fn read(path: &str)
    -> Result<Vec<u8>, io::Error>
{
    std::fs::read(path)
}
// Caller must handle Err.
// Forgot? Compile error.
let bytes = read(path)?;` },
];
