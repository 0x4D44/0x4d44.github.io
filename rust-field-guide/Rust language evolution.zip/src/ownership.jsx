// Chapter 03 — Ownership. The interactive heart of the site.
// Walks the user through 4 canonical Rust snippets, highlighting what the
// borrow checker is seeing at each step.

const EXAMPLES = [
  {
    id: "move",
    title: "Move semantics",
    blurb: "Most languages copy a variable when you reassign it. Rust moves it. After a move, the old name is dead — touching it is a compile error.",
    lines: [
      { c: 'let book = String::from("Mistborn");', notes: { book: { kind:'owned', desc:'`book` allocates on the heap. It owns the string.' } } },
      { c: 'let gift = book;', notes: { book: { kind:'moved', desc:'Ownership moved from `book` → `gift`. The compiler invalidates `book`.' }, gift: { kind:'owned', desc:'`gift` is now the unique owner.' } } },
      { c: 'println!("{}", book);', err: "error[E0382]: borrow of moved value: `book`", notes: { book: { kind:'moved' }, gift: { kind:'owned' } } },
    ],
    moral: "In C++, both variables would point to the same memory and a double-free would lurk. In Rust, only one name can own a value at a time. Period.",
  },
  {
    id: "borrow",
    title: "Borrowing",
    blurb: "If moving is too aggressive, you can lend a value out. References are tracked by the compiler — many readers OR one writer, never both at once.",
    lines: [
      { c: 'let mut log = vec![1, 2, 3];', notes: { log: { kind:'owned', desc:'`log` owns a heap-allocated vector.' } } },
      { c: 'let peek = &log;', notes: { log: { kind:'shared', desc:'shared-borrowed' }, peek: { kind:'ref', desc:'Immutable reference. Many of these are allowed.' } } },
      { c: 'let view = &log;', notes: { log: { kind:'shared' }, peek: { kind:'ref' }, view: { kind:'ref', desc:'A second immutable reference. Fine.' } } },
      { c: 'log.push(4);', err: "error[E0502]: cannot borrow `log` as mutable because it is also borrowed as immutable", notes: { log: { kind:'shared' }, peek: { kind:'ref' }, view: { kind:'ref' } } },
    ],
    moral: "Data races are not even expressible. The compiler enforces, statically, the rule every concurrency bug has been about for fifty years.",
  },
  {
    id: "lifetime",
    title: "Lifetimes",
    blurb: "A reference cannot outlive what it points to. The compiler proves this by giving every reference a 'lifetime' and tracking the scope it's valid in.",
    lines: [
      { c: 'let result;', notes: { result: { kind:'pending', desc:"Declared but uninitialized — the compiler tracks this too." } } },
      { c: '{', },
      { c: '    let tmp = String::from("hi");', notes: { result: { kind:'pending' }, tmp: { kind:'owned', desc:"Lives only inside this inner block." } } },
      { c: '    result = &tmp;', notes: { result: { kind:'ref', desc:"Now references `tmp`." }, tmp: { kind:'shared' } } },
      { c: '}  // tmp is dropped here', notes: { result: { kind:'dangling', desc:"`tmp` has been dropped. `result` would dangle." } } },
      { c: 'println!("{}", result);', err: "error[E0597]: `tmp` does not live long enough", notes: { result: { kind:'dangling' } } },
    ],
    moral: "Use-after-free is a contradiction in the type system. The exact bug that gave us Heartbleed, the bug behind ~70% of every Chrome CVE — gone.",
  },
  {
    id: "concurrency",
    title: "Fearless concurrency",
    blurb: "Send and Sync — two compiler-checked traits — turn data-race prevention into a property of types. Most threading bugs become compile errors.",
    lines: [
      { c: 'let data = vec![1, 2, 3];', notes: { data: { kind:'owned' } } },
      { c: 'thread::spawn(move || {', notes: { data: { kind:'moved', desc:"Ownership passed into the new thread." } } },
      { c: '    println!("{:?}", data);', notes: { data: { kind:'moved' } } },
      { c: '});', },
      { c: 'data.push(4);', err: "error[E0382]: borrow of moved value: `data`", notes: { data: { kind:'moved' } } },
    ],
    moral: "The same rule that prevents use-after-free also prevents two threads from racing on shared mutable state. One law, two whole bug categories destroyed.",
  },
];

function Ownership() {
  const [exId, setExId] = useState(EXAMPLES[0].id);
  const ex = EXAMPLES.find(e => e.id === exId);
  const [step, setStep] = useState(0);

  useEffect(() => { setStep(0); }, [exId]);

  const maxStep = ex.lines.length - 1;
  // Aggregate notes visible at this step: take the last `notes` object up to and including current step
  const activeNotes = useMemo(() => {
    let result = {};
    for (let i = 0; i <= step; i++) {
      if (ex.lines[i].notes) {
        // overwrite per-variable based on most-recent
        result = { ...result, ...ex.lines[i].notes };
      }
    }
    return result;
  }, [ex, step]);

  const errorOnThisStep = ex.lines[step]?.err;

  return (
    <section className="chap" id="ownership" style={{maxWidth:'1400px'}}>
      <div className="chap-tag">
        <span className="num">03</span>
        <span className="label">Ownership · the interactive part</span>
      </div>
      <div className="rule"></div>

      <div style={{display:'grid', gridTemplateColumns:'1.3fr 1fr', gap:'56px', alignItems:'start', marginTop:'48px'}}>
        <h2 className="head" style={{margin:0}}>What the <em>borrow checker</em> sees.</h2>
        <p className="lede">Every Rust value has exactly one owner. Step through four canonical snippets and watch the compiler track ownership, references, and lifetimes — and reject the bugs that would survive in C.</p>
      </div>

      {/* Tabs */}
      <div style={{display:'flex', gap:'4px', marginTop:'48px', borderBottom:'1px solid var(--line)', flexWrap:'wrap'}}>
        {EXAMPLES.map((e, i) => (
          <button key={e.id} onClick={() => setExId(e.id)} style={{
            background: exId===e.id ? 'var(--bg-2)' : 'transparent',
            border: 'none', borderBottom: exId===e.id ? '2px solid var(--rust)' : '2px solid transparent',
            color: exId===e.id ? 'var(--cream)' : 'var(--ink-3)',
            padding:'14px 22px', cursor:'pointer',
            fontFamily:"'JetBrains Mono',monospace", fontSize:'12px',
            letterSpacing:'0.16em', textTransform:'uppercase',
            marginBottom:'-1px',
          }}>
            <span style={{color:'var(--rust-2)', marginRight:'10px'}}>{String(i+1).padStart(2,'0')}</span>{e.title}
          </button>
        ))}
      </div>

      <div style={{marginTop:'24px', display:'grid', gridTemplateColumns:'1.2fr 1fr', gap:'40px'}}>
        {/* Code */}
        <div style={{background:'#0e0a07', border:'1px solid var(--line)', borderRadius:'6px', overflow:'hidden'}}>
          <div style={{display:'flex', justifyContent:'space-between', alignItems:'center', padding:'10px 16px', borderBottom:'1px solid var(--line-soft)', background:'var(--bg-2)'}}>
            <div style={{display:'flex', gap:'6px'}}>
              <span style={dot('#f0664a')} /><span style={dot('#e3a857')} /><span style={dot('#7fbc8c')} />
            </div>
            <div style={{fontFamily:"'JetBrains Mono',monospace", fontSize:'11px', color:'var(--ink-3)'}}>borrow_checker.rs</div>
          </div>
          <div style={{padding:'18px 0', fontFamily:"'JetBrains Mono',monospace", fontSize:'14px', lineHeight:'24px', position:'relative'}}>
            {ex.lines.map((l, i) => {
              const active = i === step;
              const past = i < step;
              const future = i > step;
              const hasErr = active && l.err;
              return (
                <div key={i} style={{
                  display:'grid', gridTemplateColumns:'48px 16px 1fr',
                  alignItems:'center',
                  padding:'0 16px 0 0',
                  background: active ? (hasErr ? 'rgba(240,102,74,0.08)' : 'rgba(227,90,28,0.07)') : 'transparent',
                  color: future ? 'var(--ink-3)' : (past ? 'var(--ink-2)' : 'var(--cream)'),
                  opacity: future ? 0.45 : 1,
                  borderLeft: active ? `3px solid ${hasErr?'var(--err)':'var(--rust)'}` : '3px solid transparent',
                  transition: 'background .2s',
                  minHeight:'24px',
                }}>
                  <span style={{color:'var(--ink-3)', textAlign:'right', paddingRight:'10px', fontSize:'11px', userSelect:'none'}}>{i+1}</span>
                  <span></span>
                  <span dangerouslySetInnerHTML={{ __html: highlight(l.c || '') }} />
                </div>
              );
            })}
          </div>
          {errorOnThisStep && (
            <div style={{
              borderTop:'1px solid var(--err)',
              background:'rgba(240,102,74,0.08)',
              padding:'14px 16px',
              fontFamily:"'JetBrains Mono',monospace", fontSize:'12.5px',
              color:'#ffb3a3', lineHeight:1.5,
            }}>
              <div style={{color:'var(--err)', fontWeight:700, marginBottom:'4px'}}>✗ COMPILER REJECTS</div>
              {errorOnThisStep}
            </div>
          )}
        </div>

        {/* Borrow-checker panel */}
        <div style={{display:'flex', flexDirection:'column', gap:'14px'}}>
          <div style={{display:'flex', justifyContent:'space-between', alignItems:'baseline'}}>
            <div className="small-caps" style={{color:'var(--rust)'}}>Compiler's view</div>
            <div style={{fontFamily:"'JetBrains Mono',monospace", fontSize:'11px', color:'var(--ink-3)'}}>STEP {step+1}/{ex.lines.length}</div>
          </div>

          <div style={{border:'1px solid var(--line)', borderRadius:'6px', background:'var(--bg-2)', padding:'18px', minHeight:'220px', display:'flex', flexDirection:'column', gap:'12px'}}>
            {Object.entries(activeNotes).length === 0 && (
              <div style={{color:'var(--ink-3)', fontStyle:'italic', fontFamily:"'Instrument Serif',serif", fontSize:'18px'}}>
                The compiler has nothing to track yet.
              </div>
            )}
            {Object.entries(activeNotes).map(([name, n]) => (
              <VarRow key={name} name={name} state={n.kind} desc={n.desc} />
            ))}
          </div>

          {/* Stepper */}
          <div style={{display:'flex', gap:'8px', alignItems:'center', marginTop:'4px'}}>
            <button onClick={() => setStep(s => Math.max(0, s-1))} disabled={step===0} style={stepBtn(step===0)}>◀ prev</button>
            <button onClick={() => setStep(s => Math.min(maxStep, s+1))} disabled={step===maxStep} style={stepBtn(step===maxStep, true)}>next ▶</button>
            <div style={{flex:1, height:'2px', background:'var(--line)', borderRadius:'1px', position:'relative', margin:'0 8px'}}>
              <div style={{position:'absolute', top:0, left:0, height:'100%', background:'var(--rust)', width:`${(step/maxStep)*100}%`, transition:'width .25s'}} />
            </div>
            <button onClick={() => setStep(0)} style={{...stepBtn(false), padding:'6px 10px'}}>↺</button>
          </div>

          <div style={{padding:'18px 0 0', borderTop:'1px solid var(--line)', marginTop:'8px'}}>
            <p style={{margin:0, color:'var(--ink-2)', lineHeight:1.55, fontSize:'14px'}}>{ex.blurb}</p>
          </div>
        </div>
      </div>

      {/* Moral */}
      <div style={{marginTop:'48px', padding:'36px 40px', background:'var(--bg-2)', border:'1px solid var(--line)', borderLeft:'4px solid var(--rust)', borderRadius:'4px'}}>
        <div className="small-caps" style={{color:'var(--rust)', marginBottom:'12px'}}>The point</div>
        <p style={{margin:0, fontFamily:"'Instrument Serif', serif", fontSize:'26px', lineHeight:1.35, color:'var(--cream)', fontStyle:'italic'}}>
          {ex.moral}
        </p>
      </div>
    </section>
  );
}

function VarRow({ name, state, desc }) {
  const meta = {
    owned:    { color:'var(--safe)',  label:'OWNS', tone:'var(--safe)' },
    moved:    { color:'var(--ink-3)', label:'MOVED · invalid', tone:'var(--ink-3)' },
    shared:   { color:'var(--tan)',   label:'BORROWED &', tone:'var(--tan)' },
    ref:      { color:'var(--tan)',   label:'REF →', tone:'var(--tan)' },
    pending:  { color:'var(--ink-3)', label:'uninit', tone:'var(--ink-3)' },
    dangling: { color:'var(--err)',   label:'DANGLES', tone:'var(--err)' },
  }[state] || { color:'var(--ink-2)', label:state };

  return (
    <div style={{display:'grid', gridTemplateColumns:'auto 1fr', gap:'14px', alignItems:'flex-start'}}>
      <div style={{
        fontFamily:"'JetBrains Mono',monospace", fontSize:'13px',
        background:'#0e0a07', border:`1px solid ${meta.tone}`, color: meta.color,
        padding:'4px 10px', borderRadius:'4px', whiteSpace:'nowrap', minWidth:'72px', textAlign:'center',
        fontWeight: 600,
      }}>
        {name}
      </div>
      <div>
        <div style={{
          fontFamily:"'JetBrains Mono',monospace", fontSize:'10px',
          letterSpacing:'0.16em', color: meta.color, marginBottom:'2px', fontWeight:700,
        }}>{meta.label}</div>
        {desc && <div style={{fontSize:'13px', color:'var(--ink-2)', lineHeight:1.5}}>{desc}</div>}
      </div>
    </div>
  );
}

function dot(c) { return { width:'9px', height:'9px', borderRadius:'50%', background:c, display:'inline-block' }; }
function stepBtn(disabled, primary) {
  return {
    background: primary ? 'var(--rust)' : 'transparent',
    border: '1px solid ' + (primary ? 'var(--rust)' : 'var(--line)'),
    color: primary ? 'var(--cream)' : 'var(--ink-2)',
    padding:'8px 14px', borderRadius:'3px',
    fontFamily:"'JetBrains Mono',monospace", fontSize:'11px',
    letterSpacing:'0.12em', textTransform:'uppercase',
    cursor: disabled ? 'not-allowed' : 'pointer',
    opacity: disabled ? 0.4 : 1,
  };
}

// extremely simple syntax highlighter for our snippets
function highlight(s) {
  const esc = s.replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;');
  return esc
    .replace(/\/\/[^\n]*/g, m => `<span style="color:#7a6a5c;font-style:italic">${m}</span>`)
    .replace(/"([^"]*)"/g, '<span style="color:#dea584">"$1"</span>')
    .replace(/\b(let|mut|fn|move|use|struct|impl|return|if|else|match)\b/g,
      '<span style="color:#ff7a3d">$1</span>')
    .replace(/\b(String|Vec|vec|thread|spawn|println|from|push)\b/g,
      '<span style="color:#e3a857">$1</span>')
    .replace(/(\b\d+\b)/g, '<span style="color:#7fbc8c">$1</span>');
}
