// Chapter 01 — Origins. The Graydon Hoare backstory and Mozilla's role.
function Origins() {
  return (
    <section className="chap" id="origins">
      <div className="chap-tag">
        <span className="num">01</span>
        <span className="label">Origins · 2006 — 2010</span>
      </div>
      <div className="rule"></div>

      <div style={{display:'grid', gridTemplateColumns:'1.4fr 1fr', gap:'56px', marginTop:'48px', alignItems:'start'}}>
        <div>
          <h2 className="head">A side project<br/>that ate <em>browsers</em>.</h2>
          <p className="lede">
            Sometime around 2006, a Mozilla engineer named Graydon Hoare came home to find
            his apartment elevator out of service — again — because the firmware had
            crashed. He had been thinking, vaguely, about a programming language for
            "safe systems software." That night the thinking sharpened. The result was
            named after a family of fungi prized, supposedly, for being over-engineered
            for survival: <em style={{color:'var(--rust-2)', fontStyle:'normal', fontWeight:600}}>Rust</em>.
          </p>

          <div className="pull-quote">
            "Rust is a language about pushing pain forward — finding bugs at compile
            time so users never meet them at runtime."
            <span className="cite">— THE PROJECT'S WORKING THESIS</span>
          </div>

          <p style={{fontSize:'16px', lineHeight:1.6, color:'var(--ink-2)', maxWidth:'62ch'}}>
            For three years Rust was Graydon's pet. In 2009 Mozilla took notice and began
            sponsoring it: the company had a problem — Firefox was a multi-million-line
            C++ program where every memory bug was a security CVE — and Rust was a
            plausible escape. By 2010 the project was public; by 2012 there was a
            self-hosted compiler. The language changed shape almost every week. Anyone
            who tried it in 2013 will tell you, with the special intensity of veterans,
            that nothing they wrote compiled the next year.
          </p>
        </div>

        <div style={{display:'flex', flexDirection:'column', gap:'20px'}}>
          <div className="portrait">
            <span className="sig">G.H.</span>
            <div className="who">
              <span>GRAYDON HOARE</span>
              <span>2006</span>
            </div>
          </div>
          <div style={{display:'grid', gridTemplateColumns:'1fr 1fr', gap:'12px'}}>
            <div className="origin-card" style={{padding:'18px'}}>
              <div className="when">2006</div>
              <h4 style={{fontSize:'19px', margin:'6px 0 4px'}}>Personal project</h4>
              <p style={{fontSize:'13px', margin:0}}>Graydon Hoare starts hacking on a "safe systems" language.</p>
            </div>
            <div className="origin-card" style={{padding:'18px'}}>
              <div className="when">2009</div>
              <h4 style={{fontSize:'19px', margin:'6px 0 4px'}}>Mozilla bets</h4>
              <p style={{fontSize:'13px', margin:0}}>Mozilla sponsors the project; team of paid engineers forms.</p>
            </div>
            <div className="origin-card" style={{padding:'18px'}}>
              <div className="when">2010</div>
              <h4 style={{fontSize:'19px', margin:'6px 0 4px'}}>Made public</h4>
              <p style={{fontSize:'13px', margin:0}}>First public announcement at Mozilla Summit. Compiler written in OCaml.</p>
            </div>
            <div className="origin-card" style={{padding:'18px'}}>
              <div className="when">2015</div>
              <h4 style={{fontSize:'19px', margin:'6px 0 4px'}}>Rust 1.0</h4>
              <p style={{fontSize:'13px', margin:0}}>Stable. Promise of backward compatibility. The language we know begins.</p>
            </div>
          </div>
        </div>
      </div>

      {/* Why-it-mattered band */}
      <div style={{marginTop:'80px', padding:'40px 0', borderTop:'1px solid var(--line)', borderBottom:'1px solid var(--line)'}}>
        <div style={{display:'grid', gridTemplateColumns:'repeat(3, 1fr)', gap:'40px'}}>
          <div>
            <div className="small-caps" style={{color:'var(--rust)'}}>The problem</div>
            <p style={{fontSize:'15px', color:'var(--ink-2)', lineHeight:1.55, marginTop:'10px'}}>
              ~70% of critical security bugs in C/C++ code at Microsoft, Google, and
              Apple come from one source: memory mismanagement. Use-after-free, buffer
              overflow, data race. Decades of effort. Same bugs.
            </p>
          </div>
          <div>
            <div className="small-caps" style={{color:'var(--rust)'}}>The accepted trade-off</div>
            <p style={{fontSize:'15px', color:'var(--ink-2)', lineHeight:1.55, marginTop:'10px'}}>
              Pick one: <span className="mono" style={{color:'var(--cream)'}}>safety</span> (Java, Go, Python — pay a garbage collector)
              or <span className="mono" style={{color:'var(--cream)'}}>speed</span> (C, C++ — pay with footguns).
              For 40 years, you couldn't have both.
            </p>
          </div>
          <div>
            <div className="small-caps" style={{color:'var(--rust)'}}>Rust's claim</div>
            <p style={{fontSize:'15px', color:'var(--ink-2)', lineHeight:1.55, marginTop:'10px'}}>
              Move the safety check to the compiler. No garbage collector. No runtime
              cost. Programs that compile cannot, by construction, have a whole class
              of bugs. <em style={{color:'var(--rust-2)', fontStyle:'normal', fontWeight:600}}>Fearless concurrency.</em>
            </p>
          </div>
        </div>
      </div>
    </section>
  );
}
