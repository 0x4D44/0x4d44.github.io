// Chapter 02 — Interactive timeline 2006 → 2026.
// Big year ticker on top, click any year to expand its story below.
function Timeline() {
  const events = [
    { y: 2006, t: "First commit",  body: "Graydon Hoare starts Rust as a personal project at Mozilla. Compiler written in OCaml.", tag: "ORIGIN" },
    { y: 2009, t: "Mozilla sponsors", body: "Mozilla begins funding Rust as part of its Servo browser-engine research.", tag: "FUNDING" },
    { y: 2010, t: "First public release", body: "Rust announced publicly at Mozilla Summit. Still highly experimental — syntax and semantics change weekly.", tag: "PUBLIC" },
    { y: 2012, t: "Self-hosting", body: "The Rust compiler is rewritten in Rust. OCaml dependency dropped.", tag: "MILESTONE" },
    { y: 2014, t: "Cargo arrives", body: "Cargo, the build tool and package manager, debuts. It will quickly become Rust's most loved feature.", tag: "TOOLING" },
    { y: 2015, t: "Rust 1.0", body: "First stable release. Backward-compatibility promise begins. Most code written today still compiles unchanged.", tag: "STABLE", highlight: true },
    { y: 2016, t: "Most loved (×1)", body: "Rust wins Stack Overflow's 'Most Loved Language' for the first time. It won't lose for nine years running.", tag: "CULTURE" },
    { y: 2018, t: "2018 Edition", body: "Non-lexical lifetimes, async/await reservation, module system overhaul, ?-operator. Rust gets its modern shape.", tag: "EDITION", highlight: true },
    { y: 2019, t: "async / await", body: "After years of design, async/await ships stable. Tokio and the modern web-server ecosystem explode.", tag: "FEATURE" },
    { y: 2020, t: "Mozilla layoffs", body: "Mozilla lays off the Rust team. The project's stewardship moves to the newly-formed Rust Foundation in 2021.", tag: "GOVERNANCE" },
    { y: 2021, t: "Rust Foundation", body: "AWS, Google, Huawei, Microsoft, Mozilla co-found the Rust Foundation. The language becomes industry-stewarded.", tag: "FOUNDATION", highlight: true },
    { y: 2021, t: "2021 Edition", body: "Disjoint closure captures, IntoIterator for arrays, cleaner panic macros. Quieter than 2018, but a clean handoff.", tag: "EDITION" },
    { y: 2022, t: "Rust in Linux", body: "Linus Torvalds merges initial Rust support into Linux 6.1 — the first new language in the kernel since 1991.", tag: "LINUX", highlight: true },
    { y: 2023, t: "White House memo", body: "U.S. ONCD formally recommends memory-safe languages for critical infrastructure. Names Rust explicitly.", tag: "POLICY" },
    { y: 2024, t: "2024 Edition", body: "RPIT lifetimes captured, never-type fallback, gen blocks reserved. Edition tightens existing rough edges.", tag: "EDITION", highlight: true },
    { y: 2025, t: "Rust is permanent in Linux", body: "Kernel maintainers agree: Rust is here to stay. DRM subsystem signals it will require Rust for new drivers within a year.", tag: "LINUX", highlight: true },
    { y: 2026, t: "Debian APT goes Rust", body: "Debian's package manager APT introduces hard Rust requirements. Memory-safe languages become infrastructure default.", tag: "INFRA" },
  ];

  const [selected, setSelected] = useState(2015);
  const trackRef = useRef(null);
  const [showLeft, setShowLeft] = useState(false);
  const [showRight, setShowRight] = useState(true);

  // Scroll the selected year into view in the ticker
  useEffect(() => {
    const el = trackRef.current?.querySelector(`[data-year="${selected}"]`);
    if (el) el.scrollIntoView({ behavior: 'smooth', inline: 'center', block: 'nearest' });
  }, [selected]);

  // Track scroll edges to show/hide arrows
  useEffect(() => {
    const el = trackRef.current;
    if (!el) return;
    const upd = () => {
      setShowLeft(el.scrollLeft > 10);
      setShowRight(el.scrollLeft < el.scrollWidth - el.clientWidth - 10);
    };
    upd();
    el.addEventListener('scroll', upd, { passive: true });
    return () => el.removeEventListener('scroll', upd);
  }, []);

  const scrollBy = (dx) => trackRef.current?.scrollBy({ left: dx, behavior: 'smooth' });

  const selectedEvents = events.filter(e => e.y === selected);
  const yearSpan = 2026 - 2006;

  return (
    <section className="chap" id="timeline" style={{maxWidth:'1400px'}}>
      <div className="chap-tag">
        <span className="num">02</span>
        <span className="label">Timeline · twenty years</span>
      </div>
      <div className="rule"></div>

      <div style={{display:'grid', gridTemplateColumns:'1.4fr 1fr', gap:'40px', alignItems:'end', marginTop:'48px', marginBottom:'56px'}}>
        <h2 className="head" style={{margin:0}}>From <em>elevator firmware</em><br/>to the Linux kernel.</h2>
        <p className="lede">Click any year. The big moments are marked in <span style={{color:'var(--rust)'}}>rust</span>. Drag or use the arrows to scrub.</p>
      </div>

      {/* Ticker */}
      <div style={{position:'relative'}}>
        <div ref={trackRef} className="tl-track" style={{
          display:'flex', gap:'0', overflowX:'auto', scrollSnapType:'x mandatory',
          padding:'40px 0 56px', borderTop:'1px solid var(--line)', borderBottom:'1px solid var(--line)',
          background: 'linear-gradient(to bottom, transparent, rgba(227,90,28,0.025), transparent)',
          scrollbarWidth: 'thin',
        }}>
          {Array.from({length: yearSpan + 1}).map((_, i) => {
            const y = 2006 + i;
            const yearEvents = events.filter(e => e.y === y);
            const has = yearEvents.length > 0;
            const isHi = yearEvents.some(e => e.highlight);
            const isSel = y === selected;
            return (
              <button
                key={y}
                data-year={y}
                onClick={() => setSelected(y)}
                className="tl-tick"
                style={{
                  flex: '0 0 auto', width: '78px',
                  display:'flex', flexDirection:'column', alignItems:'center',
                  background:'transparent', border:'none', cursor:'pointer',
                  padding:'8px 4px', color:'inherit', scrollSnapAlign:'center',
                  position:'relative',
                }}
              >
                <div style={{
                  fontFamily:"'Instrument Serif', serif", fontStyle: isSel?'italic':'normal',
                  fontSize: isSel ? '36px' : '22px',
                  color: isSel ? 'var(--rust)' : (has ? 'var(--ink-2)' : 'var(--ink-3)'),
                  opacity: has ? 1 : 0.4,
                  transition:'all .25s',
                  lineHeight:1,
                  marginBottom:'12px',
                }}>{y}</div>
                <div style={{
                  width: '2px',
                  height: isSel ? '48px' : (isHi ? '32px' : (has ? '20px' : '8px')),
                  background: isSel ? 'var(--rust)' : (isHi ? 'var(--rust-2)' : (has ? 'var(--ink-3)' : 'var(--line)')),
                  transition:'all .25s',
                }} />
                {has && !isSel && (
                  <div style={{
                    position:'absolute', top: isHi ? '70px' : '58px',
                    fontFamily:"'JetBrains Mono',monospace", fontSize:'9px',
                    color:'var(--ink-3)', letterSpacing:'0.1em', whiteSpace:'nowrap',
                    transform:'rotate(-30deg) translateX(-10px)',
                    transformOrigin:'left top', opacity:0.85,
                  }}>{yearEvents[0].tag}</div>
                )}
              </button>
            );
          })}
        </div>

        {showLeft && (
          <button onClick={() => scrollBy(-300)} aria-label="back" style={tlArrow(-1)}>‹</button>
        )}
        {showRight && (
          <button onClick={() => scrollBy(300)} aria-label="forward" style={tlArrow(1)}>›</button>
        )}
      </div>

      {/* Detail */}
      <div style={{marginTop:'48px', display:'grid', gridTemplateColumns:'1fr 2fr', gap:'56px', minHeight:'280px'}}>
        <div>
          <div style={{fontFamily:"'Instrument Serif', serif", fontSize:'140px', lineHeight:1, color:'var(--rust)', fontStyle:'italic'}}>{selected}</div>
          <div style={{fontFamily:"'JetBrains Mono',monospace", fontSize:'11px', color:'var(--ink-3)', letterSpacing:'0.2em', marginTop:'8px'}}>
            YEAR {selected - 2006} OF RUST
          </div>
        </div>
        <div style={{display:'flex', flexDirection:'column', gap:'28px', paddingTop:'30px'}}>
          {selectedEvents.length === 0 ? (
            <div style={{color:'var(--ink-3)', fontStyle:'italic', fontFamily:"'Instrument Serif',serif", fontSize:'24px'}}>A quiet year for the historical record.</div>
          ) : selectedEvents.map((e, i) => (
            <div key={i} style={{borderLeft:'2px solid var(--rust)', paddingLeft:'24px'}}>
              <div style={{display:'flex', gap:'12px', alignItems:'center', marginBottom:'10px'}}>
                <span className="small-caps" style={{color:'var(--rust-2)'}}>{e.tag}</span>
                {e.highlight && <span style={{fontSize:'10px', color:'var(--cream)', background:'var(--rust)', padding:'2px 8px', borderRadius:'999px', letterSpacing:'0.1em'}}>MILESTONE</span>}
              </div>
              <h3 style={{fontFamily:"'Instrument Serif',serif", fontWeight:400, fontSize:'34px', margin:'0 0 10px', lineHeight:1.1}}>{e.t}</h3>
              <p style={{color:'var(--ink-2)', lineHeight:1.6, fontSize:'16px', margin:0, maxWidth:'62ch'}}>{e.body}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}

function tlArrow(dir) {
  return {
    position:'absolute', top:'50%', [dir<0?'left':'right']: '-8px',
    transform:'translateY(-50%)',
    width:'40px', height:'40px', borderRadius:'50%',
    background:'var(--bg-2)', border:'1px solid var(--line)',
    color:'var(--ink-2)', fontSize:'24px', cursor:'pointer',
    display:'flex', alignItems:'center', justifyContent:'center',
    fontFamily:"'Instrument Serif', serif",
    zIndex:2,
  };
}
