// Chapter 04 — Editions explorer.
// Rust ships an "edition" every three years that can introduce breaking
// syntactic changes without breaking old crates. Click an edition to see
// what changed.

const EDITIONS = [
  {
    y: 2015,
    name: "2015",
    sub: "The original",
    head: "The 1.0 promise",
    body: "Rust 1.0 ships in May. The team commits to backward compatibility — anything you write today will compile in ten years. Cargo, the borrow checker, and `Result<T,E>` are already here. Code looks more like 2024 Rust than you'd guess.",
    sample: `// Rust 1.0, May 2015
fn read_log(path: &str) -> Result<String, io::Error> {
    let mut f = try!(File::open(path));
    let mut s = String::new();
    try!(f.read_to_string(&mut s));
    Ok(s)
}`,
    delta: ["Cargo + crates.io", "try! macro", "Strong stability guarantee"],
  },
  {
    y: 2018,
    name: "2018",
    sub: "Productivity",
    head: "The one everyone remembers",
    body: "The biggest edition. Non-Lexical Lifetimes (NLL) finally let the borrow checker understand that a reference's life ends at its last use — not at the end of its scope. Async/await is reserved. The module system is rethought. Imports get simpler. `try!` becomes `?`.",
    sample: `// Rust 2018
use std::fs::File;

fn read_log(path: &str) -> Result<String, io::Error> {
    let mut f = File::open(path)?;     // ? instead of try!
    let mut s = String::new();
    f.read_to_string(&mut s)?;
    Ok(s)
}`,
    delta: ["Non-Lexical Lifetimes (NLL)", "? operator", "Module system overhaul", "async/await reserved", "impl Trait returns"],
    star: true,
  },
  {
    y: 2021,
    name: "2021",
    sub: "Refinement",
    head: "A quieter handoff",
    body: "After 2018's earthquake, 2021 is gentle: disjoint closure captures (closures only capture the fields they actually use), `IntoIterator` for arrays, a cleaner `panic!` macro that prints arguments like `println!`. No drama. The point: editions can be small.",
    sample: `// Rust 2021
let p = Point { x: 10, y: 20 };
let print_x = || println!("{}", p.x);
//        Before 2021: closure captured all of "p".
//        After 2021: only captures p.x — frees up p.y.

for n in [1, 2, 3] { /* arrays are iterable now */ }`,
    delta: ["Disjoint closure captures", "IntoIterator for [T; N]", "Cleaner panic! / format!"],
  },
  {
    y: 2024,
    name: "2024",
    sub: "Sharpening",
    head: "Tightening rough edges",
    body: "2024 mostly closes long-standing gaps. RPIT (return-position impl Trait) now captures lifetimes by default — fixing a common confusing error. The never-type `!` becomes inferable in more places. `gen` blocks are reserved for future generators. Less new flash, more correctness.",
    sample: `// Rust 2024
fn first_word(s: &str) -> impl Iterator<Item = &str> {
    s.split_whitespace().take(1)
    // RPIT now captures &str's lifetime by default;
    // previous editions needed manual + '_ here.
}`,
    delta: ["RPIT lifetime capture", "Never-type fallback", "gen keyword reserved", "Stricter unsafe in macros"],
  },
];

function Editions() {
  const [eId, setEId] = useState("2018");
  const ed = EDITIONS.find(e => e.name === eId);

  return (
    <section className="chap" id="editions">
      <div className="chap-tag">
        <span className="num">04</span>
        <span className="label">Editions · how Rust evolves without breaking</span>
      </div>
      <div className="rule"></div>

      <div style={{display:'grid', gridTemplateColumns:'1.4fr 1fr', gap:'40px', alignItems:'end', marginTop:'48px', marginBottom:'32px'}}>
        <h2 className="head" style={{margin:0}}>Four <em>editions</em>,<br/>one promise.</h2>
        <p className="lede">Most languages either freeze (C++) or break the world (Python 2 → 3). Rust did neither. Every three years it ships an "edition" — opt-in, per-crate, fully cross-compatible. Pick one.</p>
      </div>

      {/* Edition selector */}
      <div style={{display:'grid', gridTemplateColumns:'repeat(4, 1fr)', gap:'12px', margin:'40px 0'}}>
        {EDITIONS.map(e => (
          <button key={e.name} onClick={() => setEId(e.name)} style={{
            background: eId === e.name ? 'var(--bg-2)' : 'transparent',
            border: '1px solid ' + (eId === e.name ? 'var(--rust)' : 'var(--line)'),
            borderRadius: '4px',
            padding: '20px 22px',
            cursor: 'pointer',
            textAlign:'left',
            color:'inherit',
            position:'relative',
            transition:'all .2s',
          }}>
            {e.star && <span style={{position:'absolute', top:8, right:10, fontSize:'10px', color:'var(--rust)', fontFamily:"'JetBrains Mono',monospace", letterSpacing:'0.16em'}}>★</span>}
            <div style={{fontFamily:"'Instrument Serif',serif", fontStyle:'italic', fontSize:'42px', color: eId===e.name?'var(--rust)':'var(--ink-2)', lineHeight:1}}>{e.name}</div>
            <div style={{marginTop:'10px', fontFamily:"'JetBrains Mono',monospace", fontSize:'10px', color:'var(--ink-3)', letterSpacing:'0.18em', textTransform:'uppercase'}}>{e.sub}</div>
          </button>
        ))}
      </div>

      <div style={{display:'grid', gridTemplateColumns:'1.1fr 1fr', gap:'40px', alignItems:'start'}}>
        <div>
          <div style={{display:'flex', alignItems:'baseline', gap:'14px', marginBottom:'14px'}}>
            <div style={{fontFamily:"'Instrument Serif',serif", fontStyle:'italic', fontSize:'72px', color:'var(--rust)', lineHeight:1}}>{ed.y}</div>
            <div>
              <h3 style={{fontFamily:"'Instrument Serif',serif", fontWeight:400, fontSize:'34px', margin:0, lineHeight:1.05}}>{ed.head}</h3>
            </div>
          </div>
          <p style={{color:'var(--ink-2)', lineHeight:1.65, fontSize:'16px', maxWidth:'60ch'}}>{ed.body}</p>

          <div style={{marginTop:'28px'}}>
            <div className="small-caps" style={{color:'var(--rust)', marginBottom:'14px'}}>Headline changes</div>
            <ul style={{listStyle:'none', padding:0, margin:0, display:'flex', flexDirection:'column', gap:'10px'}}>
              {ed.delta.map((d, i) => (
                <li key={i} style={{display:'flex', alignItems:'center', gap:'14px', fontSize:'15px'}}>
                  <span style={{fontFamily:"'JetBrains Mono',monospace", fontSize:'11px', color:'var(--ink-3)', width:'28px'}}>{String(i+1).padStart(2,'0')}</span>
                  <span style={{width:'8px', height:'8px', background:'var(--rust)', borderRadius:'1px'}}></span>
                  <span style={{color:'var(--ink-2)'}}>{d}</span>
                </li>
              ))}
            </ul>
          </div>
        </div>

        <div style={{background:'#0e0a07', border:'1px solid var(--line)', borderRadius:'6px', overflow:'hidden'}}>
          <div style={{display:'flex', justifyContent:'space-between', alignItems:'center', padding:'10px 16px', borderBottom:'1px solid var(--line-soft)', background:'var(--bg-2)'}}>
            <div style={{display:'flex', gap:'6px'}}>
              <span style={dot('#f0664a')} /><span style={dot('#e3a857')} /><span style={dot('#7fbc8c')} />
            </div>
            <div style={{fontFamily:"'JetBrains Mono',monospace", fontSize:'11px', color:'var(--ink-3)'}}>edition_{ed.name}.rs</div>
          </div>
          <pre style={{margin:0, padding:'20px 22px', fontFamily:"'JetBrains Mono',monospace", fontSize:'13.5px', lineHeight:1.7, color:'var(--cream)', overflowX:'auto'}}>
            <code dangerouslySetInnerHTML={{ __html: highlight(ed.sample) }} />
          </pre>
        </div>
      </div>

      {/* Edition timeline strip */}
      <div style={{marginTop:'64px', borderTop:'1px solid var(--line)', paddingTop:'28px'}}>
        <div className="small-caps" style={{color:'var(--ink-3)', marginBottom:'18px'}}>The promise · old code keeps compiling</div>
        <div style={{display:'flex', alignItems:'center', gap:'2px'}}>
          {[2015,2016,2017,2018,2019,2020,2021,2022,2023,2024,2025,2026].map((y) => {
            const isEd = [2015,2018,2021,2024].includes(y);
            const current = parseInt(eId) === y;
            return (
              <div key={y} style={{flex:1, position:'relative'}}>
                <div style={{
                  height: isEd?'24px':'10px',
                  background: current ? 'var(--rust)' : (isEd ? 'var(--rust-2)' : 'var(--line)'),
                  borderRadius:'1px',
                  opacity: current ? 1 : (isEd ? 0.8 : 1),
                  transition: 'all .2s',
                }} />
                <div style={{textAlign:'center', marginTop:'8px', fontFamily:"'JetBrains Mono',monospace", fontSize:'10px', color: isEd?'var(--ink-2)':'var(--ink-3)', letterSpacing:'0.1em'}}>
                  {y}
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </section>
  );
}
