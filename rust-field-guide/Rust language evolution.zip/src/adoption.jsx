// Chapter 07 — Adoption.  Who uses Rust, what they use it for, and how big.
const COMPANIES = [
  { n:"Microsoft", use:"Rewriting Windows kernel components in Rust to eliminate memory bugs.", tag:"OS" },
  { n:"Amazon AWS", use:"Firecracker microVMs (powering Lambda + Fargate) are entirely in Rust.", tag:"CLOUD" },
  { n:"Google", use:"Android system components in Rust; the kernel team funds Rust-for-Linux.", tag:"OS / MOBILE" },
  { n:"Meta", use:"Internal source-control tooling for the largest monorepo on Earth.", tag:"TOOLING" },
  { n:"Cloudflare", use:"Pingora — an HTTP proxy in Rust — serves over a trillion requests a day.", tag:"NETWORKING" },
  { n:"Discord", use:"Migrated their state service from Go to Rust to kill GC-induced latency spikes.", tag:"BACKEND" },
  { n:"Dropbox", use:"File-sync engine — the one piece of software you really don't want to crash.", tag:"SYSTEMS" },
  { n:"Mozilla", use:"Servo, then Stylo, then large parts of Firefox.", tag:"BROWSER" },
  { n:"Figma", use:"Multiplayer sync engine compiled to WebAssembly.", tag:"WASM" },
  { n:"Linux kernel", use:"As of 2025, Rust is a permanent first-class kernel language — joining C.", tag:"KERNEL" },
];

const STATS = [
  { n:"83%", l:"admiration in Stack Overflow's 2024 survey" },
  { n:"9", l:"consecutive years as most-loved language" },
  { n:"+68.75%", l:"commercial adoption growth, 2021 → 2025" },
  { n:"+300%", l:"GitHub Rust projects in the same window" },
  { n:"~70%", l:"of Microsoft's & Chrome's CVEs are memory bugs Rust prevents" },
  { n:"2.27M", l:"developers using Rust (JetBrains 2024)" },
];

function Adoption() {
  return (
    <section className="chap" id="adoption">
      <div className="chap-tag">
        <span className="num">07</span>
        <span className="label">Adoption · the language quietly eating infrastructure</span>
      </div>
      <div className="rule"></div>

      <div style={{display:'grid', gridTemplateColumns:'1.4fr 1fr', gap:'40px', alignItems:'end', marginTop:'48px', marginBottom:'40px'}}>
        <h2 className="head" style={{margin:0}}>Who's <em>actually</em> shipping it?</h2>
        <p className="lede">In 2018, Rust was a curiosity. In 2026, it's running your cloud, your phone, your file system, and — increasingly — the kernel your laptop boots into.</p>
      </div>

      {/* Stats grid */}
      <div style={{display:'grid', gridTemplateColumns:'repeat(3, 1fr)', gap:'1px', background:'var(--line)', border:'1px solid var(--line)', marginTop:'48px', marginBottom:'56px'}}>
        {STATS.map((s, i) => (
          <div key={i} style={{background:'var(--bg)', padding:'32px 28px', minHeight:'160px'}}>
            <div style={{fontFamily:"'Instrument Serif',serif", fontStyle:'italic', fontSize:'72px', color:'var(--rust)', lineHeight:1}}>{s.n}</div>
            <div style={{marginTop:'14px', color:'var(--ink-2)', fontSize:'14px', lineHeight:1.55, maxWidth:'34ch'}}>{s.l}</div>
          </div>
        ))}
      </div>

      {/* Companies */}
      <div className="small-caps" style={{color:'var(--rust)', marginBottom:'24px'}}>Production deployments</div>

      <div style={{display:'grid', gridTemplateColumns:'repeat(2, 1fr)', gap:'1px', background:'var(--line)', border:'1px solid var(--line)', borderRadius:'4px', overflow:'hidden'}}>
        {COMPANIES.map((c, i) => (
          <div key={i} style={{background:'var(--bg)', padding:'24px 28px', display:'grid', gridTemplateColumns:'180px 1fr 110px', gap:'20px', alignItems:'center'}}>
            <div style={{fontFamily:"'Instrument Serif',serif", fontWeight:400, fontSize:'28px', color:'var(--cream)'}}>{c.n}</div>
            <div style={{color:'var(--ink-2)', fontSize:'14px', lineHeight:1.55}}>{c.use}</div>
            <div style={{fontFamily:"'JetBrains Mono',monospace", fontSize:'10px', letterSpacing:'0.16em', color:'var(--rust)', textAlign:'right'}}>{c.tag}</div>
          </div>
        ))}
      </div>

      {/* Where it's used */}
      <div style={{marginTop:'64px', padding:'40px', background:'var(--bg-2)', border:'1px solid var(--line)', borderRadius:'6px'}}>
        <div className="small-caps" style={{color:'var(--rust)', marginBottom:'20px'}}>Where Rust ends up</div>
        <div style={{display:'grid', gridTemplateColumns:'repeat(5, 1fr)', gap:'16px'}}>
          {[
            { h:"Cloud infra", t:"Microservices, edge proxies, microVMs.", n:"24.3%" },
            { h:"Systems", t:"OS components, drivers, kernels.", n:"Linux 6.1+" },
            { h:"WebAssembly", t:"Figma, Shopify, Cloudflare Workers.", n:"23%" },
            { h:"Backend services", t:"High-throughput, low-latency APIs.", n:"#1" },
            { h:"Embedded", t:"Microcontrollers, satellites, automotive.", n:"growing" },
          ].map((u,i) => (
            <div key={i} style={{padding:'18px', background:'var(--bg)', border:'1px solid var(--line-soft)', borderRadius:'3px'}}>
              <div style={{fontFamily:"'Instrument Serif',serif", fontSize:'26px', color:'var(--rust-2)', fontStyle:'italic'}}>{u.n}</div>
              <h4 style={{margin:'10px 0 6px', fontSize:'14px', color:'var(--cream)'}}>{u.h}</h4>
              <p style={{margin:0, color:'var(--ink-3)', fontSize:'12px', lineHeight:1.5}}>{u.t}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
