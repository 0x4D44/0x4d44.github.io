// Chapter 08 — Future.  Where Rust goes from here, and the closing line.
function Future() {
  const bets = [
    { t:"Linux kernel by default", body:"Debian's APT goes Rust-required in May 2026. The DRM graphics subsystem will require Rust for new drivers by year-end. C is no longer the only kernel language.", odds:"shipping" },
    { t:"Memory-safe-by-policy", body:"The U.S. ONCD has recommended memory-safe languages for critical infrastructure. Expect procurement language that lists Rust by name.", odds:"likely" },
    { t:"Const generics & GATs land deeper", body:"Generic associated types and const generics are stable; the patterns they enable are still being discovered by library authors. Expect the ecosystem to bloom around them.", odds:"in progress" },
    { t:"The borrow checker becomes Polonius", body:"A new borrow-checking engine that accepts more correct programs and explains rejections better. Years in the making.", odds:"in progress" },
    { t:"Specification work", body:"The Rust Foundation is funding a formal language specification. A precondition for serious adoption in regulated industries — aerospace, automotive, medical.", odds:"underway" },
    { t:"Compile-time speed parity with Go", body:"Honest assessment: probably not. Rust's strictness costs cycles. Incremental wins keep landing, but feature parity with Go's build speed is a bet against physics.", odds:"long shot" },
  ];

  return (
    <section className="chap" id="future">
      <div className="chap-tag">
        <span className="num">08</span>
        <span className="label">Future · the bets on the table</span>
      </div>
      <div className="rule"></div>

      <div style={{display:'grid', gridTemplateColumns:'1.4fr 1fr', gap:'40px', alignItems:'end', marginTop:'48px', marginBottom:'48px'}}>
        <h2 className="head" style={{margin:0}}>What happens<br/>in the <em>next</em> twenty.</h2>
        <p className="lede">Rust is no longer a wager. The question now is how deep it goes — into kernels, into regulators, into procurement. Here's what's on the table.</p>
      </div>

      <div style={{display:'grid', gridTemplateColumns:'repeat(2, 1fr)', gap:'1px', background:'var(--line)', border:'1px solid var(--line)', marginBottom:'72px'}}>
        {bets.map((b, i) => (
          <div key={i} style={{background:'var(--bg)', padding:'28px 32px'}}>
            <div style={{display:'flex', justifyContent:'space-between', alignItems:'baseline', marginBottom:'14px'}}>
              <div style={{fontFamily:"'JetBrains Mono',monospace", fontSize:'11px', color:'var(--ink-3)', letterSpacing:'0.18em'}}>BET {String(i+1).padStart(2,'0')}</div>
              <div style={{fontFamily:"'JetBrains Mono',monospace", fontSize:'10px', color: b.odds === 'shipping' ? 'var(--safe)' : b.odds === 'long shot' ? 'var(--err)' : 'var(--rust)', letterSpacing:'0.16em', textTransform:'uppercase'}}>{b.odds}</div>
            </div>
            <h3 style={{margin:'0 0 12px', fontFamily:"'Instrument Serif',serif", fontWeight:400, fontSize:'30px', lineHeight:1.1}}>{b.t}</h3>
            <p style={{margin:0, color:'var(--ink-2)', fontSize:'15px', lineHeight:1.55}}>{b.body}</p>
          </div>
        ))}
      </div>

      {/* Closing */}
      <div style={{textAlign:'center', padding:'80px 24px', borderTop:'1px solid var(--line)', borderBottom:'1px solid var(--line)'}}>
        <div className="small-caps" style={{color:'var(--rust)', marginBottom:'24px'}}>And so</div>
        <div style={{fontFamily:"'Instrument Serif',serif", fontSize:'clamp(40px, 6vw, 84px)', lineHeight:1.05, maxWidth:'22ch', margin:'0 auto', fontStyle:'italic'}}>
          The most-loved language<br/>
          is also, finally,<br/>
          <span style={{color:'var(--rust)'}}>the most-used one</span> where it counts.
        </div>
        <div style={{marginTop:'40px', fontFamily:"'JetBrains Mono',monospace", fontSize:'13px', color:'var(--ink-3)', letterSpacing:'0.2em'}}>
          $ cargo build --release
        </div>
        <div style={{marginTop:'12px', color:'var(--safe)', fontFamily:"'JetBrains Mono',monospace", fontSize:'13px'}}>
          ✓ Finished `release` profile [optimized] in 0.42s
        </div>
      </div>
    </section>
  );
}
