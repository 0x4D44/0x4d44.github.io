// Root app — mounts every chapter in order. Each chapter is a separate file
// so the document stays small and editable.
const { useState, useEffect, useRef, useMemo } = React;

function App() {
  return (
    <>
      <Origins />
      <Timeline />
      <Ownership />
      <Editions />
      <Tradeoffs />
      <Family />
      <Adoption />
      <Future />
    </>
  );
}

ReactDOM.createRoot(document.getElementById('root')).render(<App />);
