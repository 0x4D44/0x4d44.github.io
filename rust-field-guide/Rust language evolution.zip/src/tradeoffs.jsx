// Chapter 05 — Trade-offs.  The good, the bad, the novel.  Three columns.
const TRADEOFFS = {
  good: {
    title: "The good",
    color: "var(--safe)",
    items: [
      { h: "Memory safety, no GC", b: "Use-after-free, double-free, dangling pointers, data races — gone. Without a garbage collector. C-level performance, Java-level safety." },
      { h: "Cargo + crates.io", b: "Voted the most-admired build tool in the world. `cargo new`, `cargo test`, `cargo doc`, `cargo bench`, `cargo fmt` — all built in. Dependencies are one line." },
      { h: "Errors as values", b: "`Result<T, E>` forces you to handle every failure path. No surprise exceptions. The `?` operator makes it ergonomic." },
      { h: "Zero-cost abstractions", b: "Iterators, generics, traits — all monomorphized at compile time. A `for x in items.iter().filter(p).map(f)` is as fast as a hand-rolled loop." },
      { h: "Tooling that just works", b: "rustfmt, clippy, rust-analyzer, miri. Most languages took 20 years to get here; Rust shipped most of it by year five." },
    ],
  },
  bad: {
    title: "The bad",
    color: "var(--err)",
    items: [
      { h: "The learning cliff", b: "The borrow checker is a stranger you argue with for three months. The frustration is famous. Productivity dips before it spikes." },
      { h: "Compile times", b: "Heavy generics + LLVM + linking = slow builds. Incremental compilation helps; large workspaces still sting." },
      { h: "Async is fractured", b: "async/await landed in 2019 but the ecosystem still splits across runtimes (Tokio, async-std, smol). Library authors must pick or be generic." },
      { h: "No specification", b: "There is no ISO Rust standard. There is one compiler (rustc) and one alternative (gccrs, still WIP). For some industries, that's disqualifying." },
      { h: "Linker-level pain", b: "Cross-compiling, dynamic linking, plugin systems — all harder than in C. Rust's strictness goes all the way down to your build system." },
    ],
  },
  novel: {
    title: "The novel",
    color: "var(--rust)",
    items: [
      { h: "Affine ownership", b: "Every value has exactly one owner, transferred by move. Borrowed from research languages (Cyclone, linear types), shipped to production." },
      { h: "Borrow checker", b: "A static analysis pass that proves your aliasing rules at compile time. Nothing else mainstream had ever shipped this." },
      { h: "Send / Sync", b: "Thread-safety encoded as auto-traits. The compiler tells you, mechanically, which types can cross a thread boundary." },
      { h: "Editions", b: "Per-crate, opt-in language versions that can break syntax without breaking the world. Other languages should have stolen this years ago." },
      { h: "Fearless concurrency", b: "Data races are not just discouraged — they are impossible to compile. A single property of the type system locks down half of all concurrency bugs." },
    ],
  },
};

function Tradeoffs() {
  return (
    <section className="chap" id="tradeoffs">
      <div className="chap-tag">
        <span className="num">05</span>
        <span className="label">Trade-offs · what's good, bad, and unprecedented</span>
      </div>
      <div className="rule"></div>

      <div style={{display:'grid', gridTemplateColumns:'1.4fr 1fr', gap:'40px', alignItems:'end', marginTop:'48px'}}>
        <h2 className="head" style={{margin:0}}>Nothing for <em>free</em>.</h2>
        <p className="lede">Rust is loved, but not without cost. The exact same features that earn its admirers — strictness, ownership, a compiler that says no — are what make it hard to learn and slow to build. Honest about both.</p>
      </div>

      <div style={{display:'grid', gridTemplateColumns:'repeat(3, 1fr)', gap:'24px', marginTop:'56px'}}>
        {Object.entries(TRADEOFFS).map(([key, col]) => (
          <div key={key} style={{
            background:'var(--bg-2)', border:'1px solid var(--line)', borderRadius:'6px', padding:'28px',
            position:'relative', overflow:'hidden',
          }}>
            <div style={{position:'absolute', top:0, left:0, right:0, height:'3px', background: col.color}}></div>
            <div className="small-caps" style={{color: col.color, marginBottom:'10px'}}>{key === 'good' ? '+ THE GOOD' : key === 'bad' ? '− THE BAD' : '★ THE NOVEL'}</div>
            <h3 style={{fontFamily:"'Instrument Serif',serif", fontWeight:400, fontSize:'40px', margin:'0 0 24px', lineHeight:1, fontStyle:'italic', color: col.color}}>
              {col.title}
            </h3>
            <div style={{display:'flex', flexDirection:'column', gap:'20px'}}>
              {col.items.map((it, i) => (
                <div key={i}>
                  <div style={{display:'flex', gap:'10px', alignItems:'baseline', marginBottom:'6px'}}>
                    <span style={{fontFamily:"'JetBrains Mono',monospace", fontSize:'11px', color:'var(--ink-3)'}}>{String(i+1).padStart(2,'0')}</span>
                    <h4 style={{margin:0, fontSize:'15px', color:'var(--cream)', fontWeight:600}}>{it.h}</h4>
                  </div>
                  <p style={{margin:'0 0 0 26px', color:'var(--ink-2)', fontSize:'13.5px', lineHeight:1.55}}>{it.b}</p>
                </div>
              ))}
            </div>
          </div>
        ))}
      </div>
    </section>
  );
}
