# Building Tacit-Equivalent Knowledge for Agents

> [!info] Status: Stub
> This page needs expansion.

How to build institutional memory and tacit-equivalent systems for agent teams. Covers creating knowledge accumulation workflows, designing persistent knowledge bases that agents can learn from, and maintaining institutional continuity.

## Related Pages

- [[Tacit Knowledge and Agents]]
- [[Heuristic 18 - Design Agent Workflows as Knowledge-Accumulating Systems]]

## Tags

#knowledge-management #agents #stub #backlog
