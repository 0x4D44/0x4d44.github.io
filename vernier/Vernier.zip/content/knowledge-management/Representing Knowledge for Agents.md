# Representing Knowledge for Agents

> [!info] Status: Stub
> This page needs expansion.

Formats, structures, and systems for recording knowledge in a way that's usable by both agents and humans. Covers structured knowledge representation, semantic encoding, and designing knowledge bases for agent reasoning.

## Related Pages

- [[Tacit Knowledge and Agents]]
- [[Agent Recording Protocols]]

## Tags

#knowledge-management #agents #stub #backlog
