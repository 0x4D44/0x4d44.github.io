# Techniques for Extracting Tacit Knowledge

> [!info] Status: Stub
> This page needs expansion with more techniques and worked examples.

Techniques and methods for getting tacit knowledge out of humans' heads so it can be used by agents and new team members.

## The Socratic Method

The most important technique for extracting tacit knowledge is Socratic questioning — probing, open-ended questions that lead people past their surface-level answers to the reasoning, experience, and intuition underneath. People often can't articulate what they know until the right question draws it out.

Key applications:
- **Stakeholder interviews** — Don't accept stated requirements. Ask *why* they care, what happens if they don't get it, what they've tried before. See [[Stakeholders]] and [[Context]].
- **Expert knowledge capture** — Ask experienced engineers "what would worry you about this?" rather than "tell me what you know." Scenario-based questions elicit richer knowledge than abstract ones.
- **Post-incident debriefs** — "What made you look there first?" reveals diagnostic intuition that never gets written down.

The Socratic method works because it bypasses the "curse of knowledge" — experts have internalised so much that they can't enumerate it. Questions that start from specific situations pull out knowledge that abstract requests for documentation never would.

## Other Techniques

- "Explain it to the new person" exercises
- Prompted recall — asking specific questions about specific areas
- Recording observations as you go (not retrospectively)
- Structured debriefs after incidents and projects
- Pair working where the knowledgeable person narrates their thinking

## Related Pages

- [[Tacit Knowledge and Agents]] — why extraction matters
- [[Representing Knowledge for Agents]] — what to do with extracted knowledge
- [[Context]] — Socratic questioning is also how you build context
- [[Heuristic 15 - Tacit Knowledge Is Invisible Debt]]
- [[Heuristic 16 - If You Can't Articulate It an Agent Can't Use It]]

## Tags

#knowledge-management #stub #backlog
