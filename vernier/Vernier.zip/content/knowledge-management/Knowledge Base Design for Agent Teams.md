# Knowledge Base Design for Agent Teams

> [!info] Status: Stub
> This page needs expansion.

Architecture and design principles for knowledge bases that serve agent teams. Covers organization patterns, discoverability for agents, consistency maintenance, update protocols, and integration with agent workflows.

## Related Pages

- [[Tacit Knowledge and Agents]]
- [[Agent Recording Protocols]]

## Tags

#knowledge-management #agents #stub #backlog
