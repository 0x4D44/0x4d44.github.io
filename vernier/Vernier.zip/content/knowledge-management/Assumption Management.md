# Assumption Management

> [!info] Status: Stub
> This page needs expansion.

Techniques and processes for surfacing, checking, recording, and managing assumptions — particularly important for agents who are worse than humans at recognising when they're making assumptions. Covers assumption checkpoints, validation strategies, and assumption tracking systems.

## Related Pages

- [[Heuristic 19 - Explicitly Check and Record Assumptions]]
- [[Heuristic 20 - Ask More Questions Make Fewer Assumptions]]

## Tags

#knowledge-management #agents #stub #backlog
