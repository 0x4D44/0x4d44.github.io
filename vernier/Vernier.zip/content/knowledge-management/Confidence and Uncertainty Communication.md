# Confidence and Uncertainty Communication

> [!info] Status: Stub
> This page needs expansion.

Methods for expressing, recording, and calibrating confidence levels in outputs and conclusions — critical for agent systems where output looks authoritative but may contain significant uncertainty. Covers confidence scales, uncertainty propagation, and avoiding spurious precision.

## Related Pages

- [[Heuristic 21 - State Confidence Levels Explicitly]]
- [[Heuristic 22 - Calibrate Your Confidence in Your Confidence]]
- [[Heuristic 23 - Don't Use Spurious Precision]]

## See Also

- [Confidence as the Through-Line](quality-strategy/concept-confidence-through-line.md) — Confidence as the core output of quality work
- [Risk Map vs Risk Register](quality-strategy/concept-risk-map-vs-register.md) — Confidence overlay in risk assessment

## Tags

#knowledge-management #stub #backlog
