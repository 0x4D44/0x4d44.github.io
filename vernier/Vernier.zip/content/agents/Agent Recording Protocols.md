# Agent Recording Protocols

Agents don't record context by default — you have to make it part of the task. See [[Heuristic 17 - Agents Don't Record Context by Default]].

## What Agents Should Capture

Every agent task should have an explicit "record what you learned" output alongside the actual deliverable. Not just "fix the bug" but "fix the bug and record:
- What you found
- What you tried
- What was surprising
- What you're now worried about
- What assumptions you made"

## Design Principles

- The recording format needs to be structured enough to be useful to other agents and humans
- There's a cost-benefit trade-off — recording everything is noise, recording nothing loses knowledge
- Calibrate what's worth capturing — connects to [[Risk]] and the [[Economics of Testing]]
- Agent workflows should be **knowledge-accumulating systems**, not just task-completing systems. See [[Heuristic 18 - Design Agent Workflows as Knowledge-Accumulating Systems]].

## Practical Mechanisms

- Mandatory structured output fields on every task (observations, decisions, concerns, surprises)
- Periodic "what do we now know that we didn't before" summaries
- Agent-to-agent handoff protocols that force context transfer — see [[Agent-to-Agent Knowledge Handoff]]
- A persistent knowledge base that agents read from and write to as part of their workflow

## How It Connects

- [[Tacit Knowledge and Agents]] — the broader context for why recording matters
- [[Heuristic 19 - Explicitly Check and Record Assumptions]] — assumptions are a key thing to record
- [[Heuristic 20 - Ask More Questions Make Fewer Assumptions]] — design pause points

## Tags

#agents #knowledge-management
