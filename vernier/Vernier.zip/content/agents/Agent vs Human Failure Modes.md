# Agent vs Human Failure Modes

> [!info] Status: Stub
> This page needs expansion into a comparison of failure modes and how to design review and testing for each.

Agent failure modes vs human failure modes — how to design review and testing processes that catch both kinds of error.

Humans make inconsistent, visible mistakes. Agents make consistent, plausible-looking mistakes. Review processes designed for human error patterns will miss agent error patterns.

## Related Pages

- [[Heuristic 12 - Agents Don't Get Tired But Have Blind Spots]]
- [[Heuristic 14 - Agent Output Needs Different Review]]
- [[Agent Considerations]]

## Tags

#agents #stub #backlog
