# Agent Considerations

This page consolidates links to agent-related content across the knowledge base. Agents change the quality picture in several fundamental ways — they're not just faster humans, and quality definitions, testing strategies, and processes all need to account for this.

## Agent-Related Content Across the KB

### Agent Stakeholders
Any stakeholder could be an agent — see [[Stakeholders]] and [[Heuristic 10 - Any Stakeholder Could Be an Agent]]. For a deeper look at how each stakeholder group changes with agents, see [[Agent Stakeholder Implications]].

### Agent Heuristics
The agent-specific heuristics (9-14) cover the key differences:
- [[Heuristic 9 - Don't Import Old-World Costs]] — different economics
- [[Heuristic 10 - Any Stakeholder Could Be an Agent]] — different stakeholders
- [[Heuristic 11 - Agents Have Different Strengths and Weaknesses]] — not faster humans
- [[Heuristic 12 - Agents Don't Get Tired But Have Blind Spots]] — different failure modes
- [[Heuristic 13 - Economics of Checking vs Investigating Shift with Agents]] — rebalance effort
- [[Heuristic 14 - Agent Output Needs Different Review]] — different review needs

### Agent Knowledge Management
- [[Tacit Knowledge and Agents]] — why tacit knowledge is a problem for agents
- [[Agent Recording Protocols]] — how to make agents capture knowledge
- Heuristics 15-20 cover knowledge and communication for agents

### Proxy Gaming by Agents
- [[Heuristic 7 - Proxies Are Gameable]] — Goodhart's Law, doubly for agents
- [[Heuristic 8 - Malicious Compliance Check]] — the key defence
- [[Proxy Blind Spots and Gaming Risks]] — detailed per-proxy analysis

### Confidence and Assumptions
- [[Heuristic 19 - Explicitly Check and Record Assumptions]]
- [[Heuristic 20 - Ask More Questions Make Fewer Assumptions]]
- [[Heuristic 21 - State Confidence Levels Explicitly]]
- [[Heuristic 22 - Calibrate Your Confidence in Your Confidence]]
- [[Heuristic 23 - Don't Use Spurious Precision]]

## Backlog — Agent-Specific Topics

- [[Agent Strengths and Weaknesses]] — reference list for calibrating expectations
- [[Agent Stakeholder Implications]] — how each stakeholder group changes with agents
- [[Agent vs Human Failure Modes]] — designing review for each

## See Also

- [The Old World / New World Bias Trap](quality-strategy/concept-old-world-new-world-bias.md) — Systematic check for human-centric reasoning bias
- [Quality — The Core Definition](quality-strategy/concept-quality-definition.md) — Why "or something" matters: agents as first-class stakeholders

## Tags

#agents #overview
