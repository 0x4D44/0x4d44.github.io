# Agent Stakeholder Implications

> [!info] Status: Stub
> This page needs expansion covering how each stakeholder group changes when the stakeholder is an agent.

How each [[Stakeholders|stakeholder group]] changes when the stakeholder is an agent rather than a human. Agents value different things — they don't care about visual usability but care intensely about consistency, predictability, and documentation quality.

## Related Pages

- [[Stakeholders]]
- [[Heuristic 10 - Any Stakeholder Could Be an Agent]]
- [[Agent Considerations]]

## Tags

#agents #stakeholders #stub #backlog
