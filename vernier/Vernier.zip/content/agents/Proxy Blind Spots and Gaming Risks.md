# Proxy Blind Spots and Gaming Risks

> [!warning] Status: Priority Stub
> This is a **priority** page flagged for early development. Agents will be doing the optimising, so understanding how each proxy can be gamed is critical.

For each proxy: what it doesn't tell you, how it can be gamed (by humans and by agents), what guardrails or counter-proxies to use.

This page should eventually cover every proxy in [[Proxies - Dev Tooling]] and [[Proxies - Blog Post]], analysing:
1. The blind spots — what the proxy doesn't measure
2. Human gaming patterns — how humans typically game it
3. Agent gaming patterns — how agents would game it (typically faster and more ruthlessly)
4. Guardrails — counter-proxies, explicit constraints, or review processes to prevent gaming

## Key Heuristics

- [[Heuristic 6 - Know Your Proxy's Blind Spots]]
- [[Heuristic 7 - Proxies Are Gameable]]
- [[Heuristic 8 - Malicious Compliance Check]]

## Related Pages

- [[Proxies]] — overview
- [[Proxies - Dev Tooling]] — the proxies to analyse
- [[Agent Considerations]] — broader agent context

## Tags

#agents #proxies #priority #stub #backlog
