# Agent Strengths and Weaknesses

> [!info] Status: Stub
> This page needs expansion into a reference list for calibrating expectations about what agents can and can't do.

What agents find easier and harder than humans — a reference list for calibrating expectations when designing quality strategies, testing approaches, and workflows.

## Related Pages

- [[Heuristic 11 - Agents Have Different Strengths and Weaknesses]]
- [[Heuristic 12 - Agents Don't Get Tired But Have Blind Spots]]
- [[Agent Considerations]]

## Tags

#agents #stub #backlog
