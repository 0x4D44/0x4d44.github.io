# Tacit Knowledge and Agent Knowledge Management

## The Problem

In human teams, a huge amount of quality-relevant knowledge is never written down. It lives in people's heads as:
- Intuition and "feel" for the product
- [[Smells]] — the "something's off" reactions that fire before you can name the problem
- History — "we tried that and it didn't work"
- Context — "this area is fragile"
- Expectations — "customers hate when we change this"
- Norms — what "normal" behaviour looks like

This works in human teams because humans share context through proximity, conversation, and osmosis. Agents have none of this. If it's not explicit, it doesn't exist for them. See [[Heuristic 15 - Tacit Knowledge Is Invisible Debt]].

## Why This Matters

- Agents will miss things that "everyone just knows"
- Agents will make confident decisions based on incomplete context
- Agents will repeat discovery work that humans already did
- New humans also suffer from this — tacit knowledge is the main reason ramp-up is slow. See [[Ramp-Up-Ability]].

## The Opportunity

The discipline of making tacit knowledge explicit for agents also makes it explicit for new humans. This improves [[Ramp-Up-Ability]] and reduces bus factor. Doing this well is a competitive advantage. See [[Heuristic 16 - If You Can't Articulate It an Agent Can't Use It]].

## Two Distinct Problems

### 1. Extraction — Getting Tacit Knowledge Out of Humans

Humans often can't articulate their tacit knowledge because it's intuitive. Techniques for surfacing it include:
- "Explain it to the new person" exercises
- Prompted recall — asking specific questions about specific areas
- Recording observations as you go (not retrospectively)
- Structured debriefs after incidents and projects
- Pair working where the knowledgeable person narrates their thinking

See [[Techniques for Extracting Tacit Knowledge]] for more.

### 2. Representation — Recording It Usefully

The knowledge needs to be in a form that's usable by both humans and agents. Not just docs, but structured knowledge that agents can reason with.

See [[Representing Knowledge for Agents]] for formats, structures, and systems.

## Agent Recording Protocols

Agents don't record context by default — you have to make it part of the task. See [[Agent Recording Protocols]] for the full protocol and [[Heuristic 17 - Agents Don't Record Context by Default]].

## Assumptions

Agents are much worse than humans at recognising when they're making assumptions — see [[Heuristic 19 - Explicitly Check and Record Assumptions]]. Build in explicit "what am I assuming here?" checkpoints. When in doubt, ask rather than assume — see [[Heuristic 20 - Ask More Questions Make Fewer Assumptions]].

See [[Assumption Management]] for techniques.

## Confidence Levels

State confidence levels explicitly — [[Heuristic 21 - State Confidence Levels Explicitly]]. Calibrate your confidence — [[Heuristic 22 - Calibrate Your Confidence in Your Confidence]]. Don't use spurious precision — [[Heuristic 23 - Don't Use Spurious Precision]].

See [[Confidence and Uncertainty Communication]] for more.

## See Also

- [Confidence as the Through-Line](quality-strategy/concept-confidence-through-line.md) — Tacit knowledge gaps reduce confidence; making knowledge explicit builds it

## Tags

#agents #knowledge-management
