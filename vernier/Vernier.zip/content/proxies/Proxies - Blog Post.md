# Proxies — From the Blog Post (Measurable Quality Bars)

Source: testingmanagement.wordpress.com — "Measurable Quality Bars" (December 2017)

## Key Principles

- The goal is to identify proxies that are **easy to measure** — cheap quantitative measures of quality.
- You don't need all of them, but use at least half a dozen when defining a quality bar.
- People tend to get **over-focused on proxies** under pressure — using multiple proxies prevents poor short-term decisions. See [[Heuristic 3 - Use Multiple Proxies]].
- Some proxies can be measured **internally before you ship** — these give you a handle on quality before the product goes out the door.
- **Proxies are not quality** — they're things that seem to align well with something that matters to someone. See [[Heuristic 4 - Proxies Are Not Quality]].

## Proxies by Quality Area

### Function (set and that it works)

Relates to: [[Functional Correctness]]

- (External) Functional issues (number and severity) raised by customers
- (Internal) Functional issues (number and severity) raised by ST or solution teams
- (External) % of shipped enhancements with follow-on enhancement requests / complaints that the wrong thing was delivered

### Simplicity / Complexity / Extensibility

Relates to: [[Maintainability]], [[Extensibility]]

- (External/Internal) Average elapsed time from issue raised to fix
- (External/Internal) Average number of fix attempts per bug (% of the time that a fix resolves the issue)
- (Internal) Average number of dead-on-arrival entries into ST — or — Average number of solution team acceptance tests failing when product team SLA tests pass
- (Internal) Average sprint velocity for each team (sprint velocity is also about the people, not just the product, but they're not completely disentanglable)

### Diagnostics

Relates to: [[Diagnosability]], [[Debuggability]]

- (Internal/External) Average number of repros required before fix is understood (customers/support, solution/product, within product team)
- (Internal) Average number of misdiagnosed issues going from solution or ST team to wrong product or dev team

### Documentation

Relates to: [[Documentation]]

- (Internal/External) Number of solution failures (solution teams and customer teams) resolved as misconfiguration
- (Internal/External) Average time to bring up new system/solution
- (Internal/External) Number of issues resolved with docs fix

### Integration / Installation / Upgrade

Relates to: [[Deployability]], [[Interoperability]]

- (External) Elapsed time from new release to number of customers deployed
- (Internal/External) Average time to install a new system / product / solution
- (Internal/External) Average downtime when upgrading a system / product / solution, including how impacting the downtime is

### Supportability / Cost to Us

Relates to: [[Cost Efficiency]]

- (External) Cost to support per £revenue (resource days)

### Wow Factor / Sexiness

Relates to: [[Usability]]

- (External) Customer ratings
- (External) User install/uninstall rates

## Caveat

While measuring a bunch of these is clearly better than just measuring bugs or field defects, there's even more we could do in terms of thinking about, talking about, and understanding quality without just using numbers.

## How It Connects

- [[Proxies]] — overview of proxy concepts
- [[Proxies - Dev Tooling]] — the complementary set from dev tools
- [[Heuristic 5 - Trend Lines Beat Absolute Numbers]] — these are all better tracked as trends
- [[Heuristic 6 - Know Your Proxy's Blind Spots]] — understand what each doesn't tell you

## Tags

#proxies #blog-post
