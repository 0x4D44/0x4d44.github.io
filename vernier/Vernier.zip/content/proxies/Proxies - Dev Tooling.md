# Proxies — Dev Tooling and Automation

These are standard development tools and automated measurements that can serve as quality proxies. For each, we identify what [[Quality Attributes|quality attribute(s)]] it's a proxy for, and how strong a signal it provides.

## Key Principles

1. **Most of these are better as trend lines than absolute numbers.** See [[Heuristic 5 - Trend Lines Beat Absolute Numbers]].
2. **Many of these are easy to game.** Use several that triangulate. See [[Heuristic 3 - Use Multiple Proxies]], [[Heuristic 7 - Proxies Are Gameable]].
3. **Each proxy has blind spots.** Know what it doesn't tell you. See [[Heuristic 6 - Know Your Proxy's Blind Spots]].
4. **Agents will game these faster than humans.** Apply the malicious compliance check. See [[Heuristic 8 - Malicious Compliance Check]].

---

## Test-Related Proxies

### Unit test pass rate
- **Proxy for:** [[Functional Correctness]], [[Resilience]] (regression prevention)
- **Strength:** Moderate — tells you checked things still work, says nothing about unchecked things

### Unit test code coverage
- **Proxy for:** [[Testability]], [[Maintainability]], [[Functional Correctness]]
- **Strength:** Weak to moderate — high coverage doesn't mean good tests, but very low coverage is a reliable signal of risk. Easy to game.
- **Important:** Code coverage is not one thing. See [[Code Coverage Levels]] for the breakdown:
  - **Line coverage** — was this line executed? (weakest signal)
  - **Branch coverage** — was each branch of each decision taken? (stronger)
  - **MC/DC** — does each condition independently affect the outcome? (strongest, used in safety-critical/aviation)
- An agent told to "increase coverage" will default to the cheapest version unless you specify which level.

### Functional / integration test code coverage
- **Proxy for:** [[Functional Correctness]], [[Interoperability]], [[Reliability]]
- **Strength:** Moderate — more meaningful than UT coverage because it exercises real paths, but still gameable

### End-to-end test pass rate
- **Proxy for:** [[Functional Correctness]], [[Usability]] (indirectly), [[Interoperability]]
- **Strength:** Moderate to strong — closest to real user behaviour, but brittle and slow

### Mutation testing survival rate
- **Proxy for:** [[Testability]], [[Functional Correctness]] (quality of your tests specifically)
- **Strength:** Strong — directly measures whether your tests actually catch changes. Expensive to run.

### Flaky test rate
- **Proxy for:** [[Testability]], [[Reliability]], [[Maintainability]]
- **Strength:** Moderate — flaky tests erode confidence in the whole suite and hide real failures

### Test execution time
- **Proxy for:** [[Testability]], [[Maintainability]] (of the test suite itself)
- **Strength:** Weak to moderate — slow tests discourage running them, which degrades feedback loops

---

## Code Quality Proxies

### Compiler warnings count
- **Proxy for:** [[Maintainability]], [[Functional Correctness]], [[Security]]
- **Strength:** Moderate — warnings often flag real risks. Zero warnings is a good hygiene signal.

### Linting violations count
- **Proxy for:** [[Maintainability]], [[Ramp-Up-Ability]] (readability), consistency
- **Strength:** Weak to moderate — mostly about code style, but consistent style genuinely helps maintainability

### Static analysis findings (e.g. SonarQube, Coverity)
- **Proxy for:** [[Security]], [[Functional Correctness]], [[Maintainability]], [[Reliability]]
- **Strength:** Moderate to strong — catches real bug classes. False positive rate can erode trust.

### Cyclomatic complexity
- **Proxy for:** [[Maintainability]], [[Testability]], [[Debuggability]], [[Ramp-Up-Ability]]
- **Strength:** Moderate — high complexity reliably correlates with hard-to-understand, hard-to-test code.

### Code duplication percentage
- **Proxy for:** [[Maintainability]], [[Extensibility]]
- **Strength:** Moderate — duplication is a reliable signal of future maintenance pain

### TODO/FIXME/HACK count in codebase
- **Proxy for:** [[Maintainability]], technical debt level
- **Strength:** Weak — depends on team culture. But a rising count is a signal.

### Type safety / type coverage
- **Proxy for:** [[Functional Correctness]], [[Maintainability]], [[Ramp-Up-Ability]]
- **Strength:** Moderate — types catch a class of bugs at compile time and serve as documentation

---

## Dependency Proxies

### Dependency count / dependency freshness
- **Proxy for:** [[Security]], [[Maintainability]], [[Portability]], [[Deployability]]
- **Strength:** Moderate — stale dependencies are a real security and compatibility risk.

### Dependency vulnerability scan (e.g. Dependabot, Snyk)
- **Proxy for:** [[Security]]
- **Strength:** Strong for known vulnerabilities — directly flags CVEs. Says nothing about unknown vulnerabilities or your own code.

---

## Build and Deployment Proxies

### Build time
- **Proxy for:** [[Maintainability]], [[Deployability]], developer productivity
- **Strength:** Weak to moderate — long builds slow feedback loops.

### Build success rate
- **Proxy for:** [[Maintainability]], reliability of the development process
- **Strength:** Moderate — frequent broken builds signal integration problems or fragile architecture

### Deployment frequency
- **Proxy for:** [[Deployability]], [[Extensibility]], [[Operability]]
- **Strength:** Moderate — teams that deploy often tend to have better tooling and smaller, safer changes.

### Deployment failure rate / rollback rate
- **Proxy for:** [[Deployability]], [[Reliability]], [[Testability]]
- **Strength:** Strong — directly measures whether your release process works

### Change failure rate (DORA metric)
- **Proxy for:** [[Functional Correctness]], [[Reliability]], [[Testability]]
- **Strength:** Strong — what percentage of changes cause a failure in production

### Lead time for changes (DORA metric)
- **Proxy for:** [[Extensibility]], [[Deployability]], [[Maintainability]]
- **Strength:** Moderate — slow lead time often signals process or architecture problems.

### Mean time to recover (MTTR) from deployment failure
- **Proxy for:** [[Resilience]], [[Recoverability]], [[Operability]], [[Diagnosability]]
- **Strength:** Strong — measures your ability to get back to good when things go wrong

---

## Runtime Proxies

### Code churn (rate of change in files/modules)
- **Proxy for:** [[Maintainability]], [[Reliability]], risk identification
- **Strength:** Moderate — high churn areas are where bugs cluster. Useful as a risk heatmap.

### API response time (in test environments)
- **Proxy for:** [[Performance]], [[Usability]]
- **Strength:** Moderate to strong — direct measurement, but test environments may not reflect production

### Error rate in logs (test/staging environments)
- **Proxy for:** [[Reliability]], [[Functional Correctness]], [[Diagnosability]]
- **Strength:** Moderate — noisy logs hide real signals, but a climbing error rate is always worth investigating

---

## Documentation Proxies

### Documentation coverage (e.g. public API doc coverage)
- **Proxy for:** [[Documentation]], [[Ramp-Up-Ability]], [[Interoperability]]
- **Strength:** Weak to moderate — existence of docs doesn't mean quality docs, but absence is a clear signal

## How It Connects

- [[Proxies]] — overview of proxy concepts and principles
- [[Proxies - Blog Post]] — the complementary set from the blog post
- [[Proxy Blind Spots and Gaming Risks]] — deep dive on gaming risks for each proxy

## Tags

#proxies #dev-tooling
