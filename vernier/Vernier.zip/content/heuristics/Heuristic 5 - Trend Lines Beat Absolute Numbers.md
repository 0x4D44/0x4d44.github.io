# Heuristic 5 - Trend Lines Beat Absolute Numbers

> **A single measurement tells you almost nothing. A coverage number of 73% is meaningless on its own. Coverage dropping from 73% to 65% over three sprints tells you something real. Track direction of change over time.**

Absolute numbers are deceptive. A code coverage of 73% could be excellent for a legacy system or terrible for a new service. A deployment frequency of once per week could indicate healthy release cadence or organizational bottleneck depending on context. A bug escape rate of 2% means nothing without a baseline.

But trends are information-rich. Declining coverage suggests you're adding code without adding tests. Increasing bug escape rate suggests testing or release discipline is slipping. A plateauing metric might indicate you've hit natural limits. The direction of change, sustained over time, tells you whether decisions you've made are actually working.

## Where This Applies

- [[Proxies]] — reading signals from metrics over time
- [[Proxies - Dev Tooling]] — tracking code quality, coverage, and testing metrics
- [[Quality Dashboards]] — how to design meaningful quality dashboards
- [[Risk Trends]] — detecting emerging problems before they become acute
- [[Retrospectives]] — using trends to evaluate whether process changes are working

## Related Heuristics

- [[Heuristic 4 - Proxies Are Not Quality]] — understand the signal you're reading
- [[Heuristic 6 - Know Your Proxy's Blind Spots]] — trends in a blind spot are still blind
- [[Heuristic 3 - Use Multiple Proxies]] — multiple trend lines together are more informative

## Tags

#heuristic #proxies
