# Heuristic 2 - Sub-Group Heuristic for Stakeholders

> **For every stakeholder category, ask whether there are sub-groups who care about different things or who you care about serving to different levels.**

This is the stakeholder-specific application of the sub-group heuristic. The category "end users" sounds simple until you break it down: retail customers, business customers, internal staff, support staff using the system to help others. Each group has different priorities. A bug that enrages a business customer might be acceptable to a casual user. A UI quirk that slows power users down doesn't affect occasional users at all.

The discipline of asking "what are the true sub-groups here?" is essential for building software that actually serves the people you're building for, rather than an imagined average.

## Where This Applies

- [[Stakeholders]] — discovering hidden stakeholder groups
- [[Quality Attributes]] — different groups prioritize different quality attributes
- [[Requirements]] — stakeholder sub-groups have different feature needs
- [[User Research]] — understanding what each sub-group actually values
- [[Testing]] — test coverage and test strategy may need to differ by stakeholder group

## Related Heuristics

- [[Heuristic 1 - The Sub-Group Heuristic]] — general principle this applies to stakeholders
- [[Heuristic 10 - Any Stakeholder Could Be an Agent]] — some stakeholder sub-groups might be automated

## Tags

#heuristic #general-thinking #stakeholders
