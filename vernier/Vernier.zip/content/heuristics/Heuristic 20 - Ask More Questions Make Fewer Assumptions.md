# Heuristic 20 - Ask More Questions Make Fewer Assumptions

> **When in doubt, ask. This applies to humans and agents alike but needs to be explicitly designed into agent workflows because agents default to proceeding confidently rather than pausing to clarify. A good agent workflow should have defined points where it stops and asks rather than guesses.**

Humans, when uncertain, often ask for clarification. It's the safe approach. But humans also sometimes just proceed on their best guess because asking takes time and they feel they should be able to figure it out. Agents do this more aggressively because they don't have the social friction that makes asking uncomfortable.

The right response to uncertainty is usually to ask. "Is this what you meant?" "Should I assume X or Y?" "What happens if Z?" These questions are cheap (literally, for agents—they take milliseconds) and they prevent wrong assumptions from cascading.

Design agent workflows with explicit pause points where the agent asks clarifying questions rather than guessing. This applies especially to complex or ambiguous tasks. The output of a "ask clarifying questions" step should be part of the task record, creating better documentation for the next reader.

## Where This Applies

- [[Assumption Management]] — preventing wrong assumptions through questioning
- [[Agent Workflows]] — designing pause and ask points
- [[Tacit Knowledge and Agents]] — avoiding confidence gaps
- [[Communication]] — how to structure agent-human interaction
- [[Quality Processes]] — validation through questioning

## Related Heuristics

- [[Heuristic 19 - Explicitly Check and Record Assumptions]] — assumptions are the other side of questions
- [[Heuristic 21 - State Confidence Levels Explicitly]] — low confidence should trigger questions
- [[Heuristic 14 - Agent Output Needs Different Review]] — review should ask clarifying questions too
- [[Heuristic 15 - Tacit Knowledge Is Invisible Debt]] — asking surfaces hidden knowledge

## Tags

#heuristic #knowledge-management #agents
