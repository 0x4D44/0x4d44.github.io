# Heuristic 9 - Don't Import Old-World Costs

> **Agents have radically different cost/time/error profiles than humans. Challenge any reasoning that assumes human constraints.**

Many testing and quality decisions are made based on the assumption that time and resources are scarce. Not worth writing tests for edge cases—a human would spend an hour on it and the system doesn't fail often enough to justify it. Not worth checking all variations—that's expensive manual testing. Not worth exploring every code path—time isn't free and you have deadlines.

But agents operate under entirely different constraints. An agent can test thousands of edge cases in seconds. It doesn't get tired at midnight or bored with repetitive tasks. It can check all variations in parallel. It can explore every code path and record what it finds. The reasoning that was sound for humans—"not worth the effort"—may be completely backwards for agents.

This doesn't mean agents should test everything mindlessly. But it does mean you should challenge inherited assumptions about scope and thoroughness. The cost/benefit calculation has changed.

## Where This Applies

- [[Economics of Testing]] — how cost assumptions shape testing decisions
- [[Testing Strategy]] — rebuilding testing strategy for agent capabilities
- [[Tacit Knowledge and Agents]] — assumptions about what's expensive to document
- [[Agent Considerations]] — how agents change scope economics
- [[Risk Assessment]] — different risk tolerance with different cost structures

## Related Heuristics

- [[Heuristic 13 - Economics of Checking vs Investigating Shift with Agents]] — specific rebalancing of effort types
- [[Heuristic 11 - Agents Have Different Strengths and Weaknesses]] — understand where agent effort goes
- [[Heuristic 12 - Agents Don't Get Tired But Have Blind Spots]] — different capabilities and failure modes

## Tags

#heuristic #agents
