# Heuristic 6 - Know Your Proxy's Blind Spots

> **Every proxy has blind spots. Understanding the blind spots is as important as reading the signal. High test coverage doesn't tell you whether the tests are good. Low bug count doesn't tell you whether anyone's looking.**

Test coverage measures lines executed, not test quality. High coverage can hide shallow, assertion-free tests or tests written after code in ways that just verify existing behavior. A bug count is invisible to issues that nobody's reported yet—which could mean the system is genuinely good, or could mean testing is cursory. Performance metrics don't capture user experience in slow networks. Security scanning doesn't find the business logic vulnerabilities.

Understanding blind spots isn't pessimism; it's realism. It tells you where to be skeptical, where to add complementary proxies, and where to invest human investigation. A proxy with known blind spots is useful; a proxy whose blind spots you don't understand is dangerous.

## Where This Applies

- [[Proxies]] — inherent limitations in measurement
- [[Proxy Blind Spots and Gaming Risks]] — common blind spots in code quality and testing proxies
- [[Testing]] — test coverage's limits
- [[Code Quality]] — static analysis tool limitations
- [[Risk Assessment]] — where metrics fail to see real problems

## Related Heuristics

- [[Heuristic 3 - Use Multiple Proxies]] — complementary proxies can fill each other's blind spots
- [[Heuristic 4 - Proxies Are Not Quality]] — blind spots are why proxies aren't the thing itself
- [[Heuristic 7 - Proxies Are Gameable]] — blind spots are where gaming happens
- [[Heuristic 8 - Malicious Compliance Check]] — imagine exploitation of the blind spot

## Tags

#heuristic #proxies
