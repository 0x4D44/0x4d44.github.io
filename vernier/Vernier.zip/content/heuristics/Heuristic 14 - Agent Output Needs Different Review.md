# Heuristic 14 - Agent Output Needs Different Review

> **Humans make inconsistent, visible mistakes. Agents make consistent, plausible-looking mistakes. Review processes designed for human error patterns will miss agent error patterns.**

When a human makes a mistake, it's often visible as inconsistency or a clear violation of stated rules. A typo breaks formatting. A logical error contradicts something stated earlier. Fatigue leads to shortcuts. These mistakes are detectable by review processes designed to find them.

Agents make different mistakes: they're internally consistent but wrong about context or assumptions. They follow instructions precisely but misunderstand what was intended. They produce plausible-looking results that satisfy the literal request but miss the point. These mistakes are harder to spot because they look coherent. An agent can write an entire code file with no syntax errors, consistent naming, good structure, and still miss a fundamental requirement because it misunderstood the context.

Review processes for agent output need to focus on: Does this actually solve the problem? Are the assumptions correct? Does this match our context? Is this internally self-consistent in a way that hides a misunderstanding? These are different questions from "did the human make a typo or logic error?"

## Where This Applies

- [[Testing]] — reviewing agent-generated tests
- [[Code Review]] — reviewing agent-generated code
- [[Agent Considerations]] — review processes for agent work
- [[Quality Processes]] — adapted review procedures
- [[Tacit Knowledge and Agents]] — assumption checking in review

## Related Heuristics

- [[Heuristic 12 - Agents Don't Get Tired But Have Blind Spots]] — consistent mistakes vs inconsistent ones
- [[Heuristic 19 - Explicitly Check and Record Assumptions]] — what to look for in review
- [[Heuristic 20 - Ask More Questions Make Fewer Assumptions]] — review should ask clarifying questions

## Tags

#heuristic #agents
