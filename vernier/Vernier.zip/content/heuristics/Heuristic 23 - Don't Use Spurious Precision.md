# Heuristic 23 - Don't Use Spurious Precision

> **Saying '87% confident' implies a level of calibration you almost certainly don't have. Use honest, coarse-grained levels — high/medium/low, or 'I've checked this thoroughly' vs 'I've glanced at it' vs 'I'm guessing.' False precision is worse than vagueness because it discourages further investigation.**

The number "87" sounds scientific. It sounds like it's based on data, on calculation, on calibration. But if you invented it on the spot, it's not. It's false precision. False precision is dangerous because it discourages further investigation. A reader seeing "87% confident" will trust it more than they trust "I've glanced at this."

Use honest, coarse-grained levels: High/Medium/Low. Or describe the basis: "I've checked this thoroughly" vs "I've glanced at it" vs "I'm guessing." These are honest about what you know. They're also actionable: low confidence or "I'm guessing" clearly triggers "someone should double-check this."

This applies especially to agents because agents can generate false-precision numbers confidently. An agent asked "how confident are you?" might produce "73%" because it sounds right, and that will be treated as meaningful data when it's actually meaningless.

## Where This Applies

- [[Confidence and Uncertainty Communication]] — expressing confidence honestly
- [[Agent Workflows]] — preventing false precision in output
- [[Metrics]] — when precision is real vs spurious
- [[Quality Processes]] — using confidence levels to direct work
- [[Decision-Making]] — honest uncertainty in decisions

## Related Heuristics

- [[Heuristic 21 - State Confidence Levels Explicitly]] — state confidence but do it honestly
- [[Heuristic 22 - Calibrate Your Confidence in Your Confidence]] — understand your confidence level
- [[Heuristic 4 - Proxies Are Not Quality]] — spurious precision in metrics
- [[Heuristic 5 - Trend Lines Beat Absolute Numbers]] — absolute numbers without context are misleading

## Tags

#heuristic #confidence
