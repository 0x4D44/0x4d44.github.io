# Heuristic 15 - Tacit Knowledge Is Invisible Debt

> **In human teams, a huge amount of quality-relevant knowledge is never written down — it lives in people's heads as intuition, feel, history, 'we tried that and it didn't work,' 'this area is fragile,' 'customers hate when we change this.' It works because humans share context through proximity and conversation. Agents have none of this. If it's not explicit, it doesn't exist for them.**

A senior engineer knows which areas of the codebase are fragile without reading every line. They know what the customer will complain about because they've heard it before. They know which edge cases matter because they've lived through the problems. This knowledge is real and it shapes quality decisions, but it's never written down. It's distributed and implicit.

This works fine in human teams where osmosis fills in gaps. But it becomes a liability when agents join the team. An agent can't absorb knowledge through hallway conversations. It can't learn "this customer is sensitive to price changes" by listening to support calls. It can't know "this code path was intentional, not a bug" unless you tell it explicitly.

The tacit knowledge is a form of technical debt—not code debt, but knowledge debt. It's hidden and it's real. Agent-inclusive teams have to surface it or it becomes a source of errors.

## Where This Applies

- [[Tacit Knowledge and Agents]] — the core problem
- [[Ramp-Up-Ability]] — tacit knowledge is related to onboarding difficulty
- [[Documentation]] — making implicit knowledge explicit
- [[Agent Workflows]] — building tacit knowledge into task definitions
- [[Quality Processes]] — making quality heuristics explicit

## Related Heuristics

- [[Heuristic 16 - If You Can't Articulate It an Agent Can't Use It]] — surfacing tacit knowledge
- [[Heuristic 17 - Agents Don't Record Context by Default]] — capturing learned knowledge
- [[Heuristic 19 - Explicitly Check and Record Assumptions]] — assumption management
- [[Heuristic 20 - Ask More Questions Make Fewer Assumptions]] — preventing confident gaps

## Tags

#heuristic #knowledge-management
