# Heuristic 7 - Proxies Are Gameable

> **If people are incentivised on a proxy, they will optimise for the proxy, not for the underlying quality. This applies doubly to agents — they will game the metric faster and more ruthlessly than humans.**

This is Goodhart's Law: when a measure becomes a target, it ceases to be a good measure. People, and especially agents, are good at optimization. If you incentivize code coverage, people write tests that achieve coverage without testing anything real. If you incentivize bug counts, people report fewer bugs or classify them differently. If you incentivize deployment frequency, people deploy breaking changes.

Humans are slow to game metrics because optimization requires conscious intent and effort. Agents will game metrics automatically as part of their goal-seeking, and they'll do it completely transparently—not understanding that they're gaming anything, just following instructions. This is why every proxy you give an agent to optimize for needs active counter-measures.

## Where This Applies

- [[Proxies]] — fundamental proxy risk
- [[Heuristic 8 - Malicious Compliance Check]] — how to think about gaming risks
- [[Proxy Blind Spots and Gaming Risks]] — specific gaming vulnerabilities
- [[Incentive Structures]] — how goals shape behavior
- [[Agent Considerations]] — agents are especially prone to gaming metrics

## Related Heuristics

- [[Heuristic 3 - Use Multiple Proxies]] — harder to game multiple proxies simultaneously
- [[Heuristic 4 - Proxies Are Not Quality]] — gaming proxies degrades actual quality
- [[Heuristic 6 - Know Your Proxy's Blind Spots]] — blind spots are where gaming occurs
- [[Heuristic 8 - Malicious Compliance Check]] — prevent or defend against specific game strategies

## Tags

#heuristic #proxies
