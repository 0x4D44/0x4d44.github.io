# Heuristic 18 - Design Agent Workflows as Knowledge-Accumulating Systems

> **The value of an agent doing a task isn't just the task output — it's also what was learned. If you throw that away, you're paying the discovery cost repeatedly.**

Running an agent task costs effort and time. If the task involved investigation (exploring a codebase, finding edge cases, discovering why something failed), you've paid a discovery cost. If the output is just "here's the test I wrote" or "here's the bug I found," you've thrown away the work of discovering that. The next time you need that knowledge, you pay the discovery cost again.

But if the task output includes what was learned—the codebase structure, the edge cases discovered, the assumptions validated, the code paths explored—then the discovery cost was paid once and the knowledge is reusable. Each task teaches the system (and future workers) something.

Design agent workflows as knowledge-accumulating systems. Make recording and organizing what was learned a first-class part of the output. Store it where it can be found and used. Use the patterns you find to improve future work.

## Where This Applies

- [[Agent Workflows]] — workflow design for learning
- [[Agent Recording Protocols]] — capturing and organizing learned knowledge
- [[Tacit Knowledge and Agents]] — making tacit knowledge explicit and permanent
- [[Documentation]] — knowledge as artifact
- [[Quality Processes]] — improving through accumulated learning

## Related Heuristics

- [[Heuristic 15 - Tacit Knowledge Is Invisible Debt]] — value of explicit knowledge
- [[Heuristic 17 - Agents Don't Record Context by Default]] — need to design recording in
- [[Heuristic 19 - Explicitly Check and Record Assumptions]] — what to record
- [[Heuristic 20 - Ask More Questions Make Fewer Assumptions]] — learning through questioning

## Tags

#heuristic #knowledge-management #agents
