# Heuristic 10 - Any Stakeholder Could Be an Agent

> **For every group in your stakeholder list, consider whether some or all of them might be agents rather than humans.**

Stakeholder analysis has traditionally focused on humans. But as agent capabilities expand, any stakeholder could be an agent. An agent consuming your API doesn't care about beautiful UI but cares intensely about consistency, predictability, and documentation quality. An agent scheduling meetings wants reliable calendar integration and unambiguous time representations. An agent analyzing data wants clean, structured output that's easy to parse.

This isn't speculative. Some stakeholders already are agents: the build pipeline that consumes your API, the payment processor that needs exact output format. The question is whether you've thought about agent stakeholders explicitly, and whether your quality bar for "agent-relevant" attributes is as high as for human ones.

## Where This Applies

- [[Stakeholders]] — stakeholder analysis including agent stakeholders
- [[Quality Attributes]] — different quality attributes matter to agent stakeholders
- [[Quality]] — what quality means when stakeholders include agents
- [[API Design]] — agent stakeholders have different usability needs than humans
- [[Agent Considerations]] — designing systems for agent consumption

## Related Heuristics

- [[Heuristic 2 - Sub-Group Heuristic for Stakeholders]] — agent stakeholders are a sub-group with distinct needs
- [[Heuristic 11 - Agents Have Different Strengths and Weaknesses]] — agents prioritize different quality attributes
- [[Heuristic 16 - If You Can't Articulate It an Agent Can't Use It]] — agents need explicit, structured information

## Tags

#heuristic #agents #stakeholders
