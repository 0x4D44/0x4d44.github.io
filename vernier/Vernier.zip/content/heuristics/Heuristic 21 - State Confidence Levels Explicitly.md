# Heuristic 21 - State Confidence Levels Explicitly

> **Don't just state conclusions — state how confident you are. 'This module is working correctly' is very different from 'I'm fairly confident this module is working correctly for the main paths, but I haven't explored edge cases.' Applies to humans and agents, but agents especially tend to state things flatly without qualification.**

Unqualified statements are ambiguous. "The tests are good" could mean "I've exhaustively reviewed them and they're solid" or "I glanced at them and they look plausible." These are very different confidence levels and they should be communicated differently.

Agents are especially prone to stating things flatly because they don't have the natural hedging language that humans use. A human might say "I think the API is consistent" which signals uncertainty. An agent will say "The API is consistent" with the same confidence as "water is wet." Both need to be checked, but the human statement signals "check this" and the agent statement sounds certain.

Build confidence levels into agent output explicitly. Not just the conclusion, but "high confidence based on exhaustive check" or "low confidence based on quick sampling" or "medium confidence, here's what I checked and what I didn't."

## Where This Applies

- [[Confidence and Uncertainty Communication]] — expressing confidence clearly
- [[Agent Workflows]] — structuring outputs with confidence
- [[Tacit Knowledge and Agents]] — what confidence means
- [[Quality Processes]] — using confidence to direct review
- [[Testing]] — test adequacy and confidence

## Related Heuristics

- [[Heuristic 22 - Calibrate Your Confidence in Your Confidence]] — meta-confidence matters
- [[Heuristic 23 - Don't Use Spurious Precision]] — don't fake confidence with numbers
- [[Heuristic 19 - Explicitly Check and Record Assumptions]] — confidence depends on assumptions
- [[Heuristic 20 - Ask More Questions Make Fewer Assumptions]] — uncertainty should trigger questions

## Tags

#heuristic #confidence
