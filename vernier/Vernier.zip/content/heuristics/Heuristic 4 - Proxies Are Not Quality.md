# Heuristic 4 - Proxies Are Not Quality

> **Proxies are indirect signals that seem to align with something that matters to someone. Never confuse the proxy with the thing itself. A bug count is not quality. Test coverage is not quality.**

This is the cardinal rule of proxy thinking. Proxies are tools for approximating something harder to measure directly. They work because they correlate with what you actually care about—but correlation is not identity. A system can have low bug count because it's well-tested, or because nobody's testing. It can have high coverage because tests are thorough, or because they're plentiful but shallow.

The moment you start treating the proxy as the goal, you've lost sight of what you're actually trying to achieve. You optimize for the proxy, not for quality. This is why it's critical to understand what your proxies are actually measuring, what they might be missing, and why you chose them in the first place.

## Where This Applies

- [[Proxies]] — foundational principle
- [[Quality]] — quality is multi-faceted; proxies are incomplete signals
- [[Metrics]] — distinguishing measurement tools from actual outcomes
- [[Testing]] — test count is not testing adequacy
- [[Code Quality]] — lines of code, cyclomatic complexity, coverage are signals, not guarantees

## Related Heuristics

- [[Heuristic 3 - Use Multiple Proxies]] — multiple proxies compensate for individual proxy limitations
- [[Heuristic 5 - Trend Lines Beat Absolute Numbers]] — focus on signal, not the number itself
- [[Heuristic 6 - Know Your Proxy's Blind Spots]] — understand what each proxy can't see

## Tags

#heuristic #proxies
