# Heuristic 11 - Agents Have Different Strengths and Weaknesses

> **They're not just faster humans. They're better at some things and worse at others. Your testing strategy, quality definitions, and process design should account for this rather than just slotting agents into human-shaped holes.**

Agents excel at parallel exploration, exhaustive checking, consistency, and rapidly iterating through options. They're terrible at recognizing when something is "weird" or "off" in a way that doesn't match the problem statement. They miss implicit context. They fill gaps confidently rather than asking for clarification. They're consistent in their errors in ways humans aren't—if an agent has a blind spot, it will miss the same thing repeatedly.

Building quality processes that just use agents to do what humans did faster is wasting their strengths and inheriting their weaknesses. Instead, design testing and quality processes that leverage agent strengths—exhaustive checking, parallel exploration, consistency—while using human judgment where agents struggle: pattern recognition, context evaluation, judgment calls about trade-offs.

## Where This Applies

- [[Testing]] — restructuring test approach for agent strengths
- [[Testing Strategy]] — different strategies for agent vs human testing
- [[Tacit Knowledge and Agents]] — where agents struggle with implicit knowledge
- [[Agent Considerations]] — designing for agent capabilities
- [[Quality Processes]] — redesigning processes for mixed teams

## Related Heuristics

- [[Heuristic 12 - Agents Don't Get Tired But Have Blind Spots]] — different failure modes
- [[Heuristic 13 - Economics of Checking vs Investigating Shift with Agents]] — how effort should be rebalanced
- [[Heuristic 14 - Agent Output Needs Different Review]] — review processes for agent work

## Tags

#heuristic #agents
