# Heuristic 16 - If You Can't Articulate It an Agent Can't Use It

> **This is both a problem and an opportunity. The problem: agents will miss things that 'everyone just knows.' The opportunity: the discipline of making tacit knowledge explicit for agents also makes it explicit for new humans, which improves ramp-up-ability and reduces bus factor.**

If you ask an agent to test a feature and you only explain it verbally, the agent will test what you literally said. If you didn't mention that "customers hate it when this button is in a different place than last time," the agent won't test for it. If you didn't mention that "the API should be consistent with the v1 format even though v2 is cleaner," the agent won't check for consistency.

This seems like a problem—the agent is missing knowledge you don't have time to articulate. But it's also an opportunity. If you can't explain it to an agent, you haven't thought it through well enough. Making tacit knowledge explicit forces clarity. And once it's explicit, it benefits everyone: new humans who join the team, contractors, people across the organization who need to understand the system.

The discipline of "explaining this to an agent" is a quality discipline that improves your entire knowledge base.

## Where This Applies

- [[Tacit Knowledge and Agents]] — surfacing implicit knowledge
- [[Ramp-Up-Ability]] — explicit knowledge reduces onboarding time
- [[Documentation]] — discipline of clear documentation
- [[Agent Workflows]] — task design as knowledge capture
- [[Quality Standards]] — making quality criteria explicit

## Related Heuristics

- [[Heuristic 15 - Tacit Knowledge Is Invisible Debt]] — the underlying problem
- [[Heuristic 17 - Agents Don't Record Context by Default]] — capturing what agents learn
- [[Heuristic 19 - Explicitly Check and Record Assumptions]] — making assumptions explicit
- [[Heuristic 20 - Ask More Questions Make Fewer Assumptions]] — asking when knowledge is missing

## Tags

#heuristic #knowledge-management
