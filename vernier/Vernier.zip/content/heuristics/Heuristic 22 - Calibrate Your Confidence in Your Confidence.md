# Heuristic 22 - Calibrate Your Confidence in Your Confidence

> **Meta-confidence matters. 'I'm 90% sure' is meaningless if you have no basis for that number. Be honest about whether your confidence is well-founded (based on thorough investigation) or poorly-founded (based on a quick look and vibes). An agent that says '95% confident' based on shallow analysis is more dangerous than one that says 'low confidence, here's what I checked and what I didn't.'**

There's confidence and there's calibration. Saying you're "90% sure" implies a level of precision that you probably don't have. But more importantly, it doesn't tell the reader whether that confidence is based on thorough investigation or a gut feeling.

The question to ask yourself: "If I'm wrong, would I be surprised?" If you'd be shocked, that's high confidence. If you'd say "oh I guess I didn't check that part," that's low confidence, regardless of how sure you feel. Then make that distinction explicit.

For agents, this is critical because agents are naturally overconfident about things that sound consistent. An agent can be coherently wrong at high confidence. So the distinction between "I've checked this thoroughly and I'm confident" and "I'm somewhat confident based on limited investigation" is more important for agents than for humans.

## Where This Applies

- [[Confidence and Uncertainty Communication]] — honest confidence assessment
- [[Agent Workflows]] — structuring confidence assessment
- [[Tacit Knowledge and Agents]] — understanding agent limitations
- [[Quality Processes]] — using confidence to direct effort
- [[Testing]] — test adequacy assessment

## Related Heuristics

- [[Heuristic 21 - State Confidence Levels Explicitly]] — stating confidence is necessary
- [[Heuristic 23 - Don't Use Spurious Precision]] — avoid false precision
- [[Heuristic 19 - Explicitly Check and Record Assumptions]] — confidence depends on what was checked
- [[Heuristic 14 - Agent Output Needs Different Review]] — review calibration to detect overconfidence

## Tags

#heuristic #confidence
