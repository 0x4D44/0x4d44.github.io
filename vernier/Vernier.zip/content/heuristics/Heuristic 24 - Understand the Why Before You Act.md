# Heuristic 24 - Understand the Why Before You Act

> **Before taking action, make sure you understand *why* — why this matters, why the stakeholder cares, why this is the priority. If you're not confident you understand the why, ask until you do. Only then act.**

This is a general principle that applies far beyond quality, but it's especially important in quality work because the entire field is contextual. The right answer always depends on context, and context is built from understanding "why."

A stakeholder says "we need faster response times." Without understanding why, you might optimise the wrong endpoint, or improve latency when the real problem is throughput, or hit a target number that satisfies no one because the underlying concern was something else entirely.

The discipline is straightforward:
1. Before acting, ask: do I understand why this matters?
2. Honestly assess your confidence in that understanding — see [[Heuristic 21 - State Confidence Levels Explicitly]].
3. If you're not confident, ask. Not "do a quick search and guess" — actually ask the person or people who know.
4. Only then act.

The cost of asking is almost always lower than the cost of confidently solving the wrong problem.

## Where This Applies

- [[Context]] — the full treatment of why context comes first
- [[Quality]] — quality is contextual; without the "why," you can't assess it
- [[Stakeholders]] — understanding stakeholders means understanding their motivations, not just their stated requirements
- [[Risk]] — risk assessment without context is just a list of scary things
- [[Testing]] — every test should be answering a question; if you don't know why you're testing something, stop and find out
- [[Proxies]] — a proxy without a clear "why are we measuring this?" is noise

## Old World / New World

This is one of the most critical heuristics for agents. Humans have social instincts that help them sense when they're missing context — something feels off, a request seems odd, and they ask a follow-up question. Agents don't have this instinct. They proceed confidently on whatever information they have, filling gaps with plausible-sounding assumptions.

Agent workflows need explicit "do I understand the why?" checkpoints. Not just "do I have enough information to complete the task?" — an agent can always fabricate enough to proceed — but "do I understand *why* this task matters and what good looks like?"

## Related Heuristics

- [[Heuristic 19 - Explicitly Check and Record Assumptions]] — assumptions are often missing "why"
- [[Heuristic 20 - Ask More Questions Make Fewer Assumptions]] — the mechanism for getting the why
- [[Heuristic 21 - State Confidence Levels Explicitly]] — be honest about whether you understand the why

## Tags

#heuristic #general-thinking #agents
