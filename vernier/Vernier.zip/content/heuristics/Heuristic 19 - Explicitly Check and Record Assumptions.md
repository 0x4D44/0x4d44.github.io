# Heuristic 19 - Explicitly Check and Record Assumptions

> **Agents are much worse than humans at recognising when they're making assumptions — they fill gaps confidently and silently. Humans do this too, but agents do it more aggressively. Build in explicit 'what am I assuming here?' checkpoints into agent workflows, and require assumptions to be recorded alongside decisions and observations.**

Both humans and agents fill gaps when information is missing. But humans usually do it reluctantly and with visible uncertainty. "I'm not sure what this means, so I'm assuming..." Agents do it confidently and without hesitation. An agent will assume an API behavior that makes sense based on the name, implement code based on that assumption, and never mention that it guessed.

This is especially dangerous because assumption + silence = gap in knowledge. If the assumption is wrong, the gap will cause problems later and nobody will understand why because the assumption was never recorded.

Mitigate this by making assumptions explicit checkpoints in agent workflows. Require agents to list assumptions before proceeding. Require them to validate assumptions against actual data when possible. Require them to record assumptions alongside their conclusions so that future readers (human or agent) understand what was taken as given.

## Where This Applies

- [[Tacit Knowledge and Agents]] — assumption management
- [[Assumption Management]] — recording and validating assumptions
- [[Agent Workflows]] — designing checkpoint into workflows
- [[Agent Recording Protocols]] — what to capture
- [[Quality Processes]] — preventing gap-based errors

## Related Heuristics

- [[Heuristic 15 - Tacit Knowledge Is Invisible Debt]] — unrecorded assumptions are hidden debt
- [[Heuristic 20 - Ask More Questions Make Fewer Assumptions]] — asking as an alternative to assuming
- [[Heuristic 17 - Agents Don't Record Context by Default]] — recording what was assumed
- [[Heuristic 21 - State Confidence Levels Explicitly]] — confidence should reflect assumption confidence

## Tags

#heuristic #knowledge-management #agents
