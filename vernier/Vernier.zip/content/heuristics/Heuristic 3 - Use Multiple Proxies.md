# Heuristic 3 - Use Multiple Proxies

> **Over-focusing on a single proxy encourages gaming and short-term decisions. Triangulate with several proxies that measure different aspects of quality to prevent making poor decisions while thinking you're not affecting quality.**

If you manage a system by a single metric, the system will be optimized for that metric, not for the underlying quality. High code coverage can hide brittle tests. Low bug count can hide that nobody's testing. Deployment frequency can reward reckless releases. A single proxy is a tempting target for gaming.

Triangulation with multiple proxies is cheaper and easier than measuring quality directly, and it's more resilient to single-point failures. Combine a coverage number with test execution time and bug escape rate. Combine deployment frequency with change failure rate and mean time to recovery. Let the proxies talk to each other; disagreement between them is often where the real insight lives.

## Where This Applies

- [[Proxies]] — fundamental principle of proxy design
- [[Proxies - Blog Post]] — using proxies responsibly
- [[Proxies - Dev Tooling]] — applying to code quality and testing metrics
- [[Quality Attributes]] — multiple quality dimensions need multiple measurements
- [[Risk]] — coverage is only one indicator of testing adequacy

## Related Heuristics

- [[Heuristic 4 - Proxies Are Not Quality]] — remember what you're actually measuring
- [[Heuristic 5 - Trend Lines Beat Absolute Numbers]] — single snapshots are unreliable
- [[Heuristic 6 - Know Your Proxy's Blind Spots]] — understand where each proxy fails
- [[Heuristic 7 - Proxies Are Gameable]] — single proxies invite gaming

## Tags

#heuristic #proxies
