# Heuristic 13 - Economics of Checking vs Investigating Shift with Agents

> **Checking (mechanical verification) becomes nearly free with agents. Investigation (creative exploration) is where human and agent effort should be rebalanced. Don't spend human time on what agents can check.**

In human-centric testing, resources are scarce and must be allocated. You can't check every variation, so you sample. You can't run every test permutation, so you use heuristics. You can't read every line of code, so you focus on risk areas. This made sense because human time was the bottleneck.

With agents, the bottleneck shifts. An agent can check every variation, run every test, read every line, verify every assumption. Checking is nearly free. What's expensive is deciding what to check—deciding which investigation is worth doing, understanding what failures mean, generating good hypotheses about where problems might hide, thinking creatively about edge cases.

The rebalancing is to use agents for exhaustive checking and reserve human time for investigation—figuring out what matters, designing creative tests, making judgment calls about trade-offs, investigating surprising results. This is more efficient and better uses the strengths of each.

## Where This Applies

- [[Economics of Testing]] — how cost structures change with agents
- [[Testing Strategy]] — rebalancing human and agent effort
- [[Agent Considerations]] — allocating work between humans and agents
- [[Quality Processes]] — where to focus human vs agent resources
- [[Risk Assessment]] — investigation effort for high-risk areas

## Related Heuristics

- [[Heuristic 9 - Don't Import Old-World Costs]] — challenge assumptions about what's expensive
- [[Heuristic 11 - Agents Have Different Strengths and Weaknesses]] — leveraging each strength
- [[Heuristic 13 - Economics of Checking vs Investigating Shift with Agents]] — specific rebalancing

## Tags

#heuristic #agents
