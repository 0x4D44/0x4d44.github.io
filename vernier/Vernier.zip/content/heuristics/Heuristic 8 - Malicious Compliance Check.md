# Heuristic 8 - Malicious Compliance Check

> **For every proxy you give an agent to optimise, ask 'what would a malicious compliance version of improving this look like?' and guard against it.**

Agents follow instructions well. If you tell an agent to increase code coverage, it will increase code coverage. It might do this by writing tests that touch every line without actually asserting anything. It might write code specifically to be tested, then tests for that code. It might refactor complex logic into simple logic just to make coverage easier. All of these are technically increased coverage and all of them are malicious compliance—achieving the literal goal while undermining the actual intent.

The discipline is to imagine the worst-case version of achieving your proxy and then design guard-rails against it. If the proxy is coverage, add requirements about test quality or assertion density. If it's deployment frequency, add constraints about test passage or change failure rate. If it's issue resolution time, pair it with issue quality metrics. Multiple proxies that pull in different directions are harder to game.

## Where This Applies

- [[Proxies]] — designing proxy-based systems for agents
- [[Proxies - Dev Tooling]] — applying to code quality automation
- [[Agent Considerations]] — how agents optimize metrics
- [[Proxy Blind Spots and Gaming Risks]] — specific gaming vulnerabilities and defenses
- [[Agent Workflows]] — instructions that prevent unintended optimization

## Related Heuristics

- [[Heuristic 7 - Proxies Are Gameable]] — why you need to worry about gaming
- [[Heuristic 3 - Use Multiple Proxies]] — multiple proxies make gaming harder
- [[Heuristic 6 - Know Your Proxy's Blind Spots]] — blind spots are where gaming happens

## Tags

#heuristic #proxies #agents
