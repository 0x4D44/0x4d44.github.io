# Heuristic 1 - The Sub-Group Heuristic

> **Whenever you're looking at a category of anything, actively ask: are there meaningfully different sub-groups here that need to be thought about separately?**

This heuristic applies across quality, testing, and requirements thinking. A category that seems homogeneous often breaks down when you look closely. "Users" fragments into power users and casual users, internal versus external, technical versus non-technical. "Bugs" splits into functionality bugs, performance issues, usability glitches, and data corruption. Each sub-group may have different risk profiles, different testing needs, and different quality thresholds.

The sub-group heuristic prevents you from optimizing for an average that doesn't exist. It also prevents you from missing critical blind spots—the edge case that matters only to one sub-group, or the requirement that only specific stakeholders care about.

## Where This Applies

- [[Stakeholders]] — different user groups need different things
- [[Quality Attributes]] — different aspects of quality matter to different people
- [[Risk]] — different risk areas need different investigation depth
- [[Testing Strategy]] — different test approaches may apply to different parts of the system
- [[Environments]] — development, staging, and production have different constraints
- [[Market Segments]] — different customer cohorts may care about different things

## Related Heuristics

- [[Heuristic 2 - Sub-Group Heuristic for Stakeholders]] — specific application to stakeholder groups
- [[Heuristic 3 - Use Multiple Proxies]] — different sub-groups may need different measurements

## Tags

#heuristic #general-thinking
