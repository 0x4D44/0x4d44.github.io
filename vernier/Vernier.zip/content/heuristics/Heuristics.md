# Heuristics

These are thinking tools, not rules. Each one is a prompt to think about something you might otherwise miss. They apply across the knowledge base — in specific contexts, the relevant heuristics are linked from the pages where they matter most.

## General Thinking

- [[Heuristic 1 - The Sub-Group Heuristic]] — Whenever you're looking at a category, ask: are there meaningfully different sub-groups?
- [[Heuristic 2 - Sub-Group Heuristic for Stakeholders]] — For every stakeholder category, ask whether there are sub-groups who care about different things.
- [[Heuristic 24 - Understand the Why Before You Act]] — Before taking action, make sure you understand why. If you're not confident, ask.

## Proxy Heuristics

- [[Heuristic 3 - Use Multiple Proxies]] — Triangulate with several proxies to prevent gaming and short-term decisions.
- [[Heuristic 4 - Proxies Are Not Quality]] — Never confuse the proxy with the thing itself.
- [[Heuristic 5 - Trend Lines Beat Absolute Numbers]] — Track direction of change over time, not snapshots.
- [[Heuristic 6 - Know Your Proxy's Blind Spots]] — Every proxy has blind spots. Understanding them is as important as reading the signal.
- [[Heuristic 7 - Proxies Are Gameable]] — Goodhart's Law. Doubly true for agents.
- [[Heuristic 8 - Malicious Compliance Check]] — For every proxy you give an agent, ask what malicious compliance would look like.

## Agent / New World

- [[Heuristic 9 - Don't Import Old-World Costs]] — Agents have different cost/time profiles. Challenge human-era assumptions.
- [[Heuristic 10 - Any Stakeholder Could Be an Agent]] — Consider whether stakeholders might be agents, not humans.
- [[Heuristic 11 - Agents Have Different Strengths and Weaknesses]] — They're not just faster humans.
- [[Heuristic 12 - Agents Don't Get Tired But Have Blind Spots]] — Different failure modes, not fewer.
- [[Heuristic 13 - Economics of Checking vs Investigating Shift with Agents]] — Checking becomes nearly free. Rebalance effort.
- [[Heuristic 14 - Agent Output Needs Different Review]] — Agents make consistent, plausible-looking mistakes.

## Knowledge and Communication

- [[Heuristic 15 - Tacit Knowledge Is Invisible Debt]] — If it's not explicit, it doesn't exist for agents.
- [[Heuristic 16 - If You Can't Articulate It an Agent Can't Use It]] — Both a problem and an opportunity.
- [[Heuristic 17 - Agents Don't Record Context by Default]] — You have to make recording part of the task.
- [[Heuristic 18 - Design Agent Workflows as Knowledge-Accumulating Systems]] — The value isn't just the task output — it's what was learned.
- [[Heuristic 19 - Explicitly Check and Record Assumptions]] — Agents fill gaps confidently and silently.
- [[Heuristic 20 - Ask More Questions Make Fewer Assumptions]] — Design pause points into agent workflows.

## Confidence and Precision

- [[Heuristic 21 - State Confidence Levels Explicitly]] — Don't just state conclusions — state how confident you are.
- [[Heuristic 22 - Calibrate Your Confidence in Your Confidence]] — Meta-confidence matters.
- [[Heuristic 23 - Don't Use Spurious Precision]] — Use honest, coarse-grained levels.

## See Also

- [How to Create a Quality Strategy](quality-strategy/process-how-to-create-a-quality-strategy.md) — The process where heuristics are applied in practice

## Tags

#heuristic #overview
