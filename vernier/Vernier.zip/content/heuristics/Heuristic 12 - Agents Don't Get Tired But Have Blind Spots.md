# Heuristic 12 - Agents Don't Get Tired But Have Blind Spots

> **Humans get worse at repetitive tasks over time. Agents don't. But agents will confidently miss things that a human would notice as 'weird.' The failure modes are different, not fewer.**

A human doing repetitive manual testing at 10 PM is tired, error-prone, and more likely to miss subtle bugs. An agent doing the same thing at 3 AM makes no mistakes from fatigue and makes the same checks millions of times with identical precision. This is a genuine advantage.

But agents also have consistent blind spots. A human would notice if an API response was malformed in a strange way—they'd think "that's weird." An agent will process malformed data confidently as long as it can parse it into something. A human would recognize that a feature request contradicts earlier design decisions. An agent will fulfill the request exactly as stated without seeing the conflict. Agents don't notice context violations.

You can't just trade human reviewers for agent reviewers and expect better results. Different review processes are needed: humans catch contextual weirdness; agents catch logical inconsistencies and mechanical errors. Use them for what they're good at.

## Where This Applies

- [[Testing]] — what agents and humans should test for
- [[Tacit Knowledge and Agents]] — implicit assumptions agents miss
- [[Smells]] — agents don't have the intuitive "something's off" reaction that experienced humans rely on
- [[Agent Considerations]] — blind spot mitigation
- [[Code Review]] — different review approaches for different types of error
- [[Quality Processes]] — balancing agent and human review

## Related Heuristics

- [[Heuristic 11 - Agents Have Different Strengths and Weaknesses]] — strengths and weaknesses perspective
- [[Heuristic 14 - Agent Output Needs Different Review]] — how to review agent work
- [[Heuristic 19 - Explicitly Check and Record Assumptions]] — agents miss implicit assumptions

## Tags

#heuristic #agents
