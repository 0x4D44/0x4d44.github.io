# Heuristic 17 - Agents Don't Record Context by Default

> **Humans naturally absorb and sometimes share context as a side effect of working. Agents don't. If you want an agent to capture what it learned, observed, found surprising, or decided against, you have to explicitly ask for it as part of the task definition. Every agent task should have an explicit 'record what you learned' output alongside the actual deliverable.**

When a human completes a task, they've also absorbed context. They've seen which code paths matter, which edge cases are real, which assumptions they made, which things surprised them. Some of this gets shared in code comments or ticket updates, but much is internalized and will shape their future work.

Agents don't do this. An agent completes a task and generates an output. It doesn't retain context unless it's explicitly asked to record it. And it doesn't share what it learned unless you've made recording and sharing part of the task definition.

This is a design problem. Every agent task should have explicit outputs for what was learned: assumptions made, edge cases discovered, surprising findings, code paths explored, decisions made and why. These outputs become part of your knowledge base and help the next agent (and the next human) work more effectively.

## Where This Applies

- [[Tacit Knowledge and Agents]] — capturing learned knowledge
- [[Agent Workflows]] — task design with learning capture
- [[Agent Recording Protocols]] — how to structure knowledge capture
- [[Documentation]] — making observations part of the record
- [[Quality Processes]] — improving future decisions with learned context

## Related Heuristics

- [[Heuristic 15 - Tacit Knowledge Is Invisible Debt]] — knowledge is valuable and needs capturing
- [[Heuristic 18 - Design Agent Workflows as Knowledge-Accumulating Systems]] — knowledge accumulation as strategy
- [[Heuristic 19 - Explicitly Check and Record Assumptions]] — recording assumptions explicitly
- [[Heuristic 20 - Ask More Questions Make Fewer Assumptions]] — asking rather than assuming

## Tags

#heuristic #knowledge-management #agents
