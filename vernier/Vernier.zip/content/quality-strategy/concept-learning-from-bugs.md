# Learning from Bugs at Four Levels

## The Framework

When you find a bug, there are four levels of learning you can extract from it. Not every bug warrants all four levels — but it's worth considering each, because the higher levels yield disproportionate value.

### Level 1: Fix the Bug

The obvious response. Something's broken, fix it. Every team does this.

Value: the specific problem goes away.

### Level 2: Find the Class

Ask: what *class* of similar issues might exist? The bug you found is probably not unique — it's an instance of a pattern. Are there other places in the product where the same kind of mistake could have been made?

If you found an off-by-one error in one pagination component, check the other pagination components. If you found a race condition in one async handler, look at the other async handlers.

Value: you fix multiple bugs for the effort of finding one. You catch problems before users hit them.

### Level 3: Redesign to Prevent

Ask: can we change the design, architecture, or tooling so this class of bug *can't happen* in the first place?

If you keep finding off-by-one errors in pagination, maybe the pagination logic should be centralised in one component rather than reimplemented in each place. If race conditions keep appearing in async handlers, maybe you need a different concurrency pattern.

Value: you eliminate a category of bugs permanently, rather than playing whack-a-mole with individual instances.

### Level 4: Change the Process or Organisation

Ask: can we change our process, tooling, checks, or organisational structure so that classes of bug like this are caught more efficiently in the future?

Maybe you need a new automated check. Maybe you need a different review practice. Maybe you need an agent that specifically looks for this pattern. Maybe you need to change how work is assigned or reviewed so that this kind of problem gets caught earlier.

Value: you improve the system that produces the product, not just the product itself. This is the highest-leverage learning.

## Cost and Risk at Each Level

Each level costs more than the one below it — Level 1 is cheap (fix the thing), Level 4 is expensive (change the process). Each level also carries the risk of introducing new problems — a redesign might break something else, a process change might slow things down.

The economics of testing apply here: the question is whether the value of the learning justifies the cost and risk of acting on it. Not every bug warrants a Level 4 response. But a team that *never* goes beyond Level 1 is leaving enormous value on the table.

## No Blame

This is critically important: the four levels are about learning, not blame. The question is never "who caused this bug?" The question is: "what can we learn about how to be more efficient at preventing bugs overall?"

Blame shuts down learning. If people fear being blamed for bugs, they hide them, minimise them, or avoid investigating them deeply. The team that learns the most is the team where finding a bug is treated as an opportunity for improvement, not an occasion for punishment.

The only question is: "What can we learn about how to be more efficient about preventing bugs going in or getting bugs out?"

## It's Not About the Specific Bug

A subtle but important point: the primary value of this framework is *not* about stopping the specific bug from happening again (though customers do care about repeat bugs, so that matters too). It's about using the information you've gained from finding this bug to improve the overall process.

The specific bug is a data point. The class of bugs is a pattern. The design fix prevents the pattern. The process change improves how you detect and prevent patterns in general. Each level widens the lens from the specific to the systemic.

See also: [Smells](../smells/Smells.md) — Intuitive signals that something is wrong, often the first indicator before a bug is found, [Heuristic 18 - Design Agent Workflows as Knowledge-Accumulating Systems](../heuristics/Heuristic 18 - Design Agent Workflows as Knowledge-Accumulating Systems.md)
