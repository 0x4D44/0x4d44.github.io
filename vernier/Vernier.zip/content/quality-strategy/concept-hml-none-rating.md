# The H/M/L/None Rating System

## Purpose

When you've identified your quality dimensions (unpacked, not collapsed — see [Unpack Don't Collapse](concept-unpack-dont-collapse.md)), you need a way to express how much each one matters for a given release. The H/M/L/None system provides this.

## The Four Levels

**High** — This dimension is critical to the success of this release. A significant gap here would be a dealbreaker or would seriously undermine the release goals. Active investment is warranted. This is where you focus your testing and development effort.

**Medium** — This dimension matters, but rough edges are tolerable. You want to be aware of the current state and would invest in fixing significant problems, but you're not optimising for excellence here in this release. You're managing it, not chasing it.

**Low** — This dimension is on the radar but not a priority. You wouldn't invest significant effort here unless a problem surfaced that was worse than expected. You're aware of it but deliberately choosing not to focus on it.

**None** — This dimension is explicitly not relevant for this release. It's a conscious decision to exclude it, not an oversight. This is the non-goal signal — and it's valuable precisely because it's explicit.

## Why Four Levels, Not Binary

A binary "matters / doesn't matter" loses the middle ground where most dimensions actually live. "Security matters" is true for almost any product, but whether it's the thing you invest heavily in right now or something you keep an eye on is a crucial distinction. H/M/L/None lets you say "security is Medium — we care, but we're not doing a penetration test for the alpha."

## Why "None" Matters

"None" is not the same as "Low." Low means "we're aware but not investing." None means "this is irrelevant to this release and we're explicitly saying so." The distinction matters because:

- None items don't go on the risk map. There's no gap to assess because there's no requirement.
- None items are documented decisions, not forgotten items. If someone asks "what about accessibility?" the answer is "we explicitly decided it's not relevant for the CLI alpha" — not "we didn't think about it."
- None items may become High for a later release. The quality strategy tracks how priorities change across releases.

## Rating Is Per-Release

The same dimension will have different ratings for different releases. Scalability might be None for the alpha (side projects are small) and High for the enterprise release. Security might be Medium for the internal prototype and High for the design partner trial.

The quality strategy should show this progression across releases so the team can see what's coming and prepare for it.

## Rating Requires a Rationale

A rating without a rationale is almost useless. "Reliability: Medium" tells you nothing. "Recoverability: Medium — crashes are tolerable in alpha as long as users don't lose work, because the patience budget is thin but not zero" tells you everything you need to make decisions.

Always write the rationale. One sentence is enough. The rationale is what makes the rating actionable.

See also: [Quality Attributes — What Stakeholders Care About](../quality-attributes/Quality Attributes.md)
