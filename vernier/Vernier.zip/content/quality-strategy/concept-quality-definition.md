# Quality — The Core Definition

## The Definition

**Quality is value to someone (or something) who matters.**

This is the foundational definition that everything else builds on. It comes from the context-driven testing tradition and it has specific implications that most people miss.

## What This Definition Does

It forces two questions before you can say anything about quality:

1. **Who matters?** — Who are the stakeholders? Not just users. Customers, the team, regulators, investors, support staff, the engineers maintaining the code, the AI agents working in the codebase. Anyone whose experience of the product affects whether the product is a success.

2. **What do they value?** — What does each stakeholder actually care about? Not what you assume they care about. Not what they said in a requirements doc six months ago. What they actually value, right now, in this context.

Until you've answered both questions, the word "quality" is meaningless for your project. You literally don't know what it refers to.

## Why "Or Something"

The definition says "someone *or something*." This matters in a world where AI agents are both building software and using software. An agent that consumes your API is a stakeholder. An agent that works in your codebase is a stakeholder. Their experience of quality is different from a human's — they don't tolerate ambiguity, they fall into rough edges that humans work around, and they need different things to orient effectively. "Or something" is not a throwaway qualifier. It's a deliberate expansion of who counts.

## Quality Is Contextual

The same product can be simultaneously high quality and low quality, depending on whose perspective you take. A food delivery app where the food arrives hot every time but the code is a mess is high quality to the customer and low quality to the CTO. An app with beautiful architecture but declining market share is high quality to the engineering team and low quality to the investor.

Neither perspective is wrong. Both are assessing quality — they're just assessing value to different people who matter.

This is not a problem to resolve. It's the nature of quality. The job of a quality strategy is to make these different perspectives visible and to make deliberate choices about which ones to prioritise for a given release at a given time.

## The Implication

If quality is value to someone who matters, then improving quality means:

1. Knowing who matters
2. Knowing what they value
3. Understanding where the current reality falls short of what they value
4. Doing the most efficient work to close the most important gaps

Everything else — testing, risk analysis, quality dimensions, measurables, reporting — is in service of those four steps.
