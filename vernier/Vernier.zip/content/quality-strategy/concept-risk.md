# Risk as Danger to Quality

## The Definition

**Risk is danger to quality.** Since quality is value to someone who matters, risk is anything that threatens that value.

## Two Forms of Risk

Risk comes in two distinct forms, and they require different responses:

### Unknown Risk

We don't know enough about an area to know whether the quality matches what we need. The question is: what's the potential impact of gaps here that we haven't discovered yet?

The response to unknown risk is **investigation** — testing, exploring, asking questions — to find out what's actually true. The cost is time and effort spent discovering the current state.

### Known Risk

We know enough about an area to know that the quality isn't what we ideally want, but we're living with it. The question is: what's the impact of this gap we already know about?

The response to known risk is either **acceptance** (the gap is tolerable) or **work to improve** (fix the bug, redesign the feature, change the architecture). The cost is development time and the risk of introducing new problems.

## Risk Drives Testing Focus

The economics of testing (see [The Economics of Testing](concept-economics-of-testing.md)) say you can't test everything, so you have to choose. Risk is how you choose.

You focus testing where the danger to quality is highest:

- **High impact + low confidence** = most dangerous. You don't know the state and the consequences of a gap are severe.
- **High impact + high confidence** = known problem to manage. You know the state; the question is whether to invest in fixing it.
- **Low impact + low confidence** = might be worth a quick look, but don't invest heavily.
- **Low impact + high confidence** = leave it alone.

This is the logic behind the risk map (see [Risk Map vs Risk Register](concept-risk-map-vs-register.md)).

## Risk Requires Knowing What Quality Means

You cannot assess risk without a quality definition. Risk is danger to quality, so if you haven't defined quality — who matters, what they value — you don't know what you're assessing danger *to*.

Different stakeholders face different risks from the same product. The risk of a security vulnerability is high for the corporate customer, maybe low for the internal prototype user. The risk of poor agent-friendliness is high for an AI-native workflow, irrelevant for a human-only one. The risk assessment changes with the stakeholder and the context.

See also: [Heuristic 6 - Know Your Proxy's Blind Spots](../heuristics/Heuristic 6 - Know Your Proxy's Blind Spots.md)
