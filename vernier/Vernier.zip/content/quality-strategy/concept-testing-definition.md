# Testing — What It Actually Is

## The Definition

**Testing is investigation to find out what's actually true.**

It's the act of discovering how the world (or product) actually is, as opposed to how we want it to be or assume it to be. When reality differs from what we want — that's a bug, a missing feature, a performance problem, a bad design decision, or any other gap.

## Testing Has Two Parts

Most people think testing means writing test cases, running them, and checking pass/fail. That's real, and it's legitimate — but it's only one part of testing.

**Checking** is the mechanical part: confirming that specific things work the way we expect. Automated tests, regression suites, acceptance criteria verification. Checking answers the question "does this specific thing work as specified?"

**Investigating** is the bigger, more valuable part: actively exploring, asking questions, poking at the product to discover what's actually going on — especially in places you didn't expect to need to look. Investigating answers the question "what's actually true here, and does it match what we need?"

Most teams pour almost all their effort into checking and almost none into investigation. That's the imbalance to fix.

## Testing Reveals Gaps — It Doesn't Create Them

Testing doesn't find bugs. Testing reveals *gaps* between reality and what we want. The gaps were always there. Testing makes them visible.

If you're not looking in the right places, the gaps are still there — you just can't see them. This is why "we ran all our tests and they passed" is not the same as "the product is high quality." Your tests encode someone's idea of what matters — but whose idea? And are they right? And what about all the things nobody thought to check?

## You Don't Need to See the Code to Test

This is a principle that's easy to state and hard to internalise: you do not need to understand the implementation in order to test the product. In fact, testing *is* how you discover what the product actually does, which may differ from what the builder intended.

If you wait until you understand the code before you start testing, you've already contaminated your perspective. You'll be testing against the builder's mental model rather than against what actually matters — value to the stakeholders.

This doesn't mean code knowledge is useless. It means it's not a prerequisite for testing, and sometimes it's actively harmful to the independence of your perspective.

## Testing Is Not a Phase

Testing is not something that happens at the end of a project. It starts at the start and runs throughout.

"What is your architecture and why?" is a testing question. "Who is this for and how will we know if it's right?" is a testing question. The quality strategy and testing strategy should be created before you start building — not when you get to a "test phase."

**"Test phase" is a terrible idea and should not exist.** It implies that the product is built first and checked afterwards. By that point, the most important quality decisions have already been made — the architecture, the design, the assumptions about who matters — and you've lost the ability to influence them.

See also: [Testing Starts at the Start](concept-testing-starts-at-the-start.md), [Heuristic 13 - Economics of Checking vs Investigating Shift with Agents](../heuristics/Heuristic 13 - Economics of Checking vs Investigating Shift with Agents.md)
