# How to Create a Quality Strategy

## What This Document Is

This is the step-by-step process for creating a quality strategy for a software project. It's written for someone who understands software engineering but hasn't built a quality strategy before — or who has, but wants a structured framework to do it well.

A quality strategy is a **business-level document** that tells the organisation how to get to success for the product and project. It's different from a test strategy, which is engineering-level and covers how to investigate the product. You need both, but the quality strategy comes first because it sets the context for everything else. See [Quality Strategy vs Test Strategy](concept-quality-vs-test-strategy.md).

The process described here produces a living document, not a one-time artefact. It gets created before development starts, gets updated as you learn things, and remains the reference point for quality decisions throughout the project.

## Before You Start: The Core Ideas

If you haven't internalised these yet, read them first. The process won't make sense without them.

- [Quality — The Core Definition](concept-quality-definition.md) — Quality is value to someone (or something) who matters.
- [Testing — What It Actually Is](concept-testing-definition.md) — Testing is investigation to discover what's actually true.
- [Risk as Danger to Quality](concept-risk.md) — Risk is danger to quality; it tells you where to focus.
- [The Economics of Testing](concept-economics-of-testing.md) — You can't test or fix everything; the game is maximising quality improvement for the time and effort invested.

The rest of the concept documents are referenced at the points in the process where they become relevant.

---

## The Process

The quality strategy is built in a specific order. Each section depends on the ones before it. Resist the temptation to jump ahead — the later sections are only as good as the foundations they're built on.

### Overview

| Step | What you produce | What it answers |
|---|---|---|
| 1. Context | Project context section | What are we building, why, with whom, and how? |
| 2. Releases | Release roadmap | What are we shipping, in what order, and what's each release for? |
| 3. Stakeholders | Stakeholder map per release | Who matters and what do they value? |
| 4. Non-goals | Explicit exclusions | What are we deliberately not doing? |
| 5. Quality dimensions | Rated dimension list per release | What are all the ways quality matters, and how much does each matter? |
| 6. Risk map | Quality gap analysis | Where are we, where do we need to be, and how confident are we? |
| 7. Plan of work | Prioritised action list | What do we do, in what order, and why? |

After the quality strategy is complete, you can write the test strategy (a separate, engineering-level document) that operationalises the quality strategy into specific testing activities.

---

### Step 1: Context

**What you're doing:** Writing down the project context so that no one reading the strategy is left wondering about high-level questions as they dig into the quality details.

**What to cover:**

**What we're building and why.** Not a product spec — a concise statement of the product's purpose, the problem it solves, and why it matters. Include both the immediate goal (what this version does) and the longer-term ambition (where this is heading) if they're different, because the long-term direction shapes quality priorities even for early releases.

**The team.** Who's on the team, what each person brings, what their current roles are. Be honest about whether roles are settled or in flux. If the team is small, name people. If it's larger, describe the structure. Include AI agents if they're a meaningful part of the workflow — an overnight fleet of coding agents is a team member with its own characteristics and limitations.

**Current workflows.** How does work actually flow right now? Not how you want it to flow — how it actually does. Who builds what, who reviews what, how does code get from idea to production? If the workflow is ad hoc and chaotic, say so. The quality strategy needs to start from reality, not aspiration.

**Release workflow.** How does a release get from "built" to "shipped"? This is critical because the plan of work (Step 7) depends on it directly. If you haven't defined this yet, that's fine — but flag it explicitly as an open question. See [Process Context in Quality Strategy](concept-process-context.md) for why this matters and what to ask.

**Budget and constraints.** What resources are available? How many people, how much time, what tools, what infrastructure? What are the hard constraints — deadlines, budget limits, team availability? If testing infrastructure doesn't exist yet, say so. If the team is bootstrapped and self-funded, that shapes what's realistic.

**Why context matters:** Every subsequent step in the quality strategy is shaped by context. The same product in a different team, market, or stage of development would have a different quality strategy. Making the context explicit means the strategy can be reviewed, challenged, and adapted when context changes — rather than being silently invalidated by unstated assumptions.

---

### Step 2: Release Roadmap

**What you're doing:** Describing the planned sequence of releases — not tied to specific dates, but describing what you're expected to ship in what order and what the purpose of each release is.

**What counts as a "release":** A release is any point at which you deliver value to a set of stakeholders. This might be big, chunky milestone releases (alpha, beta, GA). It might be the output at the end of each sprint. It might be continuous delivery where every merge to main is a release. The scale doesn't matter — what matters is that each release has a purpose, an audience, and a quality profile.

If you're working in sprints, each sprint end is a release. If you're doing continuous delivery, you might group releases by phase or milestone for the purposes of the quality strategy (e.g., "the next four weeks of releases are all serving the alpha audience with these goals"). The point is to have a series of identifiable points where you can ask "who is this for, and what does success look like?"

**What to cover for each release:**

- **What it is** — A name and a one-sentence description.
- **Who it's for** — The target audience for this release (may be a subset of all stakeholders).
- **What it's meant to achieve** — Not features, but goals. What questions does this release answer? What does success look like?
- **Rough sequencing** — What comes before and after this release? What are the dependencies?

**Why the purpose matters more than features:** A release whose purpose is "test whether the core technique works on external codebases" has very different quality implications from one whose purpose is "impress enterprise prospects." The purpose drives which quality dimensions are High vs Low vs None for that release.

**How this connects forward:** The release roadmap becomes the backbone of the rest of the strategy. Stakeholders (Step 3) are mapped per release. Quality dimensions (Step 5) are rated per release. The same dimension may be None for the alpha and High for the enterprise release. Showing this progression helps the team see what's coming and prepare.

---

### Step 3: Stakeholders

**What you're doing:** For each release, identifying who matters and working through what they value in a structured way.

**How to identify stakeholders:**

Start broad. Stakeholders aren't just end users. Consider:

- The end users of this release (which may be a specific subset)
- The team itself — as builders, as testers, as the people selling and positioning the product. Consider whether these are different enough to warrant separate stakeholder entries. (A dev team and a marketing team often have genuinely different quality concerns even if they're the same people wearing different hats.)
- AI agents — as team members doing work (coding agents, testing agents) and as users consuming the product's output. Agents are first-class stakeholders. See [The Old World / New World Bias Trap](concept-old-world-new-world-bias.md).
- Influential users or early adopters whose opinion carries weight beyond their own usage
- Customers of your customers (if your product is B2B)
- Regulators, if applicable
- Investors or governance, if applicable

**How to structure each stakeholder:**

For each stakeholder, use the four-lens framework to think through what quality means to them:

- **Delight** — What would exceed expectations?
- **Discussed** — What are we actively debating?
- **Good Enough** — What's the minimum for this release to succeed with this stakeholder?
- **Dealbreaker** — What would cause active rejection?

See [The Stakeholder Four-Lens Framework](concept-four-lens-framework.md) for detail on how to use this.

**Internal stakeholders are often the most important early on.** In early releases, the external feedback loop isn't established yet. The team is the primary quality sensor. What the team needs from an alpha isn't the same as what end users need — the team often needs to learn whether their assumptions are correct, which is a meta-learning goal that should be made explicit.

**Stakeholders change across releases.** The alpha stakeholders are different from the enterprise release stakeholders. Map them per release, and show how the stakeholder landscape evolves.

---

### Step 4: Non-Goals

**What you're doing:** Explicitly stating what you are not trying to achieve for each release, and why.

This step comes before quality dimensions because it's faster: you can often identify large areas that are entirely irrelevant before doing the detailed work of rating individual dimensions. It also sets the boundary that keeps the dimension work focused.

See [Non-Goals — What You're Explicitly Not Doing](concept-non-goals.md) for why this matters.

**Sources of non-goals:**

- Stakeholder groups not being served in this release
- Quality areas that are irrelevant given the release purpose (e.g., scalability for a closed alpha with 30 users)
- Quality bars that are deliberately lower than people might expect (e.g., "zero-crash reliability is not a goal for the alpha")
- Capabilities deferred to later releases
- Things you know people will ask about and want a ready answer for

**Non-goals are decisions, not oversights.** Review the non-goals list with the team to confirm everyone agrees they're deliberate exclusions. Disagreements surfaced here are much cheaper than disagreements surfaced mid-project.

---

### Step 5: Quality Dimensions

**What you're doing:** Identifying all the ways quality matters for this project, and rating each one for each release.

This is the most detailed step and the one where several concept documents come into play at once.

**How to generate the dimension list:**

Start with a broad inventory. Quality dimensions include the traditional "-ilities" (reliability, security, usability, performance, maintainability, testability, observability, accessibility, etc.) and any new-world dimensions relevant to your context (agent-friendliness, context-efficiency, human-attention-efficiency, etc.).

**Use the reference dimension list as a starting point.** The knowledge base includes a comprehensive list of quality dimensions — the standard "-ilities" and beyond — that serves as a checklist to make sure you haven't missed anything. Don't just use the ones that come to mind; walk through the full list and consider each one. You'll rate most of them and dismiss many as None, but the act of considering each ensures nothing important is overlooked.

See [Quality Attributes — The Reference List](../quality-attributes/Quality Attributes.md) for the full inventory of quality dimensions.

Then apply the unpacking principle: for each dimension, ask whether it's actually several distinct things bundled together. See [Unpack Don't Collapse](concept-unpack-dont-collapse.md). Performance is not one thing. Maintainability is not one thing. Reliability is not one thing. Unpack them into sub-dimensions that have meaningfully different priorities.

**Check for old world / new world bias.** For each dimension, ask: "Am I rating this based on old world assumptions about who the stakeholder is?" Readability might seem low priority in a small team — until you realise the agents working in the codebase are the primary consumers. See [The Old World / New World Bias Trap](concept-old-world-new-world-bias.md).

**Check for actual vs perceived splits.** For dimensions where trust matters (security is the classic example), ask whether actual quality and perceived quality should be tracked as separate sub-dimensions. See [Actual vs Perceived Quality](concept-actual-vs-perceived-quality.md).

**Rate each dimension:**

Use the H/M/L/None system. See [The H/M/L/None Rating System](concept-hml-none-rating.md).

The rating is about **how important this dimension is to each stakeholder for this release** — not about how high the quality needs to be in absolute terms. A dimension rated High means "this matters enormously to the stakeholders who matter for this release." It doesn't necessarily mean "this needs to be world-class" — the required quality level is a separate question that gets answered in the risk map (Step 6). The rating here is about importance and priority: how much should this dimension weigh in our decisions?

**Key concept documents for this step:**

- [Unpack Don't Collapse](concept-unpack-dont-collapse.md) — Composite dimensions hide important distinctions
- [The Old World / New World Bias Trap](concept-old-world-new-world-bias.md) — Check whether you're reasoning for humans or agents
- [Actual vs Perceived Quality](concept-actual-vs-perceived-quality.md) — They're different dimensions; both matter
- [The H/M/L/None Rating System](concept-hml-none-rating.md) — Four levels for rating quality dimensions
- [The Stakeholder Four-Lens Framework](concept-four-lens-framework.md) — Delight / Discussed / Good Enough / Dealbreaker

For each dimension, provide:

- **The rating** — H, M, L, or None
- **A rationale** — One or two sentences explaining *why* this rating, for this release, for these stakeholders. The rationale is what makes the rating actionable. A rating without a rationale is almost useless.

**Group by rating for readability.** Present the dimensions grouped by priority (all Highs together, all Mediums together, etc.) so the overall shape of the quality profile is visible at a glance.

**Show the progression across releases.** The same dimension will have different ratings for different releases. Showing this progression helps the team see what's changing and prepare for upcoming priorities.

---

### Step 6: Risk Map

**What you're doing:** For each quality dimension rated H or M, building a picture of the gap between where you are and where you need to be — and how confident you are on *both sides* of that gap.

This is where the strategy goes from "what matters" to "where are we actually exposed." See [Risk Map vs Risk Register](concept-risk-map-vs-register.md) for the full framework.

**The risk map has two sides:**

The first side is **what should be** — the required quality levels. For each dimension, what does this need to look like for the release to succeed? And crucially: how confident are you in that requirement? Some required levels are obvious (the product must not leak API keys). Others are genuinely uncertain (how fast does a full analysis run need to be for users to tolerate it? You might not know until you test with real users). The confidence in your required levels matters because if you're wrong about what's needed, you might be closing the wrong gaps.

The second side is **what is** — the actual current quality levels. For each dimension, where are you right now? And how confident are you in that assessment?

The risk map is the combination of those two sides: the gap between required and actual, the impact of that gap, and the confidence on both ends.

**For each dimension, assess:**

| Column | Question |
|---|---|
| **Required level** | What does this need to be for the release to succeed? |
| **Confidence in required** | How sure are we that this is the right target? |
| **Actual current level** | Where are we right now? |
| **Confidence in actual** | How sure are we about where we actually are? |
| **Gap** | What's the delta between required and actual? |
| **Impact** | How dangerous is this gap? |

**Confidence applies to both sides.** Low confidence in the actual level is dangerous because you don't know where you are. But low confidence in the required level is also dangerous — you might be working toward the wrong target. Both kinds of uncertainty need to be visible and both need resolution.

**Be honest about unknowns.** For early-stage projects, many entries in the "actual" column will be "unknown" or "?". That's not a failure — it's the most important finding. The risk map makes visible that you're operating with limited information, and it drives you toward resolving the highest-impact unknowns first.

**Pursue resolution of uncertainty.** For each low-confidence entry, ask: what would it take to upgrade our confidence? Sometimes it's a test. Sometimes it's a conversation with the builder. Sometimes it's "install the thing and try it." Resolving an uncertainty doesn't just increase confidence — it changes the actual risk value. You might learn the gap is smaller than feared, or larger than expected. Either way, you can now act on real information.

**Look for patterns.** After filling in the risk map, step back and look at the overall shape:

- Which items are hottest (large gap + high impact + low confidence)?
- Are there clusters of unknowns that could be resolved efficiently together (e.g., one conversation with the builder that answers five questions)?
- Are there dependencies (e.g., you can't assess signal quality until the product is installable)?

These patterns feed directly into the plan of work.

---

### Step 7: Plan of Work

**What you're doing:** Translating the risk map into a prioritised list of actions, ordered by dependency and impact.

The plan of work falls naturally out of the risk map. It's not a separate creative exercise — it's the logical consequence of everything you've built so far.

**Three types of work:**

The plan of work contains three fundamentally different kinds of activity, and recognising which type you're doing matters because they address different uncertainties:

- **Testing work** removes uncertainty about *what is*. It investigates the current state of quality on a dimension and upgrades your confidence in the "actual" column of the risk map.
- **Stakeholder work** removes uncertainty about *what should be*. It involves talking to stakeholders, observing users, reviewing market expectations — anything that upgrades your confidence in the "required" column of the risk map.
- **Fixing work** improves *what is* until it matches *what should be*. It closes the gap between actual and required quality on a dimension.

You can't do fixing work efficiently until you have reasonable confidence on both sides. If you don't know where you are (low confidence in actual), you might fix the wrong thing. If you don't know where you need to be (low confidence in required), you might fix to the wrong bar. Testing and stakeholder work come first; fixing work follows.

**Ordering principles:**

1. **Resolve the highest-impact unknowns first.** If you don't know the current state of a critical dimension, find out before doing anything else. Every subsequent decision depends on this information.

2. **Unblock dependencies.** Some work gates other work. If nothing can be tested until the product is installable, installability is the first work item regardless of its dimension rating.

3. **Close the largest gaps in the highest-impact areas.** Once you know where you are, fix the biggest problems in the most important areas.

4. **Group work that resolves multiple risk map entries.** A single conversation with the builder might answer five questions. A single testing session might assess three dimensions. Efficiency matters.

5. **Don't work on None items.** By design.

**Phasing:** The plan of work typically falls into natural phases, often separated by information dependencies:

- Phase 0: Remove blockers (things that prevent any other work from happening)
- Phase 1: Resolve critical unknowns (cheapest uncertainty resolution — often conversations and quick investigations)
- Phase 2: Internal testing / first-party use (the team uses the product themselves before anyone external sees it)
- Phase 3: External exposure (sequenced carefully — friendlies before influential users before the general public)
- Phase 4: Learning loop (update the quality strategy with everything you've learned, feed into the next release)

**Don't forget internal testing.** A very common gap: the plan jumps from "developer builds it" to "external users try it" without a phase where the team uses the product themselves. This phase is where you discover whether your quality dimensions are actually met, before the stakes of external exposure.

**The plan of work is not immutable.** As you execute the plan and learn things, the risk map updates, and the plan of work may need to change. That's not a failure of planning — it's the strategy working as intended. The plan is a starting point, not a contract.

---

## After the Quality Strategy: Decision Support

One of the most important functions of a quality strategy is providing **decision support on the fly**. When something new comes up — a bug report, a feature request, a user complaint, an unexpected finding — the team needs to quickly map it to the strategy and decide what to do.

The quality strategy enables this by providing:

- **Clear priorities** — Is this in a High, Medium, Low, or None area? That immediately calibrates the response.
- **Explicit non-goals** — Is this in a non-goal area? If so, the answer is "not now, by design."
- **Risk context** — Is this in an area where we already know we have a gap? Or is this new information that should update the risk map?
- **Stakeholder context** — Which stakeholder does this affect? How important is that stakeholder for this release?

A good quality strategy means that most new things can be triaged in seconds, not minutes or hours. The strategy has already done the thinking about what matters; the engineer just needs to locate the new thing on the map.

For AI agents working on the project, this is especially valuable. An agent encountering an unexpected finding can consult the quality strategy to determine whether to flag it, fix it, or move on — without needing to escalate to a human for every decision.

See [How to Know If Your Quality Strategy Is Good](concept-good-quality-strategy-indicators.md) for the full list of indicators.

---

## After the Quality Strategy: The Test Strategy

Once the quality strategy is complete, you have everything you need to write the test strategy — the engineering-level document that covers what testing to do, in what order, and why.

The test strategy translates the quality strategy into action:

- The risk map tells you where to focus testing (highest-impact unknowns first)
- The stakeholder analysis tells you whose perspective to test from
- The quality dimensions tell you what to look for
- The non-goals tell you what not to waste testing effort on
- The plan of work tells you the sequencing

See [Quality Strategy vs Test Strategy](concept-quality-vs-test-strategy.md) for how these two documents relate.

---

## After the Quality Strategy: Reporting

The quality strategy also sets up what you need for quality reporting — communicating the state of quality to governance, stakeholders, and the wider team. The risk map provides the data; the stakeholder analysis tells you who needs what level of detail.

Reporting is not covered in detail in this document, but note that the quality strategy should be designed with reporting in mind from the start. If you know you'll need to report quality state to a CEO or a client, the metrics and proxies you choose in Step 5 should be ones you can actually track and present. This is indicator #2 of a good quality strategy: instrumentation from the start.

---

## Keeping the Quality Strategy Alive

The quality strategy is not a document you write once and file. It's the reference document for quality decisions throughout the project. It stays alive by:

- **Updating the risk map** as you learn things — after testing sessions, after releases, after conversations that change your understanding
- **Reviewing stakeholder priorities** as the project evolves — early-stage stakeholders may change as you move from alpha to enterprise
- **Revising non-goals** as the context changes — what was a non-goal for the alpha may become critical for the next release
- **Reviewing the initial context** in light of what you've learned — the quality strategy may reveal that you need to change your team structure, workflows, or release process to achieve what you want

That last point is important: although the context section describes your current team, workflows, and constraints as a starting point, coming out of all the quality work you may realise that you can more efficiently achieve your goals by changing those things. The initial context is a basis from which you're working, but not immutable.

---

## Concept Documents Referenced

These standalone documents are part of this knowledge base and cover the concepts used throughout the process:

| Document | Core idea |
|---|---|
| [Quality — The Core Definition](concept-quality-definition.md) | Quality is value to someone (or something) who matters |
| [Testing — What It Actually Is](concept-testing-definition.md) | Testing is investigation to discover what's actually true |
| [Risk as Danger to Quality](concept-risk.md) | Unknown risk vs known risk; risk drives focus |
| [The Economics of Testing](concept-economics-of-testing.md) | Maximise quality improvement for time and effort invested |
| [Testing Starts at the Start](concept-testing-starts-at-the-start.md) | No test phase; testing thinking from day one |
| [The Stakeholder Four-Lens Framework](concept-four-lens-framework.md) | Delight / Discussed / Good Enough / Dealbreaker |
| [Unpack Don't Collapse](concept-unpack-dont-collapse.md) | Composite dimensions hide important distinctions |
| [The H/M/L/None Rating System](concept-hml-none-rating.md) | Four levels for rating quality dimensions |
| [Risk Map vs Risk Register](concept-risk-map-vs-register.md) | Quality gap analysis with confidence overlay |
| [Actual vs Perceived Quality](concept-actual-vs-perceived-quality.md) | They're different dimensions; both matter |
| [The Old World / New World Bias Trap](concept-old-world-new-world-bias.md) | Check whether you're reasoning for humans or agents |
| [Non-Goals — What You're Explicitly Not Doing](concept-non-goals.md) | Explicit exclusions prevent wasted effort |
| [Learning from Bugs at Four Levels](concept-learning-from-bugs.md) | Fix, find the class, redesign, change the process |
| [Quality Strategy vs Test Strategy](concept-quality-vs-test-strategy.md) | Business-level vs engineering-level documents |
| [Testing Without Seeing the Code](concept-testing-without-seeing-code.md) | Independence of perspective; testing is discovery |
| [How to Know If Your Quality Strategy Is Good](concept-good-quality-strategy-indicators.md) | Seven indicators and three confidence outcomes |
| [Confidence as the Through-Line](concept-confidence-through-line.md) | The core output of quality work is confidence |
| [Process Context in Quality Strategy](concept-process-context.md) | A plan depends on how you ship |

## Knowledge Base Pages Referenced

These pages in other sections of the knowledge base provide reference information and deeper exploration of concepts used throughout quality strategy creation:

- [Quality Attributes — The Reference List](../quality-attributes/Quality Attributes.md) — Comprehensive inventory of quality dimensions to consider when building your strategy
- [Stakeholders — Who Matters](../stakeholders/Stakeholders.md) — Reference checklist for identifying stakeholder categories to apply the framework to
- [Heuristics](../heuristics/Heuristics.md) — Thinking tools and practical principles applicable throughout the quality strategy process
