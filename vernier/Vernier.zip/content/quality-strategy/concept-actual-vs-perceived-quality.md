# Actual vs Perceived Quality

## The Principle

Actual quality and perceived quality are different dimensions. Both matter. They should be tracked separately because they have different causes, different mitigations, and different impacts on different stakeholders.

## What's the Difference?

**Actual quality** is the real state of the product on a given dimension. Is the API actually secure? Does the system actually handle 1000 concurrent users? Is the code actually maintainable?

**Perceived quality** is what stakeholders believe the state to be. Do customers *feel* secure? Does the CTO *believe* the system can scale? Do developers *think* the code is well-structured?

These can diverge in both directions:

- **Actual high, perceived low:** The product is genuinely secure, but users don't trust it because there's no visible indication of security practices. The quality is there but the stakeholders don't know it.
- **Actual low, perceived high:** The product feels polished and professional, but the underlying architecture has serious problems. Stakeholders are confident in something that's fragile.

## Why Both Matter

The gap between actual and perceived quality creates different kinds of risk:

- **Actual low, perceived high** is the more dangerous case. Stakeholders make decisions based on false confidence. When reality surfaces — an outage, a security breach, a scaling failure — trust is damaged more severely than if expectations had been managed.

- **Actual high, perceived low** is a waste. You've done the work but you're not getting credit for it. Stakeholders may invest effort in "fixing" something that's already fine, or worse, they may lose confidence in the team's ability to deliver.

## Security Is the Classic Example

Security is where this distinction bites hardest. A product can be genuinely secure (strong encryption, proper key management, no data exfiltration) but if there's no communication about security practices, no visible trust signals, and no documentation of the security model, enterprise customers won't touch it.

Conversely, a product can have impressive security documentation and certifications while having actual vulnerabilities. The perception doesn't protect you from the breach.

For a product that intends to serve enterprise or corporate customers, perceived security must be treated as a separate quality dimension from actual security. Both need to be High, and the work required for each is different: actual security is engineering work, perceived security is communication, documentation, and trust-building work.

## General Application

The actual/perceived split applies to many dimensions, not just security:

- **Reliability:** Is the system actually reliable, and do users *feel* it's reliable? (A system that recovers silently might be highly reliable but feel unstable to users who notice brief glitches.)
- **Performance:** Is it actually fast, and does it *feel* fast? (Progress indicators and responsive UI can make a slow operation feel faster than a fast operation with no feedback.)
- **Quality of output:** Is the analysis actually good, and do users *trust* it? (An AI tool that gives great results but can't explain why may not be trusted.)

## How to Handle This in a Quality Strategy

When you're assessing quality dimensions, ask: "Should we split this into actual and perceived?" The answer is yes when:

- The stakeholders include both people who experience the product directly (they form perceptions) and people who need the product to genuinely perform (they need actual quality)
- The product is heading toward enterprise or regulated contexts where trust is a first-class concern
- There's a risk that the team will focus on one at the expense of the other

When you split, rate and track both sub-dimensions independently. They'll often have the same priority but different current states and different plans of work.

See also: [Security](../quality-attributes/Security.md) — A quality attribute where actual vs perceived splits are especially important, [Heuristic 4 - Proxies Are Not Quality](../heuristics/Heuristic 4 - Proxies Are Not Quality.md) — Proxies can inflate perceived quality without improving actual quality
