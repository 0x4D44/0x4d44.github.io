# Testing Without Seeing the Code

## The Principle

You do not need to understand the implementation in order to test the product. In fact, testing *is* how you discover what the product actually does, which may be different from what the builder intended.

## Why This Matters

The natural instinct when asked to test something is "let me understand how it works first." This instinct comes from a good place — wanting to be thorough, wanting to know what you're dealing with. But it has a serious downside: it contaminates your perspective.

If you study the code before testing, you'll test against the builder's mental model. You'll verify that the code does what the code was written to do. What you won't do is discover whether the code does what the *stakeholders* need it to do — because you've adopted the builder's frame instead of the stakeholder's frame.

## Testing Is Discovery

Testing is investigation to find out what's actually true (see [Testing — What It Actually Is](concept-testing-definition.md)). When you approach a product as a tester — without the builder's assumptions — you discover:

- What the product actually does (which may differ from what it was intended to do)
- What the product doesn't do (gaps the builder didn't think about)
- How the product behaves at the edges (where assumptions break down)
- What the experience is actually like for someone encountering it fresh

All of this information is more valuable when it comes from an independent perspective than when it's filtered through the builder's understanding.

## The Relationship Between Testing and Asking

Testing (observing the product directly) and asking the builder questions are both valid ways to build understanding of the current state. They're parallel activities serving the same purpose — filling in the "actual" and "confidence" columns of the risk map.

But they answer different questions:

- **Asking the builder** tells you what was *intended* and what the builder *believes* the current state is.
- **Testing the product** tells you what *actually happens* when you use it.

The gap between these two is often where the most important bugs live.

## Practical Implication

You can — and often should — start testing before you have a full briefing on the implementation. Install the product, run it, see what happens. What's the first experience like? What's confusing? What breaks? What surprises you?

Then, after you've formed your own independent view, compare it against the builder's model. The disagreements are the interesting findings.

This doesn't mean code knowledge is never useful. Understanding the implementation can help you test more efficiently — you can target areas you know are complex or risky. But it's not a prerequisite for starting, and starting without it gives you a perspective that's impossible to recover once you've been briefed.

## For AI Agents

This principle applies equally to AI agents doing testing. An agent doesn't need a full codebase walkthrough before it can test the product's behaviour, evaluate its output, or assess its user experience. The agent's "fresh eyes" perspective — unconditioned by the builder's assumptions — is valuable for the same reason a human tester's independence is valuable.

See also: [Heuristic 24 - Understand the Why Before You Act](../heuristics/Heuristic 24 - Understand the Why Before You Act.md)
