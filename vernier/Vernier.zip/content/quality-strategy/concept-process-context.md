# Process Context in Quality Strategy

## The Problem

A quality strategy defines what quality means, who the stakeholders are, what the priorities are, and what the plan of work is. But the plan of work can't be fully specified if you haven't described **how your team actually ships software**.

The release workflow — branching, freezes, internal testing, handoffs, go/no-go decisions — is itself a quality dimension. If you haven't defined it, you can't reason about its quality, and you'll discover the gaps at the worst possible moment (usually right before a release).

## What Happened When This Was Missing

In the Tollens alpha quality strategy, the release roadmap described *what* was being shipped (alpha to friends, then wider, then design partners) but not *how* it got from "built" to "shipped." When the plan of work was drafted, it jumped straight from "make it installable" to "test on friends' machines" — completely skipping the phase where the team themselves would use the product first.

The missing piece was process context: nobody had described the workflow between "developer commits code" and "user receives a release." Without that, an entire phase of internal testing was invisible to the planning process.

## The Prompt That Catches This

For each release in your roadmap, ask:

**"How does it get from 'built' to 'shipped'? Who touches it between the developer and the end user? If the answer is 'nobody,' that's a risk. If the answer is 'we haven't decided,' that's a bigger risk."**

This question forces you to surface the release workflow, which includes:

- What's the branching and feature freeze strategy?
- Who tests what before a release is declared ready?
- What does "ready" mean?
- What's the internal release cadence vs external release cadence?
- Is there an internal testing phase before external users see it?
- What are the go/no-go criteria?
- How do fixes get from "found" to "shipped"?

## Where This Belongs

Process context belongs in the context section of the quality strategy — alongside team composition, current workflows, and resource constraints. It's the kind of information that shapes everything downstream. The plan of work depends on it directly: you can't plan the work if you don't know how the work gets delivered.

If the release workflow hasn't been defined yet (common in early-stage teams), that's fine — but it should be explicitly flagged as undefined, with the open questions listed. The act of listing what you *don't know* about your own process is itself valuable, because it surfaces decisions that need to be made before the plan of work can be completed.

## General Principle

A quality strategy should cover process, not just product. The mechanisms by which the product gets built, tested, and delivered are themselves quality-relevant. They can have gaps, risks, and areas of uncertainty just like the product itself. Treating them as part of the quality landscape — rather than as background assumptions — makes the strategy more complete and the plan of work more realistic.

See also: [Heuristic 24 - Understand the Why Before You Act](../heuristics/Heuristic 24 - Understand the Why Before You Act.md)
