# Risk Map vs Risk Register

## They're Different Things

A **risk register** is a list of things that could go wrong: "the database might fail," "we might miss the deadline," "a key person might leave." It's useful but limited — it catalogues dangers without connecting them to quality or telling you what to do about them.

A **risk map** is a quality gap analysis with a confidence overlay. It's much richer and much more useful for driving decisions.

## What a Risk Map Contains

For each quality dimension, the risk map tracks both sides of the gap and the confidence on each:

**The "what should be" side:**

1. **Required level** — What does this dimension need to be for the release to succeed? This comes from the stakeholder analysis and the H/M/L/None ratings.
2. **Confidence in required** — How sure are we that this is the right target? Some requirements are obvious; others are assumptions that haven't been validated with real users or stakeholders yet.

**The "what is" side:**

3. **Actual current level** — Where are we right now on this dimension? This comes from testing, observation, and conversation.
4. **Confidence in actual** — How sure are we about where we actually are? Low confidence means the "actual" value is a guess, which means the gap might be much larger or smaller than it appears.

**The combination:**

5. **Gap** — The delta between required and actual. This is what needs to be closed.
6. **Impact of the gap** — How dangerous is it that we're not where we need to be? Not all gaps are equally scary. A gap in a Low dimension is less urgent than the same size gap in a High dimension.

## Where the Heat Comes From

The "heat" in a risk map — the items that demand attention — comes from the interaction of gap, impact, and confidence on both sides:

- **Large gap + high impact + high confidence on both sides** = known serious problem. You know exactly what's wrong and you know it matters. Fix it.
- **Any gap + high impact + low confidence on actual** = you *think* there might be a problem in an area that matters a lot, but you're not sure what the current state is. Investigation (testing) is urgent.
- **Any gap + high impact + low confidence on required** = you might be working toward the wrong target. Stakeholder conversations are urgent — validate the requirement before investing in closing the gap.
- **Large gap + low impact** = known but tolerable. Document it, park it, revisit later.
- **Small gap + high confidence on both sides** = you're close and you know it. Minor polish.

The common mistake is treating all gaps equally. A small gap with low confidence in a high-impact area is hotter than a large gap with high confidence in a low-impact area.

## Confidence Applies to Both Sides

Many teams build risk maps with confidence only on the "actual" column — or skip confidence entirely. Both are mistakes.

Low confidence on the actual level means you can't assess the gap accurately. The response is testing — investigate to find out where you are.

Low confidence on the required level means you might be aiming at the wrong target. The response is stakeholder work — talk to the people who matter, observe real usage, validate your assumptions about what they need.

Both kinds of low confidence are dangerous. Both need resolution before you can efficiently close gaps.

## Pursuing Resolution of Uncertainty

Flagging uncertainty in the risk map is important, but it's not enough. The risk map should actively drive you toward resolving the unknowns:

- For each low-confidence entry, ask: what would it take to upgrade our confidence? Sometimes it's a conversation. Sometimes it's a test. Sometimes it's "go look at the thing and see what happens."
- Resolving an uncertainty doesn't just increase confidence — it changes the actual risk value. You might learn the gap is smaller than feared (risk drops) or larger than expected (risk increases, but now you can act on it).
- Unknown risks are more dangerous than known ones. A known problem you can work on. An unknown problem compounds silently.

## The Risk Map Feeds the Plan of Work

The risk map is not a static document. It's the primary input to the plan of work — it tells you what to do and in what order:

1. Resolve the highest-impact unknowns first (investigation)
2. Close the largest gaps in the highest-impact areas (development)
3. Monitor the areas where you're close (ongoing testing)
4. Ignore the areas rated None (by design)

As you do work and learn things, the risk map updates. Required levels may change as you understand stakeholders better. Actual levels change as you test and build. Confidence changes as you investigate. The risk map is a living document.

See also: [Risk as Danger to Quality](concept-risk.md), [The H/M/L/None Rating System](concept-hml-none-rating.md), [Heuristic 21 - State Confidence Levels Explicitly](../heuristics/Heuristic 21 - State Confidence Levels Explicitly.md), [Heuristic 22 - Calibrate Your Confidence in Your Confidence](../heuristics/Heuristic 22 - Calibrate Your Confidence in Your Confidence.md)
