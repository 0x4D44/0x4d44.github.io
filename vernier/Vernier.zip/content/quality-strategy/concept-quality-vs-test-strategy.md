# Quality Strategy vs Test Strategy

## They're Different Documents at Different Levels

People often use "quality strategy" and "test strategy" interchangeably. They're not the same thing. Getting the distinction right matters because it affects who owns each document, who reads it, and what decisions it drives.

## Quality Strategy

The quality strategy is a **business-level** document. It tells the organisation how to get to success for the product and project.

It answers:

- Who are our stakeholders and what do they value?
- What does quality mean for this project, concretely?
- What are our quality dimensions and how do we prioritise them?
- Where are the gaps between where we are and where we need to be?
- What's our plan for closing those gaps?
- What are we explicitly *not* doing?
- How will we know we've succeeded?

The audience is the whole team — engineering, product, leadership, anyone involved in the project. It sets the context for all quality-related decisions. Non-engineers should be able to read it and understand what's going on.

## Test Strategy

The test strategy is an **engineering-level** document. It covers how to investigate and understand the project and product to get the information needed to take the right actions to optimise quality improvement.

It answers:

- What testing are we going to do and why?
- How do we decide what testing to do?
- What are the principles that guide those decisions?
- What information do we need and in what order?
- Who does what kind of testing?
- What does "done" look like for each kind of testing?

The audience is the people doing the testing — engineers, testers, and increasingly AI agents that are part of the testing workflow. It's operational and actionable.

## How They Relate

The quality strategy is the input to the test strategy. You can't decide what to test without knowing what quality means (who matters, what they value, where the risks are). The quality strategy provides that context; the test strategy translates it into action.

Information flows back too: the test strategy generates information about the current state of quality, which updates the risk map in the quality strategy, which may change priorities, which updates the test strategy. They're connected by a feedback loop, not a one-way dependency.

## A Common Mistake

The most common mistake is writing a test strategy without a quality strategy — jumping straight to "what tests do we run?" without first establishing "what does quality mean and where are the risks?" This produces comprehensive-looking test plans that may be testing the wrong things in the wrong order, because the priorities weren't grounded in stakeholder value.

The second most common mistake is writing only a quality strategy without a test strategy — defining what matters but not operationalising it into a plan for finding out where you actually stand. The quality strategy becomes a nice document that doesn't change anyone's day-to-day work.

You need both.

See also: [Quality — The Core Definition](concept-quality-definition.md), [The Economics of Testing](concept-economics-of-testing.md)
