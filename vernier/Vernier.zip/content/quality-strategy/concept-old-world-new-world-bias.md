# The Old World / New World Bias Trap

## The Problem

When assessing quality dimensions, it's natural to reason about them using familiar mental models — the "old world" of software engineering where the primary actors are humans. But in teams where AI agents are building, testing, and using the product, many dimensions matter differently than they used to, and the old world reasoning leads you to the wrong priority.

This bias is systematic, not occasional. Anyone trained on pre-AI engineering practices (including AI models themselves, whose training data is predominantly old world) will instinctively rate dimensions against the wrong stakeholder unless they consciously check.

## How the Bias Shows Up

**Readability** is the clearest example. In a small team where everyone knows the codebase, the old world reasoning says: "Readability is low priority — there's nobody new to onboard." But if agents are working in the codebase daily, readability is about whether the agents can orient quickly and produce good output. That's a direct productivity concern, not a future-proofing one. The priority should be higher.

**Maintainability** has the same problem. "Our three-person team can maintain this" — but can the fleet of AI agents that are making commits overnight maintain it? If the agents produce code that nobody (human or agent) can explain, that compounds over time in a way it didn't when all code was human-authored.

**Documentation** shifts from "will a new hire understand this?" to "will an agent operating with limited context window understand this?" The bar is different and in some ways higher — humans can ask clarifying questions, agents often can't.

**Error messages** shift from "is this helpful to a developer debugging?" to "is this parseable by an agent that needs to decide what to do next?" Humans tolerate rough edges and ambiguity. Agents fall into them.

## The Check

Whenever you're rating a quality dimension, ask:

**"Am I thinking about this in old world or new world terms? Who is actually the stakeholder here — a human, an agent, or both?"**

If the answer includes agents, re-evaluate the priority with that stakeholder in mind. The rating may stay the same, or it may shift significantly.

This is especially important for AI models assisting with quality strategy creation. The model's instinct will be to apply old world reasoning because that's what dominates its training data. It should be explicitly prompted to check for this bias and flag when a dimension might matter more in a new world context than the old world reasoning suggests.

## It's Not Just "Higher Priority"

The new world doesn't just make everything more important. Sometimes it changes what the dimension means:

- Readability shifts from "human comprehension" to "agent orientation speed"
- Testability shifts from "can we write test cases" to "can we run agents that systematically probe the product"
- Diagnosability shifts from "can a human find the bug" to "can an agent identify, categorise, and potentially fix the issue autonomously"
- Documentation shifts from "reference material for humans" to "context for agents that need to understand why"

The new world doesn't just re-prioritise the old dimensions — it redefines some of them. When you're unpacking dimensions (see [Unpack Don't Collapse](concept-unpack-dont-collapse.md)), consider whether the new world meaning is different enough to warrant a separate sub-dimension.

See also: [Agent Considerations](../agents/Agent Considerations.md), [Heuristic 10 - Any Stakeholder Could Be an Agent](../heuristics/Heuristic 10 - Any Stakeholder Could Be an Agent.md)
