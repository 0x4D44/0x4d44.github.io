# The Economics of Testing

## The Core Idea

All quality work — testing, fixing, improving — is a trade-off of time, energy, and resources against the value you get back. You will never have enough time to test everything, find every gap, or fix every problem.

So the entire game — the *entire* game — is about getting the most quality improvement for the time you invest. This applies to testing (investigating to find out where you are) and to fixing (doing the work to close the gaps). Both cost time and effort. Both need to be prioritised ruthlessly.

## What This Means in Practice

The single most valuable skill in testing isn't writing test cases. It's **deciding what to test**.

To decide what to test, you need to understand:

1. **Quality** — who matters and what they value (see [Quality — The Core Definition](concept-quality-definition.md))
2. **Risk** — where the biggest danger to that quality is (see [Risk as Danger to Quality](concept-risk.md))

Without both, you're guessing where to spend your time. You might test thoroughly in an area that doesn't matter much, while a critical area goes unexplored.

## Focus Where the Gap Is Most Likely

You want to focus your testing in areas where there's most likely to be a difference between reality and what you want. That means:

- Areas of the product that are new or recently changed
- Areas that are complex or poorly understood
- Areas where the cost of a gap is highest (if this breaks, what's the impact?)
- Areas where your confidence in the current state is lowest

The risk map (see [Risk Map vs Risk Register](concept-risk-map-vs-register.md)) is the tool that makes this visible and systematic rather than intuitive and ad hoc.

## The Cost of Quality Work Is Real

Both testing and fixing have costs beyond the obvious time spent:

- Every test you run is time not spent running a different test or fixing a known problem
- Every fix you make is time not spent investigating whether there are bigger problems elsewhere
- Building test infrastructure has an up-front cost
- Maintaining tests as the product changes is ongoing work
- Fixing one thing can introduce new problems
- Testing can slow down delivery if not integrated well into the workflow

These costs are worth paying — but they're worth paying *selectively*. The economics say: invest where the expected value is highest relative to the cost. For testing, that means investigating where the risk to quality is greatest. For fixing, that means closing the gaps that matter most to the stakeholders who matter most.

## Testing Is Information Acquisition

A useful reframe: every test session should answer a named question. "I'm testing to find out whether X" is a good test session. "I'm running through the test plan" is a weak one — it's mechanical, not directed.

When you think of testing as information acquisition, the economics become clearer. You're buying information about the state of the product. The question is: which information is most valuable to buy right now, and what's the cheapest way to get it?

See also: [Heuristic 9 - Don't Import Old-World Costs](../heuristics/Heuristic 9 - Don't Import Old-World Costs.md), [Economics of Testing (core)](../core/Economics of Testing.md)
