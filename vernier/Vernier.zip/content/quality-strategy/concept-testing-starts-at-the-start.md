# Testing Starts at the Start

## The Principle

Testing thinking starts at the very beginning of a project and runs throughout. It does not begin when the code is written. It does not live in a "test phase." There should be no test phase.

## Why "Test Phase" Is Harmful

The idea of a test phase implies a sequence: design, build, *then* test. This is backwards for several reasons:

1. **The most important quality decisions happen before any code is written.** Architecture choices, technology choices, assumptions about users, decisions about what to build and what not to build — these all happen early and have enormous quality implications. If testing thinking isn't present when these decisions are made, you lose the chance to influence them.

2. **Problems found late are expensive.** A design flaw discovered in a test phase requires rework that could have been prevented by asking the right questions at the design stage. The cost of finding and fixing problems increases dramatically the later they're discovered.

3. **Testing thinking improves design.** "What could go wrong here?" and "how would we know if this works?" are questions that make designs better, not just questions that catch bugs after the fact.

4. **A test phase creates a false checkpoint.** "We're in test now" implies that building is done and we're just verifying. In practice, the test phase always reveals things that need changing, which means you're building during testing anyway — just with worse feedback loops and more pressure.

## What Testing Thinking Looks Like at Each Stage

**When choosing what to build:** "Who is this for? What do they actually need? How will we know we got it right?" These are testing questions — they're investigating the gap between assumptions and reality before any code exists.

**When designing the architecture:** "What risks does this architecture create? What risks does it mitigate? How will we diagnose problems in production? What happens when this fails?" These questions improve the design and establish quality thinking from the start.

**When planning the work:** "What are we most uncertain about? What should we build first to reduce that uncertainty? Where is the highest risk?" The quality strategy and testing strategy should be created here — before development begins — not when you get to a "test phase."

**When building:** Continuous investigation alongside construction. Recording hypotheses, observations, and inferences as you go. Not waiting until "build" is done to start "test."

**When releasing:** Understanding where the gaps are, what the risks are, and making an informed decision about whether the quality is sufficient — not hoping the test phase caught everything.

## Recording as You Go

A corollary of "testing starts at the start" is that recording your thoughts, hypotheses, observations and inferences should happen throughout the project, not in a phase at the end. If you wait to record what you've learned until a test phase, you've lost state — insights from design discussions, architectural decisions, early prototyping, all gone or only in people's heads.

See also: [Testing — What It Actually Is](concept-testing-definition.md), [Heuristic 17 - Agents Don't Record Context by Default](../heuristics/Heuristic 17 - Agents Don't Record Context by Default.md)
