# How to Know If Your Quality Strategy Is Good

## The Seven Indicators

A good quality strategy produces observable effects. If these things are true, your strategy is working. If they're not, something needs to change.

### 1. Org-Wide Clarity

Your whole organisation rapidly becomes aligned. People have a clear, shared context for what's going on. The instances of confusion — where different people thought they were trying to achieve different things — drop dramatically.

The quality strategy is the reference document that settles disagreements about priorities. "What should we focus on?" has an answer that everyone can point to.

### 2. Instrumentation from the Start

You have a good plan, from the start of the project, for what proxies you're going to measure for each area of quality, and you know how you're building measurement in from the start. You're not scrambling to add metrics after the fact — the quality strategy told you what to measure before you started building.

### 3. Legible Work Plan

You all know what your plan of work is and why you're doing each item in which order. The plan of work falls naturally out of the quality strategy — it's driven by the risk map and the priorities, not by someone's intuition or a backlog that grew organically.

### 4. Precision Over Comfort

The quality strategy is precise and clear, even when it's wrong. This is one of the most important indicators: it is much more important to be crystal clear, incredibly precise and accurate — and wrong — than to be woolly and imprecise so nobody notices the errors.

A precise statement can be checked, challenged, corrected, and improved. A vague statement hides disagreement and prevents learning. "Our reliability target for the alpha is: crashes are tolerable if the user can retry without losing work" is precise and testable. "We want good reliability" is useless.

### 5. Decision Support at the Edges

When something comes up that isn't explicitly in the strategy, engineers can quickly map that thing to the strategy and make faster decisions about what to do and whether they need to worry about it now.

This is the "rules of thumb" function — the quality strategy provides enough context and clear enough priorities that people (and agents) can make good decisions on the fly when something new appears. They don't need to escalate every unexpected finding or request.

### 6. Quick Re-Orientation

It's an easy reference and reminder when an engineer (or agent) isn't sure what matters or who matters. They can very quickly refresh that knowledge without needing to ask someone or reconstruct the reasoning from scratch.

This matters especially in longer projects where context drifts, and in teams with multiple workstreams where people switch between contexts regularly.

### 7. Explicit Non-Goals

The strategy tells you what you're not doing and why. This prevents wasted effort, reduces guilt-driven scope creep, and provides instant answers when someone asks "what about X?" for an area that's been deliberately excluded.

See [Non-Goals — What You're Explicitly Not Doing](concept-non-goals.md) for detail.

See also: [Proxies — Dev Tooling and Automation](../proxies/Proxies - Dev Tooling.md)

## The Confidence Outcomes

These seven indicators produce confidence in three areas:

1. **Confidence in shared understanding.** The whole org is confident that everyone knows what's going on, what they're going to do, and what success looks like. They're confident that each other has the same picture.

2. **Confidence in completeness.** You have confidence in the full set of things you need to do to have a successful release. Your definition of success is written down. Your plan of work covers it.

3. **Confidence in current position.** You may not have confidence that you'll hit every bar by every date — but you have absolute confidence that you know exactly where you are at all times. No nasty surprises. No "I thought someone else was handling that."

## How to Know If Your Quality Strategy Is Bad

Flip the indicators:

- People keep discovering they had different assumptions about what mattered
- You're adding measurement after the fact because nobody planned for it
- The plan of work doesn't obviously connect to the quality priorities
- The strategy is vague enough that it's hard to disagree with (which means it's not saying anything useful)
- New things keep requiring lengthy discussions about whether they matter
- People have to ask "remind me, what are we optimising for?" regularly
- There's no non-goals section, or the non-goals are just things nobody thought about rather than deliberate exclusions
