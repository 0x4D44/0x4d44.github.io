# The Stakeholder Four-Lens Framework

## Purpose

When you've identified a stakeholder — someone (or something) who matters — you need a structured way to think about what quality means *to them*. The four-lens framework provides that structure. It forces you to think at four different levels of satisfaction, which surfaces different kinds of quality concerns.

## The Four Lenses

For each stakeholder, work through these questions:

### Delight — What would make them love it?

What would exceed their expectations? What would make them tell their friends, write a blog post, insist their team adopts it? This is the aspiration — the quality bar you'd aim for if resources were unlimited.

Delight items often aren't critical for a given release, but they're important to capture because they indicate what the product should be growing toward.

### Discussed — What are we actively debating?

What quality trade-offs are genuinely open questions right now? Things where the team doesn't yet agree on the right bar, or where you're unsure what the stakeholder actually needs. These are the areas where you need more information — from testing, from conversation, from observation — before you can make a decision.

Discussed items are the most interesting ones strategically, because they're where decisions haven't been made yet and where new information is most valuable.

### Good Enough — What's the minimum for success?

What's the bar below which this stakeholder walks away, stops using the product, or considers the release a failure — but above which they're satisfied enough to continue? This is the practical quality target for the release.

Good enough is not a low bar. It's the honest bar — the real threshold of acceptability for this stakeholder in this context. Setting it requires understanding what they actually need, not what would be ideal.

### Dealbreaker — What would make them actively reject it?

What would cause not just dissatisfaction but active harm? The stakeholder tells others to avoid it. They lose trust that can't be recovered. They escalate. The relationship is damaged beyond the scope of one release.

Dealbreakers are the hard floor. Everything else is negotiable; dealbreakers are not. They're often about trust, safety, data, or first impressions.

## How to Use This

Apply the four lenses to each stakeholder separately. The same product quality dimension might sit in different lenses for different stakeholders. Fast performance might be "delight" for a side project user but "good enough" for an enterprise customer and "dealbreaker" for a real-time system operator.

The output is a structured understanding of what quality means to each stakeholder at each level, which feeds directly into your quality dimensions and their prioritisation.

## Internal Stakeholders Count

The team itself is a stakeholder — often the most important one in early releases, because the external feedback loop isn't established yet. The team is the primary quality sensor.

Apply the four lenses to the team as well. Their dealbreaker might be "we can't tell whether the product is working" rather than any specific product failure. Their "good enough" might be "we learn enough to update our strategy" rather than "the product is polished."

In a team doing multiple things — building, testing, marketing, selling — consider whether the team should be split into multiple stakeholder entries. The dev team and the marketing team may have genuinely different quality concerns even though they're the same people wearing different hats.

## Agents as Stakeholders

AI agents that build, test, or use the product are stakeholders too. Apply the four lenses to them. Their dealbreaker is typically different from humans — they don't tolerate ambiguity, they fail silently on rough edges that humans work around, and "good enough" for an agent often means machine-parseable output and clear error states rather than friendly UX.

See also: [Quality — The Core Definition](concept-quality-definition.md), [The Old World / New World Bias Trap](concept-old-world-new-world-bias.md), [Stakeholders — Who Matters](../stakeholders/Stakeholders.md), [Heuristic 2 - Sub-Group Heuristic for Stakeholders](../heuristics/Heuristic 2 - Sub-Group Heuristic for Stakeholders.md)
