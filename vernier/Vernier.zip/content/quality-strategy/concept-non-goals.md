# Non-Goals — What You're Explicitly Not Doing

## The Principle

A good quality strategy doesn't just tell you what you're doing and why. It tells you what you're **not** doing and why. This is at least as valuable as the positive priorities, because it prevents wasted effort and provides clear decision support when someone raises a question about an area you've deliberately excluded.

## Why Non-Goals Matter

Without explicit non-goals, three things happen:

1. **Scope creep by guilt.** Someone mentions accessibility, or compliance, or multi-language support, and the team feels they should be thinking about it — even though it's not relevant for this release. Without a document that says "we explicitly decided this is not a goal," the team either wastes time on it or feels bad about not addressing it.

2. **Invisible assumptions.** If you haven't stated that scalability is a non-goal for the alpha, different team members may have different assumptions about whether it matters. One person builds for scale, another doesn't, and the inconsistency creates bugs and wasted work.

3. **Poor decision-making at the edges.** When something new comes up — a user request, a bug report, a design question — the team needs to quickly decide whether to act on it. If it falls in a non-goal area, the answer is easy: not now, by design. Without the non-goal list, every new thing requires a first-principles discussion.

## How to Identify Non-Goals

Non-goals come from several sources:

- **Quality dimensions rated None** — If a dimension is rated None in the H/M/L/None system, it should appear as a non-goal with a rationale.
- **Stakeholders not being served yet** — If certain user types or markets are not part of this release, say so.
- **Quality bars deliberately set low** — If you've explicitly decided not to pursue something that people might expect (zero-crash reliability, comprehensive documentation, full test coverage), state it.
- **Capabilities deferred to later releases** — Things the product will eventually do but not now.

## Non-Goals Are Decisions, Not Oversights

The critical distinction: a non-goal is a **decision**. "We are not pursuing scalability for the alpha because our target users are working on small side projects" is a non-goal. "We forgot to think about scalability" is an oversight.

The non-goal list should be reviewed with the team to confirm that everyone agrees these are deliberate exclusions. If someone disagrees — if they think a non-goal should actually be a goal — that's a valuable conversation to have early rather than discovering the disagreement mid-project.

## Non-Goals Change Over Time

What's a non-goal for the alpha may be High priority for the enterprise release. The quality strategy tracks this progression across releases. Non-goals are not permanent — they're contextual. A non-goal with a note saying "becomes relevant at the design partner stage" helps the team see what's coming.

## Non-Goals as Decision Support

The most practical value of non-goals is at the edges — when something comes up mid-project and someone needs to decide quickly whether it matters. An engineer encounters a potential scalability issue. If scalability is an explicit non-goal, the decision is immediate: note it, don't fix it now, move on. If scalability isn't mentioned either way, the engineer has to stop and think (or ask someone), which is slower and less certain.

This is one of the key indicators of a good quality strategy: when something comes up that isn't explicitly in the strategy, people can quickly map it to the strategy and make faster decisions about what to do.

See also: [The H/M/L/None Rating System](concept-hml-none-rating.md), [Heuristic 9 - Don't Import Old-World Costs](../heuristics/Heuristic 9 - Don't Import Old-World Costs.md)
