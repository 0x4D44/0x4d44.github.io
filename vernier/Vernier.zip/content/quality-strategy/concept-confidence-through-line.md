# Confidence as the Through-Line

## The Idea

The core output of quality work — strategy, testing, measurement, reporting — is **confidence**. Not perfection. Not zero bugs. Confidence: the team knows where they are, where they need to be, and what they're doing about the gap.

## Three Levels of Confidence

### 1. Confidence in Shared Understanding

Everyone on the team has the same picture of what's going on. They know who the stakeholders are, what quality means for this project, what the priorities are, and what success looks like. They're confident that their colleagues share this picture.

This is the most basic level, and the most commonly missing. Teams where different people have different implicit assumptions about what matters produce inconsistent work, make conflicting decisions, and waste time on misalignment.

### 2. Confidence in Completeness

The team is confident that they've identified the full set of things that need to be true for a successful release. Not that they've done all the work — but that they know what the work is. Nothing important has been overlooked. The quality dimensions are mapped, the risk map covers the landscape, the plan of work addresses the gaps.

### 3. Confidence in Current Position

The team knows exactly where they are at all times. They may not know whether they'll hit every target by every date — that's a prediction about the future. But they know the current state of quality across their dimensions, they know the gaps, and they know what they're uncertain about.

This is the most operationally valuable level. A team that knows they're behind schedule on reliability can make informed decisions about what to do. A team that *doesn't know* whether they're behind has no basis for making decisions at all.

## Confidence Is Not Certainty

Confidence in current position includes knowing what you *don't* know. If the risk map says "actual: unknown, confidence: very low" for a dimension, that's the team being confident in their knowledge of their own uncertainty. That's a strong position — much stronger than falsely believing you're fine.

The quality strategy should make uncertainty visible and legitimate, not hide it. "We don't know the current state of observability and we need to find out" is a confident statement. "Observability is probably fine" is not.

## Testing and Asking Are Both Confidence-Building

Testing the product and asking the builder questions are both methods of building confidence in the current state. They're parallel activities — different tools for the same purpose.

- Testing gives you direct evidence from observing reality
- Asking gives you the builder's model and knowledge of intent

Both fill in the "actual" and "confidence" columns of the risk map. Neither is sufficient alone. The gap between what testing reveals and what asking reveals is often where the most important findings are.

## The Practical Implication

When planning work — what to build, what to test, what to investigate — the question is always: "What would most increase our confidence?" Sometimes the answer is "fix the bug." Sometimes it's "investigate this area we know nothing about." Sometimes it's "have a conversation with the builder to understand what they've built." The confidence lens helps you choose between these options based on where the confidence gap is largest.

See also: [Heuristic 21 - State Confidence Levels Explicitly](../heuristics/Heuristic 21 - State Confidence Levels Explicitly.md), [Heuristic 23 - Don't Use Spurious Precision](../heuristics/Heuristic 23 - Don't Use Spurious Precision.md), [Confidence and Uncertainty Communication](../knowledge-management/Confidence and Uncertainty Communication.md)
