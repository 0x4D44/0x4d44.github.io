# Unpack Don't Collapse (The Trenchcoat Problem)

## The Principle

When you encounter a quality dimension that seems like one thing, check whether it's actually several different things bundled together. Composite dimensions hide important distinctions. The priorities, current state, and risks of the sub-dimensions are often very different from each other, and collapsing them into one rating loses that information.

We call this "the trenchcoat problem" — several distinct concepts standing on each other's shoulders in a trenchcoat, pretending to be one adult.

## Why It Matters

If you rate "performance" as Medium priority, you've said nothing useful. Performance for whom? Performance of what? The install taking 10 seconds? The analysis run taking 5 minutes? The UI feeling responsive during a long operation? The tool fitting in 8GB of RAM?

Each of those is a different quality dimension with a different stakeholder, a different current state, a different priority, and a different risk profile. Collapsing them into one rating means you can't make good decisions about any of them.

## Worked Example: Performance

"Performance" unpacks into at least:

| Sub-dimension | What it means |
|---|---|
| **Scalability** | Can it handle large inputs without degrading? |
| **Resource consumption** | How much RAM, disk, CPU does it need? |
| **Elapsed time** | How long does a full operation take end-to-end? |
| **UX responsiveness** | Does the interface feel alive during long operations? |
| **Jitter / timing predictability** | Is performance consistent or spiky? |

For an alpha CLI tool running on side projects, scalability might be None (side projects are small), resource consumption might be Medium (if it doesn't fit on their machine, nothing else matters), elapsed time might be Low (people will wait if they know it's working), and UX responsiveness might be Medium (silence during a long LLM call makes users think it's broken).

If you'd rated "performance" as a single dimension, you'd have picked one number that's wrong for at least three of those sub-dimensions.

## Worked Example: Maintainability

"Maintainability" unpacks into at least:

| Sub-dimension | What it means |
|---|---|
| **Diagnosability** | When something goes wrong, can you tell what and where? |
| **Fixability** | Once diagnosed, how hard is the fix? |
| **Enhanceability** | Can you add new capabilities without breaking existing ones? |
| **Readability** | Can someone (or some agent) new follow the code? |
| **Understandability** | Do you know *why* the code is the way it is? |

These have very different profiles. In a three-person team, readability might seem low priority ("everyone knows the codebase") — but if agents are working in the codebase daily, readability is actually about agent orientation speed, not human onboarding. That's a much higher priority. See [The Old World / New World Bias Trap](concept-old-world-new-world-bias.md).

## Worked Example: Reliability

"Reliability" unpacks into at least:

| Sub-dimension | What it means |
|---|---|
| **Crash frequency** | How often does it fail completely? |
| **Recoverability** | When it fails, can you get back to where you were? |
| **Retry success** | If you try again, does it work? |
| **Failure mode** | What does failure look like? Graceful degradation or data loss? |
| **Shape of downtime** | Down for one second allowing retry vs down for hours? |

For an alpha release, zero crashes might be unrealistic and not even necessary — but *recoverability* matters enormously. If a crash loses an hour of work, that's a dealbreaker. If a crash means "run it again and it works," that's tolerable. Collapsing these into "reliability = high" misses this distinction entirely.

## The General Rule

Whenever you're about to rate a quality dimension, ask: "Is this actually one thing, or is it several things in a trenchcoat?" If you can identify sub-dimensions with meaningfully different priorities, unpack them. If they genuinely all have the same priority and risk profile, you can keep them bundled — but make that a conscious choice, not a default.

The sign that you need to unpack: when people disagree about the rating, they're often agreeing about different sub-dimensions.

See also: [Heuristic 1 - The Sub-Group Heuristic](../heuristics/Heuristic 1 - The Sub-Group Heuristic.md), [Quality Attribute Relationships](../quality-attributes/Quality Attribute Relationships.md), [Performance](../quality-attributes/Performance.md), [Maintainability](../quality-attributes/Maintainability.md), [Reliability](../quality-attributes/Reliability.md)
