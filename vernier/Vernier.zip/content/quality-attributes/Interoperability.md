# Interoperability

**Does it play nicely with other systems?** APIs, data formats, standards compliance.

Interoperability is about how well the system works with other systems, third-party tools, and external integrations. This includes: do you have clear, well-documented APIs? Do you use standard data formats? Can external systems integrate easily? Are you following industry standards? High interoperability increases the system's value by enabling integration with the broader ecosystem.

## Who Typically Cares

- [[Partner and Integration Consumers]]
- [[Product and Business Owners]]

## Relevant Proxies

- Functional/integration test coverage
- End-to-end test pass rate
- API documentation completeness
- Number of active integrations

## How It Connects

- [[Usability]] — API clarity is a form of usability
- [[Documentation]] — interoperability requires good API documentation
- [[Testing]] — integration testing validates interoperability

## Tags

#quality-attribute #stub
