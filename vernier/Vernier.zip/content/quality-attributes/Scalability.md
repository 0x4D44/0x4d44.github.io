# Scalability

**Can it grow?** Horizontal scaling, vertical scaling, geographic expansion.

Scalability is about whether the system can handle growth in load, users, data volume, or geographic reach. This includes: can you add more servers (horizontal scale)? Can you upgrade hardware (vertical scale)? Can you expand to new regions? How does performance degrade as you approach limits? Scalability is critical for systems that expect growth and can be a major architectural concern.

## Who Typically Cares

- [[Senior Leadership and Governance]]
- [[Investors and Shareholders]]
- [[Product and Business Owners]]

## Relevant Proxies

- Maximum achievable throughput
- Cost per transaction as scale increases
- Infrastructure cost growth rate
- Geographic deployment coverage

## How It Connects

- [[Performance]] — performance and scalability are related; performance at scale is different from baseline performance
- [[Cost Efficiency]] — scaling has cost implications
- [[Architecture]] — scaling requires architectural consideration

## Tags

#quality-attribute #stub
