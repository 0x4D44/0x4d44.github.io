# Security

**Is the system protected from unauthorized access and attack?** Confidentiality, integrity, authentication, authorisation, and vulnerability resistance.

Security breaks down into multiple sub-categories: confidentiality (keeping data secret), integrity (preventing unauthorized changes), authentication (verifying identity), authorisation (controlling what authenticated users can do), and resilience against attack. The sub-group heuristic applies strongly—security in payment systems differs significantly from security in public APIs. Security requires attention across design, implementation, dependencies, and ongoing monitoring.

## Who Typically Cares

- [[Security Stakeholders]]
- [[Regulators and Compliance Bodies]]
- [[Society and The Public]]

## Relevant Proxies

- Dependency vulnerability scan results
- Static analysis findings
- Penetration test results
- Security patch latency

## How It Connects

- [[Data Integrity]] — integrity is one aspect of security
- [[Privacy]] — overlaps with confidentiality
- [[Compliance]] — security is often a compliance requirement
- [[Heuristic 1 - The Sub-Group Heuristic]] — security categories vary by context

## Tags

#quality-attribute #stub
