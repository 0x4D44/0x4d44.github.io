# Deployability

**How easy is it to get changes into production?** CI/CD pipelines, rollback capability, deployment automation.

Deployability is about how easily, safely, and frequently changes can be released into production. This includes: are deployments automated? Can you roll back quickly if something goes wrong? How many manual steps are required? What's the risk of deployment? How long does a deployment take? High deployability enables rapid iteration and reduces risk through smaller, more frequent changes.

## Who Typically Cares

- [[The Development Team]]
- [[Operations and Support Teams]]

## Relevant Proxies

- Deployment frequency
- Deployment failure rate
- Lead time for changes (from code commit to production)
- Deployment cycle time

## How It Connects

- [[Extensibility]] — frequent deployments enable feature iteration
- [[Operability]] — deployment is an operational concern
- [[Recoverability]] — good deployment practices enable recovery

## Tags

#quality-attribute #stub
