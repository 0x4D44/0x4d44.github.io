# Privacy

**Is personal data handled correctly?** GDPR compliance, consent, data minimisation, right to erasure.

Privacy is about protecting personal data and respecting user rights. This includes: is personal data only collected with consent? Is data minimised (only what's needed)? Can users access their data? Can users request erasure? Are you compliant with GDPR, CCPA, and other privacy regulations? Privacy breaches damage trust and carry legal consequences.

## Who Typically Cares

- [[Regulators and Compliance Bodies]]
- [[Society and The Public]]
- [[End Users and Customers]]

## Relevant Proxies

- Privacy impact assessment completeness
- Consent management effectiveness
- Data minimisation verification
- Privacy policy clarity

## How It Connects

- [[Security]] — privacy overlaps with confidentiality
- [[Compliance]] — privacy is increasingly legally mandated
- [[Ethics]] — privacy is a fundamental right

## Tags

#quality-attribute #stub
