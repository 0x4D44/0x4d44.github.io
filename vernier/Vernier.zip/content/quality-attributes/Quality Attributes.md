# Quality Attributes — What Stakeholders Care About

These are the areas of quality that [[Stakeholders]] might care about. Not all matter for every project — the whole point is to identify which ones matter most for *your* context, based on who your stakeholders are and what they value.

The sub-group heuristic applies here: many of these break down into sub-categories that may need separate attention. See [[Heuristic 1 - The Sub-Group Heuristic]].

## The Reference List

- [[Functional Correctness]]
- [[Performance]]
- [[Reliability]]
- [[Availability]]
- [[Resilience]]
- [[Security]]
- [[Usability]]
- [[Accessibility]]
- [[Diagnosability]]
- [[Debuggability]]
- [[Maintainability]]
- [[Extensibility]]
- [[Testability]]
- [[Deployability]]
- [[Operability]]
- [[Scalability]]
- [[Portability]]
- [[Interoperability]]
- [[Data Integrity]]
- [[Privacy]]
- [[Compliance]]
- [[Internationalisation and Localisation]]
- [[Cost Efficiency]]
- [[Documentation]]
- [[Reproducibility]]
- [[Recoverability]]
- [[Auditability]]
- [[Observability]]
- [[Forecastability]]
- [[Ramp-Up-Ability]]

## Cross-Cutting

- [[Quality Attribute Relationships]] — How attributes relate to each other (dependencies, tensions, trade-offs)
- [[Code Coverage Levels]] — Technical deep dive on line, branch, MC/DC coverage

## How It Connects

- [[Quality]] — Quality attributes are what stakeholders value.
- [[Stakeholders]] — Each stakeholder cares about different attributes.
- [[Proxies]] — Proxies measure quality attributes indirectly.
- [[Heuristic 1 - The Sub-Group Heuristic]] — Many attributes break down into sub-categories.

## See Also

- [Unpack Don't Collapse](quality-strategy/concept-unpack-dont-collapse.md) — Why composite dimensions need breaking down into sub-dimensions
- [The H/M/L/None Rating System](quality-strategy/concept-hml-none-rating.md) — How to rate the importance of each quality dimension per release

## Tags

#core-concept #quality-attribute #overview
