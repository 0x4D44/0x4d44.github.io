# Observability

**Can you see what's happening, even when nothing's wrong?** Usage patterns, system behaviour, resource utilisation.

Observability is about having visibility into the running system during normal operation. This includes: can you see traffic patterns? Can you track resource usage? Can you understand which features are being used and by whom? Can you detect anomalies? How much can you infer about system behaviour from metrics and logs? Observability is distinct from [[Diagnosability]]—observability is about the normal state, diagnosability about the broken state. Observability pairs with [[Forecastability]]: observability tells you what's happening *now*, forecastability tells you what's *about to* happen.

## Who Typically Cares

- [[Operations and Support Teams]]
- [[Senior Leadership and Governance]]

## Relevant Proxies

- Error rate in logs
- Metric collection coverage
- Log completeness
- Dashboard functionality

## How It Connects

- [[Diagnosability]] — observability in the normal state, diagnosability in failure
- [[Forecastability]] — observability now, forecastability later
- [[Operability]] — observability enables effective operation
- [[Auditability]] — audit trails are one form of observation
- [[Testability]] — related: testability is about learning through interaction, observability about visibility during normal running
- [[Proxies]] — observability is something you design in; see "Design for Measurability"

## Tags

#quality-attribute #stub
