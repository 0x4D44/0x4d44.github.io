# Usability

**How easy is it to use?** Learnability, efficiency of use, error prevention, user satisfaction.

Usability encompasses how easily users can learn and efficiently use a system. It includes learnability (how quickly someone can start using it), efficiency of use (how fast an experienced user can operate), error prevention (how well it prevents user mistakes), and satisfaction (whether users feel good using it). Note: for AI agents and programmatic consumers, usability translates to API consistency, clear semantics, and predictable behavior.

## Who Typically Cares

- [[End Users and Customers]]
- [[The Market and Potential Customers]]

## Relevant Proxies

- User satisfaction ratings
- Time to first successful task
- Error rate in common workflows
- API consistency metrics (for agents)

## How It Connects

- [[Accessibility]] — overlaps with usability; accessibility focuses on disability accommodations
- [[Documentation]] — good docs support usability
- [[Ramp-Up-Ability]] — usability for new users specifically

## Tags

#quality-attribute #stub
