# Accessibility

**Can people with disabilities use it?** WCAG compliance, assistive technology support, inclusive design.

Accessibility could be considered a sub-category of [[Usability]] or standalone, depending on context. It focuses on ensuring that people with disabilities—visual, auditory, motor, or cognitive—can effectively use the system. This includes compliance with standards like WCAG (Web Content Accessibility Guidelines) and thoughtful support for assistive technologies. Accessibility is both an ethical imperative and increasingly a legal requirement.

## Who Typically Cares

- [[End Users and Customers]]
- [[Society and The Public]]
- [[Regulators and Compliance Bodies]]

## Relevant Proxies

- WCAG compliance level (A, AA, AAA)
- Accessibility audit findings
- Assistive technology compatibility

## How It Connects

- [[Usability]] — accessibility is increasingly considered part of usability
- [[Compliance]] — accessibility is often a regulatory requirement
- [[Quality]] — quality includes everyone

## Tags

#quality-attribute #stub
