# Reproducibility

**Given the same inputs, do you get the same outputs?** Deterministic behaviour, seed control, test environment consistency.

Reproducibility is about whether a system produces consistent, predictable results given the same inputs. This includes: can you reproduce a reported bug reliably? Does the system behave deterministically (or if probabilistic, can you control the randomness)? Can you set up identical test environments? Are builds reproducible? High reproducibility is essential for debugging, testing, and understanding system behaviour.

## Who Typically Cares

- [[The Development Team]]
- [[Operations and Support Teams]]

## Relevant Proxies

- Build reproducibility percentage
- Bug reproduction success rate
- Flaky test count
- Environment consistency score

## How It Connects

- [[Debuggability]] — reproducibility is essential for debugging
- [[Testability]] — reproducible behaviour is easier to test
- [[Reliability]] — reproducibility enables reliability verification

## Tags

#quality-attribute #stub
