# Reliability

**Does it keep working over time?** Uptime, mean time between failures, consistency of behaviour.

Reliability is about whether the system continues to function correctly over extended periods. It's related to but not the same as [[Availability]]—a system can be reliable when it's running but unavailable due to deployment or infrastructure issues. Reliability is measured through uptime metrics, mean time between failures (MTBF), and consistency of behaviour across time.

## Who Typically Cares

- [[End Users and Customers]]
- [[Operations and Support Teams]]
- [[Senior Leadership and Governance]]

## Relevant Proxies

- Deployment failure rate
- Build success rate
- Uptime percentage
- Mean time between failures

## How It Connects

- [[Availability]] — related but distinct; reliability is about maintaining function, availability is about accessibility
- [[Resilience]] — reliability is the baseline, resilience is what happens when things go wrong

## Tags

#quality-attribute #stub
