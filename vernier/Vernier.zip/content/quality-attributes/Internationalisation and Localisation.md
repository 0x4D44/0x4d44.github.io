# Internationalisation and Localisation

**Does it work across languages, regions, currencies, and date formats?** i18n/l10n support, regional adaptation.

Internationalisation (i18n) is the process of designing systems to support multiple languages and regions; localisation (l10n) is the actual adaptation for a specific region. This includes: can you easily change the language? Do you handle different currencies, date formats, and regional conventions? Is text separable from code? Are character encodings handled correctly? For global products, i18n/l10n is essential; for regional products, it may not matter much.

## Who Typically Cares

- [[End Users and Customers]]
- [[The Market and Potential Customers]]

## Relevant Proxies

- Supported language count
- Localisation completeness percentage
- Regional testing coverage
- Currency/locale support breadth

## How It Connects

- [[Usability]] — localization improves usability for non-English speakers
- [[Scalability]] — global reach requires i18n/l10n
- [[Heuristic 1 - The Sub-Group Heuristic]] — needs vary by region

## Tags

#quality-attribute #stub
