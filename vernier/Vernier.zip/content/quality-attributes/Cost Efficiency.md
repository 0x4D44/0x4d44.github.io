# Cost Efficiency

**What does it cost to run?** Infrastructure costs, licensing, cost per transaction, operational overhead.

Cost efficiency is about the total economic cost of developing, deploying, and operating the system. This includes: what are infrastructure costs? Are there licensing fees? What's the cost per transaction? What's the operational overhead? While cost is often a driver, it's frequently in tension with other quality attributes—the cheapest solution may not be the most secure, reliable, or scalable.

## Who Typically Cares

- [[Senior Leadership and Governance]]
- [[Investors and Shareholders]]
- [[Product and Business Owners]]

## Relevant Proxies

- Infrastructure cost per revenue unit
- Cost per transaction
- Operational cost as percentage of revenue
- Development cost per feature

## How It Connects

- [[Scalability]] — scaling has cost implications
- [[Portability]] — vendor lock-in affects costs
- [[Quality Attribute Relationships]] — cost is in tension with many other attributes

## Tags

#quality-attribute #stub
