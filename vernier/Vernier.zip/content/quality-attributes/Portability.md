# Portability

**Can it run in different environments?** Cloud providers, on-premise, different operating systems.

Portability is about whether the system can run on different platforms, cloud providers, or infrastructure setups without major changes. This includes: is it OS-agnostic? Can you move from one cloud provider to another? Can you run on-premise or cloud? Does it depend on specific hardware? High portability provides flexibility and reduces lock-in to specific vendors or platforms.

## Who Typically Cares

- [[Operations and Support Teams]]
- [[Senior Leadership and Governance]]

## Relevant Proxies

- Dependency count (fewer is more portable)
- Dependency freshness/stability
- Number of supported platforms
- Platform-specific code percentage

## How It Connects

- [[Cost Efficiency]] — portability can reduce vendor lock-in costs
- [[Operability]] — portability affects where and how you operate
- [[Reliability]] — multi-platform support can improve reliability

## Tags

#quality-attribute #stub
