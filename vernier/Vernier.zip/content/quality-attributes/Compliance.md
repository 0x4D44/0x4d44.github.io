# Compliance

**Does it meet the specific rules for its industry?** Regulatory requirements, standards adherence, audit readiness.

Compliance is about meeting the legal, regulatory, and industry-specific requirements that apply to your system. This might include financial regulations (PCI-DSS, SOX), healthcare (HIPAA), data protection (GDPR), accessibility (WCAG), or domain-specific standards. Compliance varies dramatically by industry and context. The sub-group heuristic applies—compliance requirements break down by regulator and standard.

## Who Typically Cares

- [[Regulators and Compliance Bodies]]
- [[Senior Leadership and Governance]]

## Relevant Proxies

- Compliance audit pass rate
- Regulatory violation count
- Time to demonstrate compliance
- Audit trail completeness

## How It Connects

- [[Privacy]] — privacy compliance is one form of compliance
- [[Security]] — security compliance is another form
- [[Auditability]] — compliance often requires audit trails
- [[Documentation]] — compliance requires documented processes

## Tags

#quality-attribute #stub
