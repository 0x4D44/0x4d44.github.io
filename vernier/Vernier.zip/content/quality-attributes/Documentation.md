# Documentation

**Is it well documented?** User guides, API docs, developer guides, operator runbooks.

Documentation includes user manuals, API documentation, developer guides, deployment runbooks, architecture diagrams, and decision records. Good documentation accelerates onboarding, reduces support burden, enables knowledge transfer, and preserves institutional knowledge. Documentation needs differ by audience—developers need different docs than operators or end users.

## Who Typically Cares

- [[The Development Team]]
- [[Operations and Support Teams]]
- [[Partner and Integration Consumers]]
- [[End Users and Customers]]

## Relevant Proxies

- Documentation coverage percentage
- Issues resolved by reading docs
- Time to bring up new person/system
- Documentation freshness (days since last update)

## How It Connects

- [[Ramp-Up-Ability]] — documentation supports onboarding
- [[Usability]] — good docs improve usability
- [[Interoperability]] — APIs need good documentation
- [[Heuristic 1 - The Sub-Group Heuristic]] — documentation needs vary by audience

## Tags

#quality-attribute #stub
