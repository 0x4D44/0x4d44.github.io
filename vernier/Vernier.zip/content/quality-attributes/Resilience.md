# Resilience

**What happens when things go wrong?** Graceful degradation, recovery time, fault tolerance.

Resilience is about how a system behaves under failure conditions. A resilient system doesn't just break when something goes wrong—it may degrade gracefully, isolate faults, recover automatically, or fail in a controlled way. Resilience is measured through recovery time, degree of graceful degradation, and fault tolerance—the ability to continue operating despite component failures.

## Who Typically Cares

- [[Operations and Support Teams]]
- [[Senior Leadership and Governance]]

## Relevant Proxies

- MTTR (mean time to recovery) from deployment failure
- Graceful degradation percentage
- Fault isolation effectiveness

## How It Connects

- [[Availability]] — resilience improves availability by enabling faster recovery
- [[Reliability]] — both contribute to a functioning system
- [[Observability]] — you need to see failures to recover from them

## Tags

#quality-attribute #stub
