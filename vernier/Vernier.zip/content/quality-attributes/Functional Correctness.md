# Functional Correctness

**Does it do what it's supposed to do?** The right answers, the right behaviour.

Functional correctness is about whether the system produces the correct outputs for given inputs and exhibits the expected behaviour according to its specification. This is the baseline quality attribute—if the system doesn't do what it's supposed to do, nothing else matters much.

## Who Typically Cares

- [[End Users and Customers]]
- [[Product and Business Owners]]

## Relevant Proxies

- Unit test pass rate
- End-to-end test pass rate
- Change failure rate

## How It Connects

- [[Testing]] — functional correctness is proven through testing
- [[Quality]] — the foundation of all quality

## Tags

#quality-attribute #stub
