# Diagnosability

**How easy is it to figure out what's going wrong?** Logging, error messages, traceability.

Diagnosability is about how easy it is to understand the root cause of a failure or unexpected behaviour. It includes clear, informative error messages; comprehensive logging that captures context; and traceability that lets you follow a request or transaction through the system. Diagnosability is distinct from [[Observability]]—diagnosability focuses on the broken state, observability on the normal running state.

## Who Typically Cares

- [[Operations and Support Teams]]
- [[The Development Team]]

## Relevant Proxies

- Average number of reproductions before fix is understood
- Misdiagnosed issues count
- Log completeness score

## How It Connects

- [[Observability]] — related but distinct; observability is for the normal state
- [[Debuggability]] — diagnosability tells you what's wrong, debuggability helps you fix it
- [[Operability]] — both support running systems in production

## Tags

#quality-attribute #stub
