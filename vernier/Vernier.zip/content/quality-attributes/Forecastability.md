# Forecastability

**Can you see problems coming before they arrive?** Trending metrics, threshold warnings, pattern recognition, capacity projections.

Forecastability is about the ability to predict problems and degradation before they impact users. This includes: can you trend metrics to see increases in latency or errors? Can you project when you'll hit capacity limits? Can you recognize patterns of degrading behaviour (e.g., increasing CPU load over time, load spikes reaching a threshold)? Can you predict customer churn or feature demand? Forecastability pairs with [[Observability]]: observability tells you what's happening *now*, forecastability tells you what's *about to* happen.

## Who Typically Cares

- [[Operations and Support Teams]]
- [[Senior Leadership and Governance]]
- [[Product and Business Owners]]

## Relevant Proxies

- Mean time to detection before impact
- Forecast accuracy
- Capacity planning accuracy
- Trend detection latency

## How It Connects

- [[Observability]] — forecasting requires observability as input
- [[Operability]] — forecastability enables proactive operation
- [[Scalability]] — capacity forecasting supports scaling decisions

## Tags

#quality-attribute #stub
