# Performance

**How fast does it respond?** Throughput, latency, response time under various loads.

Performance breaks down into at least: throughput (amount of work done in a time period), latency/response time (how quickly a single request completes), capacity under load (how much work can be handled), and scalability (how behaviour changes as load grows). The sub-group heuristic applies strongly—which performance characteristic matters most depends on your context.

## Who Typically Cares

- [[End Users and Customers]]
- [[Partner and Integration Consumers]]

## Relevant Proxies

- API response time
- Throughput
- P95 / P99 latency

## How It Connects

- [[Scalability]] — related but distinct; performance is about speed, scalability is about how speed changes with load
- [[Heuristic 1 - The Sub-Group Heuristic]] — performance breaks down into multiple sub-categories

## Tags

#quality-attribute #stub
