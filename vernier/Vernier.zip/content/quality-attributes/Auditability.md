# Auditability

**Can you demonstrate what happened, when, and why?** Audit trails, decision logs, compliance evidence.

Auditability is about the system's ability to provide evidence of what occurred, when it occurred, and who or what caused it. This includes: do you have audit trails of all significant events? Can you reconstruct a sequence of actions? Can you prove compliance? Can you answer "who changed this data and when?" Auditability is often a compliance requirement and is essential for security investigations, fraud detection, and accountability.

## Who Typically Cares

- [[Regulators and Compliance Bodies]]
- [[Security Stakeholders]]
- [[Senior Leadership and Governance]]

## Relevant Proxies

- Audit trail completeness
- Event logging coverage
- Auditability test pass rate
- Compliance evidence availability

## How It Connects

- [[Compliance]] — auditability often satisfies compliance requirements
- [[Security]] — audit trails support security investigations
- [[Observability]] — audit trails are a form of observability with immutable records
- [[Privacy]] — audit trails can demonstrate privacy compliance

## Tags

#quality-attribute #stub
