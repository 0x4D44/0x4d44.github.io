# Ramp-Up-Ability

**How quickly can a new person become productive?** Onboarding speed, learning materials, clear structure.

Ramp-up-ability is the time and effort required for a new person to become productive. Critically, this is different for different roles: a new developer needs to learn the codebase, a new QA person needs to understand how to test it, a new support person needs to understand how to diagnose and resolve issues. The sub-group heuristic applies—learnability for whom? See [[Heuristic 1 - The Sub-Group Heuristic]]. Connections to [[Tacit Knowledge and Agents]]—tacit knowledge is the main reason ramp-up is slow. High ramp-up-ability enables faster scaling of teams and better knowledge distribution.

## Who Typically Cares

- [[The Development Team]]
- [[Operations and Support Teams]]

## Relevant Proxies

- Time to first commit
- Time to first production deployment
- Time to first independent incident response
- Linting violations (readability)
- Type safety level
- Cyclomatic complexity

## How It Connects

- [[Maintainability]] — maintainable code is easier to learn
- [[Documentation]] — good docs accelerate ramp-up
- [[Testability]] — tests serve as documentation and examples
- [[Heuristic 1 - The Sub-Group Heuristic]] — ramp-up needs vary by role

## Tags

#quality-attribute #stub
