# Debuggability

**How easy is it to reproduce and fix issues once found?** Isolated test cases, clear dependencies, repeatable scenarios.

Debuggability is about how easily a developer or operator can reproduce an issue and trace through the code or system to understand and fix the cause. This includes: can you reproduce the issue reliably? Can you isolate variables to narrow down the problem? Can you step through code or trace execution? Do you have good tools for inspection and analysis? Debuggability is related to [[Diagnosability]] but focuses on the fix rather than the diagnosis.

## Who Typically Cares

- [[The Development Team]]
- [[Operations and Support Teams]]

## Relevant Proxies

- Time to fix issues (after diagnosis)
- Debugger/tracing tool coverage
- Test reproduction success rate

## How It Connects

- [[Diagnosability]] — diagnosability identifies the problem, debuggability fixes it
- [[Testability]] — testability helps you reproduce behaviour
- [[Maintainability]] — clear code aids debugging

## Tags

#quality-attribute #stub
