# Availability

**Can people get to it when they need it?** Accessibility of the system when required.

Availability is about whether users can access the system when they need it. It's related to [[Reliability]] but distinct—a system can be highly reliable when running but become unavailable during deployments, infrastructure changes, or due to external factors. Availability is typically measured as a percentage of time the system is accessible (e.g., 99.9% uptime).

## Who Typically Cares

- [[End Users and Customers]]
- [[Operations and Support Teams]]

## Relevant Proxies

- Uptime percentage
- Downtime duration
- Mean time to recovery (MTTR)

## How It Connects

- [[Reliability]] — related but distinct; both matter for a functioning system
- [[Resilience]] — resilience determines recovery speed after failures

## Tags

#quality-attribute #stub
