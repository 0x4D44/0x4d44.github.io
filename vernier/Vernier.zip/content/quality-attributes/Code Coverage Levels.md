# Code Coverage Levels

**Technical deep dive: Line, branch, and MC/DC (Modified Condition/Decision Coverage) coverage.**

Code coverage measures how much of your code is executed during testing. But not all coverage is created equal. Different levels have different strengths, costs, and usefulness.

## Line Coverage

**What it measures:** Has each line of code been executed at least once?

**Strength:** Cheap to measure and report. Easy to understand. Catches obviously untested code.

**Weakness:** Easy to game. You can execute a line without testing all its behaviour. A line with `if condition: doThing()` counts as covered if you execute it once, whether the condition is true or false.

**Cost:** Low. Most tools measure this automatically.

**When appropriate:** Baseline metric. Don't rely on it alone.

## Branch Coverage

**What it measures:** Has each path through conditional logic been executed? For an `if/else`, both the true and false branches.

**Strength:** Harder to game than line coverage. Forces you to test different conditional outcomes. Catches some logic errors.

**Weakness:** Still imperfect. Complex conditions with multiple branches (e.g., `if A or B or C`) may not be fully exercised. A condition may be true in one branch but false in another—you might not catch that.

**Cost:** Moderate. Requires deliberate test design.

**When appropriate:** Most projects. Reasonable coverage target is 70-80% branch coverage.

## MC/DC Coverage (Modified Condition/Decision Coverage)

**What it measures:** Each condition in a decision (boolean expression) has been evaluated to both true and false, AND each condition change affects the overall decision outcome independently.

**Strength:** Hardest to game. Forces thorough testing of complex logic. Catches subtle logic errors like wrong operators (`&&` vs `||`). Required by safety-critical standards (aviation, medical, automotive).

**Weakness:** Expensive to achieve. Requires careful test design. Can be overkill for non-critical code.

**Cost:** High. Requires specialized tools and deliberate test strategy.

**When appropriate:** Safety-critical or security-critical code. Financial systems with complex decision logic. Code that's hard to fix if wrong.

## Guidance for Agents

When instructing an agent to "increase coverage," specify which level:

- **Default (if unspecified):** Agents will pursue line coverage first (cheapest)
- **For better quality:** Specify branch coverage explicitly
- **For critical paths:** Specify MC/DC coverage for the most important decision points

Example:
- "Increase branch coverage to 80%" — specific, actionable
- "Improve coverage of the payment logic to MC/DC" — targets the critical path
- "Increase coverage" — ambiguous; expect line coverage focus

## How It Connects

- [[Testability]] — coverage measures how well you can test the system
- [[Proxies - Dev Tooling]] — coverage is a key proxy for testing quality
- [[Heuristic 1 - The Sub-Group Heuristic]] — coverage needs vary by code criticality
- [[Heuristic 8 - Malicious Compliance Check]] — watch for teams gaming coverage metrics

## Tags

#technical #proxies #priority #stub #backlog
