# Recoverability

**If something goes catastrophically wrong, can you get back to a good state?** Backups, disaster recovery, point-in-time restore.

Recoverability is about the system's ability to restore to a previous good state if disaster strikes—data corruption, accidental deletion, catastrophic failure, or security breach. This includes: how frequently are backups taken? Can you restore to a point in time? How long does recovery take? How much data loss is acceptable? Recoverability is a safety net—you need it rarely but desperately when you do.

## Who Typically Cares

- [[Operations and Support Teams]]
- [[Senior Leadership and Governance]]

## Relevant Proxies

- MTTR (mean time to recovery) from data loss
- Backup frequency
- Recovery test success rate
- Maximum acceptable data loss (RPO)

## How It Connects

- [[Reliability]] — recoverability handles failures that bypass reliability
- [[Data Integrity]] — recovery restores integrity after corruption
- [[Operability]] — recovery is an operational procedure

## Tags

#quality-attribute #stub
