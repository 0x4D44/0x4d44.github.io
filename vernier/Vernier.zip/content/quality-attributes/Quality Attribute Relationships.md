# Quality Attribute Relationships

**How quality attributes relate to each other: dependencies, tensions, and trade-offs.**

Quality attributes don't exist in isolation. Some attributes enable or depend on others; many are in tension—improving one may degrade another. Understanding these relationships is essential for making coherent quality decisions.

## Dependencies

Some attributes depend on others:

- [[Extensibility]] requires [[Maintainability]]—you can't easily extend unmaintainable code
- [[Scalability]] may require sacrifice of [[Cost Efficiency]]
- [[Interoperability]] requires [[Documentation]]

## Tensions and Trade-Offs

Many attributes are in tension:

- **Security vs. Usability** — More security often means more friction
- **Cost Efficiency vs. Reliability** — Redundancy costs money
- **Performance vs. Maintainability** — Highly optimized code may be harder to understand
- **Feature Velocity (Extensibility) vs. Code Quality (Maintainability)** — Adding features quickly may create technical debt

## Stakeholder Priorities

Different stakeholders prioritize attributes differently. Your job is to:

1. Identify which quality attributes matter for your context
2. Identify stakeholder priorities
3. Navigate trade-offs explicitly rather than by accident

See [[Stakeholders]] and [[Quality Attributes]].

## See Also

- [Unpack Don't Collapse](quality-strategy/concept-unpack-dont-collapse.md) — Unpacking reveals the tensions and dependencies between attributes

## Tags

#cross-cutting #stub #backlog
