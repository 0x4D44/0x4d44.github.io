# Maintainability

**How easy is it to change the code?** Readability, modularity, low technical debt.

Maintainability is about how easy it is for developers to understand, modify, and extend existing code. A maintainable codebase has clear structure, readable code, minimal duplication, good separation of concerns, and low levels of technical debt. Maintainability directly impacts development velocity—the easier code is to change safely, the faster teams can deliver new features and fixes.

## Who Typically Cares

- [[The Development Team]]
- [[Product and Business Owners]]

## Relevant Proxies

- Cyclomatic complexity
- Code duplication percentage
- Linting violations
- TODO/FIXME count
- Build time
- Code review cycle time

## How It Connects

- [[Extensibility]] — maintainability enables extensibility
- [[Testability]] — testable code tends to be more maintainable
- [[Ramp-Up-Ability]] — maintainable code is easier to learn

## Tags

#quality-attribute #stub
