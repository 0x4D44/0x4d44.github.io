# Testability

**How easy is it to learn about the quality of the code when you interact with it?**

Testability is broader than the common definition "can I write tests against it." **The core definition: testability is how easy it is to discover the actual state and behavior of a system through interaction and observation.** This encompasses: Can I tell if it's doing what it should? Can I observe its behaviour meaningfully? Can I isolate things to understand cause and effect? Can I get useful signal from running it, poking it, exploring it? Can I vary inputs and see how outputs change?

Testability connects directly to [[Testing]] as investigation—if testing is "finding out what's actually true," then testability is "how easy does the system make that discovery?" Dependency injection and mockable interfaces are *mechanisms* that might help testability, but testability itself is about how learnable the system's actual quality is through interaction.

## Who Typically Cares

- [[The Development Team]]
- [[Operations and Support Teams]]

## Relevant Proxies

- Mutation testing survival rate (how many mutants are caught by tests)
- Flaky test rate
- Test execution time
- Code coverage (see [[Code Coverage Levels]])
- Time to diagnose behaviour

## How It Connects

- [[Testing]] — testability enables effective testing
- [[Debuggability]] — testability helps isolate and understand issues
- [[Maintainability]] — testable code tends toward better structure
- [[Code Coverage Levels]] — a technical proxy for testability
- [[Proxies]] — testability is something you design in, not retrofit; see "Design for Measurability"
- [[Observability]] — related: observability is about seeing the running system, testability about learning from interacting with it

## Old World / New World

Agents benefit from high testability—systems with observable state changes, clear cause-and-effect, and meaningful feedback signals are easier for agents to learn about through exploration and trial.

## Tags

#quality-attribute #priority #stub
