# Operability

**How easy is it to run and manage in production?** Monitoring, configuration, alerting, backup/restore.

Operability is about how well a system can be operated once it's deployed. This includes: how easy is it to monitor? Can you configure it for different environments? Are alerts meaningful? How do you perform backups and restores? Can you scale it? Is it easy to diagnose problems? A highly operable system minimizes the operational burden and enables small teams to manage large, complex systems.

## Who Typically Cares

- [[Operations and Support Teams]]
- [[Senior Leadership and Governance]]

## Relevant Proxies

- MTTR (mean time to recovery)
- Deployment frequency
- Alert signal-to-noise ratio
- Configuration complexity

## How It Connects

- [[Diagnosability]] — operability requires visibility into the system
- [[Observability]] — you need data to operate effectively
- [[Recoverability]] — operability includes recovery procedures

## Tags

#quality-attribute #stub
