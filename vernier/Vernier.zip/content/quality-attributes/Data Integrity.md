# Data Integrity

**Is data accurate, consistent, uncorrupted, and not lost?** Data validation, consistency checks, durability.

Data integrity is about whether data remains accurate, consistent, and uncorrupted throughout its lifecycle. This includes: does the system prevent invalid data from being stored? Are updates transactional and consistent? Can data be corrupted by concurrency issues or system failures? Is data properly backed up and recoverable? Poor data integrity erodes trust and can have severe business consequences.

## Who Typically Cares

- [[Regulators and Compliance Bodies]]
- [[Security Stakeholders]]
- [[End Users and Customers]]
- [[Senior Leadership and Governance]]

## Relevant Proxies

- Data validation rule violations
- Constraint violation rate
- Corruption detection rate
- Recovery test success rate

## How It Connects

- [[Security]] — integrity is one aspect of security
- [[Reliability]] — reliable systems maintain data integrity
- [[Recoverability]] — you need to recover data when corruption is discovered
- [[Compliance]] — data integrity is often a compliance requirement

## Tags

#quality-attribute #stub
