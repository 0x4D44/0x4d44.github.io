# Smells

**A smell is the intuitive feeling that something isn't right — before you can articulate exactly what's wrong or why.**

Experienced engineers develop a sense for when something is off. A requirement that's too vague, a metric that's moving the wrong way, an architecture that feels brittle, a conversation where the real concern isn't being said. These reactions aren't random — they're the product of years of pattern recognition, but the patterns are often tacit. The engineer feels the discomfort before they can name it.

This section of the knowledge base is an attempt to make those instincts explicit: to describe and explain the "this doesn't feel right" reactions, what triggers them, what they usually point to, and what to do when you notice one.

## Why Smells Matter

Smells are early warning signals. They fire before you have evidence, before the data confirms a problem, often before anyone else in the room has noticed. They're not proof — they're a prompt to investigate. The correct response to a smell is not "fix it" but "dig into it." See [[Testing]] — investigation to find out what's actually true.

The danger of ignoring smells is that you miss problems early when they're cheap to address. The danger of over-reacting to smells is that you chase phantoms. The skill is in calibrating: take the smell seriously enough to investigate, but don't treat it as a conclusion. See [[Heuristic 21 - State Confidence Levels Explicitly]] — a smell is low-confidence, high-alertness.

## Smells and Tacit Knowledge

Smells are one of the purest forms of [[Tacit Knowledge and Agents|tacit knowledge]]. They live entirely in the expert's head as pattern-matched intuition. This makes them:

- **Extremely valuable** — they compress years of experience into instant reactions
- **Extremely hard to transfer** — "it just feels wrong" doesn't help a new engineer or an agent
- **Exactly what this KB should capture** — making smells explicit is one of the highest-leverage things we can do for both human ramp-up and agent capability

The [[Techniques for Extracting Tacit Knowledge|Socratic method]] is the best way to extract smells: "What made you uncomfortable about that? What were you comparing it to in your head? What's the worst thing this could mean?"

## Smells and Agents

Agents don't have smells. They don't get the uneasy feeling that something's off. They process inputs and produce outputs without the pattern-matched discomfort that would make a human pause. This is one of their most significant blind spots — see [[Heuristic 12 - Agents Don't Get Tired But Have Blind Spots]].

Making smells explicit in this KB serves a dual purpose: it gives agents specific things to check for (turning intuition into checklists), and it gives humans a vocabulary for the discomfort they feel but can't yet name.

## How to Read a Smell Entry

Each smell in this section follows a loose structure:

- **The feeling** — what the discomfort is, what triggers it
- **What it usually points to** — the underlying problems this smell tends to indicate
- **What to do** — how to investigate, what questions to ask, what to look for
- **Connections** — which parts of the KB it relates to

Smells aren't rules. A smell that fires doesn't always mean there's a problem. But it always means there's a question worth asking.

## Smell Index

*Individual smells will be added below as they're captured.*

## How It Connects

- [[Tacit Knowledge and Agents]] — smells are tacit knowledge made explicit
- [[Context]] — smells often fire when context is missing or misunderstood
- [[Testing]] — the response to a smell is investigation
- [[Risk]] — smells are informal risk signals
- [[Heuristic 24 - Understand the Why Before You Act]] — a smell is a signal that you might not understand the why
- [[Heuristic 19 - Explicitly Check and Record Assumptions]] — smells often point to unchecked assumptions
- [[Techniques for Extracting Tacit Knowledge]] — Socratic questioning is how you extract smells from experts

## See Also

- [Learning from Bugs at Four Levels](quality-strategy/concept-learning-from-bugs.md) — Smells are often the first indicator; bugs can be learned from at four levels

## Tags

#smells #overview #tacit-knowledge
