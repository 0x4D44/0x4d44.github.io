# Quality

**Quality is value to someone who matters.**

This is the foundational definition. Everything else in this knowledge base flows from it. It originates with Jerry Weinberg and is understood in the context of context-driven testing (CDT).

## Key Implications

- Quality is not a property of the product — it's a relationship between the product and a person (or agent) who cares.
- The same product can be simultaneously high quality and low quality depending on whose perspective you take.
- If you don't know who matters and what they value, you cannot assess quality. You literally don't know what the word means for your project.
- Everyone in the organisation needs to understand this definition.

## How It Connects

The definition unpacks into three questions:

1. **"Someone who matters"** → [[Stakeholders]] — Who are the people (and agents) whose perspective on value counts?
2. **"Value"** → [[Quality Attributes]] — What specifically do those stakeholders value? The -ilities and beyond.
3. **How do we know?** → [[Testing]] — How do we investigate whether the product actually delivers that value?

Danger to quality is [[Risk]]. We measure quality indirectly through [[Proxies]]. And all quality work is governed by the [[Economics of Testing]].

All of this is contextual — understanding *why* stakeholders care is as important as knowing *what* they care about. See [[Context]] and [[Heuristic 24 - Understand the Why Before You Act]].

## Old World / New World

In the agent era, "someone who matters" increasingly includes agents as stakeholders — see [[Heuristic 10 - Any Stakeholder Could Be an Agent]]. Quality for agent-stakeholders is different from quality for human-stakeholders: agents care about consistency, predictability, and documentation quality rather than usability.

## See Also

- [Quality — The Core Definition (Quality Strategy)](quality-strategy/concept-quality-definition.md) — Extended exploration of this definition with implications for AI agents
- [How to Create a Quality Strategy](quality-strategy/process-how-to-create-a-quality-strategy.md) — Step-by-step process that operationalises quality thinking

## Tags

#core-concept #foundation