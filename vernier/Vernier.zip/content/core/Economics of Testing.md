# Economics of Testing

**All testing is a trade-off of time/energy vs value.**

We're typically interested in getting the most added value (improved quality) for the energy/time/tokens invested. So we need to know how to focus our testing in areas where there's most likely to be a difference between reality and what we want.

## The Core Truth

You will never have enough time to test everything. The entire game is about getting the most quality improvement for the time you invest. The single most valuable skill in testing is deciding what to test — and you can only do that if you understand [[Quality]] and [[Risk]].

## How It Connects

- What counts as "value" comes from [[Quality]] and [[Stakeholders]].
- Where to focus comes from [[Risk]].
- [[Proxies]] help measure whether the investment is paying off.
- The economics change radically in the agent era — see [[Heuristic 9 - Don't Import Old-World Costs]].

## Old World / New World

Agents have radically different cost/time/error profiles than humans. Things that were "not worth testing" under human cost constraints may become trivial for agents. The economics of [[Testing]] need to be recalculated for every context where agents are involved.

See also: [[Heuristic 13 - Economics of Checking vs Investigating Shift with Agents]]

## See Also

- [The Economics of Testing (Quality Strategy)](quality-strategy/concept-economics-of-testing.md) — Extended treatment of testing economics and trade-offs

## Tags

#core-concept #foundation