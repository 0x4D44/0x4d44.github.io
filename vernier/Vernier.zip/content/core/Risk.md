# Risk

**Risk is danger to quality.**

It comes in two forms:

## Unknown Risk

We don't know enough about an area to know if the quality matches what we want. What is the potential impact of any gaps here that we don't know about?

There is a cost to test and find out the state.

## Known Risk

We know enough about an area to know that the quality is not what we ideally want. What's the impact of that gap?

There is a cost to do work to improve the quality.

## How It Connects

- Risk is always relative to [[Quality]] — it's danger to value for [[Stakeholders]].
- Risk drives where to focus [[Testing]] effort — see [[Economics of Testing]].
- [[Proxies]] help identify and track risk areas.
- [[Code Churn]] is a useful proxy for identifying high-risk areas.

## See Also

- [Risk as Danger to Quality (Quality Strategy)](quality-strategy/concept-risk.md) — Unknown vs known risk; risk drives focus
- [Risk Map vs Risk Register](quality-strategy/concept-risk-map-vs-register.md) — Quality gap analysis with confidence overlay

## Tags

#core-concept #foundation