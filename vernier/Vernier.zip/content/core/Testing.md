# Testing

**Testing is the act of investigating to find out what the actual truth is.**

Testing is investigation to understand the world (or product) as it actually is. When the world as it actually is differs from the world as we want it to be, that's a "bug" or "missing feature" or whatever.

Testing doesn't directly find bugs — it enables us to identify gaps between reality and what we want.

## Two Parts of Testing

- **Checking** — Confirming that specific things work the way we expect. Mechanical, repeatable, automatable.
- **Investigating** — Discovering what's actually going on, especially in the places we didn't expect. Creative, exploratory, human-judgment-heavy (though agents can do some of this).

Most teams pour almost all their effort into checking and almost none into investigation. That's the imbalance to fix.

## Testing Starts at the Start

Testing is not something that happens at the end. It starts at the start of the project and goes throughout.

- "What is your architecture (and why?)" requires testing thinking.
- The quality strategy and testing strategy are for the whole project before you start creating — not only when you get to a "test phase."
- **"Test phase" is a terrible idea and should not exist.**
- Recording your thoughts, hypotheses, observations happens throughout the project, not in a phase at the end.
- Measurement starts at the start too — know what [[Proxies]] you want to measure before you build, and design the product to make them easy to collect.

## How It Connects

- Testing exists to assess [[Quality]] — whether the product delivers value to [[Stakeholders]].
- What to test is driven by [[Risk]] — where the gaps between reality and desire are most dangerous.
- How much to test is governed by the [[Economics of Testing]].
- [[Testability]] is the quality attribute that measures how easy the system makes testing.
- [[Proxies]] are the indirect signals we use when we can't measure quality directly.

## Old World / New World

The balance between checking and investigating shifts dramatically with agents — see [[Heuristic 13 - Economics of Checking vs Investigating Shift with Agents]]. Checking becomes nearly free. Investigation is where human and agent effort should be rebalanced.

Agent output also needs different review than human output — see [[Heuristic 14 - Agent Output Needs Different Review]].

## See Also

- [Testing — What It Actually Is (Quality Strategy)](quality-strategy/concept-testing-definition.md) — Checking vs investigating distinction
- [Testing Starts at the Start](quality-strategy/concept-testing-starts-at-the-start.md) — Why testing thinking belongs from day one
- [Testing Without Seeing the Code](quality-strategy/concept-testing-without-seeing-code.md) — Independence of perspective in testing

## Tags

#core-concept #foundation