# Proxies

**Proxies are measurable things that we can measure and use to infer the level of quality in a particular area. Proxies are not actually the quality level itself.**

It's hard to measure [[Quality]] in all its different aspects, so we choose proxies. We want to identify and build in measuring of them as part of the project in order to provide data to measure the quality.

Most people just end up tracking bug counts — there's way more you can do.

## What Makes a Good Proxy

Not all proxies are equal. A good proxy has some combination of these qualities:

**Closeness to the real thing.** The best proxies enumerate something close to what the person who matters actually values. A proxy that is tightly coupled to the real quality attribute it's measuring is far more useful than one with a loose or indirect relationship. "Customer-reported functional issues" is a closer proxy for functional correctness than "lines of code changed" — though neither is the thing itself.

**Honest precision.** A good proxy is usefully and correctly precise — not spuriously so. A proxy that gives you a meaningful "high / medium / low" is better than one that gives you "87.3%" when that number implies a calibration you don't actually have. Over-precision is actively harmful because it discourages further investigation and creates false confidence. See [[Heuristic 23 - Don't Use Spurious Precision]].

**Ease of measurement.** Proxies you can actually measure cheaply and reliably are more useful than theoretically perfect ones you can't practically collect. This matters because you'll be measuring them repeatedly over time — see [[Heuristic 5 - Trend Lines Beat Absolute Numbers]]. A proxy that's expensive or painful to collect won't get collected consistently, and inconsistent data is worse than no data.

**Complementary blind spots.** Every proxy has blind spots — see [[Heuristic 6 - Know Your Proxy's Blind Spots]]. A set of proxies is good when the blind spots of one are covered by another in the same area. This is the practical application of [[Heuristic 3 - Use Multiple Proxies]]: you're not just using multiple proxies for redundancy, you're choosing proxies whose blind spots don't overlap, so together they give you a much more complete picture than any one alone.

## Design for Measurability

There's an important corollary to "proxies are more useful if they're easy to measure": **you should build measurability into the product and its surrounding processes.** Don't treat measurement as an afterthought — design the system so that the proxies you care about are naturally easy to collect.

This means thinking about your proxies *before* you build. If you know you want to measure diagnostic turnaround time, build structured logging and traceability in from the start. If you want to track deployment failure rate, instrument your deployment pipeline. If customer satisfaction matters, build feedback mechanisms into the product rather than bolting on a survey later.

The principle is: **know what proxies you want to measure before you build the product, and then build the product to make those proxies easy to measure.** This is part of the broader point that [[Testing]] starts at the start — and so does measurement. Deciding what to measure is a design-time decision, not a post-launch scramble.

This connects to [[Testability]] and [[Observability]] — both are quality attributes that make it easier to learn about the system's quality, and both benefit enormously from being designed in rather than retrofitted.

## Heuristics for Using Proxies

- Use multiple proxies, not just one — see [[Heuristic 3 - Use Multiple Proxies]]
- Proxies are not quality — see [[Heuristic 4 - Proxies Are Not Quality]]
- Trend lines beat absolute numbers — see [[Heuristic 5 - Trend Lines Beat Absolute Numbers]]
- Know what your proxy doesn't tell you — see [[Heuristic 6 - Know Your Proxy's Blind Spots]]
- Proxies are gameable (Goodhart's Law) — see [[Heuristic 7 - Proxies Are Gameable]]
- Apply the malicious compliance check for agents — see [[Heuristic 8 - Malicious Compliance Check]]

## Proxy Collections

- [[Proxies - Blog Post]] — Proxies from "Measurable Quality Bars," organised by quality area
- [[Proxies - Dev Tooling]] — Proxies from standard development tools, mapped to quality attributes with signal strength ratings

## How It Connects

- Every proxy maps to one or more [[Quality Attributes]].
- Proxy choice is governed by the [[Economics of Testing]] — measure what gives you the best signal for the cost.
- [[Risk]] helps determine which proxies matter most.
- Agents will game proxies faster than humans — see [[Proxy Blind Spots and Gaming Risks]].

## See Also

- [Actual vs Perceived Quality](quality-strategy/concept-actual-vs-perceived-quality.md) — Proxies can inflate perceived quality without improving actual quality

## Tags

#core-concept #foundation