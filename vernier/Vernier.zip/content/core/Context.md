# Context

**All quality is contextual. If you don't understand the context, you don't understand the quality.**

The [[Quality]] definition — "value to someone who matters" — is inherently context-dependent. The same product feature can be critical or irrelevant depending on who's using it, what they're trying to achieve, and why they care. Context is the thing that turns the abstract definition into something you can actually act on.

## Why Context Comes First

Knowing *what* stakeholders care about is not enough. You need to understand *why* they care about it. The "why" is the context — and without it, you'll optimise for the wrong things, test the wrong areas, and measure the wrong proxies.

A stakeholder says "we need 99.9% uptime." Why? Because they have a regulatory obligation? Because their customers are in a different timezone and use the system overnight? Because they got burned by an outage last quarter and the CEO is breathing down their neck? Each "why" leads to a different response — different architecture, different testing focus, different trade-offs. The number is the same, but the context changes everything.

This applies at every level:
- **Quality attributes** — *why* does this stakeholder care about performance? Is it user experience, cost efficiency, or competitive pressure? The answer changes which aspects of performance matter.
- **Risk** — *why* is this area risky? Is it new code, complex integration, regulatory exposure, or historical fragility? The answer changes how you investigate.
- **Proxies** — *why* are you measuring this? What decision will the measurement inform? A proxy without a clear purpose is noise.
- **Testing** — *why* are you testing this? What question are you trying to answer? A test without a clear question is busywork.

## The General Principle

There's a broader truth here that extends well beyond quality: **in almost any situation, you need to understand the "why" before you take action.** This isn't just good practice — it's the difference between effective action and confident misdirection.

See [[Heuristic 24 - Understand the Why Before You Act]].

The discipline is:
1. Before acting, ask yourself: do I understand *why* this matters?
2. Honestly assess your confidence in that understanding.
3. If you're not confident — genuinely confident, not just "I've got a plausible story" confident — then ask. Get the context. Understand the why.
4. Only then act.

This is especially critical for agents, who will confidently proceed without context unless explicitly designed to pause and ask. Humans at least have the social instinct to sense when something feels off and ask a question. Agents don't — they fill the gap with a plausible assumption and move on. See [[Heuristic 19 - Explicitly Check and Record Assumptions]] and [[Heuristic 20 - Ask More Questions Make Fewer Assumptions]].

## The Socratic Method — How You Get Context

The primary technique for uncovering context is Socratic questioning — probing, open-ended questions that lead people to articulate the reasoning behind their needs and decisions. Don't accept requirements at face value. Ask *why*. When someone says "we need X," ask what happens without it, who's affected, what the real cost is, what they tried before.

Stakeholders often state solutions rather than problems, or surface-level needs rather than root motivations. Skilled Socratic questioning uncovers the real picture — the actual needs, constraints, and fears driving the stated requirement. This is the fundamental skill for building [[Context]] when working with [[Stakeholders]].

This applies whether the interviewer is human or agent. Agents need to be designed to ask Socratic questions rather than accepting inputs and proceeding — see [[Heuristic 20 - Ask More Questions Make Fewer Assumptions]].

## Context-Driven Testing

The name says it all. Context-driven testing (CDT) is the philosophical foundation of this knowledge base — the principle that the right approach to quality and testing depends entirely on the context. There are no universal best practices, only practices that are best *in a given context*.

This doesn't mean "anything goes." It means the burden is on you to understand the context well enough to make good decisions. And if you don't understand it, the first decision is to go and find out.

## How It Connects

- [[Quality]] — context determines what quality means for any given project
- [[Stakeholders]] — understanding context means understanding why stakeholders care, not just what they want
- [[Risk]] — risk assessment requires understanding context, not just listing threats
- [[Economics of Testing]] — the right trade-offs depend entirely on context
- [[Heuristic 24 - Understand the Why Before You Act]] — the general principle extracted from this
- [[Heuristic 19 - Explicitly Check and Record Assumptions]] — assumptions are often gaps in context
- [[Heuristic 20 - Ask More Questions Make Fewer Assumptions]] — asking is how you get context

## Old World / New World

Humans absorb context osmotically — through conversations, shared history, reading the room. Agents get none of this unless you provide it explicitly. An agent given a task without context will complete it mechanically, optimising for the literal instruction rather than the underlying intent. The most dangerous agent failure mode is confidently solving the wrong problem because it never asked "why?"

Designing agent workflows that pause to gather and verify context — rather than proceeding on assumptions — is one of the highest-leverage things you can do. See [[Tacit Knowledge and Agents]].

## See Also

- [Process Context in Quality Strategy](quality-strategy/concept-process-context.md) — How release workflow shapes quality planning

## Tags

#core-concept #foundation
