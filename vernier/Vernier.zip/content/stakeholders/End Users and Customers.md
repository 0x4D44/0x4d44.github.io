# End Users and Customers

People who actually use the software day-to-day to accomplish their work or personal goals. This is often the largest and most diverse stakeholder category.

## Sub-Groups to Consider

Apply [[Heuristic 2 - Sub-Group Heuristic for Stakeholders]] — are there meaningfully different sub-groups here?

- **Retail customers** — Typically use consumer-facing features, care about ease of use and speed
- **Business/enterprise users** — Often need advanced features, audit trails, bulk processing, integrations
- **Internal staff users** — Use the same software internally, may have different support needs and use patterns
- **Novice vs. expert users** — Novices care about onboarding and help; experts care about power and efficiency
- **Users in different contexts** — Mobile vs. desktop, offline vs. connected, high-pressure vs. leisurely use

## Quality Attributes They Typically Care About

- [[Functional Correctness]] — Does it do what they need?
- [[Usability]] — Can they accomplish their goals without frustration?
- [[Performance]] — Is it fast enough for their workflow?
- [[Reliability]] — Does it work consistently without unexpected failures?
- [[Accessibility]] — Can people with disabilities use it effectively?

## Agent Considerations

When end users are agents (AI systems, bots, automated processes):
- Agents don't care about visual design or subjective usability
- They care intensely about **API consistency**, **predictability**, and **complete documentation**
- Agents need deterministic behavior and clear error codes, not helpful error messages
- They value **machine-readable formats** (JSON, structured responses) over human-friendly text
- Performance becomes critical: even small latency multiplies across millions of requests

## Related Pages

- [[Stakeholders]] — master checklist
- [[Quality]] — what quality means
- [[Heuristic 2 - Sub-Group Heuristic for Stakeholders]]
- [[Heuristic 10 - Any Stakeholder Could Be an Agent]]

> [!info] Status: Stub
> This page needs expansion with specific examples, worked scenarios, and deeper sub-group analysis.

## Tags

#stakeholder #stub
