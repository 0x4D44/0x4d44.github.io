# Operations and Support Teams

People who keep the software running in production and deal with problems reported by end users. They are the bridge between end users and the development team.

## Sub-Groups to Consider

Apply [[Heuristic 2 - Sub-Group Heuristic for Stakeholders]] — are there meaningfully different sub-groups here?

- **L1/L2 support** — Handle incoming user problems; need clear error messages, self-service diagnostics, good runbooks for common issues; success = resolve without escalation
- **L3/On-call engineers** — Debug complex issues; need comprehensive logging, reproducible scenarios, clear root cause identification
- **Operations/SRE teams** — Keep the service running; care about monitoring, alerting, deployment safety, quick incident response
- **Customer success teams** — Proactive support; care about feature usability, configuration clarity, early warning of issues
- **Release/deployment teams** — Manage deployments; care about backwards compatibility, clear changelogs, safe rollback procedures

## Quality Attributes They Typically Care About

- [[Diagnosability]] — Can you quickly figure out what went wrong?
- [[Debuggability]] — Can you trace the issue to root cause?
- [[Operability]] — Can you run, monitor, and control the system safely?
- [[Reliability]] — How often do problems occur in the first place?
- [[Observability]] — Can you see what's happening inside the system?

## Agent Considerations

When operations and support are handled by agents (automated remediation, AI monitoring, chatbots):
- Agent-based support **cannot negotiate or explain**; it needs unambiguous, deterministic diagnostics
- Agents require **structured, machine-readable logs** and **clear error classification** to route issues correctly
- **Self-healing automation** changes what "diagnosability" means: the system itself must identify and fix problems
- Agents need **algorithmic escalation criteria**, not human judgment; thresholds and rules must be explicit
- Performance of diagnostic logic becomes critical: slow detection = expensive downtime

## Related Pages

- [[Stakeholders]] — master checklist
- [[Quality]] — what quality means
- [[Heuristic 2 - Sub-Group Heuristic for Stakeholders]]
- [[Heuristic 10 - Any Stakeholder Could Be an Agent]]

> [!info] Status: Stub
> This page needs expansion with specific examples, worked scenarios, and deeper sub-group analysis.

## Tags

#stakeholder #stub
