# Society and The Public

Relevant when software has broad impact on health, safety, environment, civil rights, or access to essential services. These are external stakeholders without direct commercial relationship but with legitimate stakes.

## Sub-Groups to Consider

Apply [[Heuristic 2 - Sub-Group Heuristic for Stakeholders]] — are there meaningfully different sub-groups here?

- **Affected communities** — Live with the impact of your software (e.g., residents in smart city pilots, patients in health tech); care about safety, fairness, and being heard
- **Advocacy/civil rights organizations** — Protect vulnerable groups (disability advocates, racial justice, worker advocates); care about discrimination, exclusion, accessibility
- **Environmental stakeholders** — When software affects resource consumption, emissions, or natural systems; care about sustainability and externalities
- **Journalists/media** — Cover and scrutinize major software products; care about transparency and ability to report on impact
- **General public** — When software is critical infrastructure or widely used; care about safety, privacy, and responsible deployment
- **Future generations** — Rarely represented directly; long-term impacts (data permanence, resource decisions, AI harms)

## Quality Attributes They Typically Care About

- [[Security]] — Is personal or critical data protected?
- [[Privacy]] — Are privacy rights respected?
- [[Accessibility]] — Does everyone get equal access?
- [[Data Integrity]] — Is information accurate and not manipulated?
- [[Compliance]] — Does the product follow ethical and legal standards?

## Agent Considerations

When AI systems affect society at scale (algorithmic hiring, credit decisions, content moderation, surveillance):
- **Society-scale agents need extreme auditability and explainability**: decisions affecting millions of people must be understandable
- **Bias and fairness become existential**: AI amplifies biases in training data and optimization criteria
- **Agent decisions have power but lack accountability**: if an AI denies your loan or job, there's no one to appeal to
- **Unintended consequences** scale rapidly: an algorithm that works for group A may systematically harm group B
- **Transparency vs. gaming**: revealing how an agent decides allows adversaries to manipulate it
- **Proxy discrimination**: agents optimizing for one metric may inadvertently discriminate based on correlated protected attributes
- **Feedback loops**: agent decisions affect the data that trains the next generation of agents, creating compounding problems

## Related Pages

- [[Stakeholders]] — master checklist
- [[Quality]] — what quality means
- [[Heuristic 2 - Sub-Group Heuristic for Stakeholders]]
- [[Heuristic 10 - Any Stakeholder Could Be an Agent]]

> [!info] Status: Stub
> This page needs expansion with specific examples, worked scenarios, and deeper sub-group analysis.

## Tags

#stakeholder #stub
