# Paying Customers

People who make the buying decision and control the budget, often distinct from the end users who actually use the software. This stakeholder group drives commercial viability.

## Sub-Groups to Consider

Apply [[Heuristic 2 - Sub-Group Heuristic for Stakeholders]] — are there meaningfully different sub-groups here?

- **Enterprise buyers** — Evaluate on TCO, risk, compliance, vendor stability; lengthy procurement; need ROI justification
- **SMB self-serve customers** — Make fast decisions based on price and quick value perception; need simple trial or freemium model
- **Procurement departments** — Focus on contract terms, vendor management, compliance certification, SLA commitments
- **Finance stakeholders** — Care about cost predictability, licensing models, audit trails for spend
- **Technical evaluators** — May bridge buying and using; validate that the product meets stated requirements

## Quality Attributes They Typically Care About

- [[Cost Efficiency]] — Total cost of ownership, licensing model, scaling economics
- [[Reliability]] — Uptime guarantees, SLA compliance, proven track record
- [[Security]] — Data protection, compliance certifications, incident response
- [[Compliance]] — Regulatory requirements, audit readiness, contractual obligations

## Agent Considerations

When paying customers are agents (AI procurement systems, algorithmic buyers, automated license managers):
- Agents evaluate based on **machine-readable specs**: documented SLAs, API response times, cost algorithms
- They compare vendors using **objective, measurable criteria** rather than relationship or reputation
- Procurement agents need **standardized contract terms** and **automated billing integration**
- They care about **programmatic audit trails** and **real-time usage reporting** for cost optimization
- Determinism and predictability are essential: agents cannot negotiate or make exceptions

## Related Pages

- [[Stakeholders]] — master checklist
- [[Quality]] — what quality means
- [[Heuristic 2 - Sub-Group Heuristic for Stakeholders]]
- [[Heuristic 10 - Any Stakeholder Could Be an Agent]]

> [!info] Status: Stub
> This page needs expansion with specific examples, worked scenarios, and deeper sub-group analysis.

## Tags

#stakeholder #stub
