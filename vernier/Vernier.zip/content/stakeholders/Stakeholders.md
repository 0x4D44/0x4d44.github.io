# Stakeholders — Who Matters

The [[Quality]] definition says quality is value to **someone who matters**. Stakeholders are the "someone who matters." If you don't know who they are and what they value, you cannot assess quality.

## The Reference Checklist

This is a starting checklist of stakeholder categories for a software project. Use it to make sure you don't forget a whole category. The real work is always: for *this* project, *which specific* stakeholders exist under each heading, and what do *they* specifically care about?

1. [[End Users and Customers]]
2. [[Paying Customers]]
3. [[Operations and Support Teams]]
4. [[The Development Team]]
5. [[Product and Business Owners]]
6. [[Regulators and Compliance Bodies]]
7. [[Security Stakeholders]]
8. [[Partner and Integration Consumers]]
9. [[Senior Leadership and Governance]]
10. [[Investors and Shareholders]]
11. [[The Market and Potential Customers]]
12. [[Society and The Public]]

## The Splitting Principle

**For every stakeholder category, actively ask: "Are there meaningfully different sub-groups here who care about different things or who we care about serving to different levels?"**

See [[Heuristic 2 - Sub-Group Heuristic for Stakeholders]].

The top-level list is a prompt to think. The value is always in the specific sub-groups and what they specifically care about. A quality definition that just says "end users" is doing half the work. One that says "retail customers who care about speed, business customers who care about audit trails, and internal staff who care about bulk processing" is doing the real work.

## Agent Stakeholders

Any stakeholder category could include agents rather than (or as well as) humans. Agents value different things — an agent consuming your API doesn't care about usability but cares intensely about consistency, predictability, and documentation quality.

Quality for agent-stakeholders is different from quality for human-stakeholders, and that's fine. Track both if they differ.

See [[Heuristic 10 - Any Stakeholder Could Be an Agent]].

## Understanding Why Stakeholders Care

Knowing *what* stakeholders want is only half the work. You need to understand *why* they care — the underlying needs, fears, constraints, and motivations behind their stated requirements. See [[Context]] and [[Heuristic 24 - Understand the Why Before You Act]].

The key technique for uncovering this is the **Socratic method**: don't just take requirements at face value. Ask probing, open-ended questions that lead stakeholders to articulate the reasoning behind their needs. "We need 99.9% uptime" — why? What happens if you don't hit that? Who's affected? What's the actual cost of downtime? Each answer reveals more context, and the context is what lets you make good quality decisions.

The Socratic approach works because stakeholders often state solutions rather than problems, or surface-level needs rather than root motivations. Skilled questioning uncovers the real picture. This applies whether the interviewer is a human or an agent — though agents need to be explicitly designed to ask rather than assume. See [[Heuristic 20 - Ask More Questions Make Fewer Assumptions]].

## How It Connects

- Stakeholders define what [[Quality]] means for a given project.
- Each stakeholder cares about different [[Quality Attributes]].
- [[Risk]] is assessed relative to what stakeholders value.
- [[Proxies]] are chosen to measure what stakeholders care about.
- [[Context]] — understanding stakeholder motivations is how you build context.

## See Also

- [The Stakeholder Four-Lens Framework](quality-strategy/concept-four-lens-framework.md) — Delight / Discussed / Good Enough / Dealbreaker framework for each stakeholder
- [The Old World / New World Bias Trap](quality-strategy/concept-old-world-new-world-bias.md) — Check whether stakeholders might be agents, not humans

## Tags

#core-concept #stakeholders
