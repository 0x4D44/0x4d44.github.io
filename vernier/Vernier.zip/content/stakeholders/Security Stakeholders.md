# Security Stakeholders

Internal security teams and external auditors who assess and protect against security risks. They care about resilience to attack and detection of breaches.

## Sub-Groups to Consider

Apply [[Heuristic 2 - Sub-Group Heuristic for Stakeholders]] — are there meaningfully different sub-groups here?

- **Security operations/blue team** — Monitor for attacks, respond to incidents, maintain security posture; care about observability and rapid response
- **Information security (CISO, security architects)** — Define security strategy, assess risk, ensure compliance with security standards
- **Penetration testers/red team** — Find vulnerabilities before attackers do; care about testability and clarity of attack surface
- **External auditors/assessors** — Validate security controls against standards (ISO 27001, SOC 2, etc.); care about documentation and auditability
- **Security researchers/bug bounty programs** — Find and report vulnerabilities; care about responsible disclosure processes
- **Application security engineers** — Embedded in development teams; care about secure coding practices and security testing in CI/CD

## Quality Attributes They Typically Care About

- [[Security]] — Is the system resilient to known and plausible attack vectors?
- [[Auditability]] — Can you prove security controls are in place and working?
- [[Compliance]] — Do security practices meet standards and regulations?
- [[Data Integrity]] — Is data protected from unauthorized modification?
- [[Observability]] — Can you detect when security controls are violated?

## Agent Considerations

When security is managed by agents (AI security scanning, automated threat detection, anomaly detection):
- **Automated scanning** needs comprehensive vulnerability databases and clear classification of risk severity
- Agents need **structured security telemetry**: logs from firewalls, intrusion detection, application events
- **False positive management** is critical: agents that cry wolf too often get ignored
- Agents may **optimize incorrectly**: maximizing detection rate at the cost of unacceptable false positives
- **Adversarial robustness** is a concern: attackers might specifically evade AI detection systems
- Agents need **clear escalation thresholds**: what looks like an attack vs. normal behavior variation

## Related Pages

- [[Stakeholders]] — master checklist
- [[Quality]] — what quality means
- [[Heuristic 2 - Sub-Group Heuristic for Stakeholders]]
- [[Heuristic 10 - Any Stakeholder Could Be an Agent]]

> [!info] Status: Stub
> This page needs expansion with specific examples, worked scenarios, and deeper sub-group analysis.

## Tags

#stakeholder #stub
