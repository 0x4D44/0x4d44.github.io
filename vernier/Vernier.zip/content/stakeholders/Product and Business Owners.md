# Product and Business Owners

People accountable for commercial success, defining what gets built and prioritizing work. They care about delivering value to customers and hitting business goals.

## Sub-Groups to Consider

Apply [[Heuristic 2 - Sub-Group Heuristic for Stakeholders]] — are there meaningfully different sub-groups here?

- **Product managers** — Define features, prioritize roadmap, represent end-user needs; care about fit-for-purpose and user satisfaction
- **Business analysts** — Translate business goals into requirements; care about completeness and correctness of specification
- **Commercial/sales leads** — Care about competitive positioning, deal-closing features, time-to-market for high-value features
- **Operations managers** — Care about reliability and uptime (they get escalated when things break)
- **Marketing** — Care about performance benchmarks, feature completeness, and narrative consistency

## Quality Attributes They Typically Care About

- [[Functional Correctness]] — Does it deliver what customers paid for?
- [[Performance]] — Can we make competitive claims about speed and throughput?
- [[Cost Efficiency]] — Can we build this profitably? How much infrastructure does it need?
- [[Extensibility]] — Can we add the next feature request without major delay?

## Agent Considerations

When product/business decisions are made by agents (AI product managers, algorithmic prioritization, automated A/B test analysis):
- Agents **prioritize based on measurable signals**: revenue impact, user metrics, cost-benefit ratios
- They need **complete, machine-readable product telemetry** and **A/B testing infrastructure**
- Agents make decisions differently than humans: they may optimize for short-term metrics, miss context, or find unintuitive solutions
- **Data quality** becomes critical: agents amplify biased or incomplete data
- Agents may struggle with **qualitative feedback** (user delight, brand coherence) that humans naturally balance

## Related Pages

- [[Stakeholders]] — master checklist
- [[Quality]] — what quality means
- [[Heuristic 2 - Sub-Group Heuristic for Stakeholders]]
- [[Heuristic 10 - Any Stakeholder Could Be an Agent]]

> [!info] Status: Stub
> This page needs expansion with specific examples, worked scenarios, and deeper sub-group analysis.

## Tags

#stakeholder #stub
