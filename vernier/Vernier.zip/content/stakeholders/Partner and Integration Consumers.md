# Partner and Integration Consumers

Other teams or companies whose systems depend on yours via APIs, data feeds, webhooks, or integrations. They consume your product as a component or service.

## Sub-Groups to Consider

Apply [[Heuristic 2 - Sub-Group Heuristic for Stakeholders]] — are there meaningfully different sub-groups here?

- **Internal teams** — Other departments or services within the same organization; often have less formal SLA expectations but close coupling
- **Partner/vendor integrations** — External companies with contractual relationships; care about SLA guarantees and predictable behavior
- **Open-source consumers** — Projects depending on your library; care about backwards compatibility and long-term stability
- **Platform/marketplace participants** — Apps built on top of your platform; need clear API contracts, good documentation, and change notification
- **Data consumers** — Teams or systems that read data feeds or reports; care about data freshness, completeness, and accuracy

## Quality Attributes They Typically Care About

- [[Interoperability]] — Can different systems work together reliably?
- [[Reliability]] — Is the service available and stable?
- [[Performance]] — Are response times and throughput acceptable for their use case?
- [[Documentation]] — Is the API/integration clearly documented with examples and support?

## Agent Considerations

When integration consumers are agents (agent-to-agent APIs, automated data pipelines, bot networks):
- **Agent consumers don't negotiate**: they need predictable, deterministic behavior with clear error codes
- **API consistency** is paramount: any deviation from documented behavior breaks automated systems
- Agents need **machine-readable formats** and **complete documentation** (no "just call and see" learning)
- **Backwards compatibility** becomes stricter: upgrading an API can break millions of automations instantly
- Agents detect **subtle inconsistencies** that humans would work around: timing variations, undocumented retry behavior, implicit defaults
- **Rate limiting and throttling** must be explicit and predictable; agents cannot adaptively back off like humans

## Related Pages

- [[Stakeholders]] — master checklist
- [[Quality]] — what quality means
- [[Heuristic 2 - Sub-Group Heuristic for Stakeholders]]
- [[Heuristic 10 - Any Stakeholder Could Be an Agent]]

> [!info] Status: Stub
> This page needs expansion with specific examples, worked scenarios, and deeper sub-group analysis.

## Tags

#stakeholder #stub
