# Regulators and Compliance Bodies

Anyone who can shut you down, fine you, or force you to change your product. These are external parties with enforcement power.

## Sub-Groups to Consider

Apply [[Heuristic 2 - Sub-Group Heuristic for Stakeholders]] — are there meaningfully different sub-groups here?

- **Financial regulators** (e.g., FCA, SEC, FINRA) — Care about audit trails, risk controls, transaction integrity, customer protection
- **Data protection regulators** (e.g., ICO under GDPR, state privacy boards) — Care about consent, data minimization, privacy-by-design, breach notification
- **Industry-specific regulators** (e.g., FDA for healthcare, FAA for aviation) — Define safety requirements, testing standards, documentation obligations
- **Tax authorities** (e.g., HMRC, IRS) — Care about audit trails, calculation correctness, reporting accuracy
- **Labor/employment regulators** — When software affects worker safety or classification
- **Accessibility/civil rights bodies** — When software is public-facing or affects access to services

## Quality Attributes They Typically Care About

- [[Compliance]] — Does the system meet all applicable regulations?
- [[Security]] — Are customer data and system assets protected?
- [[Privacy]] — Are privacy principles respected in design and operation?
- [[Auditability]] — Can you prove to regulators that you meet requirements?
- [[Data Integrity]] — Is data accurate, complete, and not tampered with?

## Agent Considerations

When compliance is monitored by agents (automated compliance checking, regulatory reporting bots, AI audit systems):
- **Regulatory interpretation becomes concrete**: ambiguous rules must be codified into unambiguous logic
- Agents need **complete regulatory specification**: every requirement must be explicit and testable
- **Audit trail quality** must be machine-readable: logs must have timestamps, immutability, and clear attribution
- Agents may find **edge cases and loopholes** that humans miss, changing what "compliance" means
- **False negatives are risky**: agents missing a violation can be worse than no automation
- Agents need **clear escalation rules**: when does a potential violation require human judgment?

## Related Pages

- [[Stakeholders]] — master checklist
- [[Quality]] — what quality means
- [[Heuristic 2 - Sub-Group Heuristic for Stakeholders]]
- [[Heuristic 10 - Any Stakeholder Could Be an Agent]]

> [!info] Status: Stub
> This page needs expansion with specific examples, worked scenarios, and deeper sub-group analysis.

## Tags

#stakeholder #stub
