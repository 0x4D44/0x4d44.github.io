# The Market and Potential Customers

People you're trying to win who haven't chosen you yet. They are evaluating you against competitors and comparing value against alternative solutions.

## Sub-Groups to Consider

Apply [[Heuristic 2 - Sub-Group Heuristic for Stakeholders]] — are there meaningfully different sub-groups here?

- **Prospects in active evaluation** — Considering your product for purchase soon; care about comparison with competitors, time-to-value, implementation ease
- **Prospects unaware of your product** — Not yet in a buying process; reached through marketing; care about problem recognition and vision alignment
- **Switched customers (from competitors)** — Evaluating your product vs. their current tool; especially sensitive to migration friction and feature parity
- **Personas not yet in market** — Future customers for emerging use cases; care about roadmap and vision
- **Market analysts and influencers** — Shape perception through reviews, reports, recommendations; care about innovation, completeness, track record

## Quality Attributes They Typically Care About

- [[Usability]] — Can they get started quickly and intuitively?
- [[Performance]] — Does it feel fast and responsive?
- [[Functional Correctness]] — Does it actually do what you claim it does?

## Agent Considerations

When potential customers are agents (recommendation systems, AI procurement bots, automated market evaluation):
- **Agent evaluators use objective criteria**: feature checklists, API specs, performance benchmarks, cost models
- They compare vendors using **numerical scores and rankings**: who has the most features at the best price?
- Agents may **miss subjective quality**: design elegance, vision alignment, team quality, community feel
- **First impressions matter more**: agents may evaluate based on homepage and API documentation with no allowance for "they explain it better in sales calls"
- Recommendation agents **amplify existing preferences**: if your product is already popular, they recommend it more
- Agents need **machine-readable marketing**: spec sheets, API playgrounds, performance data, not marketing prose

## Related Pages

- [[Stakeholders]] — master checklist
- [[Quality]] — what quality means
- [[Heuristic 2 - Sub-Group Heuristic for Stakeholders]]
- [[Heuristic 10 - Any Stakeholder Could Be an Agent]]

> [!info] Status: Stub
> This page needs expansion with specific examples, worked scenarios, and deeper sub-group analysis.

## Tags

#stakeholder #stub
