# Investors and Shareholders

People with financial stake in company success. They care about return on investment and long-term viability.

## Sub-Groups to Consider

Apply [[Heuristic 2 - Sub-Group Heuristic for Stakeholders]] — are there meaningfully different sub-groups here?

- **VC/private equity investors** — Want growth and exit opportunity; care about addressable market, growth rate, unit economics
- **Public shareholders** — Want consistent returns and positive earnings; care about predictability and risk management
- **Institutional investors** — Large funds with governance oversight; care about risk controls and management quality
- **Founders/employees with equity** — Personal financial stake and identity investment; care about both returns and mission
- **Debt holders/creditors** — Want to be repaid reliably; care about financial stability and cash flow predictability

## Quality Attributes They Typically Care About

- [[Cost Efficiency]] — Are we making efficient use of capital?
- [[Scalability]] — Can we grow revenue faster than costs?
- [[Reliability]] — Can we deliver consistent, predictable results?

## Agent Considerations

When investor decisions are made by agents (algorithmic trading, AI portfolio analysis, automated due diligence):
- **AI investors evaluate using publicly available signals**: financial metrics, growth rates, market signals, technical analysis
- They need **complete, accurate, timely financial reporting** and product metrics
- Agents may **over-optimize short-term metrics** at the expense of long-term value (similar to human traders, but faster and more extreme)
- **Feedback loops matter**: AI investors can amplify market bubbles or create herd behavior
- Agents **struggle with qualitative assessment**: team quality, vision, market narrative, intangible competitive advantages
- **Explainability is low**: investors may want to understand why an agent picked (or avoided) a stock, but the answer is "these 47 signals aligned this way"

## Related Pages

- [[Stakeholders]] — master checklist
- [[Quality]] — what quality means
- [[Heuristic 2 - Sub-Group Heuristic for Stakeholders]]
- [[Heuristic 10 - Any Stakeholder Could Be an Agent]]

> [!info] Status: Stub
> This page needs expansion with specific examples, worked scenarios, and deeper sub-group analysis.

## Tags

#stakeholder #stub
