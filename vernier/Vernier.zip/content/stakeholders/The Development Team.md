# The Development Team

People who live in the codebase, extending it, maintaining it, and debugging problems. They care about code quality from the perspective of long-term productivity and ability to ship.

## Sub-Groups to Consider

Apply [[Heuristic 2 - Sub-Group Heuristic for Stakeholders]] — are there meaningfully different sub-groups here?

- **New/junior developers** — Care about clear architecture, good documentation, low friction onboarding, example code
- **Experienced/senior developers** — Care about extensibility, power of abstractions, ability to optimize, architectural control
- **Frontend developers** — Care about browser compatibility, performance on client, accessibility features, UI testing tools
- **Backend developers** — Care about scalability, database design, API clarity, error handling patterns
- **Full-stack developers** — Need the above across the whole stack
- **Maintainers/reviewers** — Care about code review ease, test coverage, CI/CD feedback loops, regression prevention

## Quality Attributes They Typically Care About

- [[Maintainability]] — Can you understand and modify code safely?
- [[Testability]] — Can you write tests easily and run them quickly?
- [[Extensibility]] — Can you add new features without major refactoring?
- [[Debuggability]] — Can you understand what went wrong when there's a bug?
- [[Ramp-Up-Ability]] — How quickly can a new developer become productive?

## Agent Considerations

When developers are AI agents (code generation, automated refactoring, AI pair programming):
- AI agents **need clear patterns and conventions** to follow consistently
- They care about **complete, accurate documentation** and **well-organized examples**
- Agents struggle with **ambiguous or undocumented implicit behavior**; they need explicitness
- **API consistency** is critical: agents cannot adapt to irregular APIs or special cases
- **Testing infrastructure** becomes more important: agents need instant feedback on correctness
- Automated agents may write code differently than humans (more verbose, different performance characteristics)

## Related Pages

- [[Stakeholders]] — master checklist
- [[Quality]] — what quality means
- [[Heuristic 2 - Sub-Group Heuristic for Stakeholders]]
- [[Heuristic 10 - Any Stakeholder Could Be an Agent]]

> [!info] Status: Stub
> This page needs expansion with specific examples, worked scenarios, and deeper sub-group analysis.

## Tags

#stakeholder #stub
