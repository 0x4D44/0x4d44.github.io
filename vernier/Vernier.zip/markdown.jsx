// Markdown renderer with wikilink support
const { useMemo } = React;

// ---------- Inline parsing ----------
// supports **bold**, *italic*, `code`, [text](url), [[wikilink]], [[wikilink|alias]]
function parseInline(text, ctx, keyPrefix = "i") {
  const out = [];
  let i = 0;
  let buf = "";
  let key = 0;
  const flush = () => {
    if (buf) {
      out.push(buf);
      buf = "";
    }
  };
  while (i < text.length) {
    const ch = text[i];
    const rest = text.slice(i);

    // [[wikilink]] or [[wikilink|alias]]
    let m = rest.match(/^\[\[([^\]|]+)(?:\|([^\]]+))?\]\]/);
    if (m) {
      flush();
      const target = m[1].trim();
      const alias = m[2] ? m[2].trim() : target;
      const id = ctx.resolveWikilink(target);
      const dead = !id;
      out.push(
        <a
          key={keyPrefix + key++}
          className={"wikilink" + (dead ? " dead" : "")}
          href={dead ? undefined : "#/note/" + encodeURIComponent(id)}
          onClick={(e) => {
            if (dead) { e.preventDefault(); return; }
            e.preventDefault();
            ctx.navigate("#/note/" + encodeURIComponent(id));
          }}
        >
          {alias}
        </a>
      );
      i += m[0].length;
      continue;
    }

    // [text](url)
    m = rest.match(/^\[([^\]]+)\]\(([^)]+)\)/);
    if (m) {
      flush();
      const label = m[1];
      const url = m[2];
      // Internal markdown link: resolve to note id when possible
      const isInternal = url.endsWith(".md") || (!/^https?:/i.test(url) && !url.startsWith("mailto:") && !url.startsWith("#"));
      if (isInternal) {
        const tail = url.split("/").pop().replace(/\.md$/, "");
        const id = ctx.resolveWikilink(tail);
        if (id) {
          out.push(
            <a
              key={keyPrefix + key++}
              className="wikilink"
              href={"#/note/" + encodeURIComponent(id)}
              onClick={(e) => { e.preventDefault(); ctx.navigate("#/note/" + encodeURIComponent(id)); }}
            >
              {parseInline(label, ctx, keyPrefix + key + "-")}
            </a>
          );
          i += m[0].length;
          continue;
        }
      }
      out.push(
        <a key={keyPrefix + key++} href={url} target={/^https?:/.test(url) ? "_blank" : undefined} rel="noopener noreferrer">
          {parseInline(label, ctx, keyPrefix + key + "-")}
        </a>
      );
      i += m[0].length;
      continue;
    }

    // **bold**
    m = rest.match(/^\*\*([^*]+)\*\*/);
    if (m) {
      flush();
      out.push(<strong key={keyPrefix + key++}>{parseInline(m[1], ctx, keyPrefix + key + "-")}</strong>);
      i += m[0].length;
      continue;
    }

    // *italic*  (avoid bold case already handled)
    m = rest.match(/^\*([^*\n]+)\*/);
    if (m) {
      flush();
      out.push(<em key={keyPrefix + key++}>{parseInline(m[1], ctx, keyPrefix + key + "-")}</em>);
      i += m[0].length;
      continue;
    }

    // `code`
    m = rest.match(/^`([^`]+)`/);
    if (m) {
      flush();
      out.push(<code key={keyPrefix + key++}>{m[1]}</code>);
      i += m[0].length;
      continue;
    }

    buf += ch;
    i++;
  }
  flush();
  return out;
}

// ---------- Block parsing ----------
function parseBlocks(md) {
  // Strip "## Tags" trailing section (rendered separately as chips)
  // We'll keep #tags removal up to higher layer; here just parse.
  const lines = md.split(/\r?\n/);
  const blocks = [];
  let i = 0;
  while (i < lines.length) {
    let line = lines[i];

    // empty line
    if (line.trim() === "") { i++; continue; }

    // heading
    let m = line.match(/^(#{1,4})\s+(.*)$/);
    if (m) {
      blocks.push({ type: "heading", level: m[1].length, text: m[2].trim() });
      i++;
      continue;
    }

    // hr
    if (/^---+\s*$/.test(line)) {
      blocks.push({ type: "hr" });
      i++;
      continue;
    }

    // blockquote
    if (line.startsWith(">")) {
      const buf = [];
      while (i < lines.length && (lines[i].startsWith(">") || lines[i].trim() === "")) {
        if (lines[i].trim() === "") {
          // peek: if next line is also a quote, treat as paragraph break inside quote
          if (i + 1 < lines.length && lines[i + 1].startsWith(">")) {
            buf.push("");
            i++;
            continue;
          }
          break;
        }
        buf.push(lines[i].replace(/^>\s?/, ""));
        i++;
      }
      blocks.push({ type: "blockquote", lines: buf });
      continue;
    }

    // list
    if (/^\s*[-*+]\s+/.test(line) || /^\s*\d+\.\s+/.test(line)) {
      const items = [];
      const ordered = /^\s*\d+\.\s+/.test(line);
      while (i < lines.length) {
        const l = lines[i];
        const isItem = ordered ? /^\s*\d+\.\s+/.test(l) : /^\s*[-*+]\s+/.test(l);
        if (isItem) {
          const text = l.replace(/^\s*(?:[-*+]|\d+\.)\s+/, "");
          // collect continuation lines (indented or non-list non-empty)
          const buf = [text];
          i++;
          while (i < lines.length) {
            const next = lines[i];
            if (next.trim() === "") break;
            if (/^\s*[-*+]\s+/.test(next) || /^\s*\d+\.\s+/.test(next)) break;
            if (/^(#{1,4})\s+/.test(next)) break;
            buf.push(next.replace(/^\s+/, " "));
            i++;
          }
          items.push(buf.join(" "));
        } else if (l.trim() === "") {
          // peek if next is item
          if (i + 1 < lines.length && ((ordered && /^\s*\d+\.\s+/.test(lines[i + 1])) || (!ordered && /^\s*[-*+]\s+/.test(lines[i + 1])))) {
            i++;
            continue;
          }
          break;
        } else {
          break;
        }
      }
      blocks.push({ type: "list", ordered, items });
      continue;
    }

    // paragraph: accumulate until empty/heading/hr/list/quote
    const buf = [line];
    i++;
    while (i < lines.length) {
      const l = lines[i];
      if (l.trim() === "") break;
      if (/^(#{1,4})\s+/.test(l)) break;
      if (/^---+\s*$/.test(l)) break;
      if (/^\s*[-*+]\s+/.test(l) || /^\s*\d+\.\s+/.test(l)) break;
      if (l.startsWith(">")) break;
      buf.push(l);
      i++;
    }
    blocks.push({ type: "paragraph", text: buf.join(" ") });
  }

  return blocks;
}

// Group blocks into sections by ## headings so we can wrap "Old World / New World"
function groupIntoSections(blocks) {
  const groups = [];
  let current = { kind: "intro", heading: null, blocks: [] };
  for (const b of blocks) {
    if (b.type === "heading" && b.level === 2) {
      if (current.blocks.length || current.heading) groups.push(current);
      current = { kind: classifyHeading(b.text), heading: b, blocks: [] };
    } else {
      current.blocks.push(b);
    }
  }
  if (current.blocks.length || current.heading) groups.push(current);
  return groups;
}

function classifyHeading(text) {
  const t = text.toLowerCase();
  if (t.includes("old world") && t.includes("new world")) return "ow-nw";
  if (t === "tags") return "tags";
  return "section";
}

function MarkdownBlock({ block, ctx, keyId }) {
  if (block.type === "heading") {
    const Tag = "h" + block.level;
    return <Tag>{parseInline(block.text, ctx, keyId + "h")}</Tag>;
  }
  if (block.type === "paragraph") {
    return <p>{parseInline(block.text, ctx, keyId + "p")}</p>;
  }
  if (block.type === "hr") return <hr />;
  if (block.type === "blockquote") {
    // join paragraphs
    const paras = [];
    let cur = [];
    for (const l of block.lines) {
      if (l === "") { if (cur.length) { paras.push(cur.join(" ")); cur = []; } }
      else cur.push(l);
    }
    if (cur.length) paras.push(cur.join(" "));
    return (
      <blockquote>
        {paras.map((p, idx) => <p key={idx}>{parseInline(p, ctx, keyId + "bq" + idx)}</p>)}
      </blockquote>
    );
  }
  if (block.type === "list") {
    const Tag = block.ordered ? "ol" : "ul";
    return (
      <Tag>
        {block.items.map((it, idx) => (
          <li key={idx}>{parseInline(it, ctx, keyId + "li" + idx)}</li>
        ))}
      </Tag>
    );
  }
  return null;
}

function Markdown({ source, ctx }) {
  const groups = useMemo(() => groupIntoSections(parseBlocks(source)), [source]);

  return (
    <div className="md">
      {groups.map((g, gi) => {
        if (g.kind === "tags") return null; // shown separately as chips
        // Filter out the leading H1 title (already shown in the note header)
        const blocks = g.blocks.filter((b) => !(b.type === "heading" && b.level === 1));
        if (g.kind === "ow-nw") {
          return (
            <div className="ow-nw" key={"g" + gi}>
              {g.heading && <h2>{g.heading.text}</h2>}
              {blocks.map((b, bi) => (
                <MarkdownBlock key={"b" + gi + "-" + bi} block={b} ctx={ctx} keyId={"g" + gi + "b" + bi} />
              ))}
            </div>
          );
        }
        return (
          <React.Fragment key={"g" + gi}>
            {g.heading && <h2>{parseInline(g.heading.text, ctx, "gh" + gi)}</h2>}
            {blocks.map((b, bi) => (
              <MarkdownBlock key={"b" + gi + "-" + bi} block={b} ctx={ctx} keyId={"g" + gi + "b" + bi} />
            ))}
          </React.Fragment>
        );
      })}
    </div>
  );
}

window.Markdown = Markdown;
