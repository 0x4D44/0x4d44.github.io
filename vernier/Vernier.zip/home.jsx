// Home page for Vernier
const SECTION_LABELS = {
  "core": "Core concepts",
  "heuristics": "Heuristics",
  "quality-attributes": "Quality attributes",
  "quality-strategy": "Quality strategy",
  "stakeholders": "Stakeholders",
  "agents": "Agents",
  "knowledge-management": "Knowledge management",
  "proxies": "Proxies",
  "smells": "Smells",
};

const SECTION_ORDER = [
  "core", "heuristics", "quality-strategy",
  "quality-attributes", "stakeholders", "proxies",
  "agents", "knowledge-management", "smells",
];

function VernierTicks({ height = 28, density = 1, accentEvery = 5 }) {
  // Draw a row of vernier-style ticks. Two scales offset to evoke the instrument.
  const ticks = 80 * density;
  const items = [];
  for (let i = 0; i < ticks; i++) {
    const x = (i / ticks) * 100;
    const major = i % accentEvery === 0;
    items.push(
      <line
        key={"t" + i}
        x1={x + "%"} y1={major ? "0%" : "25%"}
        x2={x + "%"} y2={major ? "70%" : "55%"}
        stroke={major ? "var(--ink-2)" : "var(--ink-4)"}
        strokeWidth={major ? 1 : 0.6}
      />
    );
  }
  // Lower vernier offset scale
  const ticks2 = 50 * density;
  for (let i = 0; i < ticks2; i++) {
    const x = (i / ticks2) * 60 + 8; // offset
    items.push(
      <line
        key={"v" + i}
        x1={x + "%"} y1="80%"
        x2={x + "%"} y2="100%"
        stroke="var(--accent)"
        strokeWidth={i % 5 === 0 ? 1 : 0.6}
      />
    );
  }
  return (
    <svg viewBox="0 0 1000 80" preserveAspectRatio="none" style={{ height }}>
      {items}
    </svg>
  );
}

function Home({ notes, ctx }) {
  // Curated core entry points
  const coreOrder = ["Quality", "Testing", "Context", "Risk", "Proxies", "Economics of Testing"];
  const coreCards = coreOrder.map((id, i) => {
    const n = notes[id];
    return n ? { ...n, num: String(i + 1).padStart(2, "0") } : null;
  }).filter(Boolean);

  // Heuristics grid — 24 numbered
  const heuristics = Object.values(notes)
    .filter((n) => n.section === "heuristics" && /^Heuristic\s+\d+/.test(n.id))
    .map((n) => {
      const m = n.id.match(/^Heuristic\s+(\d+)\s+-\s+(.+)$/);
      const num = m ? parseInt(m[1]) : 0;
      const short = m ? m[2] : n.title;
      const grp = num <= 2 || num === 24 ? "General" : num <= 8 ? "Proxies" : num <= 14 ? "Agents" : num <= 20 ? "Knowledge" : "Confidence";
      return { ...n, num, short, grp };
    })
    .sort((a, b) => a.num - b.num);

  const qualityAttrs = Object.values(notes)
    .filter((n) => n.section === "quality-attributes" && n.id !== "Quality Attributes" && n.id !== "Quality Attribute Relationships" && n.id !== "Code Coverage Levels")
    .sort((a, b) => a.title.localeCompare(b.title));

  const stakeholders = Object.values(notes)
    .filter((n) => n.section === "stakeholders" && n.id !== "Stakeholders")
    .sort((a, b) => a.title.localeCompare(b.title));

  const strategyConcepts = Object.values(notes)
    .filter((n) => n.section === "quality-strategy" && n.id.startsWith("concept-"))
    .sort((a, b) => a.title.localeCompare(b.title));

  const goto = (id) => ctx.navigate("#/note/" + encodeURIComponent(id));

  return (
    <div className="home">
      <div className="hero-ticks">
        <VernierTicks density={1.4} />
      </div>

      <div className="hero-grid">
        <div>
          <div className="hero-eyebrow">A field guide · est. 2026</div>
          <h1 className="hero-title">Vernier</h1>
          <p className="hero-tagline">A precision instrument for thinking about quality — in a world where the workforce is no longer only human.</p>
          <p className="hero-lede">
            Quality is value to someone who matters. Testing is investigation to find out what's actually true. Everything else — proxies, risk maps, the -ilities, the four-lens framework — is scaffolding around those two definitions.
          </p>
          <p className="hero-lede">
            Vernier collects 114 connected notes: six core concepts, twenty-four heuristics, thirty-three quality attributes, thirteen stakeholder lenses, a quality-strategy process, and a running argument about what changes when the people doing the work are agents.
          </p>
        </div>
        <div className="hero-stats">
          <div>
            <div className="hero-stat-num">114</div>
            <div className="hero-stat-label">linked notes</div>
          </div>
          <div>
            <div className="hero-stat-num">24</div>
            <div className="hero-stat-label">heuristics</div>
          </div>
          <div>
            <div className="hero-stat-num">33</div>
            <div className="hero-stat-label">quality attrs.</div>
          </div>
          <div>
            <div className="hero-stat-num">13</div>
            <div className="hero-stat-label">stakeholders</div>
          </div>
          <div>
            <div className="hero-stat-num">06</div>
            <div className="hero-stat-label">core concepts</div>
          </div>
          <div>
            <div className="hero-stat-num">01</div>
            <div className="hero-stat-label">running thesis</div>
          </div>
        </div>
      </div>

      {/* Core concepts */}
      <div className="section-rule">
        <span className="section-rule-num">§ 01</span>
        <span className="section-rule-title">Begin here · the six core concepts</span>
        <span className="section-rule-line"></span>
      </div>
      <div className="cards-grid">
        {coreCards.map((n) => (
          <div className="card" key={n.id} onClick={() => goto(n.id)}>
            <div className="card-num">CORE · {n.num}</div>
            <h3 className="card-title">{n.title}</h3>
            <p className="card-blurb">{n.excerpt}</p>
          </div>
        ))}
      </div>

      {/* Old World / New World */}
      <div className="section-rule">
        <span className="section-rule-num">§ 02</span>
        <span className="section-rule-title">The running thesis · old world ↔ new world</span>
        <span className="section-rule-line"></span>
      </div>
      <div className="two-col">
        <div className="callout-row">
          <div className="callout-eyebrow">Old world</div>
          <p>Human teams, human stakeholders, human reviewers. Costs anchored to human time. Testing imagined as a phase that happens after building. Tacit knowledge absorbed osmotically through hallways and standups.</p>
        </div>
        <div className="callout-row new">
          <div className="callout-eyebrow">New world</div>
          <p>Agents build, test, and use the product. Checking is nearly free; investigation is the scarce thing. Tacit knowledge is invisible debt — if it isn't written down, it doesn't exist for an agent. Stakeholders include the agents themselves.</p>
        </div>
      </div>

      {/* Heuristics */}
      <div className="section-rule">
        <span className="section-rule-num">§ 03</span>
        <span className="section-rule-title">The twenty-four heuristics · thinking tools, not rules</span>
        <span className="section-rule-line"></span>
      </div>
      <div className="heuristics-grid">
        {heuristics.map((h) => (
          <div className="heur-cell" key={h.id} onClick={() => goto(h.id)}>
            <div className="heur-num">H{String(h.num).padStart(2, "0")} · {h.grp}</div>
            <div className="heur-title">{h.short}</div>
          </div>
        ))}
      </div>

      {/* Quality attributes */}
      <div className="section-rule">
        <span className="section-rule-num">§ 04</span>
        <span className="section-rule-title">Quality attributes · the {qualityAttrs.length} -ilities (and a few non-ilities)</span>
        <span className="section-rule-line"></span>
      </div>
      <div className="attrs-grid">
        {qualityAttrs.map((a) => (
          <div className="attr-pill" key={a.id} onClick={() => goto(a.id)}>
            {a.title}
          </div>
        ))}
      </div>

      {/* Stakeholders */}
      <div className="section-rule">
        <span className="section-rule-num">§ 05</span>
        <span className="section-rule-title">Stakeholders · who matters</span>
        <span className="section-rule-line"></span>
      </div>
      <div className="attrs-grid">
        {stakeholders.map((a) => (
          <div className="attr-pill" key={a.id} onClick={() => goto(a.id)}>
            {a.title}
          </div>
        ))}
      </div>

      {/* Quality strategy */}
      <div className="section-rule">
        <span className="section-rule-num">§ 06</span>
        <span className="section-rule-title">Quality strategy · concepts &amp; process</span>
        <span className="section-rule-line"></span>
      </div>
      <div className="attrs-grid">
        {strategyConcepts.map((a) => (
          <div className="attr-pill" key={a.id} onClick={() => goto(a.id)}>
            {a.title.replace(/ \(.*\)$/, "")}
          </div>
        ))}
      </div>

      <div className="footer-note">
        <span>Vernier · a field guide to quality, testing &amp; agents</span>
        <span>114 notes · cross-linked · built for browsing</span>
      </div>
    </div>
  );
}

window.Home = Home;
window.SECTION_LABELS = SECTION_LABELS;
window.SECTION_ORDER = SECTION_ORDER;
window.VernierTicks = VernierTicks;
