// Vernier — main app
const { useState, useEffect, useMemo, useCallback } = React;

const NOTES = window.NOTES_DATA.notes;

// Build lookup by lowercase title and id for wikilink resolution
const LOOKUP = {};
for (const n of Object.values(NOTES)) {
  LOOKUP[n.title.toLowerCase()] = n.id;
  LOOKUP[n.id.toLowerCase()] = n.id;
}

function resolveWikilink(target) {
  return LOOKUP[target.trim().toLowerCase()] || null;
}

// ---------- Routing ----------
function parseHash() {
  const h = window.location.hash.replace(/^#/, "") || "/";
  const parts = h.split("/").filter(Boolean).map(decodeURIComponent);
  if (parts.length === 0) return { view: "home" };
  if (parts[0] === "note") return { view: "note", id: parts.slice(1).join("/") };
  if (parts[0] === "section") return { view: "section", section: parts[1] };
  if (parts[0] === "tag") return { view: "tag", tag: parts[1] };
  if (parts[0] === "index") return { view: "index" };
  return { view: "home" };
}

function useRoute() {
  const [route, setRoute] = useState(parseHash());
  useEffect(() => {
    const onHash = () => setRoute(parseHash());
    window.addEventListener("hashchange", onHash);
    return () => window.removeEventListener("hashchange", onHash);
  }, []);
  return route;
}

const navigate = (hash) => {
  window.location.hash = hash;
  window.scrollTo(0, 0);
};

// ---------- Sidebar ----------
function Sidebar({ route }) {
  const [query, setQuery] = useState("");
  const [collapsed, setCollapsed] = useState({});

  const sections = useMemo(() => {
    const bySec = {};
    for (const sec of window.SECTION_ORDER) bySec[sec] = [];
    for (const n of Object.values(NOTES)) {
      if (!bySec[n.section]) bySec[n.section] = [];
      bySec[n.section].push(n);
    }
    // Sort each section: heuristics by number, others by title
    for (const sec of Object.keys(bySec)) {
      if (sec === "heuristics") {
        bySec[sec].sort((a, b) => {
          const na = parseInt((a.id.match(/^Heuristic\s+(\d+)/) || [])[1] || 999);
          const nb = parseInt((b.id.match(/^Heuristic\s+(\d+)/) || [])[1] || 999);
          if (na !== nb) return na - nb;
          return a.title.localeCompare(b.title);
        });
      } else if (sec === "core") {
        const order = ["Quality", "Testing", "Context", "Risk", "Proxies", "Economics of Testing"];
        bySec[sec].sort((a, b) => {
          const ia = order.indexOf(a.id);
          const ib = order.indexOf(b.id);
          if (ia === -1 && ib === -1) return a.title.localeCompare(b.title);
          if (ia === -1) return 1;
          if (ib === -1) return -1;
          return ia - ib;
        });
      } else {
        bySec[sec].sort((a, b) => a.title.localeCompare(b.title));
      }
    }
    return bySec;
  }, []);

  const q = query.trim().toLowerCase();
  const searchResults = useMemo(() => {
    if (!q) return null;
    const results = [];
    for (const n of Object.values(NOTES)) {
      const title = n.title.toLowerCase();
      const content = n.content.toLowerCase();
      let score = 0;
      if (title === q) score += 100;
      if (title.startsWith(q)) score += 50;
      if (title.includes(q)) score += 25;
      if (content.includes(q)) score += 1;
      if (score > 0) results.push({ n, score });
    }
    results.sort((a, b) => b.score - a.score);
    return results.slice(0, 30);
  }, [q]);

  return (
    <aside className="sidebar">
      <div className="brand" onClick={() => navigate("#/")}>
        <div className="brand-mark">Vernier</div>
        <div className="brand-sub">A field guide · quality · agents</div>
        <div className="brand-ticks">
          <VernierTicks density={1} accentEvery={10} />
        </div>
      </div>
      <div className="search-wrap">
        <input
          className="search-input"
          placeholder="Search notes…"
          value={query}
          onChange={(e) => setQuery(e.target.value)}
        />
        <div className="search-hint">{query ? `${searchResults?.length || 0} match${searchResults?.length === 1 ? "" : "es"}` : `${Object.keys(NOTES).length} notes · type to search`}</div>
      </div>

      {searchResults ? (
        <div className="search-results">
          {searchResults.length === 0 ? (
            <div className="search-empty">No notes match "{query}"</div>
          ) : searchResults.map(({ n }) => (
            <div className="search-result" key={n.id} onClick={() => { navigate("#/note/" + encodeURIComponent(n.id)); setQuery(""); }}>
              <div className="search-result-title">{n.title}</div>
              <div className="search-result-section">{window.SECTION_LABELS[n.section] || n.section}</div>
            </div>
          ))}
        </div>
      ) : (
        <nav className="nav">
          {window.SECTION_ORDER.map((sec) => {
            const items = sections[sec] || [];
            if (items.length === 0) return null;
            const isCollapsed = collapsed[sec];
            return (
              <div className={"nav-section" + (isCollapsed ? " collapsed" : "")} key={sec}>
                <div className="nav-section-header" onClick={() => setCollapsed({ ...collapsed, [sec]: !isCollapsed })}>
                  <span className="nav-caret">▾</span>
                  <span>{window.SECTION_LABELS[sec] || sec}</span>
                  <span className="nav-count">{items.length}</span>
                </div>
                <ul className="nav-list">
                  {items.map((n) => (
                    <li
                      key={n.id}
                      className={"nav-item" + (route.view === "note" && route.id === n.id ? " active" : "")}
                      onClick={() => navigate("#/note/" + encodeURIComponent(n.id))}
                    >
                      {shortTitle(n)}
                    </li>
                  ))}
                </ul>
              </div>
            );
          })}
        </nav>
      )}
    </aside>
  );
}

function shortTitle(n) {
  // Trim "Heuristic 12 - " → "12. ..."
  const m = n.id.match(/^Heuristic\s+(\d+)\s+-\s+(.+)$/);
  if (m) return `${m[1].padStart(2, "0")}. ${m[2]}`;
  // concept-foo-bar → "Foo Bar"
  if (n.id.startsWith("concept-")) return n.title.replace(/ — .*$/, "");
  if (n.id.startsWith("process-")) return n.title;
  return n.title;
}

// ---------- Note view ----------
function NoteView({ note, ctx }) {
  const links = note.links.map((id) => NOTES[id]).filter(Boolean);
  const backlinks = note.backlinks.map((id) => NOTES[id]).filter(Boolean);

  // Strip the wiki "## See Also" and "## Tags" out so we can show as chips/lists;
  // but they're still rendered inside the markdown as the source.
  // We'll just render the full markdown but our renderer hides tags section.
  return (
    <article className="reader">
      <div className="crumb">
        <a onClick={() => navigate("#/")}>Vernier</a>
        <span className="crumb-sep">/</span>
        <a onClick={() => navigate("#/section/" + encodeURIComponent(note.section))}>{window.SECTION_LABELS[note.section] || note.section}</a>
      </div>

      <header className="note-header">
        <h1 className="note-title">{note.title}</h1>
        <div className="note-meta">
          <span>{window.SECTION_LABELS[note.section] || note.section}</span>
          <span className="dot"></span>
          <span>{links.length} link{links.length === 1 ? "" : "s"} out</span>
          <span className="dot"></span>
          <span>{backlinks.length} backlink{backlinks.length === 1 ? "" : "s"}</span>
        </div>
      </header>

      <Markdown source={note.content} ctx={ctx} />

      <div className="note-footer">
        <div>
          <div className="footer-block-title">Linked to</div>
          {links.length === 0 ? (
            <div style={{ font: "italic 13px/1.4 var(--serif-body)", color: "var(--ink-3)" }}>No outbound links.</div>
          ) : (
            <ul className="link-list">
              {links.map((n) => (
                <li key={n.id}><a onClick={() => navigate("#/note/" + encodeURIComponent(n.id))}>{n.title}</a></li>
              ))}
            </ul>
          )}
        </div>
        <div>
          <div className="footer-block-title">Backlinks · {backlinks.length}</div>
          {backlinks.length === 0 ? (
            <div style={{ font: "italic 13px/1.4 var(--serif-body)", color: "var(--ink-3)" }}>No backlinks yet.</div>
          ) : (
            <ul className="link-list">
              {backlinks.map((n) => (
                <li key={n.id}><a onClick={() => navigate("#/note/" + encodeURIComponent(n.id))}>{n.title}</a></li>
              ))}
            </ul>
          )}
        </div>
        {note.tags && note.tags.length > 0 && (
          <div style={{ gridColumn: "1 / -1" }}>
            <div className="footer-block-title">Tags</div>
            <div className="tag-list">
              {note.tags.map((t) => (
                <span key={t} className="tag-chip" onClick={() => navigate("#/tag/" + encodeURIComponent(t))}>#{t}</span>
              ))}
            </div>
          </div>
        )}
      </div>
    </article>
  );
}

// ---------- Section / Tag index ----------
function SectionView({ section, ctx }) {
  const items = Object.values(NOTES).filter((n) => n.section === section);
  if (section === "heuristics") {
    items.sort((a, b) => {
      const na = parseInt((a.id.match(/^Heuristic\s+(\d+)/) || [])[1] || 999);
      const nb = parseInt((b.id.match(/^Heuristic\s+(\d+)/) || [])[1] || 999);
      return na - nb;
    });
  } else {
    items.sort((a, b) => a.title.localeCompare(b.title));
  }
  const sectionBlurbs = {
    "core": "Six definitions everything else hangs on. Read these first; the rest of the field guide is implications and consequences of these six.",
    "heuristics": "Twenty-four thinking tools. None of them are rules; all of them are prompts to notice something you might otherwise miss.",
    "quality-attributes": "The -ilities and a few non-ilities. Quality is plural — these are the dimensions stakeholders actually care about.",
    "quality-strategy": "How to operationalise the rest of the brain into a real quality strategy on a real project.",
    "stakeholders": "Quality is value to someone who matters. These are the categories of someones. Most projects have several at once.",
    "agents": "What's different when the workforce isn't only human — failure modes, blind spots, recording protocols, stakeholder implications.",
    "knowledge-management": "Tacit knowledge is invisible debt. These notes are about making it explicit, transferrable, and durable across agent and human teammates.",
    "proxies": "Proxies are measurable things that stand in for quality. They aren't quality. Catalogues of proxies organised by area.",
    "smells": "The early-warning signals — things that look wrong in a quality strategy or testing process even when nothing has obviously broken yet.",
  };
  return (
    <div className="reader reader-wide">
      <div className="crumb">
        <a onClick={() => navigate("#/")}>Vernier</a>
      </div>
      <header className="index-header">
        <div className="index-eyebrow">{items.length} notes</div>
        <h1 className="index-title">{window.SECTION_LABELS[section] || section}</h1>
        {sectionBlurbs[section] && <p className="index-blurb">{sectionBlurbs[section]}</p>}
      </header>
      <ul className="index-list">
        {items.map((n, i) => (
          <li className="index-item" key={n.id} onClick={() => navigate("#/note/" + encodeURIComponent(n.id))}>
            <div className="index-num">{String(i + 1).padStart(2, "0")}</div>
            <div>
              <h3 className="index-item-title">{n.title}</h3>
              <div className="index-item-excerpt">{n.excerpt}</div>
            </div>
            <div className="index-item-section">{n.links.length} ↔ {n.backlinks.length}</div>
          </li>
        ))}
      </ul>
    </div>
  );
}

function TagView({ tag, ctx }) {
  const items = Object.values(NOTES).filter((n) => (n.tags || []).includes(tag));
  items.sort((a, b) => a.title.localeCompare(b.title));
  return (
    <div className="reader reader-wide">
      <div className="crumb">
        <a onClick={() => navigate("#/")}>Vernier</a>
        <span className="crumb-sep">/</span>
        <span>Tag</span>
      </div>
      <header className="index-header">
        <div className="index-eyebrow">{items.length} notes</div>
        <h1 className="index-title">#{tag}</h1>
      </header>
      <ul className="index-list">
        {items.map((n, i) => (
          <li className="index-item" key={n.id} onClick={() => navigate("#/note/" + encodeURIComponent(n.id))}>
            <div className="index-num">{String(i + 1).padStart(2, "0")}</div>
            <div>
              <h3 className="index-item-title">{n.title}</h3>
              <div className="index-item-excerpt">{n.excerpt}</div>
            </div>
            <div className="index-item-section">{window.SECTION_LABELS[n.section] || n.section}</div>
          </li>
        ))}
      </ul>
    </div>
  );
}

// ---------- App root ----------
function App() {
  const route = useRoute();
  const ctx = useMemo(() => ({ resolveWikilink, navigate }), []);

  let content;
  if (route.view === "note") {
    const note = NOTES[route.id];
    if (!note) {
      content = (
        <div className="reader">
          <h1 className="note-title">Not found</h1>
          <p>No note with id <code>{route.id}</code>.</p>
          <p><a onClick={() => navigate("#/")} style={{ cursor: "pointer", color: "var(--accent)" }}>Back to Vernier →</a></p>
        </div>
      );
    } else {
      content = <NoteView note={note} ctx={ctx} />;
    }
  } else if (route.view === "section") {
    content = <SectionView section={route.section} ctx={ctx} />;
  } else if (route.view === "tag") {
    content = <TagView tag={route.tag} ctx={ctx} />;
  } else {
    content = <Home notes={NOTES} ctx={ctx} />;
  }

  return (
    <div className="app">
      <Sidebar route={route} />
      <main className="main">{content}</main>
    </div>
  );
}

ReactDOM.createRoot(document.getElementById("root")).render(<App />);
