// timeline.jsx — Animated horizontal timeline of NetMeeting's life

const { useState, useEffect, useRef, useMemo } = React;

const NM_EVENTS = [
  {
    date: "1995",
    sort: 1995.5,
    tag: "ORIGINS",
    title: "Microsoft acquires the building blocks",
    body: "The protocol stack that becomes NetMeeting traces back to two companies: UK-based Data Connection Ltd, whose engineers built much of the H.323 conferencing code, and DataBeam Corporation of Lexington, Kentucky — a co-author of the ITU T.120 data-conferencing standard. DataBeam would later be acquired by Lotus Software.",
  },
  {
    date: "May 29, 1996",
    sort: 1996.4,
    tag: "v1.0 SHIPS",
    title: "NetMeeting 1.0 ships with Internet Explorer 3 beta",
    body: "First release. A T.120-based data-sharing client: shared whiteboard, application sharing, file transfer, text chat, and full-duplex audio over the Internet. No video yet. Distributed free from microsoft.com.",
  },
  {
    date: "Jul 1996",
    sort: 1996.55,
    tag: "PARTNERS",
    title: "Design Preview unveils standards-based conferencing vision",
    body: "Microsoft hosts more than 75 industry vendors at the NetMeeting Design Preview, pitching an open H.323/T.120 ecosystem rather than a proprietary lock-in.",
  },
  {
    date: "Sep 30, 1996",
    sort: 1996.75,
    tag: "SDK",
    title: "NetMeeting SDK released",
    body: "First SDK ships. \"More than 2 million copies\" downloaded already; 10,000+ developers had pulled the beta SDK. VDOnet's VDOPhone, EveNTs Software, and Creative Software's CamWiz all build on it.",
  },
  {
    date: "Aug 1996",
    sort: 1996.65,
    tag: "DEPLOY",
    title: "Bundled with Windows 95 OSR2",
    body: "NetMeeting becomes part of the Windows operating release cadence — preinstalled on Windows 95 OSR2 and shipped with every IE3 install.",
  },
  {
    date: "Apr 28, 1997",
    sort: 1997.33,
    tag: "v2.0",
    title: "NetMeeting 2.0 — H.323 + video",
    body: "Final 2.0 release after four public betas. Adds the H.323 video conferencing standard, real-time video, improved audio, ILS directory integration. PC Magazine Editor's Choice for Internet collaboration tools.",
  },
  {
    date: "Jun 1998",
    sort: 1998.45,
    tag: "WIN98",
    title: "Shipped inside Windows 98",
    body: "NetMeeting 2.1 ships as a default component of Windows 98 — and with every copy of Internet Explorer 4. Reach explodes.",
  },
  {
    date: "Late 1999",
    sort: 1999.9,
    tag: "v3.0",
    title: "NetMeeting 3.0 with Windows 98 SE",
    body: "Simplified UI, better low-bandwidth audio/video, remote desktop sharing, security improvements. Ships with Windows 98 Second Edition and Windows 2000.",
  },
  {
    date: "2001",
    sort: 2001.5,
    tag: "v3.01 / XP",
    title: "Version 3.01 — and quietly hidden",
    body: "Last major version. Bundled with Windows XP and Server 2003 — but the Start-menu shortcut is removed \"by design.\" Users must run conf.exe from the Run dialog. Microsoft is steering people to Windows Messenger.",
  },
  {
    date: "Nov 2000",
    sort: 2000.85,
    tag: "SECURITY",
    title: "MS00-077: DoS on port 1720",
    body: "First major security bulletin. A malformed string to the H.323 call-setup port can pin CPU and disrupt sessions. Patches keep arriving through 2007 (MS04-011 covers H.323, SSL, and PCT issues).",
  },
  {
    date: "2002",
    sort: 2002.3,
    tag: "SUCCESSOR",
    title: "Windows Messenger arrives in XP",
    body: "Microsoft's bet shifts to SIP. Windows Messenger integrates voice and video into the IM client most people already use — the writing is on the wall for H.323-based NetMeeting.",
  },
  {
    date: "Jan 2007",
    sort: 2007.05,
    tag: "REMOVAL",
    title: "Windows Vista ships — without NetMeeting",
    body: "Vista replaces NetMeeting with Windows Meeting Space, a peer-to-peer ad-hoc collaboration tool. Eleven years after launch, NetMeeting is no longer part of Windows.",
  },
  {
    date: "Mar 22, 2007",
    sort: 2007.22,
    tag: "v3.02 / EOL",
    title: "3.02 — a transition-only hotfix",
    body: "Microsoft publishes a 32-bit Vista compatibility update that installs NetMeeting 3.02. Officially unsupported. Some features (incoming remote-desktop invitations, whiteboard area selection) are gone. No further updates ever ship.",
  },
];

NM_EVENTS.sort((a, b) => a.sort - b.sort);

const RANGE_START = 1995.0;
const RANGE_END   = 2008.0;

function yearsToPct(y) {
  return ((y - RANGE_START) / (RANGE_END - RANGE_START)) * 100;
}

function Timeline() {
  const [playing, setPlaying] = useState(true);
  const [t, setT] = useState(0);            // 0..1 progress
  const [activeIdx, setActiveIdx] = useState(0);
  const rafRef = useRef(null);
  const lastTickRef = useRef(0);
  const DURATION = 32000;                    // ms full play

  // Auto-advance
  useEffect(() => {
    if (!playing) return;
    const step = (ts) => {
      if (!lastTickRef.current) lastTickRef.current = ts;
      const dt = ts - lastTickRef.current;
      lastTickRef.current = ts;
      setT(prev => {
        let next = prev + dt / DURATION;
        if (next >= 1) { next = 1; setPlaying(false); }
        return next;
      });
      rafRef.current = requestAnimationFrame(step);
    };
    rafRef.current = requestAnimationFrame(step);
    return () => { cancelAnimationFrame(rafRef.current); lastTickRef.current = 0; };
  }, [playing]);

  // Sync activeIdx with t
  const playheadYear = RANGE_START + t * (RANGE_END - RANGE_START);
  useEffect(() => {
    // Active = the latest event whose sort <= playheadYear
    let idx = 0;
    for (let i = 0; i < NM_EVENTS.length; i++) {
      if (NM_EVENTS[i].sort <= playheadYear) idx = i;
    }
    setActiveIdx(idx);
  }, [playheadYear]);

  const restart = () => {
    setT(0);
    lastTickRef.current = 0;
    setPlaying(true);
  };

  const goToEvent = (i) => {
    const e = NM_EVENTS[i];
    setT((e.sort - RANGE_START) / (RANGE_END - RANGE_START));
    setPlaying(false);
  };

  const playheadPct = yearsToPct(playheadYear);
  const active = NM_EVENTS[activeIdx];
  const years = [];
  for (let y = 1995; y <= 2008; y++) years.push(y);

  return (
    <div className="nm-timeline">
      {/* Controls */}
      <div className="nm-tl-controls">
        <button
          className="nm-tl-btn"
          onClick={() => (t >= 1 ? restart() : setPlaying(p => !p))}
          aria-label={playing ? "Pause" : "Play"}
        >
          {playing ? (
            <svg width="14" height="14" viewBox="0 0 14 14"><rect x="2" y="1" width="3" height="12" fill="currentColor"/><rect x="9" y="1" width="3" height="12" fill="currentColor"/></svg>
          ) : t >= 1 ? (
            <svg width="14" height="14" viewBox="0 0 14 14"><path d="M3 2 L3 12 L11 7 Z" fill="currentColor"/></svg>
          ) : (
            <svg width="14" height="14" viewBox="0 0 14 14"><path d="M3 2 L3 12 L11 7 Z" fill="currentColor"/></svg>
          )}
          <span>{t >= 1 ? "REPLAY" : (playing ? "PAUSE" : "PLAY")}</span>
        </button>
        <div className="nm-tl-readout mono">
          <span className="muted">YR&nbsp;</span>
          <span className="big">{playheadYear.toFixed(2)}</span>
        </div>
        <div className="nm-tl-progress mono">
          <span className="muted">{String(activeIdx + 1).padStart(2, "0")}</span>
          <span className="muted"> / </span>
          <span>{NM_EVENTS.length}</span>
        </div>
      </div>

      {/* Track */}
      <div className="nm-tl-track-wrap">
        <div className="nm-tl-track">
          {/* Year ticks */}
          {years.map(y => (
            <div key={y} className="nm-tl-tick" style={{ left: `${yearsToPct(y)}%` }}>
              <div className="nm-tl-tick-line" />
              <div className="nm-tl-tick-label mono">{y}</div>
            </div>
          ))}

          {/* Era bands */}
          <div className="nm-tl-era" style={{
            left: `${yearsToPct(1996)}%`,
            width: `${yearsToPct(2001.5) - yearsToPct(1996)}%`,
          }}>
            <span className="nm-tl-era-label mono">RISE</span>
          </div>
          <div className="nm-tl-era amber" style={{
            left: `${yearsToPct(2001.5)}%`,
            width: `${yearsToPct(2007.3) - yearsToPct(2001.5)}%`,
          }}>
            <span className="nm-tl-era-label mono">DECLINE</span>
          </div>

          {/* Event nodes */}
          {NM_EVENTS.map((e, i) => {
            const reached = e.sort <= playheadYear + 0.001;
            const isActive = i === activeIdx && reached;
            return (
              <button
                key={i}
                className={`nm-tl-node ${reached ? "reached" : ""} ${isActive ? "active" : ""}`}
                style={{ left: `${yearsToPct(e.sort)}%` }}
                onClick={() => goToEvent(i)}
                aria-label={`${e.date}: ${e.title}`}
              >
                <span className="nm-tl-node-dot" />
                <span className="nm-tl-node-stem" />
                <span className="nm-tl-node-tag mono">{e.tag}</span>
              </button>
            );
          })}

          {/* Playhead */}
          <div className="nm-tl-playhead" style={{ left: `${playheadPct}%` }}>
            <div className="nm-tl-playhead-line" />
            <div className="nm-tl-playhead-head" />
          </div>

          {/* Filled progress */}
          <div className="nm-tl-progress-fill" style={{ width: `${playheadPct}%` }} />
        </div>
      </div>

      {/* Active card */}
      <div className="nm-tl-card-wrap">
        <div className="nm-tl-card" key={activeIdx}>
          <div className="nm-tl-card-head">
            <span className="tag teal mono">{active.tag}</span>
            <span className="nm-tl-card-date mono">{active.date}</span>
          </div>
          <h3 className="serif">{active.title}</h3>
          <p>{active.body}</p>
        </div>
      </div>
    </div>
  );
}

window.Timeline = Timeline;
