// successors.jsx — Animated family tree of NetMeeting's successors

const { useState: uS, useEffect: uE, useRef: uR } = React;

/* Family tree:
   NetMeeting (1996-2007) branches into:
   - Windows Messenger (2002, XP) → MSN/Windows Live Messenger → discontinued
   - Windows Meeting Space (Vista, 2007-2012) → discontinued (Win7)
   - Office Live Meeting (2003-2017) → discontinued, merged into:
   - Office Communicator (2007) → Lync (2010) → Skype for Business (2015-2021) →
   - Microsoft Teams (2017–) — eventually absorbs all
*/

const NODES = [
  { id: "nm",   label: "NetMeeting",          years: "1996–2007", x: 50,  y: 60,  status: "dead",  highlight: true, note: "H.323 + T.120" },
  { id: "wm",   label: "Windows Messenger",   years: "2002–2006", x: 240, y: 30,  status: "dead",  note: "SIP / XP" },
  { id: "live", label: "Win Live Messenger",  years: "2005–2013", x: 450, y: 30,  status: "dead" },
  { id: "wms",  label: "Win Meeting Space",   years: "2007–2012", x: 240, y: 110, status: "dead",  note: "Vista P2P" },
  { id: "olm",  label: "Office Live Meeting", years: "2003–2017", x: 240, y: 200, status: "dead",  note: "PlaceWare acq." },
  { id: "oc",   label: "Office Communicator", years: "2007–2010", x: 450, y: 200, status: "dead" },
  { id: "lync", label: "Lync",                years: "2010–2015", x: 620, y: 200, status: "dead" },
  { id: "s4b",  label: "Skype for Business",  years: "2015–2021", x: 790, y: 200, status: "dead",  note: "Skype acq. 2011" },
  { id: "teams",label: "Microsoft Teams",     years: "2017–",     x: 960, y: 115, status: "alive", highlight: true, note: "Cloud · WebRTC" },
];

const EDGES = [
  { a: "nm",   b: "wm"   },
  { a: "wm",   b: "live" },
  { a: "nm",   b: "wms"  },
  { a: "nm",   b: "olm"  },
  { a: "olm",  b: "oc"   },
  { a: "oc",   b: "lync" },
  { a: "lync", b: "s4b"  },
  { a: "s4b",  b: "teams"},
  { a: "live", b: "teams"},
  { a: "wms",  b: "teams"},
];

function FamilyTree() {
  const [t, setT] = uS(0);
  const startR = uR(null);
  const rafR = uR(null);
  uE(() => {
    const tick = (ts) => {
      if (!startR.current) startR.current = ts;
      setT((ts - startR.current) / 1000);
      rafR.current = requestAnimationFrame(tick);
    };
    rafR.current = requestAnimationFrame(tick);
    return () => cancelAnimationFrame(rafR.current);
  }, []);

  // Edges grow in over time, in order
  const PER_EDGE = 0.55;
  const W = 1100, H = 280;

  const findNode = (id) => NODES.find(n => n.id === id);

  return (
    <div className="nm-tree-wrap">
      <svg viewBox={`0 0 ${W} ${H}`} className="nm-tree-svg" preserveAspectRatio="xMidYMid meet">
        {/* Edges */}
        {EDGES.map((e, i) => {
          const a = findNode(e.a), b = findNode(e.b);
          const start = i * PER_EDGE * 0.45; // overlapping
          const localU = Math.max(0, Math.min(1, (t - start) / PER_EDGE));
          if (localU <= 0) return null;
          // Bezier control point
          const cx = (a.x + b.x) / 2;
          const cy = (a.y + b.y) / 2 - 12 + (i % 2) * 24;
          // Approximate point along bezier for endpoint
          const tt = localU;
          const x = (1 - tt) * (1 - tt) * a.x + 2 * (1 - tt) * tt * cx + tt * tt * b.x;
          const y = (1 - tt) * (1 - tt) * a.y + 2 * (1 - tt) * tt * cy + tt * tt * b.y;
          // Path so far
          const d = `M ${a.x} ${a.y} Q ${cx} ${cy} ${x} ${y}`;
          return (
            <g key={i}>
              <path d={d} fill="none" stroke="var(--ink-3)" strokeWidth="1.2" opacity="0.55"/>
              {localU >= 1 && (
                <circle cx={b.x} cy={b.y} r="3" fill="var(--ink-3)" opacity="0.8"/>
              )}
            </g>
          );
        })}

        {/* Nodes */}
        {NODES.map((n, i) => {
          // Stagger node appearance with edges
          const showAt = Math.max(0, i - 1) * PER_EDGE * 0.4;
          const visible = t >= showAt;
          const opacity = visible ? 1 : 0;
          const scale = visible ? 1 : 0.6;
          return (
            <g key={n.id} transform={`translate(${n.x}, ${n.y})`} style={{
              transition: "opacity 400ms ease, transform 400ms cubic-bezier(.2,.7,.3,1.3)",
              opacity,
              transformOrigin: `${n.x}px ${n.y}px`,
            }}>
              <rect
                x="-66" y="-22" width="132" height="44"
                fill={n.status === "alive" ? "var(--teal-soft)" : "#f1ece1"}
                stroke={
                  n.highlight ? (n.status === "alive" ? "var(--teal)" : "var(--rust)") : "var(--ink)"
                }
                strokeWidth={n.highlight ? 1.6 : 1}
              />
              <text x="0" y="-3" textAnchor="middle" className="nm-tree-label">{n.label}</text>
              <text x="0" y="13" textAnchor="middle" className="nm-tree-year mono">{n.years}</text>
              {n.status === "dead" && (
                <line x1="-58" y1="0" x2="58" y2="0" stroke="var(--rust)" strokeOpacity="0.35" strokeWidth="1"/>
              )}
            </g>
          );
        })}
      </svg>

      <div className="nm-tree-legend mono">
        <span><i className="dot rust"/> retired / replaced</span>
        <span><i className="dot teal"/> still shipping</span>
      </div>
    </div>
  );
}

window.FamilyTree = FamilyTree;
