// architecture.jsx — Animated protocol stack + H.323 call setup sequence + ILS

const { useState: useS, useEffect: useE, useRef: useR } = React;

/* ============================================================ */
/* PROTOCOL STACK — animated packets travelling through layers   */
/* ============================================================ */

// Each "channel" describes one data path through the stack.
// dots animate from app at top -> transport at bottom on caller side,
// across the wire, up to callee.
const CHANNELS = [
  { id: "audio",   label: "Audio",            color: "teal",   transport: "UDP", path: "rtp",   layer: "h245" },
  { id: "video",   label: "Video",            color: "teal",   transport: "UDP", path: "rtp",   layer: "h245" },
  { id: "ctrl",    label: "Call control",     color: "amber",  transport: "TCP", path: "ctrl",  layer: "h225" },
  { id: "share",   label: "App share + chat", color: "rust",   transport: "TCP", path: "data",  layer: "t128" },
  { id: "wb",      label: "Whiteboard",       color: "rust",   transport: "TCP", path: "data",  layer: "t126" },
  { id: "file",    label: "File transfer",    color: "rust",   transport: "TCP", path: "data",  layer: "t127" },
];

function ProtocolStack() {
  const [time, setTime] = useS(0);
  const rafRef = useR(null);
  const startRef = useR(null);

  useE(() => {
    const step = (ts) => {
      if (!startRef.current) startRef.current = ts;
      setTime((ts - startRef.current) / 1000);
      rafRef.current = requestAnimationFrame(step);
    };
    rafRef.current = requestAnimationFrame(step);
    return () => cancelAnimationFrame(rafRef.current);
  }, []);

  // Animation: for each channel, emit dots periodically that travel
  // caller-app -> caller-stack-down -> wire -> callee-stack-up -> callee-app
  // We render as SVG so it can scale.

  return (
    <div className="nm-arch-stack">
      <div className="nm-arch-legend mono">
        <span><i className="dot teal" /> H.323 media · UDP/RTP</span>
        <span><i className="dot amber" /> H.225 / H.245 signaling · TCP</span>
        <span><i className="dot rust" /> T.120 data conferencing · TCP</span>
      </div>

      <svg viewBox="0 0 960 540" className="nm-arch-svg" preserveAspectRatio="xMidYMid meet">
        <defs>
          <linearGradient id="wireGrad" x1="0" x2="1">
            <stop offset="0" stopColor="#c8bfa6" />
            <stop offset="0.5" stopColor="#6e6553" />
            <stop offset="1" stopColor="#c8bfa6" />
          </linearGradient>
        </defs>

        {/* Background grid */}
        <g opacity="0.4">
          {Array.from({length: 12}).map((_,i)=>(
            <line key={i} x1="0" x2="960" y1={i*45} y2={i*45} stroke="#d8cfb4" strokeWidth="0.5"/>
          ))}
        </g>

        {/* CALLER stack — left */}
        <StackColumn x={40}  label="ALICE@192.0.2.10" />

        {/* CALLEE stack — right */}
        <StackColumn x={620} label="BOB@198.51.100.4" flip />

        {/* Wire between them — IP layer */}
        <g>
          <line x1="270" y1="500" x2="900" y2="500" stroke="url(#wireGrad)" strokeWidth="1.5" />
          <text x="585" y="495" textAnchor="middle" className="nm-arch-wire-lbl">internet · IP packets</text>
        </g>

        {/* Animated packets */}
        {CHANNELS.map((ch, ci) => (
          <AnimatedPackets key={ch.id} channel={ch} time={time} index={ci} />
        ))}
      </svg>

      <div className="nm-arch-caption mono">
        FIG. 1 &nbsp;·&nbsp; H.323 + T.120 protocol stack, NetMeeting 2.x–3.x.
        Audio &amp; video travel as UDP/RTP. Call control rides H.225/H.245 over TCP.
        Whiteboard, file transfer, application sharing, and chat ride the T.120 stack over a single TCP connection on port 1503.
      </div>
    </div>
  );
}

/* A single stack column (Alice or Bob) */
function StackColumn({ x, label, flip }) {
  // Layer y-positions (top-down)
  const layers = [
    { y: 30,  h: 80,  title: "APPLICATION", items: ["Video win", "Audio", "Whiteboard", "Chat", "Share", "Files"], color: "ink" },
    { y: 130, h: 60,  title: "H.245 ctrl + RTP",   items: ["G.711 / G.723.1", "H.261 / H.263"], color: "teal" },
    { y: 210, h: 50,  title: "H.225 call setup",   items: ["port 1720"],                     color: "amber" },
    { y: 280, h: 80,  title: "T.120 MCS / GCC",    items: ["T.128 share · T.126 WB", "T.127 files · Share 2.0"], color: "rust" },
    { y: 380, h: 60,  title: "TRANSPORT",          items: ["TCP", "UDP"],                    color: "ink-2" },
    { y: 460, h: 30,  title: "IP",                 items: [],                                color: "ink-2" },
  ];

  return (
    <g transform={`translate(${x},0)`}>
      <text x="115" y="18" textAnchor="middle" className="nm-arch-host-lbl">{label}</text>

      {layers.map((L, i) => (
        <g key={i}>
          <rect x="0" y={L.y} width="230" height={L.h - 8}
            fill="#f1ece1"
            stroke={
              L.color === "teal"   ? "var(--teal)" :
              L.color === "amber"  ? "var(--amber)" :
              L.color === "rust"   ? "var(--rust)" :
              "#1a1813"
            }
            strokeWidth="1"
          />
          <text x="10" y={L.y + 14} className="nm-arch-layer-lbl mono">{L.title}</text>
          {L.items.map((it, j) => (
            <text key={j} x="10" y={L.y + 30 + j*14} className="nm-arch-layer-item mono">{it}</text>
          ))}
        </g>
      ))}
    </g>
  );
}

/* Animated dots travelling through a channel's path. */
function AnimatedPackets({ channel, time, index }) {
  // Each channel emits a packet every `period` seconds, offset by index
  const period = channel.color === "teal" ? 0.6 : channel.color === "amber" ? 2.4 : 1.4;
  const offset = (index * 0.15) % period;
  const dots = [];
  // Show 3 in-flight at a time per channel for the fast channels, 1 for slow
  const count = channel.color === "teal" ? 4 : channel.color === "amber" ? 1 : 2;

  for (let k = 0; k < count; k++) {
    const localT = ((time - offset - k * (period / count)) % period + period) % period;
    const u = localT / period;       // 0..1 progress along full path
    const pos = pathPoint(channel, u);
    dots.push({ x: pos.x, y: pos.y, u });
  }

  const fill =
    channel.color === "teal" ? "oklch(0.52 0.10 195)" :
    channel.color === "amber" ? "oklch(0.62 0.13 60)" :
    "oklch(0.50 0.13 32)";

  return (
    <g>
      {dots.map((d, i) => (
        <circle key={i} cx={d.x} cy={d.y} r="3.2" fill={fill} opacity={0.35 + 0.65 * Math.sin(d.u * Math.PI)} />
      ))}
    </g>
  );
}

/* Returns x,y on the path for a given channel and progress u in 0..1.
   Path: Alice app box -> down -> wire -> up -> Bob app box.    */
function pathPoint(ch, u) {
  // Alice column x range: 40..270
  // Bob   column x range: 620..850
  // Layer Y for the channel mid-point:
  const layerY = ({
    h245: 160, // H.245 / RTP layer
    h225: 230, // H.225 call setup
    t128: 320, // T.120 stack
    t126: 320,
    t127: 320,
  })[ch.layer] || 200;

  // Define 4 segments:
  // 0..0.25: Alice app(y≈70) -> Alice layer(y=layerY) at x≈155 (mid of column)
  // 0.25..0.4: Alice layer -> Alice IP(y=500) at x=155 then to wire
  // 0.4..0.6: travel along wire (y=500) from x=155 -> x=735
  // 0.6..0.75: from wire up to Bob layer
  // 0.75..1.0: Bob layer up to Bob app(y≈70)
  const aliceX = 155;
  const bobX   = 735;
  if (u < 0.20) {
    const k = u / 0.20;
    return { x: aliceX, y: 70 + (layerY - 70) * k };
  }
  if (u < 0.40) {
    const k = (u - 0.20) / 0.20;
    return { x: aliceX, y: layerY + (500 - layerY) * k };
  }
  if (u < 0.60) {
    const k = (u - 0.40) / 0.20;
    return { x: aliceX + (bobX - aliceX) * k, y: 500 };
  }
  if (u < 0.80) {
    const k = (u - 0.60) / 0.20;
    return { x: bobX, y: 500 + (layerY - 500) * k };
  }
  const k = (u - 0.80) / 0.20;
  return { x: bobX, y: layerY + (70 - layerY) * k };
}

/* ============================================================ */
/* CALL SETUP SEQUENCE — animated H.323 ladder diagram           */
/* ============================================================ */

const CALL_STEPS = [
  { from: "A", to: "B", proto: "H.225", port: "TCP 1720", label: "SETUP",            note: "Caller offers call" },
  { from: "B", to: "A", proto: "H.225", port: "TCP 1720", label: "CALL PROCEEDING", note: "Callee acknowledges" },
  { from: "B", to: "A", proto: "H.225", port: "TCP 1720", label: "ALERTING",         note: "Phone is ringing" },
  { from: "B", to: "A", proto: "H.225", port: "TCP 1720", label: "CONNECT",          note: "Bob picks up" },
  { from: "A", to: "B", proto: "H.245", port: "dynamic",  label: "terminalCapabilitySet", note: "What codecs do you support?" },
  { from: "B", to: "A", proto: "H.245", port: "dynamic",  label: "terminalCapabilitySet", note: "Bob replies with his list" },
  { from: "A", to: "B", proto: "H.245", port: "dynamic",  label: "masterSlaveDetermination", note: "Who breaks ties?" },
  { from: "A", to: "B", proto: "H.245", port: "dynamic",  label: "openLogicalChannel", note: "Open audio (G.723.1)" },
  { from: "B", to: "A", proto: "H.245", port: "dynamic",  label: "openLogicalChannel", note: "Open audio (G.723.1)" },
  { from: "A", to: "B", proto: "H.245", port: "dynamic",  label: "openLogicalChannel", note: "Open video (H.263)" },
  { from: "B", to: "A", proto: "H.245", port: "dynamic",  label: "openLogicalChannel", note: "Open video (H.263)" },
  { from: "A", to: "B", proto: "RTP",   port: "UDP",      label: "audio + video stream", note: "Conversation begins", flow: true },
  { from: "B", to: "A", proto: "RTP",   port: "UDP",      label: "audio + video stream", note: "", flow: true },
];

function CallSetup() {
  const [step, setStep] = useS(0);
  const [playing, setPlaying] = useS(true);
  const rafR = useR(null);
  const lastR = useR(0);
  const ROW_H = 38;
  const STEP_MS = 1100;

  useE(() => {
    if (!playing) return;
    const tick = (ts) => {
      if (!lastR.current) lastR.current = ts;
      if (ts - lastR.current >= STEP_MS) {
        lastR.current = ts;
        setStep(s => {
          if (s + 1 >= CALL_STEPS.length) { setPlaying(false); return s; }
          return s + 1;
        });
      }
      rafR.current = requestAnimationFrame(tick);
    };
    rafR.current = requestAnimationFrame(tick);
    return () => cancelAnimationFrame(rafR.current);
  }, [playing]);

  const restart = () => { setStep(0); lastR.current = 0; setPlaying(true); };

  const W = 720;
  const H = ROW_H * CALL_STEPS.length + 80;
  const colA = 110;
  const colB = W - 110;

  return (
    <div className="nm-callseq">
      <div className="nm-callseq-controls">
        <button className="nm-tl-btn" onClick={() => step >= CALL_STEPS.length - 1 ? restart() : setPlaying(p => !p)}>
          {playing ? "PAUSE" : step >= CALL_STEPS.length - 1 ? "REPLAY" : "PLAY"}
        </button>
        <span className="mono nm-callseq-step">STEP {String(step + 1).padStart(2,"0")} / {CALL_STEPS.length}</span>
        <span className="mono nm-callseq-note">{CALL_STEPS[step].note}</span>
      </div>
      <svg viewBox={`0 0 ${W} ${H}`} className="nm-callseq-svg" preserveAspectRatio="xMidYMin meet">
        {/* Header lanes */}
        <g>
          <rect x={colA - 80} y="6" width="160" height="34" fill="#f1ece1" stroke="var(--ink)" strokeWidth="1"/>
          <text x={colA} y="28" textAnchor="middle" className="nm-callseq-head">ALICE · caller</text>

          <rect x={colB - 80} y="6" width="160" height="34" fill="#f1ece1" stroke="var(--ink)" strokeWidth="1"/>
          <text x={colB} y="28" textAnchor="middle" className="nm-callseq-head">BOB · callee</text>
        </g>

        {/* Lanes */}
        <line x1={colA} y1="40" x2={colA} y2={H - 12} stroke="var(--rule)" strokeWidth="1" strokeDasharray="2 3"/>
        <line x1={colB} y1="40" x2={colB} y2={H - 12} stroke="var(--rule)" strokeWidth="1" strokeDasharray="2 3"/>

        {/* Messages */}
        {CALL_STEPS.map((s, i) => {
          const y = 70 + i * ROW_H;
          const active = i <= step;
          const isCurrent = i === step;
          const x1 = s.from === "A" ? colA : colB;
          const x2 = s.to   === "A" ? colA : colB;
          const stroke = s.proto === "H.225" ? "var(--amber)" :
                         s.proto === "H.245" ? "var(--ink-2)" :
                         "var(--teal)";
          return (
            <g key={i} opacity={active ? 1 : 0.18}>
              {/* arrow line */}
              <line x1={x1 + (x1 < x2 ? 6 : -6)} y1={y} x2={x2 + (x2 < x1 ? 6 : -6)} y2={y}
                    stroke={stroke} strokeWidth={isCurrent ? 1.8 : 1}/>
              {/* arrowhead */}
              <polygon
                points={x2 < x1
                  ? `${x2+6},${y} ${x2+13},${y-4} ${x2+13},${y+4}`
                  : `${x2-6},${y} ${x2-13},${y-4} ${x2-13},${y+4}`}
                fill={stroke}
              />
              {/* label */}
              <text
                x={(x1 + x2) / 2}
                y={y - 5}
                textAnchor="middle"
                className="nm-callseq-msg mono"
                fill={isCurrent ? "var(--ink)" : "var(--ink-2)"}
              >
                {s.label}
              </text>
              <text
                x={(x1 + x2) / 2}
                y={y + 12}
                textAnchor="middle"
                className="nm-callseq-sub mono"
              >
                {s.proto} · {s.port}
              </text>
            </g>
          );
        })}
      </svg>
    </div>
  );
}

/* ============================================================ */
/* ILS lookup diagram — animated                                  */
/* ============================================================ */

function IlsLookup() {
  const [t, setT] = useS(0);
  const rafR = useR(null);
  const startR = useR(null);
  useE(() => {
    const step = (ts) => {
      if (!startR.current) startR.current = ts;
      setT((ts - startR.current) / 1000);
      rafR.current = requestAnimationFrame(step);
    };
    rafR.current = requestAnimationFrame(step);
    return () => cancelAnimationFrame(rafR.current);
  }, []);

  // Two-phase loop: client registers with ILS, then resolves a peer.
  const PHASE = 6; // seconds total
  const u = (t % PHASE) / PHASE;

  // Compute dot positions for each phase
  // 0.00-0.20: Alice -> ILS  (LDAP register)
  // 0.20-0.30: hold
  // 0.30-0.50: Bob lookup query Alice -> ILS
  // 0.50-0.70: ILS -> Bob (returns Alice's IP)
  // 0.70-1.00: Bob -> Alice direct call (H.225)

  const clamp = (n) => Math.max(0, Math.min(1, n));

  // Coords
  const A = { x: 80,  y: 220, label: "ALICE", sub: "192.0.2.10" };
  const I = { x: 380, y: 80,  label: "ILS server", sub: "ils.microsoft.com · LDAP/389" };
  const B = { x: 680, y: 220, label: "BOB",   sub: "198.51.100.4" };

  const lerp = (p, q, k) => ({ x: p.x + (q.x - p.x) * k, y: p.y + (q.y - p.y) * k });

  let activeDots = [];
  let activeLabel = "";
  if (u < 0.20) {
    const k = u / 0.20;
    activeDots = [{ ...lerp(A, I, k), color: "var(--amber)" }];
    activeLabel = "1.  Alice registers with ILS  ·  email + IP";
  } else if (u < 0.30) {
    activeLabel = "·  Alice is now visible in the directory";
  } else if (u < 0.50) {
    const k = (u - 0.30) / 0.20;
    activeDots = [{ ...lerp(B, I, k), color: "var(--ink-2)" }];
    activeLabel = "2.  Bob queries ILS  ·  who is alice@example.com?";
  } else if (u < 0.70) {
    const k = (u - 0.50) / 0.20;
    activeDots = [{ ...lerp(I, B, k), color: "var(--ink-2)" }];
    activeLabel = "3.  ILS returns Alice's current IP  ·  192.0.2.10";
  } else {
    const k = (u - 0.70) / 0.30;
    activeDots = [{ ...lerp(B, A, k), color: "var(--teal)" }];
    activeLabel = "4.  Bob direct-dials Alice  ·  H.225 SETUP to TCP 1720";
  }

  return (
    <div className="nm-ils">
      <div className="nm-ils-stage-label mono">{activeLabel}</div>
      <svg viewBox="0 0 760 320" className="nm-ils-svg" preserveAspectRatio="xMidYMid meet">
        {/* Connecting lines (faint when inactive) */}
        <line x1={A.x} y1={A.y} x2={I.x} y2={I.y} stroke="var(--rule)" strokeWidth="1" strokeDasharray="3 4"/>
        <line x1={B.x} y1={B.y} x2={I.x} y2={I.y} stroke="var(--rule)" strokeWidth="1" strokeDasharray="3 4"/>
        <line x1={A.x} y1={A.y} x2={B.x} y2={B.y} stroke="var(--rule)" strokeWidth="1" strokeDasharray="3 4"/>

        {/* Nodes */}
        {[A, I, B].map((n, idx) => (
          <g key={idx} transform={`translate(${n.x}, ${n.y})`}>
            <rect x="-58" y="-26" width="116" height="52" fill="#f1ece1" stroke="var(--ink)" strokeWidth="1"/>
            <text x="0" y="-6" textAnchor="middle" className="nm-ils-node-label">{n.label}</text>
            <text x="0" y="14" textAnchor="middle" className="nm-ils-node-sub mono">{n.sub}</text>
          </g>
        ))}

        {/* Animated dots */}
        {activeDots.map((d, i) => (
          <g key={i}>
            <circle cx={d.x} cy={d.y} r="5" fill={d.color} />
            <circle cx={d.x} cy={d.y} r="10" fill={d.color} opacity="0.25"/>
          </g>
        ))}
      </svg>
    </div>
  );
}

window.ProtocolStack = ProtocolStack;
window.CallSetup = CallSetup;
window.IlsLookup = IlsLookup;
