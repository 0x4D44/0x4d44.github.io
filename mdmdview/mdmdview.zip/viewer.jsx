// Live viewer mockup — toggleable theme, raw/rendered, search overlay,
// document picker. Renders simulated markdown elements.

const SAMPLE_DOCS = {
  welcome: {
    title: "welcome.md",
    blocks: [
      { t: "h1", text: "Welcome to mdmdview" },
      { t: "p", text: "A markdown viewer that opens instantly and renders cleanly. Drop a `.md` file, double-click one from your file manager, or pick a sample from **File ▸ Samples**." },
      { t: "quote", text: "“Reading is a separate act from skimming. Tools should know the difference.”" },
      { t: "h2", text: "What's inside" },
      { t: "ul", items: [
        "**CommonMark** parsing via pulldown-cmark",
        "**Syntax highlighting** for 100+ languages",
        "**Live image refresh** when source files change",
        "**Mermaid · Pikchr · D2** diagrams, all offline",
      ]},
      { t: "h2", text: "A code block" },
      { t: "code", lang: "rust", lines: [
        ["com", "// app.rs — main update loop"],
        ["kw", "impl ", "ty", "App ", "kw", "for ", "ty", "MarkdownViewerApp ", "p", "{"],
        ["p", "    ", "kw", "fn ", "fn", "update", "p", "(&", "kw", "mut ", "p", "self, ctx: &", "ty", "egui::Context", "p", ", _: &", "kw", "mut ", "ty", "Frame", "p", ") {"],
        ["p", "        self.handle_shortcuts(ctx);"],
        ["p", "        self.render_menu_bar(ctx);"],
        ["p", "        self.render_content(ctx);"],
        ["p", "        self.persist_window_state();"],
        ["p", "    }"],
        ["p", "}"],
      ]},
    ],
  },
  tables: {
    title: "tables.md",
    blocks: [
      { t: "h1", text: "Markdown tables" },
      { t: "p", text: "Tables render as a proper grid with striped rows. Column widths follow a policy based on content density." },
      { t: "table",
        head: ["Shortcut", "Action", "Mode"],
        rows: [
          ["Ctrl+O", "Open file dialog", "any"],
          ["Ctrl+R", "Toggle Rendered ↔ Raw", "any"],
          ["Ctrl+E", "Enter Edit mode", "raw only"],
          ["Alt+←", "Back in history", "any"],
          ["F11", "Toggle fullscreen", "any"],
        ],
      },
      { t: "p", text: "Tables also work inside lists, blockquotes, and accept inline formatting in every cell." },
    ],
  },
  search: {
    title: "search.md",
    blocks: [
      { t: "h1", text: "Search across diacritics" },
      { t: "p", text: "mdmdview normalises both the query and the document before comparing. A search for **istanbul** finds *İstanbul*. A search for **resume** finds *résumé*. Highlighting respects grapheme clusters, so emoji and accent marks stay intact in the results." },
      { t: "h2", text: "Cities" },
      { t: "ul", items: [
        "Istanbul · İstanbul — both match a single query.",
        "Zürich · Zurich — both match.",
        "São Paulo · Sao Paulo — both match.",
        "Réunion · Reunion — both match.",
      ]},
      { t: "p", text: "Try typing in the search box at the top right." },
    ],
  },
  poetry: {
    title: "poetry.md",
    blocks: [
      { t: "h1", text: "Line breaks preserved" },
      { t: "p", text: "Single newlines in paragraphs are kept exactly — vital for poetry, lyrics, and structured notes:" },
      { t: "p", text: "October, and the trees are giving up,\nthe maples burning slow.\nA wind comes in and rearranges nothing,\nnot really.\nThe leaves had already decided." },
      { t: "p", text: "Most markdown renderers collapse those soft breaks. mdmdview keeps them, because they're meant to be there." },
    ],
  },
  images: {
    title: "images.md",
    blocks: [
      { t: "h1", text: "Images and assets" },
      { t: "p", text: "Relative image paths resolve against the markdown file's folder. The renderer caches textures and watches mtimes — edit a PNG and the document refreshes." },
      { t: "img", alt: "diagram of the render pipeline (placeholder)" },
      { t: "p", text: "Supported formats: **PNG · JPEG · GIF · BMP · ICO · WebP · SVG**. Missing images show a placeholder instead of crashing." },
    ],
  },
};

function Viewer() {
  const [docKey, setDocKey] = useState("welcome");
  const [dark, setDark] = useState(false);
  const [raw, setRaw] = useState(false);
  const [zoom, setZoom] = useState(1);
  const [query, setQuery] = useState("");
  const [matchIdx, setMatchIdx] = useState(0);

  const doc = SAMPLE_DOCS[docKey];
  const rawText = useMemo(() => stringifyDoc(doc), [doc]);

  // Normalised query: lowercase + strip diacritics
  const normQuery = useMemo(() => normalize(query.trim()), [query]);

  // Count matches across rendered text only (rough)
  const matchInfo = useMemo(() => {
    if (!normQuery) return { total: 0 };
    const text = rawText;
    const normText = normalize(text);
    let total = 0; let i = 0;
    while ((i = normText.indexOf(normQuery, i)) !== -1) { total++; i += normQuery.length; }
    return { total };
  }, [normQuery, rawText]);

  useEffect(() => { setMatchIdx(0); }, [normQuery, docKey, raw]);

  // Auto-scroll the viewer body to the current match
  const bodyRef = useRef(null);
  useEffect(() => {
    if (!bodyRef.current) return;
    const els = bodyRef.current.querySelectorAll(".search-hl-cur");
    if (els.length > 0) {
      const el = els[0];
      const top = el.offsetTop - 40;
      bodyRef.current.scrollTo({ top, behavior: "smooth" });
    }
  }, [matchIdx, normQuery, docKey, raw]);

  return (
    <section id="viewer">
      <div className="wrap">
        <div className="section-eyebrow"><span className="num">04</span> The viewer, live</div>
        <h2 className="section-title">Try a working mock <em>right here.</em></h2>
        <p className="section-lede">
          This is not a screenshot — it's an interactive recreation of mdmdview's interface. Toggle
          themes, switch view modes, search with diacritic folding, swap documents.
        </p>

        <div style={{ marginTop: 40 }}>
          <div className="viewer">
            <div className="titlebar">
              <span className="tl-dots"><span /><span /><span /></span>
              <span className="tl-title">mdmdview — {doc.title}</span>
              <span style={{ opacity: 0.5 }}>1.16.0</span>
            </div>
            <div className="menubar">
              {["File", "Edit", "View", "Search", "Help"].map(m => <span key={m} className={m === "View" ? "active" : ""}>{m}</span>)}
              <span style={{ marginLeft: "auto", color: "var(--ink-4)" }}>{rawText.length} chars · {rawText.split(/\s+/).filter(Boolean).length} words</span>
            </div>

            <div ref={bodyRef} className={`body ${dark ? "dark" : ""}`} style={{ fontSize: 16 * zoom }}>
              {normQuery && matchInfo.total > 0 && (
                <div className="search-overlay">
                  <span style={{ opacity: 0.6 }}>⌕</span>
                  <input value={query} onChange={e => setQuery(e.target.value)} placeholder="search…" />
                  <span className="count">{matchInfo.total === 0 ? "0/0" : `${(matchIdx % matchInfo.total) + 1}/${matchInfo.total}`}</span>
                  <button
                    onClick={() => setMatchIdx(i => (i + 1) % Math.max(1, matchInfo.total))}
                    style={{ background: "transparent", border: "none", cursor: "pointer", color: "inherit", fontFamily: "var(--mono)", fontSize: 12, padding: "0 4px" }}
                  >↓</button>
                  <button
                    onClick={() => setQuery("")}
                    style={{ background: "transparent", border: "none", cursor: "pointer", color: "inherit", fontFamily: "var(--mono)", fontSize: 12, padding: "0 4px" }}
                  >×</button>
                </div>
              )}

              {raw ? (
                <pre style={{ fontFamily: "var(--mono)", fontSize: 13 * zoom, lineHeight: 1.6, margin: 0, whiteSpace: "pre-wrap", color: dark ? "#cfcdc8" : "var(--ink-2)" }}>
                  {highlightText(rawText, normQuery, matchIdx)}
                </pre>
              ) : (
                <RenderedDoc blocks={doc.blocks} query={normQuery} matchIdx={matchIdx} matchTotal={matchInfo.total} />
              )}
            </div>

            <div className="statusbar">
              <span><span className="dot" />{dark ? "dark theme" : "light theme"} · {raw ? "Raw view" : "Rendered view"}{normQuery ? ` · ${matchInfo.total} matches` : ""}</span>
              <span>zoom {Math.round(zoom * 100)}% · UTF-8 · CommonMark</span>
            </div>
          </div>

          {/* Controls below */}
          <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr 1fr", gap: 16, marginTop: 18 }}>
            <ControlGroup label="Document">
              <div style={{ display: "flex", flexWrap: "wrap", gap: 6 }}>
                {Object.entries(SAMPLE_DOCS).map(([k, v]) => (
                  <button
                    key={k}
                    onClick={() => setDocKey(k)}
                    className={`kb-cat-btn ${docKey === k ? "active" : ""}`}
                    style={{
                      background: docKey === k ? "var(--ink)" : "transparent",
                      color: docKey === k ? "var(--paper)" : "var(--ink-3)",
                      borderColor: docKey === k ? "var(--ink)" : "var(--rule)",
                    }}
                  >{v.title}</button>
                ))}
              </div>
            </ControlGroup>

            <ControlGroup label="View mode">
              <div style={{ display: "flex", gap: 6, flexWrap: "wrap" }}>
                <ToggleBtn on={!dark} onClick={() => setDark(false)}>Light</ToggleBtn>
                <ToggleBtn on={dark} onClick={() => setDark(true)}>Dark</ToggleBtn>
                <span style={{ width: 8 }} />
                <ToggleBtn on={!raw} onClick={() => setRaw(false)}>Rendered <span style={{ opacity: 0.5, marginLeft: 4 }}>Ctrl+R</span></ToggleBtn>
                <ToggleBtn on={raw} onClick={() => setRaw(true)}>Raw</ToggleBtn>
              </div>
            </ControlGroup>

            <ControlGroup label="Zoom & search">
              <div style={{ display: "flex", gap: 6, alignItems: "center", flexWrap: "wrap" }}>
                <ToggleBtn onClick={() => setZoom(z => Math.max(0.7, +(z - 0.1).toFixed(2)))}>−</ToggleBtn>
                <span style={{ fontFamily: "var(--mono)", fontSize: 12, color: "var(--ink-3)", minWidth: 44, textAlign: "center" }}>{Math.round(zoom * 100)}%</span>
                <ToggleBtn onClick={() => setZoom(z => Math.min(1.6, +(z + 0.1).toFixed(2)))}>+</ToggleBtn>
                <ToggleBtn onClick={() => setZoom(1)}>Reset</ToggleBtn>
                <input
                  placeholder="search… (try ‘istanbul’)"
                  value={query}
                  onChange={e => setQuery(e.target.value)}
                  style={{
                    fontFamily: "var(--mono)", fontSize: 12, padding: "6px 10px",
                    border: "1px solid var(--rule)", borderRadius: 999,
                    background: "var(--paper-2)", color: "var(--ink)", outline: "none",
                    width: 160, marginLeft: 6,
                  }}
                />
              </div>
            </ControlGroup>
          </div>
        </div>
      </div>
    </section>
  );
}

function ControlGroup({ label, children }) {
  return (
    <div style={{ background: "var(--paper-2)", border: "1px solid var(--rule)", borderRadius: 10, padding: "12px 14px" }}>
      <div style={{ fontFamily: "var(--mono)", fontSize: 10, letterSpacing: "0.14em", textTransform: "uppercase", color: "var(--ink-4)", marginBottom: 8 }}>{label}</div>
      {children}
    </div>
  );
}
function ToggleBtn({ on, onClick, children }) {
  return (
    <button onClick={onClick} className={`kb-cat-btn ${on ? "active" : ""}`}
      style={{
        background: on ? "var(--ink)" : "transparent",
        color: on ? "var(--paper)" : "var(--ink-3)",
        borderColor: on ? "var(--ink)" : "var(--rule)",
      }}>{children}</button>
  );
}

// —————— Render the simulated markdown ——————
function RenderedDoc({ blocks, query, matchIdx, matchTotal }) {
  // We need a running counter for highlight occurrences so we can mark the "current" one
  const counterRef = useRef({ idx: 0 });
  counterRef.current.idx = 0;
  const cur = matchTotal > 0 ? matchIdx % matchTotal : -1;

  const hl = (text) => highlightInline(text, query, counterRef, cur);

  return (
    <div>
      {blocks.map((b, i) => {
        if (b.t === "h1") return <h1 className="md-h1" key={i}>{hl(b.text)}</h1>;
        if (b.t === "h2") return <h2 className="md-h2" key={i}>{hl(b.text)}</h2>;
        if (b.t === "h3") return <h3 className="md-h3" key={i}>{hl(b.text)}</h3>;
        if (b.t === "p") {
          return <p className="md-p" key={i} style={{ whiteSpace: "pre-line" }}>{renderInline(b.text, query, counterRef, cur)}</p>;
        }
        if (b.t === "quote") return <blockquote className="md-quote" key={i}>{hl(b.text)}</blockquote>;
        if (b.t === "ul") return (
          <ul className="md-ul" key={i}>{b.items.map((it, j) => <li key={j}>{renderInline(it, query, counterRef, cur)}</li>)}</ul>
        );
        if (b.t === "table") return (
          <table className="md-table" key={i}>
            <thead><tr>{b.head.map((h, j) => <th key={j}>{hl(h)}</th>)}</tr></thead>
            <tbody>
              {b.rows.map((r, j) => <tr key={j}>{r.map((c, k) => <td key={k}>{k === 0 ? <code className="md-code-inline">{hl(c)}</code> : hl(c)}</td>)}</tr>)}
            </tbody>
          </table>
        );
        if (b.t === "code") {
          return (
            <div className="md-codeblock" key={i}>
              <span className="lang">{b.lang}</span>
              {b.lines.map((line, j) => (
                <div key={j}>{renderCodeLine(line)}</div>
              ))}
            </div>
          );
        }
        if (b.t === "img") return <div className="md-image-placeholder" key={i}>[ image · {b.alt} ]</div>;
        return null;
      })}
    </div>
  );
}

function renderCodeLine(pairs) {
  // pairs is alternating [class, text, class, text, ...]
  const out = [];
  for (let i = 0; i < pairs.length; i += 2) {
    out.push(<span key={i} className={pairs[i]}>{pairs[i + 1]}</span>);
  }
  return out;
}

// —————— Inline rendering with **bold** *em* `code` ——————
function renderInline(text, query, counterRef, cur) {
  // Split on **bold**, *em*, `code`. Simple state machine.
  const parts = [];
  const re = /(\*\*[^*]+\*\*|`[^`]+`|\*[^*]+\*)/g;
  let last = 0; let m;
  while ((m = re.exec(text))) {
    if (m.index > last) parts.push({ k: "t", v: text.slice(last, m.index) });
    const s = m[0];
    if (s.startsWith("**")) parts.push({ k: "b", v: s.slice(2, -2) });
    else if (s.startsWith("`")) parts.push({ k: "c", v: s.slice(1, -1) });
    else parts.push({ k: "i", v: s.slice(1, -1) });
    last = m.index + s.length;
  }
  if (last < text.length) parts.push({ k: "t", v: text.slice(last) });

  return parts.map((p, i) => {
    const hl = highlightInline(p.v, query, counterRef, cur);
    if (p.k === "b") return <strong key={i} className="md-strong">{hl}</strong>;
    if (p.k === "c") return <code key={i} className="md-code-inline">{hl}</code>;
    if (p.k === "i") return <em key={i} className="md-em">{hl}</em>;
    return <React.Fragment key={i}>{hl}</React.Fragment>;
  });
}

function highlightInline(text, query, counterRef, cur) {
  if (!query) return text;
  const lower = normalize(text);
  const out = [];
  let i = 0; let last = 0;
  while ((i = lower.indexOf(query, last)) !== -1) {
    if (i > last) out.push(text.slice(last, i));
    const idx = counterRef.current.idx++;
    const isCur = idx === cur;
    out.push(<span key={`h-${idx}`} className={`search-hl ${isCur ? "search-hl-cur" : ""}`}>{text.slice(i, i + query.length)}</span>);
    last = i + query.length;
  }
  if (last < text.length) out.push(text.slice(last));
  return out;
}

function highlightText(text, query, cur) {
  // Plain text highlight for raw view
  if (!query) return text;
  const lower = normalize(text);
  const out = [];
  let i = 0; let last = 0; let idx = 0;
  while ((i = lower.indexOf(query, last)) !== -1) {
    if (i > last) out.push(text.slice(last, i));
    const isCur = idx === cur;
    out.push(<span key={`r-${idx}`} className={`search-hl ${isCur ? "search-hl-cur" : ""}`}>{text.slice(i, i + query.length)}</span>);
    idx++;
    last = i + query.length;
  }
  if (last < text.length) out.push(text.slice(last));
  return out;
}

function normalize(s) {
  return s.normalize("NFD").replace(/[\u0300-\u036f]/g, "").toLowerCase();
}

function stringifyDoc(doc) {
  const out = [];
  for (const b of doc.blocks) {
    if (b.t === "h1") out.push(`# ${b.text}`);
    else if (b.t === "h2") out.push(`## ${b.text}`);
    else if (b.t === "h3") out.push(`### ${b.text}`);
    else if (b.t === "p") out.push(b.text);
    else if (b.t === "quote") out.push(`> ${b.text}`);
    else if (b.t === "ul") out.push(b.items.map(i => `- ${i}`).join("\n"));
    else if (b.t === "table") {
      out.push(`| ${b.head.join(" | ")} |`);
      out.push(`| ${b.head.map(() => "---").join(" | ")} |`);
      out.push(b.rows.map(r => `| ${r.join(" | ")} |`).join("\n"));
    } else if (b.t === "code") {
      out.push("```" + b.lang);
      out.push(b.lines.map(l => l.filter((_, i) => i % 2 === 1).join("")).join("\n"));
      out.push("```");
    } else if (b.t === "img") {
      out.push(`![${b.alt}](./diagram.png)`);
    }
  }
  return out.join("\n\n");
}

window.Viewer = Viewer;
