/* Global data — facts about mdmdview pulled from the codebase */

window.MDMDVIEW = {
  version: "1.16.0",
  license: "MIT",
  binarySize: "4.8 MB",
  languages: "100+",
  tests: "1,100+",
  testRuntime: "~8 min",
  platforms: ["Windows", "Linux", "macOS"],
  edition: "Rust 2021",
  msrv: "1.70+",

  hero: {
    eyebrow: "v1.16 · MIT · single binary",
    titlePre: "A markdown reader,",
    titleItalic: "for people who really read.",
    lede: "mdmdview is a single-binary markdown viewer built in Rust. It opens fast, renders cleanly, and ships everything it needs in one ~4.8 MB executable — no servers, no Electron, no dependencies.",
  },

  pillars: [
    { eyebrow: "Cold start", v: "< 200", sub: "ms", k: "to first paint" },
    { eyebrow: "Binary", v: "4.8", sub: "MB", k: "release build, stripped + LTO" },
    { eyebrow: "Languages", v: "100", sub: "+", k: "syntax highlighting via syntect" },
    { eyebrow: "Test suite", v: "1,100", sub: "+", k: "tests across four oracles" },
  ],

  // Architecture nodes - clickable boxes. Layout uses rows.
  arch: {
    layers: [
      {
        label: "Entry",
        rows: [{ cells: [{ id: "main", t: "main.rs", s: "eframe setup · CLI · icon · screenshot mode" }] }],
      },
      {
        label: "State & UI",
        rows: [{ cells: [{ id: "app", t: "app.rs (224 tests)", s: "MarkdownViewerApp · menus · history · shortcuts · search" }] }],
      },
      {
        label: "Rendering",
        rows: [{
          cells: [
            { id: "renderer", t: "markdown_renderer.rs", s: "pulldown-cmark → MarkdownElement → egui widgets" },
            { id: "syntect", t: "syntect", s: "syntax highlight, 100+ langs" },
          ],
        }],
      },
      {
        label: "Diagrams",
        rows: [{
          cells: [
            { id: "mermaid", t: "mermaid (QuickJS)", s: "Embedded JS engine, offline" },
            { id: "pikchr", t: "pikchr", s: "C library, compiled in" },
            { id: "d2", t: "d2 (native)", s: "crates/d2 — pure Rust" },
          ],
        }],
      },
      {
        label: "Resources",
        rows: [{
          cells: [
            { id: "emoji", t: "emoji catalog", s: "Twemoji PNGs embedded" },
            { id: "samples", t: "sample_files", s: "Built-in demo docs" },
            { id: "winstate", t: "window_state", s: "Position persistence" },
            { id: "shell", t: "shell_integration", s: "Clipboard, reveal" },
          ],
        }],
      },
    ],
    detail: {
      main: {
        title: "main.rs",
        tag: "entry point",
        body: "Boots eframe, parses CLI args (single file open, --screenshot mode), generates the window icon at runtime, and restores window position from the previous session before handing off to the app loop.",
        bullets: [
          "Headless --screenshot renders direct to PNG — same renderer, no UI",
          "--theme · --zoom · --content-only · --scroll · --wait-ms flags",
          "Cross-platform window state on Windows/Linux/macOS",
        ],
      },
      app: {
        title: "app.rs",
        tag: "ui · state",
        body: "Owns the MarkdownViewerApp struct. Runs the immediate-mode update loop every frame: menus, status bar, content area, search panel, drag-and-drop overlay.",
        bullets: [
          "Browser-style navigation history (Alt+← / Alt+→)",
          "Rendered ↔ Raw ↔ Write modes (Ctrl+R / Ctrl+E)",
          "Multi-file drop queue with sequential navigation",
          "Thread-local test fixtures — no mocks, no globals",
        ],
      },
      renderer: {
        title: "markdown_renderer.rs",
        tag: "parse + draw",
        body: "Parses CommonMark with pulldown-cmark, lowers events into a typed MarkdownElement tree, then walks it once per frame to emit egui widgets. Caches textures for images and diagrams.",
        bullets: [
          "Element types: Paragraph, Header, CodeBlock, List, Table, Blockquote, Mermaid, Image, HorizontalRule",
          "InlineSpan: Text · Code · Strong · Emphasis · Strikethrough · Link · Image",
          "Live image refresh by watching mtime — F5 reloads from disk",
          "Header IDs auto-generated for [link](#anchor) navigation",
          "Single newlines preserved in paragraphs (poetry / lyrics)",
        ],
      },
      syntect: {
        title: "syntect",
        tag: "dependency",
        body: "syntect provides Sublime-grammar-driven syntax highlighting for 100+ languages — Rust, Python, JavaScript, C++, Go, TypeScript, SQL, and many more — with theme-driven color schemes that match the active light or dark mode.",
        bullets: [
          "Tokenised line by line for incremental rendering",
          "Pre-warmed in a background thread on first code block",
        ],
      },
      mermaid: {
        title: "mermaid_renderer.rs",
        tag: "QuickJS · offline",
        body: "Mermaid.js runs inside an embedded QuickJS interpreter, executed entirely in-process with no network access. Diagrams compile to SVG, rasterise via usvg/resvg, and land in a width-bucketed LRU texture cache.",
        bullets: [
          "Theme: Auto / Dark / Default / Forest / Neutral",
          "Strict security level hardcoded — sandboxed JS",
          "202 dedicated unit tests · pixel-diffed against the official Mermaid CLI",
        ],
      },
      pikchr: {
        title: "pikchr_renderer.rs",
        tag: "C lib · embedded",
        body: "Pikchr (the diagram language from SQLite) renders synchronously through an embedded C library compiled at build time. SVG output flows through the same usvg/resvg rasteriser as Mermaid.",
        bullets: [
          "PIKCHR_DARK_MODE flag mirrors the app's theme",
          "Shared SVG → texture pipeline with Mermaid and D2",
        ],
      },
      d2: {
        title: "crates/d2 (native)",
        tag: "pure Rust",
        body: "An in-tree D2 implementation: parser, compiler, Sugiyama layout, edge routing, SVG renderer — written from scratch and validated by four geometric invariants on every fixture.",
        bullets: [
          "Workspace crate at crates/d2 — 161 tests",
          "Layout: Sugiyama hierarchical · orthogonal edge routing",
          "Conformance: labels don't overlap nodes, edges don't pass through, etc.",
        ],
      },
      emoji: {
        title: "emoji_catalog + assets",
        tag: "Twemoji",
        body: "Twemoji's full coverage is embedded directly in the binary as PNG byte arrays. Shortcodes like :rocket: expand to 🚀 and render with grapheme-aware cluster handling.",
        bullets: [
          "Color emoji on every platform — no system font dependency",
          "CC-BY 4.0 (Twitter, Inc. & Twemoji contributors)",
        ],
      },
      samples: {
        title: "sample_files.rs",
        tag: "built-in docs",
        body: "A bundle of demonstration markdown files baked into the executable: welcome, formatting reference, code samples, usage guide, search test, and an image showcase — accessible from File ▸ Samples.",
        bullets: ["Useful as a smoke test on a fresh install"],
      },
      winstate: {
        title: "window_state.rs",
        tag: "persistence",
        body: "Saves window position, size, and maximised state once per second (throttled) and on exit. Reads back at startup, then validates the geometry so the window never opens off-screen.",
        bullets: [
          "Windows: HKEY_CURRENT_USER\\Software\\MarkdownView + file backup",
          "Linux: $XDG_CONFIG_HOME/mdmdview/window_state.txt",
          "macOS: ~/Library/Application Support/MarkdownView/",
        ],
      },
      shell: {
        title: "shell_integration.rs",
        tag: "OS bridge",
        body: "Cross-platform helpers for the File menu: copy a file to the clipboard, or reveal it in the OS file manager.",
        bullets: [
          "Windows: CF_HDROP via clipboard-win",
          "macOS: osascript",
          "Linux: xclip",
        ],
      },
    },
  },

  pipeline: [
    { n: "01", title: "Parse", body: "pulldown-cmark walks the source and emits CommonMark events." },
    { n: "02", title: "Lower", body: "Events fold into a typed MarkdownElement tree with InlineSpans." },
    { n: "03", title: "Resolve", body: "Image paths resolve against the file's base dir; mtime is cached for live refresh." },
    { n: "04", title: "Highlight", body: "Code blocks run through syntect; diagrams compile to SVG via QuickJS / Pikchr / D2." },
    { n: "05", title: "Draw", body: "The render loop walks the tree once per frame, drawing egui widgets and textures." },
  ],

  testCategories: [
    { label: "Unit tests (Rust #[test])", count: 1100, pct: 100, color: "" },
    { label: "Markdown renderer", count: 403, pct: 37, color: "amber" },
    { label: "App state · keyboard · history", count: 224, pct: 20, color: "rust" },
    { label: "Mermaid renderer + cache", count: 202, pct: 18, color: "moss" },
    { label: "D2 native crate", count: 161, pct: 15, color: "slate" },
    { label: "Window state · I/O", count: 45, pct: 4, color: "" },
    { label: "Pikchr renderer", count: 43, pct: 4, color: "" },
  ],

  testOracles: [
    { name: "Unit tests", oracle: "Explicit assertions on state and invariants." },
    { name: "D2 conformance", oracle: "Four geometric invariants checked on every diagram." },
    { name: "Visual regression", oracle: "Pixel-diff vs. baseline (26 markdown cases)." },
    { name: "Mermaid visual", oracle: "Pixel-diff vs. official Mermaid CLI (15 cases)." },
  ],

  invariants: [
    { name: "label_not_overlapping_node", desc: "Edge labels must not overlap any node rectangle." },
    { name: "edge_not_through_node", desc: "Edge paths cannot pass through non-endpoint nodes." },
    { name: "nodes_not_overlapping", desc: "Node rectangles never overlap (except container nesting)." },
    { name: "label_near_edge", desc: "Edge labels must sit within 50px of their edge path." },
  ],

  shortcuts: [
    { cat: "File", keys: ["Ctrl", "O"], what: "Open file dialog" },
    { cat: "File", keys: ["Ctrl", "W"], what: "Close current file" },
    { cat: "File", keys: ["F5"], what: "Reload current file from disk" },
    { cat: "File", keys: ["Ctrl", "Q"], what: "Quit application" },
    { cat: "Navigation", keys: ["Alt", "←"], what: "Back in history" },
    { cat: "Navigation", keys: ["Alt", "→"], what: "Forward in history" },
    { cat: "Navigation", keys: ["Home"], what: "Top of document" },
    { cat: "Navigation", keys: ["End"], what: "Bottom of document" },
    { cat: "Navigation", keys: ["PgUp"], what: "Page up (~80% viewport)" },
    { cat: "Navigation", keys: ["PgDn"], what: "Page down (~80% viewport)" },
    { cat: "View", keys: ["Ctrl", "F"], what: "Toggle search panel" },
    { cat: "View", keys: ["Ctrl", "R"], what: "Toggle Rendered ↔ Raw" },
    { cat: "View", keys: ["Ctrl", "E"], what: "Edit mode (in Raw view)" },
    { cat: "View", keys: ["F11"], what: "Toggle fullscreen" },
    { cat: "View", keys: ["Ctrl", "+"], what: "Zoom in" },
    { cat: "View", keys: ["Ctrl", "−"], what: "Zoom out" },
    { cat: "View", keys: ["Ctrl", "0"], what: "Reset zoom" },
    { cat: "Search", keys: ["Enter"], what: "Next match" },
    { cat: "Search", keys: ["Shift", "Enter"], what: "Previous match" },
    { cat: "Search", keys: ["F3"], what: "Next match" },
    { cat: "Search", keys: ["Esc"], what: "Close search" },
  ],

  deps: [
    { name: "eframe / egui", role: "GUI framework", v: "0.27" },
    { name: "pulldown-cmark", role: "CommonMark parser", v: "0.9" },
    { name: "syntect", role: "syntax highlight", v: "5.2" },
    { name: "rfd", role: "native file dialogs", v: "0.14" },
    { name: "image", role: "PNG/JPEG/GIF/BMP/WebP", v: "0.24" },
    { name: "usvg + resvg + tiny-skia", role: "SVG rasterisation", v: "0.43" },
    { name: "rquickjs", role: "embedded JS for Mermaid", v: "0.11" },
    { name: "pikchr", role: "C-lib diagram language", v: "0.1" },
    { name: "unicode-normalization", role: "search folding", v: "0.1" },
    { name: "unicode-segmentation", role: "grapheme clusters", v: "1" },
    { name: "anyhow", role: "error propagation", v: "1.0" },
    { name: "crossbeam-channel", role: "worker pool", v: "0.5" },
    { name: "winres", role: "Windows resources", v: "0.1" },
  ],
};
