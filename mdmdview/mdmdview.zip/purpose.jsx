function Purpose() {
  const beliefs = [
    {
      h: "One file. One executable.",
      p: "No installer required, no Node, no Python, no embedded browser. mdmdview is a stripped, LTO-linked Rust binary you can drop on a USB stick and run.",
    },
    {
      h: "Native, not webview.",
      p: "Built on egui — an immediate-mode GUI that draws straight to the GPU. Scroll stays butter-smooth even on documents with a thousand elements.",
    },
    {
      h: "Reads everything offline.",
      p: "Mermaid runs in an embedded QuickJS interpreter; Pikchr ships as a compiled-in C library; emoji art is bundled. Open a file on a plane and every diagram renders.",
    },
    {
      h: "Keyboard-first, but not keyboard-only.",
      p: "Drag a folder, drop multiple files into a queue, double-click a .md from Explorer. Then never touch the mouse again — every command has a shortcut.",
    },
  ];
  return (
    <section id="purpose">
      <div className="wrap">
        <div className="section-eyebrow"><span className="num">01</span> Purpose</div>
        <h2 className="section-title">A tool that respects the document, <em>and the reader.</em></h2>
        <p className="section-lede">
          Most markdown viewers either render in a browser tab or wrap one in chrome. mdmdview
          treats markdown as the long-form medium it actually is — and treats the act of reading
          as worth optimising for.
        </p>

        <div style={{ display: "grid", gridTemplateColumns: "repeat(2, 1fr)", gap: 14, marginTop: 40 }}>
          {beliefs.map((b, i) => (
            <div className="card" key={i}>
              <h3>{b.h}</h3>
              <p>{b.p}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}

window.Purpose = Purpose;
