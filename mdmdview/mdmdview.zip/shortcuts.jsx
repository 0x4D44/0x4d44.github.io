function Shortcuts() {
  const cats = ["All", "File", "Navigation", "View", "Search"];
  const [cat, setCat] = useState("All");
  const [hover, setHover] = useState(null);
  const visible = cat === "All" ? MDMDVIEW.shortcuts : MDMDVIEW.shortcuts.filter(s => s.cat === cat);

  // Listen for the actual key combo and light up the matching card
  const [hot, setHot] = useState(null);
  useEffect(() => {
    const onKey = (e) => {
      const parts = [];
      if (e.ctrlKey || e.metaKey) parts.push("Ctrl");
      if (e.altKey) parts.push("Alt");
      if (e.shiftKey) parts.push("Shift");
      let k = e.key;
      if (k === "ArrowLeft") k = "←";
      else if (k === "ArrowRight") k = "→";
      else if (k === "ArrowUp") k = "↑";
      else if (k === "ArrowDown") k = "↓";
      else if (k === "PageUp") k = "PgUp";
      else if (k === "PageDown") k = "PgDn";
      else if (k === " ") k = "Space";
      else if (k === "Escape") k = "Esc";
      else if (k.length === 1) k = k.toUpperCase();
      if (!["Control", "Alt", "Shift", "Meta"].includes(e.key)) parts.push(k);
      const sig = parts.join("+");
      setHot(sig);
      setTimeout(() => setHot(h => h === sig ? null : h), 1200);
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, []);

  const sigOf = (s) => s.keys.join("+");

  return (
    <section id="shortcuts">
      <div className="wrap">
        <div className="section-eyebrow"><span className="num">07</span> Keyboard cheatsheet</div>
        <h2 className="section-title">Twenty-one shortcuts. <em>Press one.</em></h2>
        <p className="section-lede">
          Try pressing a shortcut on your keyboard right now. The matching card will light up on the board below.
        </p>

        <div className="kb-board" style={{ marginTop: 40 }}>
          <div className="kb-cat">
            {cats.map(c => (
              <button key={c} className={`kb-cat-btn ${cat === c ? "active" : ""}`} onClick={() => setCat(c)}>{c}</button>
            ))}
            <span style={{ marginLeft: "auto", fontFamily: "var(--mono)", fontSize: 11, color: "color-mix(in srgb, var(--paper) 50%, transparent)", alignSelf: "center" }}>
              {hot ? <>Detected: <b style={{ color: "var(--paper)" }}>{hot}</b></> : "Listening for key presses…"}
            </span>
          </div>
          <div className="kb-grid">
            {visible.map((s, i) => {
              const isHot = hot === sigOf(s);
              return (
                <div key={i} className={`kb-item ${isHot || hover === sigOf(s) ? "hot" : ""}`}
                  onMouseEnter={() => setHover(sigOf(s))} onMouseLeave={() => setHover(null)}>
                  <div className="keys">
                    {s.keys.map((k, j) => (
                      <React.Fragment key={j}>
                        {j > 0 ? <span className="plus">+</span> : null}
                        <span className="kbd">{k}</span>
                      </React.Fragment>
                    ))}
                  </div>
                  <div className="what">{s.what}</div>
                </div>
              );
            })}
          </div>
        </div>
      </div>
    </section>
  );
}

window.Shortcuts = Shortcuts;
