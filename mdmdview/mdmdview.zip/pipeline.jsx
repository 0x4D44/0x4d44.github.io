function Pipeline() {
  return (
    <section id="pipeline">
      <div className="wrap">
        <div className="section-eyebrow"><span className="num">03</span> The render pipeline</div>
        <h2 className="section-title">From bytes on disk to pixels on screen.</h2>
        <p className="section-lede">
          What happens between opening a file and seeing it laid out — every frame, in milliseconds.
        </p>

        <div className="pipeline">
          {MDMDVIEW.pipeline.map((p, i, arr) => (
            <div className="pipe" key={p.n}>
              <div className="n">{p.n}</div>
              <h4>{p.title}</h4>
              <p>{p.body}</p>
              {i < arr.length - 1 ? <div className="arrow">→</div> : null}
            </div>
          ))}
        </div>

        <div style={{ marginTop: 32, background: "var(--paper-2)", border: "1px solid var(--rule)", borderRadius: 12, padding: "20px 24px", display: "flex", gap: 28, flexWrap: "wrap" }}>
          <div style={{ flex: "1 1 220px" }}>
            <div style={{ fontFamily: "var(--mono)", fontSize: 11, letterSpacing: "0.12em", textTransform: "uppercase", color: "var(--ink-4)" }}>Live image refresh</div>
            <p style={{ fontSize: 14, color: "var(--ink-2)", margin: "6px 0 0", lineHeight: 1.5 }}>
              mtime is sampled per frame. Edit a linked PNG in a paint app and the rendered document picks it up — no F5 required.
            </p>
          </div>
          <div style={{ flex: "1 1 220px" }}>
            <div style={{ fontFamily: "var(--mono)", fontSize: 11, letterSpacing: "0.12em", textTransform: "uppercase", color: "var(--ink-4)" }}>Texture cache</div>
            <p style={{ fontSize: 14, color: "var(--ink-2)", margin: "6px 0 0", lineHeight: 1.5 }}>
              Width-bucketed LRU. Diagrams compiled once per (source, width) and reused across scroll, search, and zoom.
            </p>
          </div>
          <div style={{ flex: "1 1 220px" }}>
            <div style={{ fontFamily: "var(--mono)", fontSize: 11, letterSpacing: "0.12em", textTransform: "uppercase", color: "var(--ink-4)" }}>Single-pass walk</div>
            <p style={{ fontSize: 14, color: "var(--ink-2)", margin: "6px 0 0", lineHeight: 1.5 }}>
              Immediate-mode means the element tree is walked top-to-bottom each frame. State lives in the app, not the widgets.
            </p>
          </div>
        </div>
      </div>
    </section>
  );
}

window.Pipeline = Pipeline;
