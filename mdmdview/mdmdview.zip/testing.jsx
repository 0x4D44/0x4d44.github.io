function Testing() {
  const [animatedPcts, setAnimatedPcts] = useState(MDMDVIEW.testCategories.map(() => 0));
  const ref = useRef(null);
  useEffect(() => {
    if (!ref.current) return;
    const obs = new IntersectionObserver(entries => {
      if (entries[0].isIntersecting) {
        setTimeout(() => setAnimatedPcts(MDMDVIEW.testCategories.map(t => t.pct)), 120);
        obs.disconnect();
      }
    }, { threshold: 0.2 });
    obs.observe(ref.current);
    return () => obs.disconnect();
  }, []);

  return (
    <section id="testing" ref={ref}>
      <div className="wrap">
        <div className="section-eyebrow"><span className="num">06</span> Testing</div>
        <h2 className="section-title">Tested by <em>four different oracles.</em></h2>
        <p className="section-lede">
          1,100+ tests across the workspace, plus integration suites that pixel-diff rendered
          output against reference renderers. The bar runs at <code style={{ background: "var(--paper-2)", padding: "1px 5px", borderRadius: 3, fontFamily: "var(--mono)", fontSize: "0.9em" }}>cargo clippy -- -D warnings</code> with zero warnings allowed.
        </p>

        <div className="test-grid" style={{ marginTop: 40 }}>
          <div>
            <div style={{ fontFamily: "var(--mono)", fontSize: 11, letterSpacing: "0.12em", textTransform: "uppercase", color: "var(--ink-4)", marginBottom: 14 }}>Where the tests live</div>
            {MDMDVIEW.testCategories.map((t, i) => (
              <div key={i} style={{ marginBottom: 16 }}>
                <div style={{ display: "flex", justifyContent: "space-between", marginBottom: 6, fontFamily: "var(--mono)", fontSize: 13, color: i === 0 ? "var(--ink)" : "var(--ink-2)", fontWeight: i === 0 ? 600 : 400 }}>
                  <span>{t.label}</span>
                  <span style={{ fontVariantNumeric: "tabular-nums" }}>{t.count}</span>
                </div>
                <div className={`test-bar ${t.color}`}>
                  <div className="fill" style={{ width: `${animatedPcts[i] || 0}%` }} />
                </div>
              </div>
            ))}
          </div>

          <div>
            <div style={{ fontFamily: "var(--mono)", fontSize: 11, letterSpacing: "0.12em", textTransform: "uppercase", color: "var(--ink-4)", marginBottom: 14 }}>Four oracles</div>
            {MDMDVIEW.testOracles.map((o, i) => (
              <div key={i} style={{ borderBottom: "1px solid var(--rule)", padding: "14px 0" }}>
                <div style={{ fontFamily: "var(--serif)", fontSize: 18, fontWeight: 500, color: "var(--ink)" }}>{o.name}</div>
                <div style={{ fontSize: 14, color: "var(--ink-3)", marginTop: 4 }}>{o.oracle}</div>
              </div>
            ))}

            <div style={{ marginTop: 28 }}>
              <div style={{ fontFamily: "var(--mono)", fontSize: 11, letterSpacing: "0.12em", textTransform: "uppercase", color: "var(--ink-4)", marginBottom: 12 }}>D2 geometric invariants</div>
              <div className="invariants">
                {MDMDVIEW.invariants.map((inv, i) => (
                  <div className="invariant" key={i}>
                    <div className="check">✓</div>
                    <div className="name">{inv.name}</div>
                    <div className="desc">{inv.desc}</div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>

        <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr 1fr", gap: 14, marginTop: 36 }}>
          <div className="card dark">
            <div style={{ fontFamily: "var(--mono)", fontSize: 11, letterSpacing: "0.12em", textTransform: "uppercase", color: "color-mix(in srgb, var(--paper) 60%, transparent)", marginBottom: 8 }}>No mocks</div>
            <h3 style={{ color: "var(--paper)" }}>Thread-local injection</h3>
            <p>Forced actions, open paths, scan errors, parse errors — all swappable from a test via RAII guard types. No globals, no mocks, no fakes.</p>
          </div>
          <div className="card dark">
            <div style={{ fontFamily: "var(--mono)", fontSize: 11, letterSpacing: "0.12em", textTransform: "uppercase", color: "color-mix(in srgb, var(--paper) 60%, transparent)", marginBottom: 8 }}>CPU priority</div>
            <h3 style={{ color: "var(--paper)" }}>BELOW_NORMAL on Windows</h3>
            <p>The test binary self-lowers via a CRT initializer so the 8-minute suite never starves an interactive session — important over remote desktop.</p>
          </div>
          <div className="card dark">
            <div style={{ fontFamily: "var(--mono)", fontSize: 11, letterSpacing: "0.12em", textTransform: "uppercase", color: "color-mix(in srgb, var(--paper) 60%, transparent)", marginBottom: 8 }}>CI gate</div>
            <h3 style={{ color: "var(--paper)" }}>Zero warnings</h3>
            <p>fmt --check, clippy -D warnings, full test suite, release build, MSI installer. Every step must pass before artifacts publish.</p>
          </div>
        </div>
      </div>
    </section>
  );
}

window.Testing = Testing;
