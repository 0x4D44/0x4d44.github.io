function Community() {
  return (
    <section id="community">
      <div className="wrap">
        <div className="section-eyebrow"><span className="num">09</span> Community &amp; license</div>
        <h2 className="section-title">Open, permissive, and small enough to read.</h2>
        <p className="section-lede">
          mdmdview is MIT-licensed and lives on GitHub. The codebase fits comfortably in an afternoon — somewhere
          between &ldquo;weekend project&rdquo; and &ldquo;daily driver&rdquo;.
        </p>

        <div className="community" style={{ marginTop: 40 }}>
          <div className="card">
            <div style={{ fontFamily: "var(--mono)", fontSize: 11, letterSpacing: "0.12em", textTransform: "uppercase", color: "var(--ink-4)", marginBottom: 8 }}>Contribute</div>
            <h3>Pull requests welcome</h3>
            <p>Three rules: zero warnings, well-commented public functions, new features ship with unit tests. Run <code style={{ background: "var(--paper)", padding: "1px 5px", borderRadius: 3, fontFamily: "var(--mono)", fontSize: "0.9em" }}>cargo fmt && cargo clippy && cargo test</code> before opening a PR.</p>
            <a href="#" className="btn ghost" style={{ marginTop: 14 }}>Read AGENTS.md →</a>
          </div>
          <div className="card">
            <div style={{ fontFamily: "var(--mono)", fontSize: 11, letterSpacing: "0.12em", textTransform: "uppercase", color: "var(--ink-4)", marginBottom: 8 }}>License</div>
            <h3>MIT — use it for anything</h3>
            <p>Including the embedded Twemoji art (CC-BY 4.0, attribution baked into the binary) and the bundled Mermaid.js (MIT). No surprises.</p>
            <a href="#" className="btn ghost" style={{ marginTop: 14 }}>View LICENSE →</a>
          </div>
          <div className="card">
            <div style={{ fontFamily: "var(--mono)", fontSize: 11, letterSpacing: "0.12em", textTransform: "uppercase", color: "var(--ink-4)", marginBottom: 8 }}>Get in touch</div>
            <h3>Issues &amp; discussions</h3>
            <p>Bug reports, feature ideas, and questions go to GitHub Issues. For longer-form conversation, GitHub Discussions is open and indexed.</p>
            <a href="#" className="btn ghost" style={{ marginTop: 14 }}>Open an issue →</a>
          </div>
        </div>

        <div style={{ marginTop: 48, background: "var(--ink)", color: "var(--paper)", borderRadius: 14, padding: 36, display: "grid", gridTemplateColumns: "1fr 1fr", gap: 32 }}>
          <div>
            <div style={{ fontFamily: "var(--mono)", fontSize: 11, letterSpacing: "0.12em", textTransform: "uppercase", color: "color-mix(in srgb, var(--paper) 50%, transparent)", marginBottom: 10 }}>The release pipeline</div>
            <h3 style={{ fontFamily: "var(--serif)", fontWeight: 500, fontSize: 28, letterSpacing: "-0.01em", margin: 0, color: "var(--paper)" }}>
              Tag a version. Watch the world.
            </h3>
            <p style={{ fontFamily: "var(--sans)", fontSize: 14, color: "color-mix(in srgb, var(--paper) 75%, transparent)", lineHeight: 1.55, marginTop: 12 }}>
              Pushing a <code style={{ fontFamily: "var(--mono)", background: "#2a2620", padding: "1px 5px", borderRadius: 3 }}>v*</code> git tag fires the Release workflow:
              format check, clippy lint, full test suite, release binary, MSI installer. All five steps must pass
              before artifacts publish to the GitHub Release.
            </p>
          </div>
          <div style={{ fontFamily: "var(--mono)", fontSize: 13, lineHeight: 1.7, color: "color-mix(in srgb, var(--paper) 80%, transparent)" }}>
            <div>$ git tag v{MDMDVIEW.version}</div>
            <div>$ git push origin v{MDMDVIEW.version}</div>
            <div style={{ color: "var(--amber)", marginTop: 6 }}>→ cargo fmt --check ........... ✓</div>
            <div style={{ color: "var(--amber)" }}>→ cargo clippy -D warnings ..... ✓</div>
            <div style={{ color: "var(--amber)" }}>→ cargo test --all-targets ..... ✓</div>
            <div style={{ color: "var(--amber)" }}>→ cargo build --release ........ ✓</div>
            <div style={{ color: "var(--amber)" }}>→ cargo wix --no-build ......... ✓</div>
            <div style={{ marginTop: 8 }}>artifacts:</div>
            <div style={{ color: "color-mix(in srgb, var(--paper) 60%, transparent)" }}>{"  "}mdmdview-v{MDMDVIEW.version}-windows-x86_64.msi</div>
            <div style={{ color: "color-mix(in srgb, var(--paper) 60%, transparent)" }}>{"  "}mdmdview-v{MDMDVIEW.version}-windows-x86_64.zip</div>
          </div>
        </div>
      </div>
    </section>
  );
}

function Foot() {
  return (
    <footer className="foot">
      <div className="wrap foot-inner">
        <div>
          <span style={{ color: "var(--ink-2)" }}>mdmdview</span> · MIT · built with Rust + egui
        </div>
        <div>v{MDMDVIEW.version} · single-binary · offline-first</div>
        <div>An explainer site — not the official project page.</div>
      </div>
    </footer>
  );
}

window.Community = Community;
window.Foot = Foot;
