function Hero() {
  return (
    <section id="top" className="hero">
      <div className="wrap">
        <div className="hero-grid">
          <div>
            <h1>
              A markdown reader,<br />
              <span className="italic">for people who really read.</span>
            </h1>
            <div className="hero-meta">
              <div className="m">License <b>{MDMDVIEW.license}</b></div>
              <div className="m">Built with <b>Rust + egui</b></div>
              <div className="m">Runs on <b>Win · Linux · macOS</b></div>
              <div className="m">Version <b>{MDMDVIEW.version}</b></div>
            </div>
          </div>
          <div className="hero-side">
            <span className="hero-tag"><span className="dot"></span> {MDMDVIEW.hero.eyebrow}</span>
            <p className="hero-lede">{MDMDVIEW.hero.lede}</p>
            <div className="hero-buttons">
              <a href="#install" className="btn">Install mdmdview →</a>
              <a href="#architecture" className="btn ghost">Read the architecture</a>
            </div>
          </div>
        </div>

        <div className="stats">
          {MDMDVIEW.pillars.map((p, i) => (
            <div className="stat" key={i}>
              <div className="v">{p.v}<sub>{p.sub}</sub></div>
              <div className="k">{p.k}</div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}

window.Hero = Hero;
