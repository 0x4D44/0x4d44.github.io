// Features playground — tabs with interactive demos
const FEATURES = [
  { key: "syntax", name: "Syntax highlighting", hint: "syntect · 100+ langs" },
  { key: "mermaid", name: "Mermaid diagrams", hint: "QuickJS · offline" },
  { key: "search", name: "Unicode search", hint: "diacritic-fold" },
  { key: "tables", name: "Tables", hint: "striped · responsive" },
  { key: "emoji", name: "Emoji", hint: "Twemoji embedded" },
  { key: "dnd", name: "Drag & drop", hint: "files · folders · queue" },
  { key: "screenshot", name: "Screenshot mode", hint: "CLI → PNG" },
  { key: "history", name: "Navigation history", hint: "Alt+← / Alt+→" },
];

function Features() {
  const [active, setActive] = useState("mermaid");
  const Pane = FEATURE_PANES[active];

  return (
    <section id="features">
      <div className="wrap">
        <div className="section-eyebrow"><span className="num">05</span> Feature deep-dives</div>
        <h2 className="section-title">Eight things mdmdview does <em>especially well.</em></h2>
        <p className="section-lede">
          Click any feature on the left. Each pane is interactive — actually try the behaviour.
        </p>

        <div className="feature-grid">
          <div className="feature-tabs">
            {FEATURES.map(f => (
              <button key={f.key} className={`feature-tab ${active === f.key ? "active" : ""}`} onClick={() => setActive(f.key)}>
                <div className="name">{f.name}</div>
                <div className="hint">{f.hint}</div>
              </button>
            ))}
          </div>
          <div>
            <Pane />
          </div>
        </div>
      </div>
    </section>
  );
}

// ————— Individual feature panes —————

function PaneShell({ title, blurb, children }) {
  return (
    <div style={{ background: "var(--paper-2)", border: "1px solid var(--rule)", borderRadius: 14, padding: 28, minHeight: 380 }}>
      <h3 style={{ fontFamily: "var(--serif)", fontWeight: 500, fontSize: 24, letterSpacing: "-0.01em", margin: 0 }}>{title}</h3>
      <p style={{ fontFamily: "var(--serif)", fontSize: 17, color: "var(--ink-2)", margin: "8px 0 20px", lineHeight: 1.5, textWrap: "pretty" }}>{blurb}</p>
      {children}
    </div>
  );
}

function PaneSyntax() {
  const [lang, setLang] = useState("rust");
  const samples = {
    rust: [
      ["com", "// markdown_renderer.rs"],
      ["kw", "pub enum ", "ty", "MarkdownElement ", "p", "{"],
      ["p", "    ", "ty", "Paragraph", "p", "(", "ty", "Vec", "p", "<", "ty", "InlineSpan", "p", ">),"],
      ["p", "    ", "ty", "Header ", "p", "{ level: ", "ty", "u8", "p", ", spans: ", "ty", "Vec", "p", "<", "ty", "InlineSpan", "p", ">, id: ", "ty", "String ", "p", "},"],
      ["p", "    ", "ty", "CodeBlock ", "p", "{ language: ", "ty", "Option", "p", "<", "ty", "String", "p", ">, code: ", "ty", "String ", "p", "},"],
      ["p", "    ", "ty", "Table ", "p", "{ headers: ", "ty", "Vec", "p", "<", "ty", "Vec", "p", "<", "ty", "InlineSpan", "p", ">>, rows: ", "ty", "Vec", "p", "<...> },"],
      ["p", "    ", "ty", "Mermaid", "p", "(", "ty", "String", "p", "),"],
      ["p", "    ", "ty", "HorizontalRule", "p", ","],
      ["p", "}"],
    ],
    python: [
      ["com", "# render.py — equivalent dispatch"],
      ["kw", "def ", "fn", "render", "p", "(element, ", "ty", "Ctx", "p", " ctx) -> ", "ty", "None", "p", ":"],
      ["p", "    ", "kw", "match ", "p", "element:"],
      ["p", "        ", "kw", "case ", "ty", "Heading", "p", "(level, spans, _):"],
      ["p", "            ctx.heading(level, spans)"],
      ["p", "        ", "kw", "case ", "ty", "CodeBlock", "p", "(lang, code):"],
      ["p", "            ctx.highlight(lang ", "kw", "or ", "str", "'text'", "p", ", code)"],
      ["p", "        ", "kw", "case ", "ty", "Table", "p", "(headers, rows):"],
      ["p", "            ctx.table(headers, rows)"],
    ],
    sql: [
      ["com", "-- supported by syntect grammars"],
      ["kw", "SELECT ", "p", "name, ", "fn", "COUNT", "p", "(*) ", "kw", "AS ", "p", "n"],
      ["kw", "FROM ", "p", "documents"],
      ["kw", "WHERE ", "p", "format = ", "str", "'markdown'"],
      ["p", "  ", "kw", "AND ", "p", "size_kb < ", "num", "1024"],
      ["kw", "GROUP BY ", "p", "name"],
      ["kw", "ORDER BY ", "p", "n ", "kw", "DESC", "p", ";"],
    ],
    bash: [
      ["com", "# screenshot a document headlessly"],
      ["fn", "mdmdview ", "kw", "--screenshot ", "p", "document.md ", "kw", "\\"],
      ["p", "    ", "kw", "--output ", "p", "out.png ", "kw", "\\"],
      ["p", "    ", "kw", "--theme ", "str", "dark ", "kw", "--zoom ", "num", "1.25 ", "kw", "\\"],
      ["p", "    ", "kw", "--width ", "num", "1280 ", "kw", "--height ", "num", "720"],
    ],
  };
  const langs = Object.keys(samples);
  return (
    <PaneShell
      title="Syntax highlighting"
      blurb="Code blocks are tokenised by syntect, the same Sublime-grammar engine used by bat and a lot of static-site tooling. 100+ languages, with line-based output that streams cleanly into the egui layout."
    >
      <div style={{ display: "flex", gap: 6, marginBottom: 12 }}>
        {langs.map(l => (
          <button key={l} className={`kb-cat-btn ${lang === l ? "active" : ""}`}
            onClick={() => setLang(l)}
            style={{ background: lang === l ? "var(--ink)" : "transparent", color: lang === l ? "var(--paper)" : "var(--ink-3)", borderColor: lang === l ? "var(--ink)" : "var(--rule)" }}
          >{l}</button>
        ))}
      </div>
      <div className="md-codeblock" style={{ margin: 0 }}>
        <span className="lang">{lang}</span>
        {samples[lang].map((line, i) => <div key={i}>{renderCodeLine(line)}</div>)}
      </div>
      <p style={{ fontSize: 13, color: "var(--ink-4)", fontFamily: "var(--mono)", marginTop: 12 }}>
        // colors follow the active light / dark theme
      </p>
    </PaneShell>
  );
}

function PaneMermaid() {
  // We'll build an animated, themed SVG of a flow diagram with nodes and arrows
  const themes = ["dark", "default", "forest", "neutral"];
  const [theme, setTheme] = useState("default");
  const palette = {
    default: { bg: "#fff8e6", node: "#ffe6a1", stroke: "#a8842f", text: "#3a2a00" },
    dark:    { bg: "#1f1c17", node: "#3a3025", stroke: "#caa766", text: "#f3eed8" },
    forest:  { bg: "#eaf3e3", node: "#bedba7", stroke: "#4a7a3a", text: "#1f3514" },
    neutral: { bg: "#f0f0ee", node: "#dedede", stroke: "#888", text: "#222" },
  }[theme];
  return (
    <PaneShell
      title="Mermaid diagrams — offline"
      blurb="Mermaid.js is bundled with the binary and runs in an embedded QuickJS interpreter. No browser, no network, no shelling out. SVG output flows through usvg/resvg into the same texture cache as everything else."
    >
      <div style={{ display: "flex", gap: 6, marginBottom: 12 }}>
        {themes.map(t => (
          <button key={t} className={`kb-cat-btn ${theme === t ? "active" : ""}`}
            onClick={() => setTheme(t)}
            style={{ background: theme === t ? "var(--ink)" : "transparent", color: theme === t ? "var(--paper)" : "var(--ink-3)", borderColor: theme === t ? "var(--ink)" : "var(--rule)" }}
          >{t}</button>
        ))}
      </div>
      <div style={{ background: palette.bg, borderRadius: 10, padding: 16, border: "1px solid var(--rule)", overflow: "hidden" }}>
        <svg viewBox="0 0 640 280" style={{ width: "100%", height: 260, fontFamily: "var(--mono)", fontSize: 12 }}>
          {/* Nodes */}
          <MermNode x={20} y={110} w={130} h={60} text="markdown" sub=".md file" pal={palette} />
          <MermNode x={200} y={50} w={160} h={60} text="pulldown-cmark" sub="CommonMark parser" pal={palette} />
          <MermNode x={200} y={170} w={160} h={60} text="QuickJS" sub="Mermaid.js engine" pal={palette} />
          <MermNode x={420} y={50} w={160} h={60} text="MarkdownElement" sub="typed tree" pal={palette} />
          <MermNode x={420} y={170} w={160} h={60} text="SVG → texture" sub="usvg/resvg" pal={palette} />
          {/* Edges */}
          <MermEdge from={[150,140]} to={[200,80]} pal={palette} />
          <MermEdge from={[150,140]} to={[200,200]} pal={palette} />
          <MermEdge from={[360,80]} to={[420,80]} pal={palette} />
          <MermEdge from={[360,200]} to={[420,200]} pal={palette} />
          {/* Label */}
          <text x={320} y={258} textAnchor="middle" fill={palette.text} style={{ opacity: 0.6, fontStyle: "italic" }}>theme: {theme}</text>
        </svg>
      </div>
      <p style={{ fontFamily: "var(--mono)", fontSize: 12, color: "var(--ink-4)", marginTop: 12 }}>
        View ▸ Mermaid Theme: Auto · Dark · Default · Forest · Neutral
      </p>
    </PaneShell>
  );
}
function MermNode({ x, y, w, h, text, sub, pal }) {
  return (
    <g>
      <rect x={x} y={y} width={w} height={h} rx={6} fill={pal.node} stroke={pal.stroke} strokeWidth={1.2} />
      <text x={x + w / 2} y={y + h / 2 - 4} textAnchor="middle" fill={pal.text} fontWeight={600}>{text}</text>
      <text x={x + w / 2} y={y + h / 2 + 14} textAnchor="middle" fill={pal.text} opacity={0.65} fontSize={10}>{sub}</text>
    </g>
  );
}
function MermEdge({ from, to, pal }) {
  const dx = to[0] - from[0]; const midX = from[0] + dx / 2;
  const d = `M${from[0]},${from[1]} C${midX},${from[1]} ${midX},${to[1]} ${to[0]},${to[1]}`;
  return (
    <g>
      <path d={d} stroke={pal.stroke} fill="none" strokeWidth={1.2} markerEnd="url(#arrow)" />
      <defs>
        <marker id="arrow" viewBox="0 0 10 10" refX="9" refY="5" markerWidth="6" markerHeight="6" orient="auto-start-reverse">
          <path d="M 0 0 L 10 5 L 0 10 z" fill={pal.stroke} />
        </marker>
      </defs>
    </g>
  );
}

function PaneSearch() {
  const corpus = "İstanbul · Istanbul · Zürich · Zurich · São Paulo · Sao Paulo · résumé · resume · café · cafe · naïve · naive · jalapeño · jalapeno";
  const [q, setQ] = useState("istanbul");
  const normCorpus = useMemo(() => corpus.normalize("NFD").replace(/[\u0300-\u036f]/g, "").toLowerCase(), [corpus]);
  const normQ = q.trim().normalize("NFD").replace(/[\u0300-\u036f]/g, "").toLowerCase();

  const segments = useMemo(() => {
    if (!normQ) return [{ t: corpus, m: false }];
    const out = []; let i = 0; let last = 0;
    while ((i = normCorpus.indexOf(normQ, last)) !== -1) {
      if (i > last) out.push({ t: corpus.slice(last, i), m: false });
      out.push({ t: corpus.slice(i, i + normQ.length), m: true });
      last = i + normQ.length;
    }
    if (last < corpus.length) out.push({ t: corpus.slice(last), m: false });
    return out;
  }, [normQ, corpus, normCorpus]);

  return (
    <PaneShell
      title="Search across diacritics"
      blurb="Both the query and the document are unicode-normalised (NFD) and case-folded before comparison. A search for ‘istanbul’ matches İstanbul; ‘resume’ finds résumé. Highlights respect grapheme clusters so accents stay attached."
    >
      <div style={{ display: "flex", gap: 8, alignItems: "center", marginBottom: 16 }}>
        <span style={{ fontFamily: "var(--mono)", fontSize: 12, color: "var(--ink-4)" }}>query:</span>
        <input value={q} onChange={e => setQ(e.target.value)} style={{ flex: 1, fontFamily: "var(--mono)", fontSize: 14, padding: "8px 12px", border: "1px solid var(--rule)", borderRadius: 8, background: "var(--paper)", outline: "none" }} placeholder="try ‘istanbul’ or ‘resume’ or ‘cafe’" />
      </div>
      <div style={{ background: "var(--paper)", borderRadius: 10, padding: 18, border: "1px solid var(--rule)", lineHeight: 1.8, fontSize: 16, fontFamily: "var(--serif)" }}>
        {segments.map((s, i) => s.m ? <span key={i} className="search-hl">{s.t}</span> : <span key={i}>{s.t}</span>)}
      </div>
      <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 12, marginTop: 14, fontFamily: "var(--mono)", fontSize: 12, color: "var(--ink-3)" }}>
        <div><span style={{ color: "var(--ink-4)" }}>NFD-folded query:</span> {normQ || "—"}</div>
        <div><span style={{ color: "var(--ink-4)" }}>matches:</span> {segments.filter(s => s.m).length}</div>
      </div>
    </PaneShell>
  );
}

function PaneTables() {
  const [policy, setPolicy] = useState("auto");
  return (
    <PaneShell
      title="Tables with a layout policy"
      blurb="Tables are not just rendered — they’re laid out. The renderer computes column widths from content density, then applies a policy (auto, equal, content-aware) so wide content doesn’t squish narrow columns."
    >
      <div style={{ display: "flex", gap: 6, marginBottom: 12 }}>
        {["auto", "equal", "content"].map(p => (
          <button key={p} className={`kb-cat-btn ${policy === p ? "active" : ""}`}
            onClick={() => setPolicy(p)}
            style={{ background: policy === p ? "var(--ink)" : "transparent", color: policy === p ? "var(--paper)" : "var(--ink-3)", borderColor: policy === p ? "var(--ink)" : "var(--rule)" }}
          >{p}</button>
        ))}
      </div>
      <table className="md-table" style={{
        tableLayout: policy === "equal" ? "fixed" : "auto",
        background: "var(--paper)",
      }}>
        <thead>
          <tr><th>Module</th><th>Tests</th><th>Validates</th></tr>
        </thead>
        <tbody>
          <tr><td><code className="md-code-inline">markdown_renderer.rs</code></td><td>403</td><td>parsing, rendering, image cache, search highlighting</td></tr>
          <tr><td><code className="md-code-inline">app.rs</code></td><td>224</td><td>state, shortcuts, history, drag-and-drop queue</td></tr>
          <tr><td><code className="md-code-inline">mermaid_renderer.rs</code></td><td>202</td><td>LRU cache, SVG, theme, security, worker pool</td></tr>
          <tr><td><code className="md-code-inline">crates/d2</code></td><td>161</td><td>parser, compiler, layout, edge routing</td></tr>
          <tr><td><code className="md-code-inline">window_state.rs</code></td><td>45</td><td>persistence, sanitisation, env handling</td></tr>
        </tbody>
      </table>
    </PaneShell>
  );
}

function PaneEmoji() {
  const codes = [
    ["rocket", "🚀"], ["tada", "🎉"], ["heart", "❤️"], ["fire", "🔥"],
    ["sparkles", "✨"], ["bulb", "💡"], ["wrench", "🔧"], ["package", "📦"],
    ["zap", "⚡"], ["white_check_mark", "✅"], ["x", "❌"], ["warning", "⚠️"],
    ["link", "🔗"], ["mag", "🔍"], ["floppy_disk", "💾"], ["scroll", "📜"],
  ];
  const [demo, setDemo] = useState("Type :rocket: when you ship.");
  const rendered = demo.replace(/:([a-z_]+):/g, (m, n) => {
    const e = codes.find(([k]) => k === n);
    return e ? e[1] : m;
  });
  return (
    <PaneShell
      title="Emoji — embedded, not borrowed"
      blurb="Twemoji's full glyph set is compiled into the binary as PNG byte arrays. Shortcodes like :rocket: expand to 🚀 with grapheme-aware cluster handling — even on systems with no emoji font at all."
    >
      <div style={{ background: "var(--paper)", borderRadius: 10, border: "1px solid var(--rule)", padding: 18 }}>
        <div style={{ fontFamily: "var(--mono)", fontSize: 12, color: "var(--ink-4)", marginBottom: 8 }}>source</div>
        <textarea value={demo} onChange={e => setDemo(e.target.value)} rows={2} style={{ width: "100%", fontFamily: "var(--mono)", fontSize: 14, border: "1px solid var(--rule)", borderRadius: 6, padding: 10, background: "var(--paper-2)", outline: "none", resize: "vertical" }} />
        <div style={{ fontFamily: "var(--mono)", fontSize: 12, color: "var(--ink-4)", margin: "14px 0 8px" }}>rendered</div>
        <div style={{ fontFamily: "var(--serif)", fontSize: 18, color: "var(--ink)" }}>{rendered}</div>
      </div>
      <div style={{ display: "grid", gridTemplateColumns: "repeat(8, 1fr)", gap: 6, marginTop: 14 }}>
        {codes.map(([k, e]) => (
          <button key={k} onClick={() => setDemo(d => d + ` :${k}:`)}
            style={{ background: "var(--paper)", border: "1px solid var(--rule)", borderRadius: 8, padding: "10px 4px", cursor: "pointer", fontFamily: "var(--mono)", fontSize: 11, color: "var(--ink-3)" }}
            title={`:${k}:`}>
            <div style={{ fontSize: 22, lineHeight: 1 }}>{e}</div>
            <div style={{ marginTop: 4 }}>:{k}:</div>
          </button>
        ))}
      </div>
    </PaneShell>
  );
}

function PaneDnd() {
  const [files, setFiles] = useState([
    { name: "README.md", state: "loaded" },
    { name: "CHANGELOG.md", state: "queued" },
    { name: "GUIDE.md", state: "queued" },
    { name: "notes.md", state: "queued" },
  ]);
  const advance = () => setFiles(fs => {
    const idx = fs.findIndex(f => f.state === "loaded");
    if (idx === -1 || idx === fs.length - 1) return fs;
    return fs.map((f, i) => i === idx ? { ...f, state: "seen" } : i === idx + 1 ? { ...f, state: "loaded" } : f);
  });
  const back = () => setFiles(fs => {
    const idx = fs.findIndex(f => f.state === "loaded");
    if (idx <= 0) return fs;
    return fs.map((f, i) => i === idx ? { ...f, state: "queued" } : i === idx - 1 ? { ...f, state: "loaded" } : f);
  });
  return (
    <PaneShell
      title="Drag & drop — files, folders, queues"
      blurb="Drop a single file, drop ten at once, drop a folder. mdmdview opens the first and queues the rest. Alt+→ steps through the queue; Alt+← walks back. 50-file cap prevents accidental folder dumps."
    >
      <div style={{ background: "var(--paper)", border: "1px dashed var(--ink-4)", borderRadius: 12, padding: 20, position: "relative" }}>
        <div style={{ fontFamily: "var(--mono)", fontSize: 11, letterSpacing: "0.12em", textTransform: "uppercase", color: "var(--ink-4)", marginBottom: 10 }}>
          📋 {files.filter(f => f.state === "queued").length + (files.findIndex(f => f.state === "loaded") !== -1 ? 1 : 0)} files in queue
        </div>
        <div style={{ display: "flex", flexDirection: "column", gap: 8 }}>
          {files.map((f, i) => (
            <div key={i} style={{
              display: "flex", justifyContent: "space-between", alignItems: "center",
              padding: "10px 14px", borderRadius: 8,
              background: f.state === "loaded" ? "var(--ink)" : "var(--paper-2)",
              color: f.state === "loaded" ? "var(--paper)" : "var(--ink-2)",
              border: f.state === "loaded" ? "1px solid var(--ink)" : "1px solid var(--rule)",
              fontFamily: "var(--mono)", fontSize: 13,
              opacity: f.state === "seen" ? 0.4 : 1,
            }}>
              <span>{f.state === "loaded" ? "▸ " : "  "}{f.name}</span>
              <span style={{ fontSize: 11, color: f.state === "loaded" ? "color-mix(in srgb, var(--paper) 70%, transparent)" : "var(--ink-4)" }}>{f.state}</span>
            </div>
          ))}
        </div>
      </div>
      <div style={{ display: "flex", gap: 8, marginTop: 14, alignItems: "center" }}>
        <button onClick={back} className="kb-cat-btn" style={{ background: "transparent", color: "var(--ink)", borderColor: "var(--rule)" }}>
          <span className="kbd">Alt</span> + <span className="kbd">←</span>
        </button>
        <button onClick={advance} className="kb-cat-btn" style={{ background: "transparent", color: "var(--ink)", borderColor: "var(--rule)" }}>
          <span className="kbd">Alt</span> + <span className="kbd">→</span>
        </button>
        <span style={{ fontFamily: "var(--mono)", fontSize: 11, color: "var(--ink-4)", marginLeft: "auto" }}>
          .md · .markdown · .mdown · .mkd · .txt
        </span>
      </div>
    </PaneShell>
  );
}

function PaneScreenshot() {
  const [zoom, setZoom] = useState(1.25);
  const [theme, setTheme] = useState("dark");
  const [content, setContent] = useState(true);
  return (
    <PaneShell
      title="Headless screenshot mode"
      blurb="The same renderer can run without a window. `mdmdview --screenshot doc.md --output out.png` produces a pixel-identical PNG you can pipe into CI, embed in docs, or use for visual regression."
    >
      <div className="code-block" style={{ marginTop: 0 }}>
        <span className="prompt">$</span>
        mdmdview <span className="flag">--screenshot</span> document.md <br />
        <span style={{ paddingLeft: 24 }}>
          <span className="flag">--output</span> out.png{" "}
          <span className="flag">--theme</span> {theme}{" "}
          <span className="flag">--zoom</span> {zoom}{" "}
          {content && <span className="flag">--content-only</span>}<br />
          <span style={{ paddingLeft: 0 }}>
            <span className="flag">--width</span> 1280 <span className="flag">--height</span> 720{" "}
            <span className="flag">--wait-ms</span> 600 <span className="flag">--settle-frames</span> 3
          </span>
        </span>
      </div>
      <div style={{ display: "flex", gap: 12, marginTop: 14, alignItems: "center", flexWrap: "wrap" }}>
        <span style={{ fontFamily: "var(--mono)", fontSize: 11, color: "var(--ink-4)" }}>--theme</span>
        {["light", "dark"].map(t => (
          <button key={t} className={`kb-cat-btn ${theme === t ? "active" : ""}`} onClick={() => setTheme(t)} style={{ background: theme === t ? "var(--ink)" : "transparent", color: theme === t ? "var(--paper)" : "var(--ink-3)", borderColor: theme === t ? "var(--ink)" : "var(--rule)" }}>{t}</button>
        ))}
        <span style={{ fontFamily: "var(--mono)", fontSize: 11, color: "var(--ink-4)", marginLeft: 12 }}>--zoom</span>
        <input type="range" min={0.75} max={2} step={0.05} value={zoom} onChange={e => setZoom(+e.target.value)} />
        <button className={`kb-cat-btn ${content ? "active" : ""}`} onClick={() => setContent(c => !c)} style={{ background: content ? "var(--ink)" : "transparent", color: content ? "var(--paper)" : "var(--ink-3)", borderColor: content ? "var(--ink)" : "var(--rule)" }}>
          --content-only
        </button>
      </div>
      <p style={{ fontFamily: "var(--mono)", fontSize: 11.5, color: "var(--ink-4)", marginTop: 12 }}>
        // used by the visual regression suite — same code path, no UI thread
      </p>
    </PaneShell>
  );
}

function PaneHistory() {
  const initial = ["~/notes/INDEX.md", "~/notes/2024/q4-review.md", "~/repos/mdmdview/README.md", "~/repos/mdmdview/tests.md"];
  const [stack, setStack] = useState({ back: initial.slice(0, 3), current: initial[3], fwd: [] });
  const goBack = () => setStack(s => {
    if (s.back.length === 0) return s;
    return { back: s.back.slice(0, -1), current: s.back[s.back.length - 1], fwd: [s.current, ...s.fwd] };
  });
  const goFwd = () => setStack(s => {
    if (s.fwd.length === 0) return s;
    return { back: [...s.back, s.current], current: s.fwd[0], fwd: s.fwd.slice(1) };
  });
  return (
    <PaneShell
      title="Navigation history — like a browser"
      blurb="Every file you open, every sample you pick, every internal anchor you click becomes a node in the history stack. Alt+← walks back, Alt+→ walks forward, just like in Chrome — except offline, in a single binary."
    >
      <div style={{ display: "flex", gap: 8, marginBottom: 16 }}>
        <button onClick={goBack} disabled={stack.back.length === 0} className="kb-cat-btn" style={{ background: stack.back.length === 0 ? "transparent" : "var(--ink)", color: stack.back.length === 0 ? "var(--ink-4)" : "var(--paper)", borderColor: stack.back.length === 0 ? "var(--rule)" : "var(--ink)", opacity: stack.back.length === 0 ? 0.5 : 1, cursor: stack.back.length === 0 ? "not-allowed" : "pointer" }}>
          ← Alt+←
        </button>
        <button onClick={goFwd} disabled={stack.fwd.length === 0} className="kb-cat-btn" style={{ background: stack.fwd.length === 0 ? "transparent" : "var(--ink)", color: stack.fwd.length === 0 ? "var(--ink-4)" : "var(--paper)", borderColor: stack.fwd.length === 0 ? "var(--rule)" : "var(--ink)", opacity: stack.fwd.length === 0 ? 0.5 : 1, cursor: stack.fwd.length === 0 ? "not-allowed" : "pointer" }}>
          Alt+→ →
        </button>
      </div>
      <div style={{ display: "grid", gridTemplateColumns: "1fr", gap: 0, fontFamily: "var(--mono)", fontSize: 13 }}>
        {stack.back.map((p, i) => (
          <div key={`b-${i}`} style={{ padding: "10px 14px", color: "var(--ink-4)", borderBottom: "1px solid var(--rule)", background: "var(--paper)" }}>← {p}</div>
        ))}
        <div style={{ padding: "12px 14px", color: "var(--paper)", background: "var(--ink)", borderBottom: "1px solid var(--ink)", fontWeight: 600 }}>▸ {stack.current}</div>
        {stack.fwd.map((p, i) => (
          <div key={`f-${i}`} style={{ padding: "10px 14px", color: "var(--ink-4)", borderBottom: "1px solid var(--rule)", background: "var(--paper)" }}>→ {p}</div>
        ))}
      </div>
    </PaneShell>
  );
}

const FEATURE_PANES = {
  syntax: PaneSyntax,
  mermaid: PaneMermaid,
  search: PaneSearch,
  tables: PaneTables,
  emoji: PaneEmoji,
  dnd: PaneDnd,
  screenshot: PaneScreenshot,
  history: PaneHistory,
};

window.Features = Features;
