function Install() {
  const [tab, setTab] = useState("msi");
  const blocks = {
    msi: (
      <>
        <div className="code-block">
          <button className="copy" onClick={(e) => copyParent(e)}>copy</button>
          <span className="com"># Download mdmdview-vX.Y.Z-windows-x86_64.msi from Releases</span><br />
          <span className="com"># Then double-click to install — or:</span><br />
          <span className="prompt">PS&gt;</span> msiexec /i mdmdview-v{MDMDVIEW.version}-windows-x86_64.msi<br />
          <br />
          <span className="com"># Installs to C:\Program Files\mdmdview\</span><br />
          <span className="com"># Registers .md and .markdown file associations</span><br />
          <span className="com"># Adds Add/Remove Programs entry with proper metadata</span>
        </div>
        <p style={{ fontFamily: "var(--mono)", fontSize: 12, color: "var(--ink-4)", marginTop: 12 }}>
          // Upgrade in place: a newer MSI auto-removes the old version (stable UpgradeCode GUID)
        </p>
      </>
    ),
    portable: (
      <>
        <div className="code-block">
          <button className="copy" onClick={(e) => copyParent(e)}>copy</button>
          <span className="com"># 1. Download mdmdview-vX.Y.Z-{`{platform}`}.zip</span><br />
          <span className="com"># 2. Unzip anywhere — desktop, USB stick, network share</span><br />
          <span className="com"># 3. Run the binary:</span><br />
          <br />
          <span className="prompt">$</span> ./mdmdview ~/notes/index.md<br />
          <br />
          <span className="com"># Single executable. No install, no dependencies, no admin.</span>
        </div>
      </>
    ),
    source: (
      <>
        <div className="code-block">
          <button className="copy" onClick={(e) => copyParent(e)}>copy</button>
          <span className="prompt">$</span> git clone https://github.com/0x4D44/mdmdview.git<br />
          <span className="prompt">$</span> <span className="kw">cd</span> mdmdview<br />
          <span className="prompt">$</span> cargo build <span className="flag">--release</span><br />
          <br />
          <span className="com"># ~4.8 MB stripped binary at:</span><br />
          <span className="prompt">$</span> ./target/release/mdmdview<br />
          <br />
          <span className="com"># Without embedded Mermaid (smaller binary, no diagram support):</span><br />
          <span className="prompt">$</span> cargo build <span className="flag">--release --no-default-features</span>
        </div>
      </>
    ),
    cli: (
      <>
        <div className="code-block">
          <button className="copy" onClick={(e) => copyParent(e)}>copy</button>
          <span className="com"># Open with the welcome screen</span><br />
          <span className="prompt">$</span> mdmdview<br />
          <br />
          <span className="com"># Open a specific file</span><br />
          <span className="prompt">$</span> mdmdview README.md<br />
          <span className="prompt">$</span> mdmdview "C:\Users\me\notes\My File.md"<br />
          <br />
          <span className="com"># Render headlessly to PNG</span><br />
          <span className="prompt">$</span> mdmdview <span className="flag">--screenshot</span> README.md{" "}
          <span className="flag">--output</span> readme.png <span className="flag">\</span><br />
          {"        "}<span className="flag">--theme</span> dark <span className="flag">--zoom</span> 1.25<br />
          <br />
          <span className="com"># Logging</span><br />
          <span className="prompt">$</span> RUST_LOG=debug mdmdview document.md
        </div>
      </>
    ),
  };
  return (
    <section id="install">
      <div className="wrap">
        <div className="section-eyebrow"><span className="num">08</span> Install &amp; use</div>
        <h2 className="section-title">Four ways in, depending on your day.</h2>

        <div className="install-grid" style={{ marginTop: 40 }}>
          <div>
            <div className="install-tabs">
              <button className={tab === "msi" ? "active" : ""} onClick={() => setTab("msi")}>Windows MSI</button>
              <button className={tab === "portable" ? "active" : ""} onClick={() => setTab("portable")}>Portable</button>
              <button className={tab === "source" ? "active" : ""} onClick={() => setTab("source")}>From source</button>
              <button className={tab === "cli" ? "active" : ""} onClick={() => setTab("cli")}>CLI usage</button>
            </div>
            {blocks[tab]}
          </div>

          <div>
            <div style={{ fontFamily: "var(--mono)", fontSize: 11, letterSpacing: "0.12em", textTransform: "uppercase", color: "var(--ink-4)", marginBottom: 12 }}>Where state lives</div>
            <div style={{ fontFamily: "var(--mono)", fontSize: 12.5, color: "var(--ink-3)", lineHeight: 1.8 }}>
              <div><b style={{ color: "var(--ink)" }}>Windows</b><br />
                <span style={{ color: "var(--ink-4)" }}>%APPDATA%\MarkdownView\</span><br />
                <span style={{ color: "var(--ink-4)" }}>HKCU\Software\MarkdownView</span>
              </div>
              <div style={{ marginTop: 12 }}><b style={{ color: "var(--ink)" }}>Linux</b><br />
                <span style={{ color: "var(--ink-4)" }}>~/.config/mdmdview/window_state.txt</span>
              </div>
              <div style={{ marginTop: 12 }}><b style={{ color: "var(--ink)" }}>macOS</b><br />
                <span style={{ color: "var(--ink-4)" }}>~/Library/Application Support/MarkdownView/</span>
              </div>
            </div>

            <div style={{ marginTop: 28, fontFamily: "var(--mono)", fontSize: 11, letterSpacing: "0.12em", textTransform: "uppercase", color: "var(--ink-4)", marginBottom: 8 }}>System requirements</div>
            <div style={{ fontFamily: "var(--mono)", fontSize: 12.5, color: "var(--ink-3)", lineHeight: 1.7 }}>
              Windows 10 / 11<br />
              Ubuntu 20.04+, Fedora 35+<br />
              macOS 10.15+<br />
              Rust {MDMDVIEW.msrv} (source builds only)
            </div>
          </div>
        </div>

        <div style={{ marginTop: 48 }}>
          <div style={{ fontFamily: "var(--mono)", fontSize: 11, letterSpacing: "0.12em", textTransform: "uppercase", color: "var(--ink-4)", marginBottom: 12 }}>What's inside the binary</div>
          <div className="deps-cloud">
            {MDMDVIEW.deps.map((d, i) => (
              <span className="dep" key={i}>
                <b>{d.name}</b> · {d.role}{d.v ? <> · <span style={{ color: "var(--ink-4)" }}>{d.v}</span></> : null}
              </span>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}

function copyParent(e) {
  const block = e.target.closest(".code-block");
  if (!block) return;
  const text = block.innerText.replace(/^copy\n?/m, "").trim();
  navigator.clipboard.writeText(text).then(() => {
    const prev = e.target.innerText;
    e.target.innerText = "copied ✓";
    setTimeout(() => { e.target.innerText = prev; }, 1500);
  }).catch(() => {});
}

window.Install = Install;
