// Nav and hero
const { useState, useEffect, useRef, useMemo } = React;

function Nav() {
  return (
    <nav className="nav">
      <div className="wrap nav-inner">
        <a href="#top" className="brand">
          <span className="mark">m</span>
          <b>mdmdview</b>
          <span className="ver">v{MDMDVIEW.version}</span>
        </a>
        <div className="nav-links">
          <a href="#purpose">Purpose</a>
          <a href="#architecture">Architecture</a>
          <a href="#viewer">Viewer</a>
          <a href="#features">Features</a>
          <a href="#testing">Testing</a>
          <a href="#shortcuts">Shortcuts</a>
          <a href="#install">Install</a>
        </div>
        <a href="#install" className="nav-cta">Get mdmdview →</a>
      </div>
    </nav>
  );
}

window.Nav = Nav;
