function Architecture() {
  const [active, setActive] = useState("renderer");
  const detail = MDMDVIEW.arch.detail[active];

  return (
    <section id="architecture">
      <div className="wrap">
        <div className="section-eyebrow"><span className="num">02</span> Architecture</div>
        <h2 className="section-title">A short tour, <em>top to bottom.</em></h2>
        <p className="section-lede">
          mdmdview is structured as a thin set of layers — entry, application state, renderer,
          diagram backends, embedded resources. Click any box to expand.
        </p>

        <div className="arch" style={{ marginTop: 40 }}>
          <div className="arch-diagram">
            {MDMDVIEW.arch.layers.map((layer, li) => (
              <div key={li} style={{ marginBottom: 14, position: "relative" }}>
                <div style={{ fontFamily: "var(--mono)", fontSize: 10, letterSpacing: "0.16em", textTransform: "uppercase", color: "var(--ink-4)", marginBottom: 8 }}>
                  {layer.label}
                </div>
                {layer.rows.map((row, ri) => (
                  <div key={ri} className={`arch-row r${row.cells.length}`}>
                    {row.cells.map(cell => (
                      <button
                        key={cell.id}
                        className={`arch-node ${active === cell.id ? "active" : ""}`}
                        onClick={() => setActive(cell.id)}
                        type="button"
                      >
                        <div className="t">{cell.t}</div>
                        <div className="s">{cell.s}</div>
                      </button>
                    ))}
                  </div>
                ))}
              </div>
            ))}
          </div>

          <div className="arch-detail">
            <span className="tag">{detail.tag}</span>
            <h3 style={{ marginTop: 14 }}>{detail.title}</h3>
            <p>{detail.body}</p>
            <ul>
              {detail.bullets.map((b, i) => <li key={i}>{b}</li>)}
            </ul>
          </div>
        </div>
      </div>
    </section>
  );
}

window.Architecture = Architecture;
