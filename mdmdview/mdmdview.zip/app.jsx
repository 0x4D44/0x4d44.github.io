function App() {
  return (
    <>
      <Nav />
      <Hero />
      <Purpose />
      <Architecture />
      <Pipeline />
      <Viewer />
      <Features />
      <Testing />
      <Shortcuts />
      <Install />
      <Community />
      <Foot />
    </>
  );
}

const root = ReactDOM.createRoot(document.getElementById("root"));
root.render(<App />);
