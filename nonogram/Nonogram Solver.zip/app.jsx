// Top-level explainer app.

const { useState, useMemo, useEffect, useRef } = React;

// ---------- Win 3.1 window chrome ----------
function Win({ title, children, bodyClass = "", icon = true }) {
  return (
    <div className="win">
      <div className="win-title">
        {icon && <span className="ico"></span>}
        <span>{title}</span>
        <span className="spacer"></span>
        <span className="btns">
          <span className="btn-sq">▼</span>
          <span className="btn-sq">▲</span>
        </span>
      </div>
      <div className={"win-body " + bodyClass}>{children}</div>
    </div>
  );
}

// ---------- Hero ----------
function Hero() {
  return (
    <div className="win">
      <div className="win-title">
        <span className="ico"></span>
        <span>NONOGRAM.EXE — File: NONOGRAM.PAS</span>
        <span className="spacer"></span>
        <span className="btns">
          <span className="btn-sq">_</span>
          <span className="btn-sq">□</span>
        </span>
      </div>
      <div className="hero">
        <div className="hero-left">
          <div className="section-h">A codebase walkthrough · 1994</div>
          <h1>Nonogram<span className="ext">.exe</span></h1>
          <p className="sub" style={{marginTop: 14}}>
            A 6,370-line Object Pascal program for Windows 3.1 that solves
            the picture-logic puzzles printed weekly in the Sunday Telegraph.
            Five layered solver heuristics, an MDI shell, a custom file format,
            a Visual Basic installer, and a Help file that still feels
            personal three decades on.
          </p>
          <div className="meta-row">
            <span className="tag">v2.3</span>
            <span className="tag">15 Nov 1994</span>
            <span className="tag">Author: M. G. Davidson</span>
            <span className="tag">Borland TPW + OWL</span>
            <span className="tag">Win16</span>
          </div>
        </div>
        <div className="hero-right">
          <h3>Sample puzzle · GREETING.NGM</h3>
          <div className="grid-preview">
            <PreviewMini />
          </div>
          <table className="kvtable" style={{marginTop: 16}}>
            <tbody>
              <tr><td>title</td><td>Christmas Nonogram 1997 — Greetings</td></tr>
              <tr><td>size</td><td>60 × 50</td></tr>
              <tr><td>format</td><td>plain text · X clues, Y clues</td></tr>
              <tr><td>packed</td><td>NG_ (LZ-compressed install asset)</td></tr>
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}

// A tiny static preview puzzle (decorative)
function PreviewMini() {
  // 16 × 12 abstract glyph
  const W = 16, H = 12;
  const cells = `
0000111111100000
0011000000110000
0110011001011000
0110111101011000
0110011001011000
0110000000011000
0110111111011000
0110100000011000
0011000000110000
0001111111100000
0000000000000000
0000111111100000`.trim().split("\n");
  const px = 14;
  return (
    <svg width={W*px} height={H*px} className="nonogram-svg" viewBox={`0 0 ${W*px} ${H*px}`}>
      {Array.from({length: H}, (_, r) =>
        Array.from({length: W}, (_, c) => {
          const v = cells[r][c];
          return <rect key={r+"-"+c} x={c*px} y={r*px} width={px} height={px}
            className={"cell-bg" + ((c%5===0||r%5===0)?" major":"")} />;
        }))}
      {Array.from({length: H}, (_, r) =>
        Array.from({length: W}, (_, c) => {
          if (cells[r][c] === "1") {
            return <rect key={"f"+r+"-"+c} x={c*px+1.2} y={r*px+1.2} width={px-2.4} height={px-2.4} className="blockmark" />;
          }
          return null;
        }))}
    </svg>
  );
}

// ---------- Stats strip ----------
function Stats() {
  const data = [
    { num: "6,370", lbl: "Lines · NONOGRAM.PAS", sub: "One file. Pascal." },
    { num: "5", lbl: "Solver phases", sub: "Layered, toggleable" },
    { num: "44", lbl: ".NGM puzzles shipped", sub: "Snowman · Bear · Santa · …" },
    { num: "4", lbl: "Languages", sub: "Pascal · VB · RTF · NGM" },
    { num: "1994", lbl: "Released", sub: "Win 3.1 · 16-bit" },
  ];
  return (
    <div className="stats">
      {data.map((d, i) =>
        <div className="cell" key={i}>
          <div className="num">{d.num}</div>
          <div className="lbl">{d.lbl}</div>
          <div className="sublbl">{d.sub}</div>
        </div>
      )}
    </div>
  );
}

// ---------- Architecture ----------
const MODULES = [
  { id: "main", name: "TMainWindow", color: "#1c1858",
    desc: "MDI frame window. Owns the toolbar, status bar, menus, app-wide config in NONOGRAM.INI, recent-files list, and the drop-files handler." },
  { id: "display", name: "TDisplay (MDI child)", color: "#c8511d",
    desc: "One window per puzzle. Holds the grid state, the X/Y clue arrays, the in-place edit popup, scrolling, printing, and ALL solver routines." },
  { id: "toolbar", name: "TToolbar + TToolbutton", color: "#1d6c5e",
    desc: "Hand-rolled 3D toolbar. Each button is its own TWindow subclass with up/down bitmaps and tooltip text. 13 buttons, swapped at runtime." },
  { id: "stat", name: "TStatbar", color: "#8a6a1d",
    desc: "Status bar at the bottom. Three regions: main text, elapsed solve time, points-found counter. Repaints during the solve loop." },
  { id: "dialogs", name: "Dialog classes", color: "#5a3e1d",
    desc: "TInfo, TConfDispl, TConfSolut, TPrefer, THeadData, TLicence — owned dialogs for the Options menu. Built off Borland's TDialog." },
  { id: "mdgen", name: "MDGEN.DLL", color: "#7a4477",
    desc: "Tiny helper DLL (Pascal). Three exports: GetVersion, FileExists, ConvertDate. Pulled out so the EXE stays under the 16-bit segment ceiling." },
  { id: "setup", name: "SETUP1.EXE", color: "#385e8f",
    desc: "Visual Basic 2.0 installer. Decompresses the *.NG_ / *.DL_ / *.EX_ assets, registers the program group, validates licence number." },
  { id: "help", name: "NONOGRAM.HLP", color: "#6e7c1d",
    desc: "WinHelp 3.1 file compiled from NONOGRAM.RTF + NONOGRAM.HPJ + 30 embedded BMPs. F1 context maps via the HC_* constants in the Pascal code." },
];

function Architecture() {
  const [active, setActive] = useState("display");
  return (
    <div className="arch">
      <div className="arch-svg-wrap">
        <svg className="arch-svg" viewBox="0 0 320 360">
          {/* Frame */}
          <rect x="10" y="10" width="300" height="340" fill="#fbf8ec" stroke="#1a1a1a" strokeWidth="1" />
          <text x="20" y="26" className="title">Process: NONOGRAM.EXE</text>

          {/* MainWindow */}
          <rect x="25" y="40" width="270" height="50"
            className={"node-rect" + (active === "main" ? " active" : "")}
            fill={active==="main"?"#fde0d0":"#ece9d0"} onClick={() => setActive("main")} style={{cursor:"pointer"}} />
          <text x="35" y="60" onClick={() => setActive("main")} style={{cursor:"pointer"}}>TMainWindow</text>
          <text x="35" y="74" fill="#7a7568">MDI frame · toolbar · status · menus</text>

          {/* MDI child windows */}
          <rect x="25" y="105" width="125" height="55"
            className={"node-rect" + (active === "display" ? " active" : "")}
            fill={active==="display"?"#fde0d0":"#ece9d0"} onClick={() => setActive("display")} style={{cursor:"pointer"}} />
          <text x="35" y="123" onClick={() => setActive("display")} style={{cursor:"pointer"}}>TDisplay</text>
          <text x="35" y="137" fill="#7a7568">grid · clues</text>
          <text x="35" y="150" fill="#7a7568">solver routines</text>

          {/* Children: toolbar, statbar */}
          <rect x="170" y="105" width="125" height="25"
            className={"node-rect" + (active === "toolbar" ? " active" : "")}
            fill={active==="toolbar"?"#fde0d0":"#ece9d0"} onClick={() => setActive("toolbar")} style={{cursor:"pointer"}} />
          <text x="180" y="121" onClick={() => setActive("toolbar")} style={{cursor:"pointer"}}>TToolbar</text>

          <rect x="170" y="135" width="125" height="25"
            className={"node-rect" + (active === "stat" ? " active" : "")}
            fill={active==="stat"?"#fde0d0":"#ece9d0"} onClick={() => setActive("stat")} style={{cursor:"pointer"}} />
          <text x="180" y="151" onClick={() => setActive("stat")} style={{cursor:"pointer"}}>TStatbar</text>

          {/* Dialogs */}
          <rect x="25" y="180" width="270" height="35"
            className={"node-rect" + (active === "dialogs" ? " active" : "")}
            fill={active==="dialogs"?"#fde0d0":"#ece9d0"} onClick={() => setActive("dialogs")} style={{cursor:"pointer"}} />
          <text x="35" y="201" onClick={() => setActive("dialogs")} style={{cursor:"pointer"}}>Dialog classes  ▸  Info · Solution · Display · Prefer · Header</text>

          {/* External resources */}
          <line x1="160" y1="225" x2="160" y2="240" className="edge" />

          <rect x="25" y="240" width="125" height="40"
            className={"node-rect" + (active === "mdgen" ? " active" : "")}
            fill={active==="mdgen"?"#fde0d0":"#dde6dd"} onClick={() => setActive("mdgen")} style={{cursor:"pointer"}} />
          <text x="35" y="258" onClick={() => setActive("mdgen")} style={{cursor:"pointer"}}>MDGEN.DLL</text>
          <text x="35" y="272" fill="#7a7568">helper · dates · files</text>

          <rect x="170" y="240" width="125" height="40"
            className={"node-rect" + (active === "help" ? " active" : "")}
            fill={active==="help"?"#fde0d0":"#dde6dd"} onClick={() => setActive("help")} style={{cursor:"pointer"}} />
          <text x="180" y="258" onClick={() => setActive("help")} style={{cursor:"pointer"}}>NONOGRAM.HLP</text>
          <text x="180" y="272" fill="#7a7568">WinHelp 3.1 · F1</text>

          {/* Setup */}
          <rect x="25" y="295" width="270" height="45"
            className={"node-rect" + (active === "setup" ? " active" : "")}
            fill={active==="setup"?"#fde0d0":"#dde0ec"} onClick={() => setActive("setup")} style={{cursor:"pointer"}} />
          <text x="35" y="313" onClick={() => setActive("setup")} style={{cursor:"pointer"}}>SETUP1.EXE (Visual Basic 2.0)</text>
          <text x="35" y="327" fill="#7a7568">decompresses NG_/DL_/EX_ · licence dialog · prog group</text>

          {/* Edges */}
          <line x1="100" y1="90" x2="100" y2="105" className="edge" />
          <line x1="220" y1="90" x2="220" y2="105" className="edge" />
          <line x1="160" y1="160" x2="160" y2="180" className="edge" />
        </svg>
      </div>
      <div className="arch-list">
        <div className="section-h">Click a module</div>
        {MODULES.map(m =>
          <div key={m.id}
            className={"row" + (active === m.id ? " active" : "")}
            onClick={() => setActive(m.id)}>
            <span className="swatch" style={{ background: m.color }}></span>
            <div>
              <div className="name">{m.name}</div>
              <div className="desc">{m.desc}</div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}

// ---------- Solver demo ----------
function Solver() {
  const PHASES = window.NONOGRAM.phases;
  const PUZZLES = window.NONOGRAM.PUZZLES;
  const [puzzleId, setPuzzleId] = useState("arrow");
  const puzzle = PUZZLES[puzzleId];
  const W = puzzle.cols.length, H = puzzle.rows.length;

  const initialGrid = () => Array.from({length: H}, () => Array(W).fill(0));
  const [grid, setGrid] = useState(initialGrid);
  const [enabled, setEnabled] = useState({
    quick: true, edge: true, full: true, follow: true, single: true, comb: false,
  });
  const [lastChange, setLastChange] = useState(0);
  const [phaseLog, setPhaseLog] = useState([]);
  const [solving, setSolving] = useState(false);

  function reset(id = puzzleId) {
    setPuzzleId(id);
    setGrid(Array.from({length: PUZZLES[id].rows.length}, () => Array(PUZZLES[id].cols.length).fill(0)));
    setLastChange(0);
    setPhaseLog([]);
  }

  function applyPhase(p) {
    const g = grid.map(r => r.slice());
    const n = p.run(g, puzzle.rows, puzzle.cols);
    setGrid(g);
    setLastChange(n);
    setPhaseLog(log => [...log.slice(-5), `${p.pname}: +${n} cells`]);
  }

  async function runAll() {
    setSolving(true);
    setPhaseLog([]);
    let g = grid.map(r => r.slice());
    let prevFilled = -1;
    let curFilled = countFilled(g);
    let iter = 0;
    while (prevFilled !== curFilled && iter < 12) {
      iter++;
      for (const p of PHASES) {
        if (!enabled[p.id]) continue;
        const before = countAll(g);
        const n = p.run(g, puzzle.rows, puzzle.cols);
        const after = countAll(g);
        if (after - before > 0) {
          setPhaseLog(log => [...log, `iter ${iter} · ${p.pname}: +${after - before}`]);
          setGrid(g.map(r => r.slice()));
          await sleep(220);
        }
      }
      prevFilled = curFilled;
      curFilled = countFilled(g);
    }
    setSolving(false);
  }

  function countFilled(g) { return g.flat().filter(v => v === 1).length; }
  function countDots(g)   { return g.flat().filter(v => v === 2).length; }
  function countAll(g)    { return g.flat().filter(v => v !== 0).length; }
  function sleep(ms) { return new Promise(r => setTimeout(r, ms)); }

  const filled = useMemo(() => countFilled(grid), [grid]);
  const dots   = useMemo(() => countDots(grid),   [grid]);
  const known  = filled + dots;
  const total  = W * H;
  const solved = known === total;

  return (
    <div className="solver">
      <div className="solver-grid-wrap">
        <div className="puzzle-pick">
          {Object.entries(PUZZLES).map(([id, p]) =>
            <button key={id}
              className={puzzleId === id ? "active" : ""}
              onClick={() => reset(id)}>
              {p.name} · {p.cols.length}×{p.rows.length}
            </button>
          )}
        </div>
        <NonogramSvg grid={grid} rows={puzzle.rows} cols={puzzle.cols} />
        <div className="ministatus">
          <span>{puzzle.note}</span>
          <span style={{color: solved ? "var(--accent-2)" : "var(--ink-2)", fontWeight: solved ? 700 : 400}}>
            {solved
              ? "✓ Solved · " + filled + " blocks · " + dots + " dots"
              : known + "/" + total + " determined · " + (total - known) + " unknown"}
          </span>
        </div>
        <div style={{
          marginTop: 8,
          fontSize: 11,
          fontFamily: "JetBrains Mono, monospace",
          color: "var(--ink-3)",
          display: "flex",
          gap: 14,
        }}>
          <span><span style={{
            display: "inline-block", width: 10, height: 10, background: "var(--block)",
            verticalAlign: "middle", marginRight: 4
          }}></span>block (1)</span>
          <span><span style={{
            display: "inline-block", width: 10, height: 10, background: "var(--dot)",
            borderRadius: "50%", verticalAlign: "middle", marginRight: 4
          }}></span>dot · known empty (2)</span>
          <span><span style={{
            display: "inline-block", width: 10, height: 10, background: "var(--grid-bg)",
            border: "1px solid #bbb6a0", verticalAlign: "middle", marginRight: 4
          }}></span>unknown (0) — only appears mid-solve</span>
        </div>
      </div>
      <div className="solver-controls">
        <div className="section-h">Options ▸ Configure solution</div>
        <div className="dialog" style={{marginBottom: 14, padding: "10px 12px"}}>
          <div style={{fontWeight: 600, fontSize: 13, marginBottom: 6}}>Solver phases (toggle &amp; step)</div>
          <div style={{fontSize: 12, color: "var(--ink-2)"}}>
            These mirror the six check-boxes in the Pascal Configure Solution dialog (<span className="mono">ID_QSTART…ID_GREEDY</span>).
          </div>
        </div>
        {PHASES.map(p =>
          <div className="phase-row" key={p.id}>
            <label>
              <input
                type="checkbox" className="phase-check"
                checked={enabled[p.id]}
                onChange={e => setEnabled({...enabled, [p.id]: e.target.checked})} />
              <div className="phase-text">
                <div className="name">{p.name}<span className="pname">{p.pname}</span></div>
                <div className="blurb">{p.blurb}</div>
              </div>
            </label>
            <button className="btn-3d" style={{marginLeft: "auto", alignSelf: "flex-start", padding: "3px 9px", fontSize: 11}}
              onClick={() => applyPhase(p)} disabled={solving}>
              Step
            </button>
          </div>
        )}
        <div className="solver-actions">
          <button className="btn-3d primary" onClick={runAll} disabled={solving}>
            ▶ Solve
          </button>
          <button className="btn-3d" onClick={() => reset()} disabled={solving}>
            Reset
          </button>
        </div>
        {phaseLog.length > 0 &&
          <div className="ministatus" style={{flexDirection: "column", gap: 2, alignItems: "stretch", marginTop: 14}}>
            {phaseLog.slice(-6).map((l, i) => <span key={i}>{l}</span>)}
          </div>}
        <div style={{
          marginTop: 14, fontSize: 12, color: "var(--ink-3)",
          borderTop: "1px dotted var(--ink-3)", paddingTop: 10
        }}>
          <b style={{color:"var(--ink-2)"}}>Why might cells stay unknown?</b>{" "}
          NONOGRAM.EXE — and this demo — only do <i>line-solving</i>: every
          deduction is made within a single row or column. A puzzle whose
          clues admit two valid grids (ambiguous) or whose cells require
          cross-line reasoning will leave gaps. The original program reports
          this as <code>"Cannot obtain a solution!"</code> in the status bar.
          A modern solver would add backtracking search on top — but Davidson
          chose configurable line-solving and stopped there.
        </div>
      </div>
    </div>
  );
}

function NonogramSvg({ grid, rows, cols }) {
  const W = cols.length, H = rows.length;
  const px = W <= 8 ? 28 : W <= 10 ? 24 : 18;
  const maxRowClues = Math.max(...rows.map(r => r.length));
  const maxColClues = Math.max(...cols.map(c => c.length));
  const padL = maxRowClues * 16 + 8;
  const padT = maxColClues * 14 + 8;
  const totalW = padL + W * px + 8;
  const totalH = padT + H * px + 8;
  return (
    <svg className="nonogram-svg" width="100%" viewBox={`0 0 ${totalW} ${totalH}`}>
      {/* Column clues */}
      {cols.map((clueArr, c) =>
        clueArr.map((n, i) =>
          <text key={`cc-${c}-${i}`} x={padL + c * px + px/2} y={padT - (clueArr.length - i - 1) * 12 - 4} className="clue" textAnchor="middle">{n}</text>
        )
      )}
      {/* Row clues */}
      {rows.map((clueArr, r) =>
        clueArr.map((n, i) =>
          <text key={`rc-${r}-${i}`} x={padL - (clueArr.length - i - 1) * 14 - 6} y={padT + r * px + px/2 + 3} className="clue" textAnchor="end">{n}</text>
        )
      )}
      {/* Cells */}
      {Array.from({length: H}, (_, r) =>
        Array.from({length: W}, (_, c) => {
          const major = (c % 5 === 0 && c > 0) || (r % 5 === 0 && r > 0);
          return <rect key={`bg-${r}-${c}`} x={padL + c*px} y={padT + r*px} width={px} height={px}
            className={"cell-bg" + (major ? " major" : "")} />;
        })
      )}
      {/* Outer frame */}
      <rect x={padL} y={padT} width={W*px} height={H*px} fill="none" stroke="#1a1a1a" strokeWidth="1.5" />

      {/* Marks */}
      {grid.map((row, r) =>
        row.map((v, c) => {
          if (v === 1) {
            return <rect key={`m-${r}-${c}`}
              x={padL + c*px + 1.5} y={padT + r*px + 1.5}
              width={px - 3} height={px - 3}
              className="blockmark" />;
          }
          if (v === 2) {
            return <circle key={`d-${r}-${c}`}
              cx={padL + c*px + px/2} cy={padT + r*px + px/2}
              r={1.6}
              className="dotmark" />;
          }
          return null;
        })
      )}
    </svg>
  );
}

// ---------- Version Timeline ----------
const VERSIONS = [
  {
    v: "2.1", date: "20 Feb 1994",
    title: "The SINGLE breakthrough",
    body: <>
      <p>Adds the <code>SingleTst</code> solver pass — a special case for lines whose clues are all the same value. Author's note in the file header:</p>
      <p className="quote">"This allows the program to solve 'Hermit Crab' which it could not previously do."</p>
      <p>This is the most telling commit in the whole history. The puzzle won. A new heuristic was written specifically to beat it.</p>
    </>,
  },
  {
    v: "2.2", date: "10 Apr 1994",
    title: "The big rewrite",
    body: <>
      <p>Major release. Five things change at once:</p>
      <ul>
        <li><b>Full MDI</b> — multiple puzzles open simultaneously, each in its own <code>TDisplay</code> child.</li>
        <li><b>3D look</b> — Borland's custom controls swapped for <i>Microsoft's</i> CTL3D, which is what gives the program its proper Windows 3.1 chrome.</li>
        <li><b>In-place clue editing</b> — click a number, retype it, press Return. Saves to disk.</li>
        <li><b>Greedy mode</b> — disables the cooperative-yield inside <code>Combination</code> for raw speed.</li>
        <li><b>Self-installing</b> — the VB-based <code>SETUP1.EXE</code> ships for the first time.</li>
      </ul>
    </>,
  },
  {
    v: "2.21", date: "2 May 1994",
    title: "Scrollbar bug-fix release",
    body: <>
      <p>Pure bug-fix. The header is honest about it:</p>
      <ul>
        <li>Cursor keys could push the in-place edit window off the visible area when the scrollbars were non-zero.</li>
        <li>Clicking clue "18" with the scrollbar offset pulled up the wrong row's edit popup.</li>
        <li>Scrollbars failed to redraw when loading a differently-sized file into an existing window.</li>
      </ul>
      <p className="quote">"No changes have been made to the fundmental Nonogram solving routines."</p>
    </>,
  },
  {
    v: "2.3", date: "15 Nov 1994",
    title: "Going commercial",
    body: <>
      <p>The final shipped version. Six months of quiet work, then:</p>
      <ul>
        <li>Dialogs tidied; help file expanded.</li>
        <li>Solver code rewritten enough to pass with <code>{`{$R+}`}</code> range-checking on — "sloppy array handling" was fixed.</li>
        <li>Bug in <code>DrawPoint</code> where the viewport origin wasn't set when the procedure obtained its own DC.</li>
      </ul>
      <p className="quote">"The aim of the changes has been to get the program into a state where it can be released commercially."</p>
      <p>Bundled licence number system arrives. <code>MDGEN.DLL</code> bumps to v1.01.</p>
    </>,
  },
];

function Timeline() {
  const [idx, setIdx] = useState(3);
  const v = VERSIONS[idx];
  return (
    <div className="timeline">
      <div className="tl-list">
        {VERSIONS.map((vv, i) =>
          <div key={i} className={"tl-item" + (idx === i ? " active" : "")} onClick={() => setIdx(i)}>
            <div className="v">v{vv.v}</div>
            <div className="d">{vv.date}</div>
          </div>
        )}
      </div>
      <div className="tl-detail">
        <h3>{v.title}</h3>
        <div className="when">v{v.v} · {v.date}</div>
        <div style={{fontSize: 14}}>{v.body}</div>
      </div>
    </div>
  );
}

// ---------- File format ----------
function FileFormat() {
  return (
    <div className="fmt">
      <div>
        <p>
          Every puzzle ships as a plain-text <code>.NGM</code> file (the
          installer compresses them to <code>.NG_</code> with the Microsoft
          Compress utility, then SETUP1 unpacks them on install). The format
          is humanly readable and trivially hackable — anyone can author a
          new nonogram with Notepad.
        </p>
        <p>
          The header is one line of free-form text used for the
          status bar caption, then the grid dimensions, then the
          X-axis (column) clues, then the Y-axis (row) clues.
          Numbers are separated by any non-numeric character —
          spaces, commas, even tabs all work, parsed inside
          <code> TDisplay.FileLoadImplement</code>.
        </p>
        <p>
          The parser is lenient by design: empty clue lines mean "no clues
          for this column or row yet". This is exactly how <code>MILLENNI.NGM</code>
          (a 75×55 puzzle that ships partially blank) and <code>GREETING.NGM</code>
          are formatted — Davidson appears to have authored them by entering
          dimensions first, then filling clues in the in-place editor as he
          went.
        </p>
      </div>
      <div>
        <div className="section-h">SNOWMAN.NGM · first 12 lines</div>
        <div className="fmt-code">
<span className="ln-title">Nonogram 176 - Snowman - 09/01/1994</span>{"\n"}
<span className="ln-dim">25 20</span>{"\n"}
<span className="ln-x">4 5 9</span>{"\n"}
<span className="ln-x">2 9 2</span>{"\n"}
<span className="ln-x">3 3 1</span>{"\n"}
<span className="ln-x">3 1</span>{"\n"}
<span className="ln-x">2</span>{"\n"}
<span className="ln-x">2</span>{"\n"}
<span className="ln-x">2 1 1</span>{"\n"}
<span className="ln-x">2 1</span>{"\n"}
<span className="ln-x">…</span>{"\n"}
<span style={{color:"var(--ink-3)"}}>{"// 25 column clues, then 20 row clues"}</span>
        </div>
        <div className="langlegend">
          <span><span className="sw" style={{background:"var(--accent)"}}></span>title</span>
          <span><span className="sw" style={{background:"var(--accent-2)"}}></span>dimensions (W × H)</span>
          <span><span className="sw" style={{background:"var(--ink)"}}></span>column clues</span>
          <span><span className="sw" style={{background:"var(--accent-3)"}}></span>row clues</span>
        </div>
      </div>
    </div>
  );
}

// ---------- Files & languages ----------
function Files() {
  // Approx LOC distribution by language
  const langs = [
    { name: "Object Pascal", color: "#1c1858", pct: 79, files: "NONOGRAM.PAS, MDGEN.PAS, CTL3D.PAS, MDGENTPU.PAS" },
    { name: "Visual Basic 2", color: "#385e8f", pct: 11, files: "SETUP1.BAS, *.FRM (LICENCE, MESSAGE, PATH, STATUS)" },
    { name: "WinHelp RTF", color: "#6e7c1d", pct: 8, files: "NONOGRAM.RTF, NONOGRAM.HPJ" },
    { name: "Other", color: "#8a6a1d", pct: 2, files: "NONOGRAM.RES, .LIC, .NGM data files" },
  ];
  const categories = [
    { ext: ".PAS", what: "Pascal source. Main program, helper DLL, CTL3D unit binding.", ct: "5 files" },
    { ext: ".FRM", what: "Visual Basic forms — the installer's dialogs.", ct: "4 forms" },
    { ext: ".BAS", what: "VB module. CopyFile, decompression, status updates.", ct: "604 lines" },
    { ext: ".NGM", what: "Source puzzle data. Plain text. Hand-editable.", ct: "8 in tree" },
    { ext: ".NG_", what: "Compressed puzzle ready for SETUP1 to unpack.", ct: "44 shipped" },
    { ext: ".RTF", what: "Help-file source. Includes 30 embedded BMPs.", ct: "1,279 lines" },
    { ext: ".HPJ", what: "WinHelp project file. Maps context IDs to topics.", ct: "—" },
    { ext: ".RES", what: "Binary resource (menus, dialogs, bitmaps, icons).", ct: "Compiled" },
    { ext: ".TPU", what: "Turbo Pascal unit binary. Pre-compiled CTL3D &amp; MDGEN.", ct: "2 units" },
    { ext: ".DL_", what: "Compressed DLL — VBRUN200, CTL3D, COMMDLG, MDGEN.", ct: "4 deps" },
    { ext: ".EX_", what: "Compressed EXE — NONOGRAM and SETUP1 themselves.", ct: "2 exes" },
    { ext: ".LIC", what: "Licence file. Hand-rolled validation in VB.", ct: "Per-install" },
  ];
  return (
    <div>
      <div className="section-h">Language mix (by approximate LOC)</div>
      <div className="langbar">
        {langs.map(l =>
          <div key={l.name} className="lb" style={{ width: l.pct + "%", background: l.color }}>
            {l.pct >= 10 ? `${l.name} ${l.pct}%` : `${l.pct}%`}
          </div>
        )}
      </div>
      <div className="langlegend">
        {langs.map(l =>
          <span key={l.name}>
            <span className="sw" style={{background: l.color}}></span>
            <b>{l.name}</b> · <span style={{color:"var(--ink-3)"}}>{l.files}</span>
          </span>
        )}
      </div>

      <div className="section-h" style={{marginTop: 24}}>File types in this codebase</div>
      <div className="filegrid">
        {categories.map(c =>
          <div className="file-card" key={c.ext}>
            <div className="ext">{c.ext}</div>
            <div className="what">{c.what}</div>
            <div className="ct">{c.ct}</div>
          </div>
        )}
      </div>
    </div>
  );
}

// ---------- Analysis ----------
function Analysis() {
  return (
    <div className="ana">
      <div className="ana-col good">
        <h3><span className="marker">+</span> The good</h3>
        <ul>
          <li><b>Layered heuristics.</b> The five passes are deliberately ordered cheap-to-expensive. <code>QuickData</code> &amp; <code>CheckEdge</code> fire instantly; <code>Combination</code> is the slow universal fallback. The outer loop re-runs until nothing changes — a tidy fixpoint.</li>
          <li><b>Configurable solver.</b> Every pass is a check-box. You can watch a puzzle become unsolvable by disabling <code>Combination</code>, then watch it succumb when you re-enable it.</li>
          <li><b>Cooperative yielding.</b> <code>Yielder</code> calls <code>PeekMessage</code> deep inside the solve loop — essential on Win 3.1's non-preemptive scheduler. Without it, solving any non-trivial puzzle would freeze the whole OS.</li>
          <li><b>MDI for puzzles.</b> Each puzzle is its own window with its own grid and own solver state. Multitasking <i>within</i> the program before the OS could do it well.</li>
          <li><b>Drag-and-drop &amp; recent files.</b> <code>WMDropFiles</code> + a four-item MRU menu (<code>CM_FILE1..4</code>) shipped in 1994. Genuinely UX-aware.</li>
          <li><b>An honest header comment.</b> Every version block in the file's preamble reads like a release-note. Self-documenting evolution.</li>
        </ul>
      </div>
      <div className="ana-col bad">
        <h3><span className="marker">−</span> The rough edges</h3>
        <ul>
          <li><b>One file, 6,370 lines.</b> The entire UI, solver, parser, printer and persistence layer live in <code>NONOGRAM.PAS</code>. There's no separation between view and model — solver routines call <code>DrawPoint</code> directly.</li>
          <li><b>Hard caps everywhere.</b> <code>MaxXAcross = 64</code>, <code>MaxYAcross = 64</code>, <code>MaxNoElements = 15</code>. The "VARS" enumeration buffer is bounded at 300 (max 600), so very combinatorially rich rows can't be fully enumerated — they get truncated with a "more" flag.</li>
          <li><b>Combinational pass is brute force.</b> It permutes every block start position then filters; modern solvers fuse enumeration with constraint propagation. Hence the need for "Greedy mode" — speed-vs-responsiveness was a real trade.</li>
          <li><b>Solver lives on <code>TDisplay</code>.</b> It's window-state, not domain state — which is why the solver can't run headless and can't be unit-tested.</li>
          <li><b>Win 3.1 only.</b> Pinned to <code>Win31</code>, <code>WObjects</code>, <code>CTL3D</code>, the 16-bit segmented memory model (<code>{`{$M 40000, 8192}`}</code>), VBRUN200.DLL. There is no port path; you'd rewrite it.</li>
          <li><b>No undo.</b> The in-place editor commits straight to <code>XElements/YElements</code>.</li>
        </ul>
      </div>
      <div className="ana-col fun">
        <h3><span className="marker">★</span> The interesting</h3>
        <ul>
          <li><b>Versioned via comment blocks.</b> There's no VCS, no <code>CHANGELOG.md</code>. The release history is a stack of paragraph-length comments at the top of the source file. Each one ends with a release date.</li>
          <li><b>Two Pascal compilers in one project.</b> <code>.TPU</code> files are Borland Turbo Pascal for Windows unit binaries; the main program is compiled from source against them. The CTL3D unit is pre-built — Microsoft shipped the C bindings, Borland users got a Pascal shim.</li>
          <li><b>A puzzle named in the changelog.</b> v2.1 exists to solve one specific puzzle — Hermit Crab (<code>HERCRAB.NG_</code> in the install tree). The solver was forked by a puzzle's resistance.</li>
          <li><b>Greedy mode.</b> A user-facing toggle for "let me hog the CPU." This is exactly the right ergonomic for Win 3.1 — and we lost that affordance for decades after preemptive multitasking arrived.</li>
          <li><b>The maths is in the comments.</b> <code>CalComplexity</code> ships with a 30-line ASCII-art derivation of the recurrence relation it uses to compute the combination count. The author teaches the formula in-line.</li>
          <li><b>Display rotation.</b> Four orthogonal display rotations and a flip toggle — a <i>graphic</i>-design feature in a solver. You could mount your monitor on its side and the program would cope.</li>
          <li><b>Two installers.</b> The VB-built setup uses <code>VerInstallFile</code> for date-aware copying, and runs its own licence validator before letting you continue.</li>
        </ul>
      </div>
    </div>
  );
}

// ---------- Algorithm explainer ----------
function AlgoExplainer() {
  return (
    <div className="two-col">
      <div>
        <p>
          The heart of the program is <code>TDisplay.CMSolve</code>. It's the kind
          of routine you'd write today as a worker, but on Win 3.1 it ran on the
          UI thread and yielded by hand. Stripped to its skeleton, it's an outer
          fixpoint loop wrapped around the configured passes:
        </p>
        <pre className="fmt-code" style={{whiteSpace:"pre-wrap"}}>
{`IF QuickStrtOn THEN QuickData;
WHILE (OldTotal <> PlotTotal) AND CanThink DO BEGIN
  OldTotal := PlotTotal;
  IF EdgeCheckOn THEN CheckEdge;
  IF FullRwTstOn THEN TestRowFull;
  IF RowFollowOn THEN FollowRow;
  IF SingleTstOn THEN SingleTst;
  IF CombinatnOn THEN Combination;
  Yielder;             { let other Windows apps breathe }
END;`}
        </pre>
        <p>
          <b>Why a fixpoint?</b> Each pass uses what's already known. As cells
          get filled, previously-stuck lines unstick. Looping until nothing
          changes is the cheapest correct termination condition — and a
          beautifully Pascal-shaped one.
        </p>
      </div>
      <div>
        <p>
          The deductions split naturally:
        </p>
        <ul style={{fontSize: 13.5, lineHeight: 1.6}}>
          <li><b>Cheap geometric facts</b> — <code>QuickData</code> uses overlap of leftmost/rightmost packings; <code>TestRowFull</code> handles the "no slack" case; <code>CheckEdge</code> anchors known boundary fills.</li>
          <li><b>Local follow-through</b> — <code>FollowRow</code> chases known runs along the line; <code>SingleTst</code> caps homogenous-clue rows.</li>
          <li><b>Universal but expensive</b> — <code>Combination</code> enumerates everything still consistent and intersects. The buffer for it is fixed-size (<code>VARS = 300</code> by default, ceilinged at 600), so a sufficiently rich line will overflow with the <code>More</code> flag and the routine commits what it has.</li>
        </ul>
        <p>
          The <code>CheckGroup</code> recursive helper is the lowest-level
          predicate: <i>does this candidate placement of block <code>Group</code>
          still permit the rest to fit?</i> It's a classic backtracking
          subroutine but, again, it shares a global array with the UI thread
          and yields between iterations.
        </p>
      </div>
    </div>
  );
}

// ---------- Footer ----------
function Footer() {
  return (
    <div className="footer">
      Compiled with Borland Pascal 7.0 · Tested on Windows 3.1 · 1994 · M. G. Davidson
    </div>
  );
}

// ---------- Section heading ----------
function SectionHeading({ kicker, title, sub }) {
  return (
    <div style={{margin: "8px 0 14px"}}>
      <div className="section-h">{kicker}</div>
      <h2 className="title">{title}</h2>
      {sub && <p style={{maxWidth: "80ch", color: "var(--ink-2)", fontSize: 15}}>{sub}</p>}
    </div>
  );
}

// ---------- App ----------
function App() {
  return (
    <>
      <Hero />
      <Stats />

      <Win title="Architecture — module overview">
        <SectionHeading
          kicker="1 · ARCHITECTURE"
          title="How the program is wired together"
          sub="A Borland ObjectWindows (OWL) MDI application. The frame owns chrome, each puzzle gets its own MDI child, and the solver lives entirely on that child class." />
        <Architecture />
      </Win>

      <Win title="The Solver — interactive">
        <SectionHeading
          kicker="2 · THE SOLVER"
          title="Five layered heuristics — toggle each one"
          sub="The Pascal Configure Solution dialog ships six check-boxes. This port mirrors them. Toggle phases off and re-run Solve to feel which puzzles are tractable without the expensive Combination pass." />
        <Solver />
      </Win>

      <Win title="The algorithm — the fixpoint at the centre">
        <SectionHeading
          kicker="3 · ALGORITHM"
          title="An outer fixpoint, six inner passes"
          sub="What CMSolve actually does, and why each phase exists." />
        <AlgoExplainer />
      </Win>

      <Win title="Version history">
        <SectionHeading
          kicker="4 · EVOLUTION"
          title="Four releases, eight months, one big rewrite"
          sub="Click a version to read what changed. The history is preserved entirely in source-file comment blocks — there is no other changelog." />
        <Timeline />
      </Win>

      <Win title="Files &amp; languages">
        <SectionHeading
          kicker="5 · LANGUAGES"
          title="Four languages, mostly Pascal"
          sub="A Pascal core, a Visual Basic installer, a Rich-Text Format help file, and a custom plain-text puzzle format." />
        <Files />
      </Win>

      <Win title="The data format · NGM">
        <SectionHeading
          kicker="6 · DATA"
          title="The NGM puzzle file"
          sub="Notepad-editable. Title, dimensions, columns, rows. That's it." />
        <FileFormat />
      </Win>

      <Win title="Verdict — strengths, weaknesses, oddities">
        <SectionHeading
          kicker="7 · ANALYSIS"
          title="Reading the code three decades later"
          sub="What aged well, what didn't, what's worth remembering." />
        <Analysis />
      </Win>

      <Footer />
    </>
  );
}

ReactDOM.createRoot(document.getElementById("root")).render(<App />);
