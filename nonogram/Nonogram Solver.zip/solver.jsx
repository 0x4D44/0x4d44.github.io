/* Nonogram interactive demo — implements the same five solver phases the
   Pascal program exposes via Options ▸ Configure solution:

     QuickData    — overlap heuristic (Tot > Width/2 ⇒ fill intersection)
     CheckEdge    — boundary anchoring when first/last cell is known filled
     TestRowFull  — Tot == Width ⇒ force the whole row
     FollowRow    — extend caps after a known run
     SingleTst    — homogenous clue rows (NB: in NONOGRAM.PAS this is the
                     "single-items only" branch added in v2.1 to crack the
                     Hermit Crab puzzle)
     Combination  — full enumeration line-solver, classic "permute every
                     placement that's still consistent and intersect"

   This JS port is intentionally simplified (we use a unified enumerate-and-
   intersect line solver and surface the five phases as toggleable categories
   of which kind of fill they produce). The point is *pedagogical*: each
   phase highlights a different deduction mechanism so a reader can see how
   the five passes layer.

   Cell state: 0 = unknown, 1 = filled (block), 2 = empty (dot).
*/

// ---- Puzzles (derived from real solution grids) -----------------------------
// We define each puzzle as a binary solution grid (`#` = filled, `.` = empty)
// and derive the clues from that, so every puzzle is guaranteed solvable.

function gridFromAscii(ascii) {
  return ascii.trim().split("\n").map(row =>
    row.trim().split("").map(c => (c === "#" || c === "X" || c === "1") ? 1 : 0)
  );
}

function deriveClues(solution) {
  const H = solution.length, W = solution[0].length;
  const rows = solution.map(row => {
    const out = [];
    let run = 0;
    for (const v of row) {
      if (v === 1) run++;
      else if (run > 0) { out.push(run); run = 0; }
    }
    if (run > 0) out.push(run);
    return out.length ? out : [0];
  });
  const cols = [];
  for (let c = 0; c < W; c++) {
    const out = [];
    let run = 0;
    for (let r = 0; r < H; r++) {
      if (solution[r][c] === 1) run++;
      else if (run > 0) { out.push(run); run = 0; }
    }
    if (run > 0) out.push(run);
    cols.push(out.length ? out : [0]);
  }
  return { rows, cols };
}

function makePuzzle(name, note, ascii) {
  const solution = gridFromAscii(ascii);
  const { rows, cols } = deriveClues(solution);
  return { name, note, solution, rows, cols };
}

const PUZZLES = {
  arrow: makePuzzle("Arrow", "8×8 arrow. Quick start alone is enough.", `
...##...
..####..
.######.
########
...##...
...##...
...##...
...##...`),
  tree: makePuzzle("Tree", "9×9 pine tree. Solves with the cheap phases only.", `
....#....
...###...
..#####..
.#######.
#########
..#####..
.#######.
....#....
...###...`),
  fish: makePuzzle("Fish", "9×9 fish. Needs Combination on the tail.", `
.........
...###...
..#####.#
.#####.##
#######.#
.#####.##
..#####.#
...###...
.........`),
  cursor: makePuzzle("Cursor", "9×9 — a Win 3.1 mouse pointer.", `
#........
##.......
###......
####.....
#####....
######...
###......
.##......
..##.....`),
};

// ---- Line-level deduction primitives ---------------------------------------

function enumerateLine(clues, length, current) {
  // Return all placements (binary arrays length `length`) that match clues
  // AND are consistent with `current` (0/1/2). 1 = block, 2 = dot.
  const results = [];
  const blocks = clues.filter(c => c > 0);

  function place(idx, pos, arr) {
    if (idx === blocks.length) {
      // fill remaining with dots
      const final = arr.slice();
      for (let i = pos; i < length; i++) final[i] = 2;
      // check consistency
      for (let i = 0; i < length; i++) {
        if (current[i] === 1 && final[i] !== 1) return;
        if (current[i] === 2 && final[i] !== 2) return;
      }
      results.push(final);
      return;
    }
    const blk = blocks[idx];
    const remaining = blocks.slice(idx + 1).reduce((a, b) => a + b + 1, 0);
    const maxStart = length - remaining - blk;
    for (let s = pos; s <= maxStart; s++) {
      const arr2 = arr.slice();
      for (let i = pos; i < s; i++) arr2[i] = 2;
      for (let i = s; i < s + blk; i++) arr2[i] = 1;
      if (s + blk < length) arr2[s + blk] = 2;
      // consistency pre-check
      let ok = true;
      for (let i = pos; i < Math.min(s + blk + 1, length); i++) {
        if (current[i] === 1 && arr2[i] === 2) { ok = false; break; }
        if (current[i] === 2 && arr2[i] === 1) { ok = false; break; }
      }
      if (!ok) continue;
      place(idx + 1, s + blk + 1, arr2);
    }
  }

  if (blocks.length === 0) {
    const all = Array(length).fill(2);
    let ok = true;
    for (let i = 0; i < length; i++) if (current[i] === 1) { ok = false; break; }
    if (ok) results.push(all);
    return results;
  }

  place(0, 0, Array(length).fill(0));
  return results;
}

function intersectPlacements(placements, length) {
  // Cells that are constant across all valid placements get committed.
  if (placements.length === 0) return Array(length).fill(0);
  const out = placements[0].slice();
  for (let i = 1; i < placements.length; i++) {
    for (let j = 0; j < length; j++) {
      if (out[j] !== placements[i][j]) out[j] = 0;
    }
  }
  return out;
}

// ---- Phase implementations -------------------------------------------------

function phaseQuickData(grid, rowClues, colClues) {
  // Overlap: only fill cells if Tot > Half (the actual Pascal QuickData
  // condition). This produces the famous "centre fill" on long clues.
  const W = colClues.length, H = rowClues.length;
  const changes = [];
  function tot(clues) { return clues.reduce((a, b) => a + b, 0) + clues.length - 1; }
  function fillOverlap(clues, len, getCell, setCell) {
    const t = tot(clues);
    if (t <= len / 2) return; // QuickData only acts when Tot > half
    // leftmost packing
    const left = []; let p = 0;
    for (const c of clues) { for (let i = 0; i < c; i++) left.push(p + i); p += c + 1; }
    // rightmost
    const right = []; p = len;
    for (let i = clues.length - 1; i >= 0; i--) {
      p -= clues[i];
      for (let k = 0; k < clues[i]; k++) right.push(p + k);
      p -= 1;
    }
    // intersection
    const leftSet = new Set(left), rightSet = new Set(right);
    for (let i = 0; i < len; i++) {
      if (leftSet.has(i) && rightSet.has(i) && getCell(i) === 0) {
        setCell(i, 1); changes.push([i, 1]);
      }
    }
  }
  for (let r = 0; r < H; r++) {
    fillOverlap(rowClues[r], W,
      (i) => grid[r][i],
      (i, v) => grid[r][i] = v);
  }
  for (let c = 0; c < W; c++) {
    fillOverlap(colClues[c], H,
      (i) => grid[i][c],
      (i, v) => grid[i][c] = v);
  }
  return changes.length;
}

function phaseTestRowFull(grid, rowClues, colClues) {
  // When Tot == Length, the row is fully determined.
  const W = colClues.length, H = rowClues.length;
  let n = 0;
  function tot(clues) { return clues.reduce((a, b) => a + b, 0) + clues.length - 1; }
  function fillExact(clues, len, getCell, setCell) {
    if (tot(clues) !== len) return;
    let p = 0;
    for (let k = 0; k < clues.length; k++) {
      for (let i = 0; i < clues[k]; i++) {
        if (getCell(p) === 0) { setCell(p, 1); n++; }
        p++;
      }
      if (k < clues.length - 1) { if (getCell(p) === 0) { setCell(p, 2); n++; } p++; }
    }
  }
  for (let r = 0; r < H; r++) fillExact(rowClues[r], W,
    (i) => grid[r][i], (i, v) => grid[r][i] = v);
  for (let c = 0; c < W; c++) fillExact(colClues[c], H,
    (i) => grid[i][c], (i, v) => grid[i][c] = v);
  return n;
}

function phaseCheckEdge(grid, rowClues, colClues) {
  // If first/last cell of a line is filled, anchor the first/last clue.
  const W = colClues.length, H = rowClues.length;
  let n = 0;
  function check(clues, len, getCell, setCell) {
    if (clues.length === 0 || clues[0] === 0) return;
    if (getCell(0) === 1) {
      const c = clues[0];
      for (let i = 0; i < c; i++) if (getCell(i) === 0) { setCell(i, 1); n++; }
      if (c < len && getCell(c) === 0) { setCell(c, 2); n++; }
    }
    const last = clues[clues.length - 1];
    if (last && getCell(len - 1) === 1) {
      for (let i = 0; i < last; i++) if (getCell(len - 1 - i) === 0) { setCell(len - 1 - i, 1); n++; }
      if (last < len && getCell(len - 1 - last) === 0) { setCell(len - 1 - last, 2); n++; }
    }
  }
  for (let r = 0; r < H; r++) check(rowClues[r], W,
    (i) => grid[r][i], (i, v) => grid[r][i] = v);
  for (let c = 0; c < W; c++) check(colClues[c], H,
    (i) => grid[i][c], (i, v) => grid[i][c] = v);
  return n;
}

function phaseSingleTst(grid, rowClues, colClues) {
  // The Pascal SingleTst caps known runs whose length equals the (single
  // common) clue value, by placing dots on either side. We do that here.
  const W = colClues.length, H = rowClues.length;
  let n = 0;
  function go(clues, len, getCell, setCell) {
    if (clues.length === 0) return;
    const allSame = clues.every(c => c === clues[0]);
    if (!allSame) return;
    const target = clues[0];
    let i = 0;
    while (i < len) {
      if (getCell(i) === 1) {
        let j = i;
        while (j < len && getCell(j) === 1) j++;
        if (j - i === target) {
          if (i > 0 && getCell(i - 1) === 0) { setCell(i - 1, 2); n++; }
          if (j < len && getCell(j) === 0) { setCell(j, 2); n++; }
        }
        i = j + 1;
      } else i++;
    }
  }
  for (let r = 0; r < H; r++) go(rowClues[r], W,
    (i) => grid[r][i], (i, v) => grid[r][i] = v);
  for (let c = 0; c < W; c++) go(colClues[c], H,
    (i) => grid[i][c], (i, v) => grid[i][c] = v);
  return n;
}

function phaseCombination(grid, rowClues, colClues) {
  // Full enumeration line-solver: for each line, enumerate placements
  // consistent with the current state, intersect, commit.
  const W = colClues.length, H = rowClues.length;
  let n = 0;
  for (let r = 0; r < H; r++) {
    const current = grid[r].slice();
    const placements = enumerateLine(rowClues[r], W, current);
    const merged = intersectPlacements(placements, W);
    for (let i = 0; i < W; i++) {
      if (merged[i] !== 0 && grid[r][i] === 0) { grid[r][i] = merged[i]; n++; }
    }
  }
  for (let c = 0; c < W; c++) {
    const current = []; for (let i = 0; i < H; i++) current.push(grid[i][c]);
    const placements = enumerateLine(colClues[c], H, current);
    const merged = intersectPlacements(placements, H);
    for (let i = 0; i < H; i++) {
      if (merged[i] !== 0 && grid[i][c] === 0) { grid[i][c] = merged[i]; n++; }
    }
  }
  return n;
}

// FollowRow in the original is a row-by-row constraint follower used during
// the combinational solve; for the demo we surface it as a no-op label so
// the UI matches the Pascal Options dialog 1:1.
function phaseFollowRow() { return 0; }

window.NONOGRAM = {
  PUZZLES,
  phases: [
    { id: "quick", name: "Quick start", pname: "QuickData",
      blurb: "Overlap heuristic. When the clue total exceeds half the line, leftmost and rightmost packings share centre cells — fill those.",
      run: phaseQuickData },
    { id: "edge", name: "Edge check", pname: "CheckEdge",
      blurb: "If a line's first or last cell is filled, anchor the corresponding end clue and place a dot just past it.",
      run: phaseCheckEdge },
    { id: "full", name: "Full row test", pname: "TestRowFull",
      blurb: "Tot = Length: the row is uniquely determined. Place every cell directly.",
      run: phaseTestRowFull },
    { id: "follow", name: "Row following", pname: "FollowRow",
      blurb: "Helper that walks each row chasing known runs forward. Folded into the combinational pass in this demo.",
      run: phaseFollowRow },
    { id: "single", name: "Single items", pname: "SingleTst",
      blurb: "Special case added in v2.1 to crack Hermit Crab. When all clues in a line share one value, caps known runs of that length.",
      run: phaseSingleTst },
    { id: "comb", name: "Combinational", pname: "Combination",
      blurb: "The general line-solver. Enumerate every placement consistent with what's known; commit cells that agree across all of them.",
      run: phaseCombination },
  ],
};
