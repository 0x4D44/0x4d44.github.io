/* ============================================================
   mdmcp deep-dive — codebase facts (all grounded in source)
   ============================================================ */

const CRATES = [
  {
    id: "mdmcpsrvr", name: "mdmcpsrvr", kind: "Binary · server", accent: "#ee6b35",
    path: "mdmcpsrvr/src/", tag: "core",
    desc: "The hardened MCP server itself. Speaks JSON-RPC 2.0 over stdio and enforces every policy gate before any file or process is touched.",
    facts: [
      ["Role", "MCP server binary"],
      ["Transport", "NDJSON over stdio"],
      ["Modules", "8 (rpc, server, policy, fs_safety, cmd_catalog, sandbox, audit)"],
      ["Largest file", "server.rs · ~4,040 lines"],
      ["Runtime", "Tokio (multi-thread)"],
    ],
    deps: ["tokio", "cap-std", "serde_yaml", "regex", "sha2", "tracing", "nix", "windows-sys"],
  },
  {
    id: "mdmcpcfg", name: "mdmcpcfg", kind: "Binary · CLI", accent: "#36c6c0",
    path: "mdmcpcfg/src/", tag: "tooling",
    desc: "The configuration & lifecycle CLI. Installs the server, wires up Claude Desktop, self-updates from GitHub releases, and safely edits policy.",
    facts: [
      ["Role", "Install / update / policy CLI"],
      ["Commands", "install · update · policy · doctor · uninstall"],
      ["Update flow", "GitHub release + SHA256SUMS verify"],
      ["Self-upgrade", "Spawns helper to replace itself"],
      ["Claude integration", "Edits claude_desktop_config.json"],
    ],
    deps: ["clap", "reqwest", "sha2", "zip", "serde_json", "tokio"],
  },
  {
    id: "mdmcp_policy", name: "mdmcp_policy", kind: "Library crate", accent: "#9a8cf0",
    path: "crates/mdmcp_policy/", tag: "shared",
    desc: "The security brain: policy types, YAML parsing, validation, and compilation. Turns a human policy.yaml into canonicalized roots and compiled regexes.",
    facts: [
      ["Role", "Policy types + validation"],
      ["Key types", "Policy · CompiledPolicy · CommandRule · WriteRule"],
      ["Compilation", "Canonicalize paths · compile regex · SHA256 hash"],
      ["Merge model", "policy.core.yaml ⊕ user policy.yaml"],
      ["Size", "~1,120 lines (incl. tests)"],
    ],
    deps: ["serde", "serde_yaml", "regex", "schemars", "sha2", "dunce", "dirs"],
  },
  {
    id: "mdmcp_common", name: "mdmcp_common", kind: "Library crate", accent: "#9a8cf0",
    path: "crates/mdmcp_common/", tag: "shared",
    desc: "Pure protocol types — JSON-RPC envelopes, MCP error codes, and the wire shapes for fs.read / fs.write / cmd.run params and results.",
    facts: [
      ["Role", "MCP / JSON-RPC wire types"],
      ["Defines", "RpcRequest · RpcResponse · McpErrorCode"],
      ["Error codes", "-32001 PolicyDeny … -32603 Internal"],
      ["Dependencies", "Just serde — zero runtime logic"],
      ["Size", "~450 lines"],
    ],
    deps: ["serde", "serde_json"],
  },
  {
    id: "mdaicli", name: "mdaicli", kind: "Plugin · CLI", accent: "#e8b84b",
    path: "plugins/mdaicli/", tag: "plugin",
    desc: "The flagship plugin: one CLI for four AI providers. Self-versioned (0.5.1), it adds caching, rate-limiting, pricing, and encrypted credential storage.",
    facts: [
      ["Providers", "OpenAI · Anthropic · Ollama · OpenRouter"],
      ["Credentials", "OS keyring + AES-GCM/Argon2 fallback"],
      ["Features", "Streaming · cache · rate-limit · pricing"],
      ["Own version", "0.5.1 (decoupled from workspace)"],
      ["Tests", "mockito mocks per provider"],
    ],
    deps: ["reqwest", "keyring", "aes-gcm", "argon2", "clap", "mockito"],
  },
  {
    id: "mdjiracli", name: "mdjiracli", kind: "Plugin · CLI", accent: "#e8b84b",
    path: "plugins/mdjiracli/", tag: "plugin",
    desc: "Jira Cloud CLI — keychain-stored credentials, Agile-first board/issue access via the REST + Agile APIs, with a privacy-conscious whoami check.",
    facts: [
      ["Target", "Jira Cloud /rest/api/3 + Agile"],
      ["Auth", "API token via OS keychain"],
      ["Capabilities", "Boards · issues · JQL · whoami"],
      ["Tests", "Snapshot CLI-help tests"],
    ],
    deps: ["reqwest", "keyring", "clap", "serde_json"],
  },
  {
    id: "mdslackcli", name: "mdslackcli", kind: "Plugin · CLI", accent: "#e8b84b",
    path: "plugins/mdslackcli/", tag: "plugin",
    desc: "Slack CLI — post messages and read channels. Designed to be added to the command catalog so an LLM can reach Slack through the policy gate.",
    facts: [
      ["Target", "Slack Web API"],
      ["Capabilities", "Send messages · read channels · whoami"],
      ["Tests", "Mocked channels + aliases + whoami"],
    ],
    deps: ["reqwest", "clap", "serde_json"],
  },
  {
    id: "mdmailcli", name: "mdmailcli", kind: "Plugin · CLI", accent: "#e8b84b",
    path: "plugins/mdmailcli/", tag: "plugin",
    desc: "Mail CLI built around the Microsoft Graph API — send and read email, with Graph extensions documented alongside the source.",
    facts: [
      ["Target", "Microsoft Graph API"],
      ["Capabilities", "Send · read email"],
      ["Docs", "MSFT Graph API extensions note"],
    ],
    deps: ["reqwest", "clap", "serde_json"],
  },
  {
    id: "mdconfcli", name: "mdconfcli", kind: "Plugin · CLI", accent: "#e8b84b",
    path: "plugins/mdconfcli/", tag: "plugin",
    desc: "Confluence CLI — authenticated access to Confluence content, the most lightly-built of the integration plugins.",
    facts: [
      ["Target", "Confluence REST API"],
      ["Auth", "Dedicated auth module"],
      ["Status", "Lean / early-stage"],
    ],
    deps: ["reqwest", "clap", "serde_json"],
  },
];

const MODULES = [
  {
    id: "main", name: "main.rs", loc: "~255",
    role: "Entry point. Parses CLI args, initializes tracing, loads + merges + compiles policy, then runs the stdio read loop.",
    points: [
      "<b>Custom log formatter</b> stamps every line <code>TS-MDMCPsrvr-PID:</code> to stderr, ANSI stripped.",
      "Loads an optional <b>policy.core.yaml</b> next to the user policy and merges them via <code>spawn_blocking</code>.",
      "The stdio loop reads NDJSON line-by-line; an empty read (EOF) means the client disconnected → graceful shutdown.",
      "Installs a panic hook and a <b>Ctrl-C</b> handler that exits cleanly.",
    ],
  },
  {
    id: "rpc", name: "rpc.rs", loc: "~260",
    role: "JSON-RPC 2.0 transport. Parses incoming lines into requests vs. notifications and frames outgoing responses.",
    points: [
      "Distinguishes <b>requests</b> (have <code>id</code>) from <b>notifications</b> (no id, no response).",
      "Constructs success and error responses with the standard MCP error envelope.",
      "Validates method names before dispatch.",
      "Writes responses as single-line NDJSON to stdout.",
    ],
  },
  {
    id: "server", name: "server.rs", loc: "~4,040",
    role: "The orchestrator — and by far the largest file. Holds hot-swappable policy state and implements every MCP method and tool.",
    points: [
      "Owns a <code>RwLock&lt;Arc&lt;CompiledPolicy&gt;&gt;</code> so <b>reload_policy</b> can hot-swap without a restart.",
      "Handles <code>initialize</code> for protocol versions <b>2024-11-05</b> and <b>2025-06-18</b>.",
      "Builds the <b>tools/list</b> schema dynamically from the live command catalog.",
      "Implements ~18 tools — file reads, command runs, datetime, working-dir, server_info, and more.",
      "Strips ANSI from captured output and threads structured error context into every failure.",
    ],
  },
  {
    id: "policy", name: "policy.rs", loc: "~210",
    role: "Server-side policy glue: path expansion helpers and the reload path that re-reads and re-compiles from disk.",
    points: [
      "<code>expand_policy_path</code> resolves <code>~</code> and platform config dirs.",
      "Coordinates with <code>mdmcp_policy</code> to rebuild the <b>CompiledPolicy</b> on reload.",
      "Keeps the audit log destination in sync with policy logging config.",
    ],
  },
  {
    id: "fs_safety", name: "fs_safety.rs", loc: "~840",
    role: "The filesystem firewall. Every read and write passes through guarded handles that confine, canonicalize, and atomically commit.",
    points: [
      "Uses <b>cap-std</b> capability handles bound to the parent directory — not raw paths — to resist TOCTOU.",
      "<b>Refuses symlinks</b> outright on both read and write to prevent escape via link swaps.",
      "Writes go to a <code>.tmp.&lt;pid&gt;</code> file, then <b>atomic rename</b>; sets <code>0o600</code> on Unix.",
      "Detects network filesystems: <code>/proc/mounts</code> on Linux, <code>statfs</code> on macOS, <code>GetDriveTypeW</code> + UNC classification on Windows.",
      "Implements the three-tier <b>WSL UNC</b> policy (deny_all / allow_local_wsl / allow_all).",
    ],
  },
  {
    id: "cmd_catalog", name: "cmd_catalog.rs", loc: "~616",
    role: "Validates a requested command against the catalog: argument allowlists, regex patterns, path scoping, cwd policy, and env.",
    points: [
      "Resolves working directory <i>first</i>, so relative path-args can be scoped correctly.",
      "<b>enforce_path_scope</b> rejects any path-like argument that resolves outside allowed roots.",
      "Merges <b>fixed</b> args (always prepended) with validated user args before execution.",
      "Applies <code>env_static</code> from policy under requested env, then hands off to the sandbox.",
    ],
  },
  {
    id: "sandbox", name: "sandbox.rs", loc: "~808",
    role: "Subprocess isolation: clears the environment, applies OS resource limits, enforces timeouts, and truncates runaway output.",
    points: [
      "<code>env_clear()</code> then re-adds only allowlisted + essential vars — no ambient leakage.",
      "<b>Unix rlimits</b> via pre_exec: CPU 300s, address space 1 GB, 32 procs, 64 file descriptors.",
      "<b>Windows</b> sets <code>CREATE_NEW_PROCESS_GROUP</code> (full Job-Object limits noted as future work).",
      "Streams stdout/stderr concurrently with a hard byte cap, flagging <code>truncated</code>.",
      "On Windows, bootstraps the <b>MSVC environment</b> via <code>vswhere</code> when running cargo/rustc.",
    ],
  },
  {
    id: "audit", name: "audit.rs", loc: "~473",
    role: "Tamper-aware audit trail. Every allow / deny / error is written as one JSON line with a content hash and policy hash.",
    points: [
      "<b>JSONL</b> entries record tool, decision, path, duration, exit code, and SHA256 content hash.",
      "Thread-safe writer behind a <code>Mutex</code>, flushed on every entry.",
      "<b>Auto-rotates</b> the log at 10 MB into a timestamped backup.",
      "Honors a redaction list so environment values never hit disk in the clear.",
    ],
  },
];

/* request lifecycle scenarios — verdicts replicate the real gate logic */
const STAGES = [
  { k: "rpc", icon: "❮❯", name: "rpc.rs", sub: "parse NDJSON" },
  { k: "dispatch", icon: "⇄", name: "server.rs", sub: "route method" },
  { k: "gate", icon: "🛡", name: "policy", sub: "authorize", gate: true },
  { k: "exec", icon: "⚙", name: "catalog / fs", sub: "prepare" },
  { k: "sandbox", icon: "▣", name: "sandbox / io", sub: "act" },
  { k: "audit", icon: "✎", name: "audit.rs", sub: "log JSONL" },
  { k: "resp", icon: "→", name: "response", sub: "JSON-RPC" },
];

const SCENARIOS = {
  read: {
    label: "read a file", dot: "#36c6c0", verdict: "allow", denyAt: -1,
    title: 'read_lines · "~/code/app/main.rs"',
    log: [
      ['00.0ms', 'recv', '{"method":"tools/call","name":"read_lines"}'],
      ['00.2ms', 'route', 'dispatch → handle_fs_read'],
      ['00.4ms', 'gate', 'canonicalize → /home/u/code/app/main.rs'],
      ['00.5ms', 'gate', 'prefix match allowed_roots[0] ✓', 'ok'],
      ['00.6ms', 'gate', 'symlink check ✓  · network-fs check ✓', 'ok'],
      ['00.9ms', 'io', 'cap-std Dir.open(parent) → read 4,096 B'],
      ['01.1ms', 'audit', 'decision=allow sha256=9f2a… bytes=4096', 'ok'],
      ['01.2ms', 'resp', 'result.content (200 OK)', 'ok'],
    ],
    verdictReason: 'Path resolved <span class="hl">inside an allowed root</span>, is a regular file, and lives on a local filesystem. The guarded reader streamed it under the byte cap.',
  },
  cmd: {
    label: "run a command", dot: "#ee6b35", verdict: "allow", denyAt: -1,
    title: 'run_command · git status',
    log: [
      ['00.0ms', 'recv', '{"method":"tools/call","name":"run_command"}'],
      ['00.2ms', 'route', 'dispatch → handle_cmd_run (id="git")'],
      ['00.4ms', 'gate', 'lookup catalog["git"] ✓', 'ok'],
      ['00.6ms', 'gate', 'arg "status" ∈ args.allow ✓', 'ok'],
      ['00.7ms', 'gate', 'path-scope: no path args to check ✓', 'ok'],
      ['01.0ms', 'exec', 'env_clear + allowlist · cwd within_root'],
      ['12.4ms', 'sandbox', 'spawn /usr/bin/git · exit=0 · 312 B'],
      ['12.6ms', 'audit', 'decision=allow cmd="git" exit=0', 'ok'],
      ['12.7ms', 'resp', 'result.stdout (200 OK)', 'ok'],
    ],
    verdictReason: 'The command id <span class="hl">git</span> exists in the catalog and the argument <span class="hl">status</span> is on its allowlist. It ran in a cleared environment under a timeout.',
  },
  escape: {
    label: "escape the sandbox", dot: "#ef5d6b", verdict: "deny", denyAt: 2,
    title: 'read_lines · "/etc/shadow"',
    log: [
      ['00.0ms', 'recv', '{"method":"tools/call","name":"read_lines"}'],
      ['00.2ms', 'route', 'dispatch → handle_fs_read'],
      ['00.4ms', 'gate', 'canonicalize → /etc/shadow'],
      ['00.5ms', 'gate', 'prefix match allowed_roots → none', 'no'],
      ['00.6ms', 'gate', 'FsError::PathNotAllowed raised', 'no'],
      ['00.7ms', 'audit', 'decision=deny rule=pathNotAllowed', 'no'],
      ['00.8ms', 'resp', 'error -32001 PolicyDeny', 'no'],
    ],
    verdictReason: '<span class="hl">/etc/shadow</span> does not start with any allowed root, so the guarded reader never opened a handle. The denial is logged and an MCP <span class="hl">PolicyDeny</span> error returned — no bytes ever read.',
  },
  inject: {
    label: "inject an argument", dot: "#ef5d6b", verdict: "deny", denyAt: 2,
    title: 'run_command · rm -rf /',
    log: [
      ['00.0ms', 'recv', '{"method":"tools/call","name":"run_command"}'],
      ['00.2ms', 'route', 'dispatch → handle_cmd_run (id="git")'],
      ['00.4ms', 'gate', 'lookup catalog["git"] ✓', 'ok'],
      ['00.5ms', 'gate', 'arg "--upload-pack=…" ∉ allow', 'no'],
      ['00.6ms', 'gate', 'no regex pattern matches arg', 'no'],
      ['00.7ms', 'gate', 'PolicyDenied{ argNotAllowed }', 'no'],
      ['00.8ms', 'audit', 'decision=deny rule=argNotAllowed', 'no'],
      ['00.9ms', 'resp', 'error -32001 PolicyDeny', 'no'],
    ],
    verdictReason: 'Even though <span class="hl">git</span> is allowed, the injected argument is neither on the allowlist nor matched by any regex pattern. Argument validation fails <span class="hl">before</span> any process is spawned.',
  },
};

const LAYERS = [
  { n: "1", c: "#ee6b35", t: "Path confinement", gist: "Reads & writes can never leave allowed_roots.",
    body: "Every path is canonicalized with <code>dunce::canonicalize</code> and must be a prefix-child of a configured allowed root. Because canonicalization resolves <code>..</code> and symlinks first, classic <code>../../etc/passwd</code> traversal collapses to a real path that simply fails the prefix test.",
    src: "fs_safety.rs · GuardedFileReader::open / CompiledPolicy::is_path_allowed" },
  { n: "2", c: "#36c6c0", t: "Capability handles + atomic writes", gist: "No raw path I/O; writes commit atomically.",
    body: "Files are opened through <b>cap-std</b> <code>Dir</code> handles bound to the parent directory, shrinking the TOCTOU window. Writes land in a <code>.tmp.&lt;pid&gt;</code> sibling, are <code>fsync</code>'d, then atomically renamed — a reader never sees a half-written file. Unix files get <code>0o600</code>.",
    src: "fs_safety.rs · GuardedFileWriter::write_atomic" },
  { n: "3", c: "#9a8cf0", t: "Symlink & special-file refusal", gist: "Symlinks and devices are rejected on sight.",
    body: "Before opening, <code>symlink_metadata</code> is checked; any symlink is refused with a <code>SpecialFile</code> error. Non-regular files (directories, devices, FIFOs) are likewise blocked, so a link planted inside an allowed root can't be used to read outside it.",
    src: "fs_safety.rs · is_special_file" },
  { n: "4", c: "#4cc98a", t: "Network-FS isolation", gist: "NFS/SMB/UNC denied by default.",
    body: "Network filesystems are blocked unless explicitly allowed. Detection is per-OS: parse <code>/proc/mounts</code> on Linux, <code>statfs</code> fs-type on macOS, and <code>GetDriveTypeW</code> + UNC-path classification on Windows. WSL paths get their own three-tier policy.",
    src: "fs_safety.rs · check_network_fs_access" },
  { n: "5", c: "#e8b84b", t: "Command whitelisting", gist: "Only catalog commands can ever run.",
    body: "There is no shell. <code>run_command</code> takes a <code>command_id</code> that must resolve to a catalog entry whose <code>exec</code> is an <b>absolute, canonicalized</b> path. Anything not pre-approved in policy is a <code>CommandNotFound</code> denial.",
    src: "cmd_catalog.rs · validate_command / Policy::compile" },
  { n: "6", c: "#ee6b35", t: "Argument validation + path scoping", gist: "Args are allowlisted, regex-checked, scope-bound.",
    body: "Each user argument must appear in <code>args.allow</code>, match a compiled regex pattern, or be a path that resolves within allowed roots. Path-like arguments are canonicalized and re-checked, so you can't smuggle <code>/etc/passwd</code> in as a positional arg.",
    src: "policy.rs · validate_args · cmd_catalog.rs · enforce_path_scope" },
  { n: "7", c: "#36c6c0", t: "Environment filtering", gist: "Child processes start from a clean env.",
    body: "The sandbox calls <code>env_clear()</code> and re-adds only an OS baseline (PATH, HOME, …) plus the command's <code>env_allowlist</code>. Static policy vars layer in underneath request values. Secrets in the parent environment never reach the child.",
    src: "sandbox.rs · filter_environment" },
  { n: "8", c: "#9a8cf0", t: "Resource limits & timeouts", gist: "Runaway processes are capped and killed.",
    body: "On Unix a <code>pre_exec</code> hook sets rlimits — 5 min CPU, 1 GB address space, 32 processes, 64 file descriptors. Every command has a wall-clock timeout and a max-output byte cap; exceeding either ends the run with a typed error.",
    src: "sandbox.rs · apply_security_constraints" },
  { n: "9", c: "#4cc98a", t: "Audit & accountability", gist: "Every decision is logged with hashes.",
    body: "Allow, deny, and error outcomes are appended as JSONL with a request id, the active <b>policy hash</b>, content SHA256, and duration. The log auto-rotates at 10 MB and respects a redaction list, giving a tamper-evident trail of exactly what the LLM did.",
    src: "audit.rs · Auditor::log_success / log_denial" },
];

const TOOLS = [
  { n: "read_lines", c: "fs", d: "Read a file by line range, within allowed roots." },
  { n: "read_bytes", c: "fs", d: "Read raw bytes with offset/length and encoding." },
  { n: "write_file", c: "fs", d: "Atomic write — requires a matching write rule.", lock: true },
  { n: "list_directory", c: "fs", d: "Enumerate a directory inside an allowed root." },
  { n: "stat_path", c: "fs", d: "File/dir metadata for a confined path." },
  { n: "list_accessible_directories", c: "fs", d: "Reveal exactly which roots are reachable." },
  { n: "run_command", c: "cmd", d: "Execute a catalog command by id.", lock: true },
  { n: "get_command_catalog", c: "cmd", d: "Full catalog as JSON (clients lacking resources)." },
  { n: "set_working_directory", c: "cmd", d: "Set cwd for session or next command only." },
  { n: "get_working_directory", c: "cmd", d: "Report the current working directory." },
  { n: "environment_defaults", c: "cmd", d: "List default env vars passed to children." },
  { n: "get_datetime", c: "meta", d: "System date/time/zone (iso · unix · human)." },
  { n: "platform_hints", c: "meta", d: "OS + accessible-root guidance for the client." },
  { n: "server_info", c: "meta", d: "Version, policy summary, format reference." },
  { n: "reload_policy", c: "meta", d: "Hot-reload policy from disk — no restart.", lock: true },
  { n: "list_resources", c: "meta", d: "Enumerate mdmcp:// MCP resources." },
  { n: "Documentation", c: "meta", d: "Built-in usage guide for the toolchain." },
];

const TIMELINE = [
  { ver: "DESIGN SPEC", c: "#9a8cf0", t: "A deliberately tiny surface", open: true,
    d: "The v1 design spec sets the thesis: an MCP server exposing only three capabilities — cmd.run, fs.read, fs.write — with everything else funneled through a curated command catalog.",
    more: ["monorepo workspace laid out up front", "policy.schema.json as the contract", "“everything is policy-gated” from day one"] },
  { ver: "GROWTH", c: "#36c6c0", t: "Server matures into an orchestrator",
    d: "server.rs accretes the full MCP method set, dynamic tool schemas, prompts/resources support, and dual protocol-version handling — eventually the workspace's largest file at ~4,000 lines.",
    more: ["protocol 2024-11-05 + 2025-06-18", "structured error context (v2 error-handling design docs)", "ANSI stripping + help-capture snippets"] },
  { ver: "PLUGINS", c: "#e8b84b", t: "The integration ecosystem",
    d: "Five standalone CLIs join the workspace — mdaicli, mdjiracli, mdslackcli, mdmailcli, mdconfcli — each independently versioned and designed to slot into the command catalog.",
    more: ["mdaicli adds AES-GCM/Argon2 credential vaulting", "keyring-based secret storage across plugins", "mockito provider tests"] },
  { ver: "v0.6 → 0.7", c: "#ee6b35", t: "Remove-root & WSL UNC support",
    d: "A documented HLD + implementation journal adds the policy remove-root command and a three-tier network-fs policy, replacing the old boolean deny_network_fs flag.",
    more: ["NetworkFsPolicy enum: deny_all / allow_local_wsl / allow_all", "backward-compatible: old fields parsed & ignored", "171+ tests passing, clippy -D warnings clean"] },
  { ver: "2026.01", c: "#4cc98a", t: "The coverage push",
    d: "A staged campaign lifts workspace test coverage from ~39% to ~60%, hardening the security-critical crates first and mocking the GitHub update and AI-provider flows.",
    more: ["mdmcp_policy ~80% · fs_safety ~86%", "sandbox ~74% · server ~58%", "provider mocks: anthropic 0→73%, openrouter 0→34%"] },
];

const BARS = [
  { n: "server.rs", v: "~4,040", pct: 100, c: "#ee6b35" },
  { n: "mdmcpcfg/install.rs", v: "~3,450", pct: 85, c: "#36c6c0" },
  { n: "crates/mdmcp_policy", v: "~1,120", pct: 28, c: "#9a8cf0" },
  { n: "fs_safety.rs", v: "~840", pct: 21, c: "#4cc98a" },
  { n: "sandbox.rs", v: "~808", pct: 20, c: "#e8b84b" },
  { n: "cmd_catalog.rs", v: "~616", pct: 15, c: "#9a8cf0" },
  { n: "audit.rs", v: "~473", pct: 12, c: "#36c6c0" },
];

const COV = [
  ["mdmcp_policy", "~80%"], ["fs_safety.rs", "~86%"], ["sandbox.rs", "~74%"],
  ["server.rs", "~58%"], ["doctor.rs", "~55%"], ["mdaicli", "~38%"],
];

const GOOD = [
  ["Security-first, not security-bolted-on", "Every capability is denied by default and gated by an explicit policy. The architecture makes the safe path the only path."],
  ["Defense in depth", "Path confinement, symlink refusal, capability handles, env clearing, rlimits, and audit logging stack — no single check carries the whole burden."],
  ["Clean crate boundaries", "Protocol types (mdmcp_common) and policy logic (mdmcp_policy) are split into reusable libraries with their own tests, away from the server binary."],
  ["Thoughtful cross-platform code", "Per-OS network-FS detection, Unix rlimits vs. Windows process groups, WSL UNC handling, and MSVC env bootstrapping are all handled deliberately."],
  ["Idiomatic, well-documented Rust", "Typed errors via thiserror, anyhow context, module-level doc comments, and a strong test culture (171+ tests, clippy -D warnings clean)."],
];

/* ---------- what makes it different ---------- */
const UNIQ_COMPARE = {
  bad: {
    title: "The conventional way",
    sub: "one bespoke MCP server per integration",
    points: [
      "Want Git, Jira, ffmpeg, sqlite? Write (or find, and trust) a <b>separate MCP server</b> for each.",
      "Every server reimplements transport, auth, error handling, and its own ad-hoc safety story.",
      "New tool = new TypeScript/Python project to build, ship, version, and keep updated.",
      "Security posture is <b>per-server and inconsistent</b> — you audit each one separately.",
    ],
  },
  good: {
    title: "The mdmcp way",
    sub: "one gateway, the entire CLI ecosystem",
    points: [
      "Any command-line tool you already have becomes an agent capability with <b>~8 lines of YAML</b>.",
      "Decades of battle-tested CLIs — git, ripgrep, jq, ffmpeg, pandoc, gh, docker — are instantly reachable.",
      "Every tool inherits the <b>same</b> arg-validation, path-scoping, sandbox, and audit trail for free.",
      "The bundled plugins prove the model: <b>they're just CLIs you register</b>, not MCP servers.",
    ],
  },
};

const CLI_CATALOG = [
  { id: "git", cat: "vcs", exposes: "Read-only version control across your repos.",
    snippet: `- id: "git"
  exec: "/usr/bin/git"
  description: "Read-only git operations"
  args:
    allow: ["status","log","diff","show","branch"]
  cwd_policy: "within_root"
  timeout_ms: 30000` },
  { id: "rg", cat: "search", exposes: "Full-text code search at ripgrep speed.",
    snippet: `- id: "rg"
  exec: "/usr/bin/rg"
  description: "ripgrep full-text search"
  args:
    allow: ["--vimgrep","--line-number","--hidden"]
    patterns:
      - { type: "regex", value: "^[\\\\w\\\\-./@:\\\\s]+$" }
  cwd_policy: "within_root"` },
  { id: "jq", cat: "data", exposes: "Query & transform JSON on disk.",
    snippet: `- id: "jq"
  exec: "/usr/bin/jq"
  description: "JSON query / transform"
  args:
    patterns:
      - { type: "regex", value: "^[^;&|\\\`$]+$" }
  cwd_policy: "within_root"
  timeout_ms: 10000` },
  { id: "ffmpeg", cat: "media", exposes: "Transcode audio & video in place.",
    snippet: `- id: "ffmpeg"
  exec: "/usr/bin/ffmpeg"
  description: "Media transcoding"
  args:
    allow: ["-i","-vf","-c:v","-c:a","-y"]
  cwd_policy: "within_root"
  timeout_ms: 120000
  max_output_bytes: 200000` },
  { id: "pandoc", cat: "docs", exposes: "Convert documents — md ↔ docx ↔ pdf.",
    snippet: `- id: "pandoc"
  exec: "/usr/bin/pandoc"
  description: "Universal document converter"
  args:
    allow: ["-f","-t","-o","--standalone"]
  cwd_policy: "within_root"
  timeout_ms: 60000` },
  { id: "sqlite3", cat: "data", exposes: "Query local SQLite databases.",
    snippet: `- id: "sqlite3"
  exec: "/usr/bin/sqlite3"
  description: "SQLite query runner"
  args:
    allow: ["-readonly","-json",".tables",".schema"]
  cwd_policy: "within_root"
  timeout_ms: 15000` },
  { id: "gh", cat: "vcs", exposes: "GitHub issues, PRs and releases.",
    snippet: `- id: "gh"
  exec: "/usr/bin/gh"
  description: "GitHub CLI"
  args:
    allow: ["pr","issue","repo","list","view","status"]
  env_allowlist: ["GH_TOKEN"]
  cwd_policy: "within_root"` },
  { id: "mdaicli", cat: "ai", exposes: "A bundled plugin — itself just a registered CLI.",
    snippet: `- id: "mdaicli"
  exec: "~/.local/bin/mdaicli"
  description: "Unified AI provider CLI (plugin)"
  args:
    allow: ["query","list","--provider","--model"]
  env_allowlist: ["OPENAI_API_KEY"]
  timeout_ms: 60000` },
];

const DEBUG_LOOP = [
  { n: "1", c: "#9a8cf0", t: "Discover", gist: "Claude asks the server what it can do.",
    tools: ["server_info", "get_command_catalog", "list_accessible_directories", "platform_hints"],
    detail: "The server is <b>self-describing</b>. Point Claude at a running mdmcpsrvr and it can enumerate the exact tool list, the full command catalog (with help snippets), and precisely which directories are reachable — no out-of-band docs required. <code>tools/list</code> is even built dynamically from the live policy." },
  { n: "2", c: "#36c6c0", t: "Test", gist: "It exercises each endpoint for real.",
    tools: ["read_lines", "run_command", "stat_path", "get_datetime"],
    detail: "Claude can <b>call the tools directly</b> to probe behavior — read a known file, run a catalog command, stat a path — and observe real results. Because everything is policy-gated, even a misfired test is safe: the worst case is a clean denial." },
  { n: "3", c: "#ee6b35", t: "Diagnose", gist: "Typed errors + audit log pinpoint the cause.",
    tools: ["structured error.data", "audit JSONL", "mdmcpcfg doctor"],
    detail: "Failures come back as <b>typed, structured errors</b> — <code>PolicyDeny</code>, <code>argNotAllowed</code>, <code>PathNotAllowed</code> — each with a userMessage, suggestions, and the active policy hash. Cross-referenced with the JSONL audit trail (and <code>mdmcpcfg doctor</code>), the root cause is usually obvious." },
  { n: "4", c: "#4cc98a", t: "Adjust & reload", gist: "Tune runtime config — within the boundary.",
    tools: ["set_working_directory", "reload_policy"],
    detail: "Claude can change <b>runtime</b> config itself: set the working directory (bounded to allowed roots) or trigger <code>reload_policy</code> to hot-swap a freshly-edited policy <b>without a restart</b>. The loop closes in seconds — and the privilege boundary holds (see below)." },
];

const SELF_CFG = {
  can: [
    "Re-read &amp; hot-reload policy from disk via <code>reload_policy</code>",
    "Set its working directory — but only <i>inside</i> allowed roots",
    "Enumerate its own tools, catalog, and accessible paths",
    "Inspect server version, platform, and policy hash",
  ],
  cannot: [
    "Grant itself a new <code>allowed_root</code>",
    "Add or edit a <code>command</code> in the catalog",
    "Create a <code>write_rule</code> or widen <code>network_fs_policy</code>",
    "Edit <code>policy.yaml</code> on disk through any tool",
  ],
};

const CONTEXT_FOOT = {
  techniques: [
    ["A focused tool list", "~18 tools with one-line descriptions — not hundreds of verbose entries the model must read on every turn."],
    ["The catalog lives behind a resource", "Full command detail is fetched on demand via <code>resources/read('mdmcp://commands/catalog')</code>, not inlined into every <code>tools/list</code>."],
    ["Payload caps, by design", "The <code>command_id</code> enum is capped at 50 and descriptions are truncated — the source literally notes this is “to keep payload small.”"],
    ["Dynamic, not bloated", "<code>run_command</code>'s help is summarized from the live policy (top 6, 40 chars each) rather than dumping the whole catalog."],
  ],
  // illustrative comparison of tool-surface context footprint
  compare: [
    { label: "Broad “kitchen-sink” tool server", note: "dozens of tools · full JSON schemas inlined", pct: 100, c: "#ef5d6b" },
    { label: "mdmcp", note: "~18 terse tools · catalog behind a resource", pct: 17, c: "#4cc98a" },
  ],
};

const IMPROVE = [
  ["server.rs is a 4,000-line god-module", "The orchestrator concentrates routing, every tool body, schema building, and error helpers in one file — a prime candidate for splitting into a tools/ submodule."],
  ["Process-tree kill is unfinished", "On timeout the sandbox kills the child but a comment notes it should <code>kill the entire process tree</code>; spawned grandchildren can outlive the parent."],
  ["Windows resource limits are partial", "Unix gets real rlimits, but Windows only sets <code>CREATE_NEW_PROCESS_GROUP</code> — full Job-Object CPU/memory/process caps are still marked future work."],
  ["Signature verification is a placeholder", "The updater verifies SHA256SUMS but the pinned <code>MINISIGN_PUBKEY</code> is empty and signature checks are stubbed — integrity without authenticity."],
  ["allow_any_args defaults to true", "A dev-friendly default means a freshly-added command skips argument validation unless explicitly tightened — easy to overlook."],
  ["Stub & dead paths", "The <code>run</code> smoke-test command is a TODO stub, and several helpers are <code>#[allow(dead_code)]</code> — small signs of in-flight surface."],
];
