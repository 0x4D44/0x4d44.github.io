/* ============================================================
   mdmcp deep-dive — interactions
   ============================================================ */
(function () {
  "use strict";
  const $ = (s, r = document) => r.querySelector(s);
  const $$ = (s, r = document) => [...r.querySelectorAll(s)];
  const el = (t, c, h) => { const e = document.createElement(t); if (c) e.className = c; if (h != null) e.innerHTML = h; return e; };

  /* ---------- hero terminal typing ---------- */
  const TERM = [
    ['c-cmt', '// MCP handshake over stdio (NDJSON)\n'],
    ['c-arrow', '→ '], ['', '{'], ['c-key', '"method"'], ['', ':'], ['c-str', '"initialize"'], ['', ', '],
    ['c-key', '"protocolVersion"'], ['', ':'], ['c-str', '"2025-06-18"'], ['', '}\n'],
    ['c-arrow', '← '], ['', '{'], ['c-key', '"serverInfo"'], ['', ':{'], ['c-key', '"name"'], ['', ':'], ['c-str', '"mdmcpsrvr"'], ['', '}}\n'],
    ['c-cmt', '\n// agent asks to read a file\n'],
    ['c-arrow', '→ '], ['', '{'], ['c-key', '"name"'], ['', ':'], ['c-str', '"read_lines"'], ['', ', '],
    ['c-key', '"path"'], ['', ':'], ['c-str', '"~/code/main.rs"'], ['', '}\n'],
    ['c-cmt', '  ↳ canonicalize · prefix-match allowed_roots '], ['c-ok', '✓\n'],
    ['c-cmt', '  ↳ symlink check · network-fs check '], ['c-ok', '✓\n'],
    ['c-arrow', '← '], ['', '{'], ['c-key', '"content"'], ['', ':'], ['c-str', '"fn main() {…"'], ['', '} '], ['c-ok', '200\n'],
    ['c-cmt', '\n// agent tries to escape\n'],
    ['c-arrow', '→ '], ['', '{'], ['c-key', '"path"'], ['', ':'], ['c-str', '"/etc/shadow"'], ['', '}\n'],
    ['c-cmt', '  ↳ prefix-match allowed_roots '], ['', '✗  '], ['c-num', 'PathNotAllowed\n'],
    ['c-arrow', '← '], ['', '{'], ['c-key', '"error"'], ['', ':{'], ['c-key', '"code"'], ['', ':'], ['c-num', '-32001'], ['', ', '],
    ['c-key', '"message"'], ['', ':'], ['c-str', '"Policy denied"'], ['', '}}\n'],
  ];
  function typeTerm() {
    const out = $('#termText'); if (!out) return;
    let i = 0, frag = "";
    const cursor = '<span class="cursor"></span>';
    function step() {
      if (i >= TERM.length) { out.innerHTML = frag + cursor; return; }
      const [cls, txt] = TERM[i];
      frag += cls ? `<span class="${cls}">${txt.replace(/</g, "&lt;")}</span>` : txt.replace(/</g, "&lt;");
      out.innerHTML = frag + cursor;
      i++;
      setTimeout(step, txt.includes("\n") ? 140 : 38 + Math.random() * 26);
    }
    step();
  }

  /* ---------- overview cards ---------- */
  function renderOverview() {
    const cards = [
      ["🛡", "Policy-first", "Nothing is permitted unless policy.yaml says so. Allowed roots, write rules, and a command catalog are the entire trust model.", "#ee6b35"],
      ["📦", "Sandboxed execution", "Commands run with a cleared environment, OS resource limits, wall-clock timeouts, and output caps — no shell, ever.", "#36c6c0"],
      ["✎", "Audited & accountable", "Every allow, deny, and error is a hashed JSONL line carrying the active policy hash — a tamper-evident record of the agent's reach.", "#9a8cf0"],
    ];
    const wrap = $("#overviewCards");
    cards.forEach(([ic, t, d, c]) => {
      const card = el("div", "crate");
      card.style.cssText = "--accent:" + c + ";cursor:default;";
      card.innerHTML = `<div class="nm" style="font-size:17px"><span style="font-size:20px;margin-right:8px">${ic}</span><b>${t}</b></div><div class="ds" style="font-size:13.5px;margin-top:10px">${d}</div>`;
      wrap.appendChild(card);
    });
  }

  /* ---------- workspace ---------- */
  function renderWorkspace() {
    const grid = $("#crateGrid"), detail = $("#crateDetail");
    function paint(c) {
      detail.style.setProperty("--accent", c.accent);
      detail.innerHTML =
        `<div class="kind">${c.kind}</div>
         <h3>${c.name}</h3>
         <div class="path">${c.path}</div>
         <div class="desc">${c.desc}</div>
         <div class="facts">${c.facts.map(([k, v]) => `<div class="fact"><span class="fk">${k}</span><span class="fv">${v}</span></div>`).join("")}</div>
         <div class="deps">${c.deps.map(d => `<span class="chip">${d}</span>`).join("")}</div>`;
    }
    CRATES.forEach((c, i) => {
      const card = el("button", "crate" + (i === 0 ? " active" : ""));
      card.style.setProperty("--accent", c.accent);
      card.innerHTML = `<span class="tag">${c.tag}</span><div class="k">${c.kind.split("·")[0].trim()}</div><div class="nm"><b>${c.name}</b></div><div class="ds">${c.desc.split(".")[0]}.</div>`;
      card.addEventListener("click", () => { $$(".crate", grid).forEach(x => x.classList.remove("active")); card.classList.add("active"); paint(c); });
      grid.appendChild(card);
    });
    paint(CRATES[0]);
  }

  /* ---------- anatomy ---------- */
  function renderAnatomy() {
    const list = $("#modList"), detail = $("#modDetail");
    function paint(m) {
      detail.innerHTML =
        `<div class="mh"><h3>${m.name}</h3><span class="mono dim" style="font-size:13px">${m.loc} lines</span></div>
         <div class="role">${m.role}</div>
         <ul>${m.points.map(p => `<li>${p}</li>`).join("")}</ul>`;
    }
    MODULES.forEach((m, i) => {
      const row = el("button", "mod" + (i === 0 ? " active" : ""));
      row.innerHTML = `<span class="idx">${String(i + 1).padStart(2, "0")}</span><span class="mn">${m.name}</span><span class="loc">${m.loc}</span>`;
      row.addEventListener("click", () => { $$(".mod", list).forEach(x => x.classList.remove("active")); row.classList.add("active"); paint(m); });
      list.appendChild(row);
    });
    paint(MODULES[0]);
  }

  /* ---------- request lifecycle ---------- */
  let curScenario = "read", running = false;
  function renderLifecycle() {
    const pipe = $("#pipeline");
    STAGES.forEach(s => {
      const st = el("div", "stage" + (s.gate ? " gate" : ""));
      st.dataset.k = s.k;
      st.innerHTML = `<div class="node">${s.icon}</div><div class="sn">${s.name}</div><div class="sd">${s.sub}</div>`;
      pipe.appendChild(st);
    });
    const pick = $("#scenarioPick");
    Object.entries(SCENARIOS).forEach(([k, v], i) => {
      const b = el("button", "sc-btn" + (i === 0 ? " active" : ""));
      b.dataset.k = k;
      b.innerHTML = `<span class="d" style="background:${v.dot}"></span>${v.label}`;
      b.addEventListener("click", () => {
        if (running) return;
        curScenario = k;
        $$(".sc-btn", pick).forEach(x => x.classList.remove("active"));
        b.classList.add("active");
        resetPipeline();
      });
      pick.appendChild(b);
    });
    resetPipeline();
    $("#runBtn").addEventListener("click", runScenario);
  }
  function resetPipeline() {
    const sc = SCENARIOS[curScenario];
    $("#runTitle").textContent = sc.title;
    $$(".stage").forEach(s => s.className = "stage" + (s.dataset.k === "gate" ? " gate" : ""));
    $("#logStream").innerHTML = "";
    $("#logCount").textContent = "0 events";
    const v = $("#verdict"); v.className = "verdict idle"; v.textContent = "— awaiting run —";
    $("#verdictReason").innerHTML = "Press run to evaluate this scenario against the policy gates.";
  }
  function runScenario() {
    if (running) return;
    running = true;
    const sc = SCENARIOS[curScenario];
    resetPipeline();
    $("#runBtn").disabled = true;
    const stages = $$(".stage");
    const logStream = $("#logStream");
    const denyIdx = sc.denyAt; // stage index where it dies (-1 = full pass)
    let step = 0;
    const lastStage = denyIdx >= 0 ? denyIdx + 1 : stages.length; // include the gate stage that denies

    function lightStage() {
      if (step >= lastStage) { dumpLog(); return; }
      const st = stages[step];
      if (denyIdx >= 0 && step === denyIdx) {
        st.classList.add("lit", "denied");
        // mark downstream as blocked
        for (let j = step + 1; j < stages.length; j++) {
          if (stages[j].dataset.k === "audit" || stages[j].dataset.k === "resp") continue;
          stages[j].classList.add("blocked");
        }
        // still light audit + resp to show the denial is logged & returned
        stages.forEach(s => { if (s.dataset.k === "audit" || s.dataset.k === "resp") s.classList.add("lit", "denied"); });
      } else {
        st.classList.add("lit");
      }
      step++;
      setTimeout(lightStage, 360);
    }

    function dumpLog() {
      sc.log.forEach((entry, i) => {
        setTimeout(() => {
          const [t, tag, msg, kind] = entry;
          const line = el("div", "log-line");
          const klass = kind === "ok" ? "ok" : kind === "no" ? "no" : "";
          line.innerHTML = `<span class="t">${t}</span> <span class="${klass}">[${tag}]</span> ${escapeHtml(msg)}`;
          logStream.appendChild(line);
          requestAnimationFrame(() => line.classList.add("show"));
          $("#logCount").textContent = (i + 1) + " events";
          if (i === sc.log.length - 1) finish();
        }, i * 130);
      });
    }
    function finish() {
      const v = $("#verdict");
      v.className = "verdict " + sc.verdict;
      v.innerHTML = sc.verdict === "allow" ? "✓ ALLOW" : "✕ DENY";
      $("#verdictReason").innerHTML = sc.verdictReason;
      running = false;
      $("#runBtn").disabled = false;
    }
    lightStage();
  }

  /* ---------- security layers ---------- */
  function renderLayers() {
    const wrap = $("#layers");
    LAYERS.forEach((L, i) => {
      const d = el("div", "layer" + (i === 0 ? " open" : ""));
      d.style.setProperty("--lc", L.c);
      d.innerHTML =
        `<div class="layer-head"><span class="ln">${L.n}</span>
           <div><h4>${L.t}</h4><div class="gist">${L.gist}</div></div>
           <span class="tog">+</span></div>
         <div class="layer-body"><div class="layer-body-inner"><p>${L.body}</p><div class="src">↳ ${L.src}</div></div></div>`;
      d.querySelector(".layer-head").addEventListener("click", () => d.classList.toggle("open"));
      wrap.appendChild(d);
    });
  }

  /* ---------- policy playground ---------- */
  const PG = {
    roots: [
      { id: "code", path: "~/code", on: true },
      { id: "docs", path: "~/Documents/projects", on: true },
      { id: "tmp", path: "/tmp/mdmcp-scratch", on: false },
    ],
    writes: [
      { id: "scratch", path: "~/code/scratch", on: true },
    ],
    cmds: [
      { id: "git", allow: ["status", "log", "diff"], on: true },
      { id: "ls", allow: ["-l", "-la", "-a"], on: true },
      { id: "rm", allow: ["-i"], on: false },
    ],
    net: "deny_all",
  };

  const OPERATIONS = [
    { id: "r1", icon: "📖", label: 'read_lines  ~/code/app/main.rs', kind: "read", path: "~/code/app/main.rs" },
    { id: "r2", icon: "📖", label: 'read_lines  /etc/passwd', kind: "read", path: "/etc/passwd" },
    { id: "r3", icon: "📖", label: 'read_lines  ~/code/../.ssh/id_rsa', kind: "read", path: "~/.ssh/id_rsa", traversal: "~/code/../.ssh/id_rsa" },
    { id: "w1", icon: "✍", label: 'write_file  ~/code/scratch/out.txt', kind: "write", path: "~/code/scratch/out.txt" },
    { id: "w2", icon: "✍", label: 'write_file  ~/code/app/main.rs', kind: "write", path: "~/code/app/main.rs" },
    { id: "c1", icon: "⚙", label: 'run_command  git status', kind: "cmd", cmd: "git", args: ["status"] },
    { id: "c2", icon: "⚙", label: 'run_command  git push --force', kind: "cmd", cmd: "git", args: ["push", "--force"] },
    { id: "c3", icon: "⚙", label: 'run_command  rm -rf /', kind: "cmd", cmd: "rm", args: ["-rf", "/"] },
    { id: "n1", icon: "🌐", label: 'read_lines  //wsl$/Ubuntu/home/x', kind: "read", path: "//wsl$/Ubuntu/home/x", wsl: true },
  ];

  function rootActive(path) { return PG.roots.some(r => r.on && pathStartsWith(path, r.path)); }
  function pathStartsWith(p, root) {
    // normalize a couple of forms for the sim
    const norm = s => s.replace(/\\/g, "/").replace(/\/+$/, "");
    return norm(p) === norm(root) || norm(p).startsWith(norm(root) + "/");
  }
  function resolveTraversal(p) {
    // collapse a single ../ for the demo (~/code/../.ssh -> ~/.ssh)
    const parts = p.replace(/\\/g, "/").split("/");
    const out = [];
    for (const seg of parts) { if (seg === "..") out.pop(); else out.push(seg); }
    return out.join("/");
  }

  function evaluate(op) {
    // returns { verdict, gate, why, trace:[{label,state}] }
    const trace = [];
    const add = (label, state) => trace.push({ label, state });

    if (op.kind === "read") {
      let real = op.path;
      if (op.traversal) { real = resolveTraversal(op.traversal); add(`canonicalize: ${op.traversal} → ${real}`, "pass"); }
      else add(`canonicalize → ${real}`, "pass");

      // network fs
      if (op.wsl) {
        if (PG.net === "deny_all") { add("network-fs / WSL UNC check", "fail"); return deny("Network-FS isolation", `<span class="gk">${real}</span> is a WSL UNC path and <span class="gk">network_fs_policy</span> is <b>deny_all</b>. Switch it to allow_local_wsl to permit it.`, trace); }
        add("WSL UNC allowed by policy", "pass");
      }
      const okRoot = rootActive(real);
      add(`prefix-match allowed_roots`, okRoot ? "pass" : "fail");
      if (!okRoot) return deny("Path confinement", `<span class="gk">${real}</span> does not start with any enabled allowed root, so the guarded reader refuses to open it (<span class="gk">FsError::PathNotAllowed</span>).`, trace);
      add("symlink / special-file check", "pass");
      return allow(`<span class="gk">${real}</span> resolves inside an enabled root and passes the symlink & network checks — the read proceeds under the byte cap.`, trace);
    }

    if (op.kind === "write") {
      add(`canonicalize → ${op.path}`, "pass");
      const okRoot = rootActive(op.path);
      add("prefix-match allowed_roots", okRoot ? "pass" : "fail");
      if (!okRoot) return deny("Path confinement", `<span class="gk">${op.path}</span> is outside every enabled allowed root.`, trace);
      const wr = PG.writes.find(w => w.on && pathStartsWith(op.path.replace(/\/[^/]+$/, ""), w.path));
      add("match a write_rule (recursive)", wr ? "pass" : "fail");
      if (!wr) return deny("Write rule required", `Reads would be fine, but writing also needs a <span class="gk">write_rule</span>. No enabled rule covers <span class="gk">${op.path}</span>, so it's <span class="gk">WriteNotPermitted</span>.`, trace);
      add("atomic temp-write + rename", "pass");
      return allow(`<span class="gk">${op.path}</span> sits under an enabled write rule, so the writer commits atomically via a .tmp file + rename.`, trace);
    }

    if (op.kind === "cmd") {
      const c = PG.cmds.find(x => x.id === op.cmd);
      const enabled = c && c.on;
      add(`lookup catalog["${op.cmd}"]`, enabled ? "pass" : "fail");
      if (!enabled) return deny("Command whitelisting", `<span class="gk">${op.cmd}</span> is not an enabled command in the catalog — there is no shell, so unknown commands are <span class="gk">CommandNotFound</span>.`, trace);
      // path-scope: check path-like args
      let badArg = null, scopeFail = null;
      for (const a of op.args) {
        if (a.startsWith("-")) continue;
        if (a === "/" || a.startsWith("/") || a.includes("/")) {
          if (!rootActive(a)) { scopeFail = a; break; }
        }
      }
      const allowMiss = op.args.find(a => !c.allow.includes(a) && !(a.startsWith("/") || a === "/"));
      // path scope first (mirrors enforce_path_scope running before/with arg validation)
      if (scopeFail !== null) {
        add(`path-scope arg "${scopeFail}"`, "fail");
        return deny("Argument path-scoping", `The argument <span class="gk">${scopeFail}</span> resolves outside allowed roots, so <span class="gk">enforce_path_scope</span> rejects the whole command before it spawns.`, trace);
      }
      add("path-scope of args", "pass");
      const denArg = op.args.find(a => !a.startsWith("/") && a !== "/" && !c.allow.includes(a));
      add("each arg ∈ args.allow / patterns", denArg ? "fail" : "pass");
      if (denArg) return deny("Argument validation", `<span class="gk">${op.cmd}</span> is allowed, but the argument <span class="gk">${denArg}</span> is not on its allowlist and matches no pattern — <span class="gk">argNotAllowed</span>.`, trace);
      add("env_clear + rlimits + timeout", "pass");
      return allow(`<span class="gk">${op.cmd} ${op.args.join(" ")}</span> is fully allowlisted; it runs in a cleared env under resource limits and a timeout.`, trace);
    }
  }
  function allow(why, trace) { return { verdict: "allow", why, trace }; }
  function deny(gate, why, trace) { return { verdict: "deny", gate, why, trace }; }

  let selectedOp = null;
  function renderPlayground() {
    // policy toggles
    const mkToggle = (label, sub, on, onChange) => {
      const row = el("div", "toggle-row");
      row.innerHTML = `<span class="lbl">${label}${sub ? ` <span class="sub">${sub}</span>` : ""}</span>`;
      const sw = el("div", "sw" + (on ? " on" : ""));
      sw.addEventListener("click", () => { const now = !sw.classList.contains("on"); sw.classList.toggle("on", now); onChange(now); reEval(); });
      row.appendChild(sw);
      return row;
    };
    const rt = $("#rootToggles");
    PG.roots.forEach(r => rt.appendChild(mkToggle(r.path, "", r.on, v => r.on = v)));
    const wt = $("#writeToggles");
    PG.writes.forEach(w => wt.appendChild(mkToggle(w.path, "recursive", w.on, v => w.on = v)));
    const ct = $("#cmdToggles");
    PG.cmds.forEach(c => ct.appendChild(mkToggle(c.id, c.allow.join(" · "), c.on, v => c.on = v)));

    // net policy as 3-way segmented
    const net = $("#netToggle");
    const seg = el("div", "scenario-pick");
    seg.style.cssText = "width:100%;display:grid;grid-template-columns:repeat(3,1fr)";
    [["deny_all", "deny all"], ["allow_local_wsl", "local WSL"], ["allow_all", "allow all"]].forEach(([k, lbl]) => {
      const b = el("button", "sc-btn" + (PG.net === k ? " active" : ""));
      b.style.fontSize = "11px"; b.textContent = lbl;
      b.addEventListener("click", () => { PG.net = k; $$(".sc-btn", seg).forEach(x => x.classList.remove("active")); b.classList.add("active"); reEval(); });
      seg.appendChild(b);
    });
    net.appendChild(seg);

    // operations
    const ol = $("#opList");
    OPERATIONS.forEach(op => {
      const b = el("button", "op");
      b.dataset.id = op.id;
      b.innerHTML = `<span class="opi">${op.icon}</span><span>${op.label}</span><span class="opv q">?</span>`;
      b.addEventListener("click", () => { selectedOp = op; $$(".op", ol).forEach(x => x.classList.remove("sel")); b.classList.add("sel"); reEval(); });
      ol.appendChild(b);
    });
    // pre-evaluate verdict pills
    refreshPills();
  }
  function refreshPills() {
    OPERATIONS.forEach(op => {
      const b = $(`.op[data-id="${op.id}"]`); if (!b) return;
      const res = evaluate(op);
      const pill = b.querySelector(".opv");
      pill.className = "opv " + (res.verdict === "allow" ? "a" : "d");
      pill.textContent = res.verdict;
    });
  }
  function reEval() {
    refreshPills();
    if (!selectedOp) return;
    const res = evaluate(selectedOp);
    const box = $("#pgResult");
    const traceHtml = res.trace.map(t => {
      const m = t.state === "pass" ? "✓" : t.state === "fail" ? "✕" : "·";
      return `<div class="tr ${t.state}"><span class="m">${m}</span><span>${escapeHtml(t.label)}</span></div>`;
    }).join("");
    box.innerHTML =
      `<div class="vd ${res.verdict}">${res.verdict === "allow" ? "✓ ALLOW" : "✕ DENY"}${res.gate ? ` <span class="mono" style="font-size:12px;color:var(--fg-mute);font-weight:400">· gate: ${res.gate}</span>` : ""}</div>
       <div class="why">${res.why}</div>
       <div class="trace">${traceHtml}</div>`;
  }

  /* ---------- tools ---------- */
  function renderTools() {
    const g = $("#toolsGrid");
    TOOLS.forEach(t => {
      const d = el("div", "tool");
      const catLabel = t.c === "fs" ? "filesystem" : t.c === "cmd" ? "command" : "meta";
      d.innerHTML = `<div class="tnm">${t.lock ? '<span class="lock">🔒 </span>' : ""}${t.n}</div><div class="tds">${t.d}</div><span class="cat ${t.c}">${catLabel}</span>`;
      g.appendChild(d);
    });
  }

  /* ---------- timeline ---------- */
  function renderTimeline() {
    const tl = $("#timeline");
    TIMELINE.forEach(n => {
      const d = el("div", "tnode" + (n.open ? " open" : ""));
      d.style.setProperty("--dotc", n.c);
      d.innerHTML =
        `<div class="ver">${n.ver}</div><div class="tt">${n.t}</div><div class="td">${n.d}</div>
         <div class="more"><div class="more-in"><ul style="list-style:none;padding:0;margin:8px 0 0">${n.more.map(m => `<li>↳ ${m}</li>`).join("")}</ul></div></div>`;
      d.addEventListener("click", () => d.classList.toggle("open"));
      tl.appendChild(d);
    });
  }

  /* ---------- metrics ---------- */
  function renderMetrics() {
    const bl = $("#barList");
    BARS.forEach(b => {
      const row = el("div", "bar");
      row.innerHTML = `<div class="bt"><span class="bn">${b.n}</span><span class="bv">${b.v}</span></div><div class="track"><div class="fill" style="--bc:${b.c}"></div></div>`;
      bl.appendChild(row);
      row._pct = b.pct;
    });
    const cr = $("#covRows");
    COV.forEach(([n, v]) => { cr.appendChild(el("div", "cov-row", `<span class="cn">${n}</span><span class="cv">${v}</span>`)); });
  }

  /* ---------- assessment ---------- */
  function renderAssessment() {
    const g = $("#goodCol"), im = $("#improveCol");
    GOOD.forEach(([t, b]) => g.appendChild(el("div", "acard good", `<div class="at">${t}</div><div class="ab">${b}</div>`)));
    IMPROVE.forEach(([t, b]) => im.appendChild(el("div", "acard improve", `<div class="at">${t}</div><div class="ab">${b}</div>`)));
  }

  /* ---------- what makes it different ---------- */
  function highlightYaml(src) {
    let s = escapeHtml(src);
    s = s.replace(/(^|\n)(\s*)(-?\s*)([a-z_]+)(:)/g, (m, nl, sp, dash, key, col) =>
      `${nl}${sp}${dash}<span class="y-key">${key}</span>${col}`);
    s = s.replace(/(#[^\n]*)/g, '<span class="y-cmt">$1</span>');
    s = s.replace(/&quot;([^&]*?)&quot;/g, '<span class="y-str">&quot;$1&quot;</span>');
    return s;
  }
  function renderDifferent() {
    // comparison
    const uc = $("#uniqCompare");
    const mk = (cls, d) => {
      const c = el("div", "cmp " + cls);
      c.innerHTML = `<div class="ct">${d.title}</div><div class="cs">${d.sub}</div><ul>${d.points.map(p => `<li>${p}</li>`).join("")}</ul>`;
      return c;
    };
    uc.appendChild(mk("bad", UNIQ_COMPARE.bad));
    uc.appendChild(mk("good", UNIQ_COMPARE.good));

    // cli catalog demo
    const chips = $("#cliChips"), code = $("#cliCode"), exp = $("#cliExposes");
    function paintCli(t) {
      code.innerHTML = highlightYaml(t.snippet);
      exp.innerHTML = `<div class="xl">▶ now exposed to the agent</div><div class="xv">${t.exposes}</div><div class="xn">run_command · command_id: "${t.id}"</div>`;
    }
    CLI_CATALOG.forEach((t, i) => {
      const b = el("button", "cli-chip" + (i === 0 ? " active" : ""));
      b.textContent = t.id;
      b.addEventListener("click", () => { $$(".cli-chip", chips).forEach(x => x.classList.remove("active")); b.classList.add("active"); paintCli(t); });
      chips.appendChild(b);
    });
    paintCli(CLI_CATALOG[0]);

    // debug loop
    const loop = $("#loop"), ld = $("#loopDetail");
    function paintLoop(s) {
      ld.style.setProperty("--lpc", s.c);
      ld.innerHTML = `<p>${s.detail}</p><div class="lt">${s.tools.map(t => `<span class="chip">${t}</span>`).join("")}</div>`;
    }
    DEBUG_LOOP.forEach((s, i) => {
      const b = el("button", "loop-step" + (i === 0 ? " active" : ""));
      b.style.setProperty("--lpc", s.c);
      b.innerHTML = `<span class="ls-n">${s.n}</span><div class="ls-t">${s.t}</div><div class="ls-g">${s.gist}</div>`;
      b.addEventListener("click", () => { $$(".loop-step", loop).forEach(x => x.classList.remove("active")); b.classList.add("active"); paintLoop(s); });
      loop.appendChild(b);
    });
    paintLoop(DEBUG_LOOP[0]);

    // boundary
    $("#cfgCan").innerHTML = SELF_CFG.can.map(x => `<li>${x}</li>`).join("");
    $("#cfgCannot").innerHTML = SELF_CFG.cannot.map(x => `<li>${x}</li>`).join("");

    // context footprint
    $("#ctxList").innerHTML = CONTEXT_FOOT.techniques.map(([t, b]) => `<div class="ctx-item"><div class="cit">${t}</div><div class="cib">${b}</div></div>`).join("");
    const cb = $("#ctxBars");
    CONTEXT_FOOT.compare.forEach(c => {
      const row = el("div", "ctx-bar");
      row.innerHTML = `<div class="cbt"><span class="cbn">${c.label}</span><span class="cbnote">${c.note}</span></div><div class="track"><div class="fill" style="--cbc:${c.c}"></div></div>`;
      cb.appendChild(row);
      row._pct = c.pct;
    });
  }

  /* ---------- scroll fx ---------- */
  function scrollFx() {
    const prog = $("#progress"), nav = $("#topnav");
    const onScroll = () => {
      const h = document.documentElement.scrollHeight - innerHeight;
      prog.style.width = (scrollY / h * 100) + "%";
      nav.classList.toggle("scrolled", scrollY > 20);
    };
    addEventListener("scroll", onScroll, { passive: true });
    onScroll();

    const io = new IntersectionObserver((ents) => {
      ents.forEach(e => {
        if (e.isIntersecting) {
          e.target.classList.add("in");
          // animate bars when metrics enters
          if (e.target.querySelector && e.target.querySelector("#barList")) {
            $$("#barList .bar").forEach((row, i) => setTimeout(() => { row.querySelector(".fill").style.width = row._pct + "%"; }, i * 90));
          }
          // animate context-footprint bars
          if (e.target.querySelector && e.target.querySelector("#ctxBars")) {
            $$("#ctxBars .ctx-bar").forEach((row, i) => setTimeout(() => { row.querySelector(".fill").style.width = row._pct + "%"; }, 200 + i * 220));
          }
          io.unobserve(e.target);
        }
      });
    }, { threshold: 0.12 });
    $$(".reveal").forEach(r => io.observe(r));
  }

  function escapeHtml(s) { return String(s).replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;"); }

  /* ---------- boot ---------- */
  document.addEventListener("DOMContentLoaded", () => {
    typeTerm();
    renderOverview();
    renderDifferent();
    renderWorkspace();
    renderAnatomy();
    renderLifecycle();
    renderLayers();
    renderPlayground();
    renderTools();
    renderTimeline();
    renderMetrics();
    renderAssessment();
    scrollFx();
  });
})();
