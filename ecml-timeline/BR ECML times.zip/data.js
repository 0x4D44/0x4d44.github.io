/* ── ECML chapters ──────────────────────────────────────────────
   Each chapter targets the stage state.
   - year: dominant year for header
   - dateLabel: ticker date
   - era: short era name
   - tag: small kicker
   - loco: key into LOCOS  (null = no change / hold previous)
   - locoLabel / locoSpec : caption under the loco
   - time: fastest journey time in minutes (London ↔ Edinburgh)
   - speed: max service speed (mph)
   - trains: through trains per day (each way, approximate)
   - weight: train tare weight (long tons)
   - operator, power, fare : ctx-meta
   - title / body : the scroll-panel card
   - meta : 3 small chips at panel bottom
   - event : { y: 1850..2030, kind: "passed|current|future" }  position on timeline
   ────────────────────────────────────────────────────────────── */

const CHAPTERS = [
  {
    year: 1862,
    dateLabel: "JUN 1862",
    era: "Special Scotch Express",
    tag: "ERA · STEAM",
    loco: "stirling",
    locoLabel: "Stirling Single 4-2-2",
    locoSpec: "GNR No.1 · Coal",
    time: 630,         // 10h30
    speed: 50,
    trains: 1,
    weight: 110,
    operator: "GNR / NER / NBR",
    power: "Steam · coal",
    fare: "£3 4s",
    title: "<i>The 10:00 from King's Cross</i>",
    body: "Three companies — Great Northern, North Eastern, North British — pool their carriages as <b>East Coast Joint Stock</b>. The premier service departs simultaneously from London and Edinburgh at 10 a.m. each day. The journey takes ten and a half hours, including a half-hour stop at York for lunch. Locomotives change at York; passengers do not.",
    meta: [
      ["Companies", "GNR · NER · NBR"],
      ["York stop", "30 min"],
      ["Cars", "6–8 wood"],
    ],
    timelineYear: 1862,
  },
  {
    year: 1888,
    dateLabel: "AUG 1888",
    era: "Race to the North",
    tag: "ERA · STEAM · COMPETITION",
    loco: "atlantic",
    locoLabel: "Ivatt Atlantic 4-4-2",
    locoSpec: "GNR · Press-race era",
    time: 510,         // 8h30
    speed: 60,
    trains: 2,
    weight: 180,
    operator: "GNR / NER / NBR",
    power: "Steam · coal",
    fare: "£3 10s",
    title: "<i>The press calls it</i> a race.",
    body: "East and West Coast routes compete daily for the fastest published timing to Edinburgh. East Coast trains, with shorter mileage and gentler gradients, cut the schedule to <b>8h 30m</b>; one record run posts <b>7h 26¾m</b>. Atlantic types replace the singles to handle longer, heavier trains at sustained 60 mph.",
    meta: [
      ["Best timing", "8h 30m"],
      ["Record run", "7h 26m"],
      ["Sustained", "60 mph"],
    ],
    timelineYear: 1888,
  },
  {
    year: 1923,
    dateLabel: "JAN 1923",
    era: "The LNER is born",
    tag: "ERA · GROUPING",
    loco: "a3",
    locoLabel: "LNER A1/A3 Pacific 4-6-2",
    locoSpec: "No. 4472 · Doncaster Works",
    time: 510,         // still 8h30 (limited by 1888 agreement)
    speed: 70,
    trains: 4,
    weight: 450,
    operator: "London &amp; North Eastern Rly",
    power: "Steam · Pacific",
    fare: "£3 17s",
    title: "<i>Grouped</i> into LNER. A new Pacific is named.",
    body: "The Railways Act 1921 merges the three East Coast partners into the <b>London and North Eastern Railway</b>. Gresley's A1 Pacifics enter service the same year; in February 1924 No.&nbsp;4472 receives the name of the train it hauls. It appears at the British Empire Exhibition and becomes a household name. Journeys remain pegged at 8½ hours by a 1888 industry truce against speed.",
    meta: [
      ["Loco design", "Sir Nigel Gresley"],
      ["Wheel arr.", "4-6-2 Pacific"],
      ["Locos built", "52 (A1+A3)"],
    ],
    timelineYear: 1923,
  },
  {
    year: 1928,
    dateLabel: "01 MAY 1928",
    era: "First Non-stop",
    tag: "ERA · LNER PUBLICITY",
    loco: "a3",
    locoLabel: "LNER A3 4472 · corridor tender",
    locoSpec: "Crew change at speed",
    time: 483,         // 8h03m
    speed: 80,
    trains: 5,
    weight: 480,
    operator: "London &amp; North Eastern Rly",
    power: "Steam · Pacific",
    fare: "£4 0s",
    title: "<i>The first non-stop</i> from London to Edinburgh.",
    body: "Gresley fits ten Pacifics with a <b>corridor tender</b> — a narrow passage through the coal bunker lets crews swap mid-journey, near Alne north of York. On 1 May 1928, No.&nbsp;4472 hauls the inaugural non-stop, 392¾ miles in <b>8h 03m</b>. The barber's shop, the cocktail bar and the cinema coach all date from this run.",
    meta: [
      ["Distance non-stop", "392¾ mi"],
      ["Coal carried", "9 long tons"],
      ["Crew change", "On the move"],
    ],
    timelineYear: 1928,
  },
  {
    year: 1938,
    dateLabel: "03 JUL 1938",
    era: "Streamlined Age",
    tag: "ERA · STEAM · SPEED RECORD",
    loco: "a4",
    locoLabel: "LNER A4 Pacific · Mallard",
    locoSpec: "126 mph · Stoke Bank",
    time: 440,         // 7h20
    speed: 90,
    trains: 7,
    weight: 500,
    operator: "London &amp; North Eastern Rly",
    power: "Steam · streamlined",
    fare: "£4 10s",
    title: "<i>126 mph</i> on Stoke Bank.",
    body: "Gresley's streamlined A4 class — wind-tunnel curves, valance over the wheels, a stainless trim stripe — enters service in 1935. On 3 July 1938 No.&nbsp;4468 <b>Mallard</b> reaches 126 mph descending Stoke Bank: a world record for steam traction that still stands. Daily Flying Scotsman timings drop to 7h 20m.",
    meta: [
      ["Steam world record", "126 mph"],
      ["Class built", "35 (A4)"],
      ["Schedule", "7h 20m"],
    ],
    timelineYear: 1938,
  },
  {
    year: 1948,
    dateLabel: "01 JAN 1948",
    era: "Nationalised",
    tag: "ERA · BRITISH RAILWAYS",
    loco: "a4",
    locoLabel: "BR A4 60022 · 'Mallard' renumbered",
    locoSpec: "BR Brunswick green",
    time: 450,         // 7h30
    speed: 90,
    trains: 9,
    weight: 540,
    operator: "British Railways · Eastern Region",
    power: "Steam · Pacific",
    fare: "£5 2s",
    title: "<i>Big Four</i> become one.",
    body: "Rail in Britain nationalises. The A4s soldier on through the 1950s in BR Brunswick green; the line is busier than ever, but austerity, coal shortages and overdue maintenance slow schedules. The Modernisation Plan of 1955 commits BR to diesel traction. The end of steam on the ECML is set for the early 1960s.",
    meta: [
      ["Region", "Eastern"],
      ["Daily expresses", "≈ 9 each way"],
      ["Mod Plan", "1955"],
    ],
    timelineYear: 1948,
  },
  {
    year: 1961,
    dateLabel: "MAR 1961",
    era: "Deltics on the line",
    tag: "ERA · DIESEL",
    loco: "deltic",
    locoLabel: "Class 55 · English Electric Deltic",
    locoSpec: "3,300 hp · Napier Deltic ×2",
    time: 360,         // 6h00
    speed: 100,
    trains: 12,
    weight: 470,
    operator: "British Railways",
    power: "Diesel-electric",
    fare: "£6 0s",
    title: "<i>Torpedo engines</i> on rails.",
    body: "Twenty-two Class 55 <b>Deltics</b> replace the Pacifics, powered by paired Napier engines originally built for fast naval torpedo boats. They cut over an hour from the schedule on arrival — King's Cross to Edinburgh drops from seven hours to under six. By the mid-1970s, infrastructure work shaves another half-hour off.",
    meta: [
      ["Locos in class", "22"],
      ["Top speed", "100 mph"],
      ["Cut from sched", "−1h+"],
    ],
    timelineYear: 1962,
  },
  {
    year: 1978,
    dateLabel: "MAY 1978",
    era: "InterCity 125",
    tag: "ERA · HST",
    loco: "hst",
    locoLabel: "Class 43 HST · 'InterCity 125'",
    locoSpec: "Paxman Valenta · 125 mph",
    time: 270,         // 4h30
    speed: 125,
    trains: 16,
    weight: 420,
    operator: "British Rail · InterCity",
    power: "Diesel-hydraulic (Mk3)",
    fare: "£18 (1978)",
    title: "<i>The fastest diesel</i> in the world.",
    body: "The High Speed Train enters East Coast service in 1978. Two power cars top-and-tail seven Mk3 coaches; the body cuts wind better than anything before it. Routine running at <b>125 mph</b> brings the fastest London–Edinburgh time down by another hour, to about 4½. The HST will run on the ECML for 41 years.",
    meta: [
      ["Service speed", "125 mph"],
      ["Test record", "143 mph (1973)"],
      ["Withdrawn ECML", "2019"],
    ],
    timelineYear: 1978,
  },
  {
    year: 1991,
    dateLabel: "JUL 1991",
    era: "Wires to Edinburgh",
    tag: "ERA · ELECTRIC",
    loco: "class91",
    locoLabel: "Class 91 · InterCity 225",
    locoSpec: "Mk4 stock · 6,300 hp",
    time: 240,         // 4h00 (best, special run 3h29 with shortened set)
    speed: 125,
    trains: 22,
    weight: 460,
    operator: "British Rail · InterCity",
    power: "25 kV AC overhead",
    fare: "£42 (1991)",
    title: "<i>Edinburgh</i> goes electric.",
    body: "Phase one wires King's Cross to Hitchin in 1978; phase two pushes north through York (1989), Newcastle (1990) and reaches <b>Edinburgh Waverley in July 1991</b>. At its peak, the project is the longest construction site in the world. Class 91 'Electra' locomotives and Mark 4 coaches form the InterCity 225 — '225' for the 225 km/h they were built to run at, though the signalling limits them to 125 mph. A special shortened set runs London–Edinburgh in <b>3h 29m</b>.",
    meta: [
      ["Wires complete", "1991"],
      ["Top tested speed", "162 mph"],
      ["Best timing", "3h 29m"],
    ],
    timelineYear: 1991,
  },
  {
    year: 2019,
    dateLabel: "01 AUG 2019",
    era: "Azuma",
    tag: "ERA · BI-MODE",
    loco: "azuma",
    locoLabel: "Class 800/801 · 'Azuma' · LNER",
    locoSpec: "Hitachi A-Train · Bi-mode",
    time: 240,         // 4h00 fastest
    speed: 125,
    trains: 30,
    weight: 420,
    operator: "LNER (DfT OLR)",
    power: "25 kV AC + diesel back-up",
    fare: "£30–£200",
    title: "<i>Azuma</i> takes the Flying Scotsman name.",
    body: "After Virgin Trains East Coast hands back the franchise in 2018, the government's operator LNER takes over. Hitachi's <b>Class 800/801 Azuma</b> replaces both the IC125 and IC225 fleets from 2019. Bi-mode 800s carry their own diesels for the gap-toothed lines beyond the wires. Fastest London–Edinburgh: <b>4h 00m</b>, one stop at Newcastle.",
    meta: [
      ["Length", "5 / 9 / 10 cars"],
      ["Top speed", "125 mph"],
      ["Annual pax", "≈ 22 million"],
    ],
    timelineYear: 2019,
  },
  {
    year: 2025,
    dateLabel: "DEC 2025 →",
    era: "Digital signalling, next",
    tag: "ERA · ETCS / UPGRADE",
    loco: "azuma",
    locoLabel: "Class 800/801 + ETCS in-cab",
    locoSpec: "Digital signalling rollout",
    time: 253,         // 4h13 with new York stop
    speed: 125,        // could be 140 with ETCS
    trains: 32,
    weight: 420,
    operator: "LNER · Network Rail",
    power: "25 kV AC + diesel",
    fare: "£30–£200",
    title: "<i>Headway, not horsepower.</i>",
    body: "From 14 December 2025 the Flying Scotsman adds a York stop, lengthening to 4h 13m. Lineside signals between London and Stoke Tunnel — last refreshed in 1977 — give way to the <b>European Train Control System</b> through the late 2020s. With in-cab signalling, the ECML can finally clear 125 mph for sections at 140; the next half hour comes not from a faster engine, but from running trains closer together.",
    meta: [
      ["ETCS rollout", "2025 – 2029"],
      ["Target speed", "140 mph"],
      ["Capacity gain", "+25% seats"],
    ],
    timelineYear: 2025,
  },
];

// Mini route stations used in side rail
const STATIONS = [
  { name: "King's Cross",      mi: 0   },
  { name: "Peterborough",      mi: 76  },
  { name: "York",              mi: 188 },
  { name: "Newcastle",         mi: 268 },
  { name: "Berwick",           mi: 335 },
  { name: "Edinburgh Waverley",mi: 393 },
];

// Timeline span
const T_MIN = 1850;
const T_MAX = 2030;

window.CHAPTERS = CHAPTERS;
window.STATIONS = STATIONS;
window.T_MIN = T_MIN;
window.T_MAX = T_MAX;
