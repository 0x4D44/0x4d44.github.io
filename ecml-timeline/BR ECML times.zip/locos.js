/* ──────────────────────────────────────────────
   Wire-line loco drawings for the ECML timeline.
   Each is a stylised profile silhouette, viewBox 0 0 1600 700.
   All face right. Stroke-only.
   ────────────────────────────────────────────── */

const INK    = "var(--ink)";
const INK3   = "var(--ink-3)";
const RULE   = "var(--rule-soft)";
const ACC    = "var(--accent)";

/* shared bits ----------------------------------------------------------- */
function track(){
  // two rails + sleepers + ground line
  let sleepers = '';
  for(let x=20; x<1580; x+=44){
    sleepers += `<rect x="${x}" y="640" width="22" height="6" fill="${INK3}" opacity=".5"/>`;
  }
  return `
    ${sleepers}
    <line x1="0" y1="632" x2="1600" y2="632" stroke="${INK}" stroke-width="1.5"/>
    <line x1="0" y1="648" x2="1600" y2="648" stroke="${INK}" stroke-width="1.5"/>
  `;
}

// Spoked wheel
function wheel(cx, cy, r, opts={}){
  const spokes = opts.spokes ?? 8;
  const hubR   = opts.hub ?? Math.max(6, r*0.18);
  const flange = opts.flange ?? r+4;
  let s = `<circle cx="${cx}" cy="${cy}" r="${flange}" fill="none" stroke="${INK3}" stroke-width="1"/>`;
  s += `<circle cx="${cx}" cy="${cy}" r="${r}" fill="var(--paper)" stroke="${INK}" stroke-width="2"/>`;
  s += `<circle cx="${cx}" cy="${cy}" r="${hubR}" fill="${INK}" stroke="none"/>`;
  for(let i=0;i<spokes;i++){
    const a = (Math.PI*2*i)/spokes;
    const x1 = cx + Math.cos(a)*hubR;
    const y1 = cy + Math.sin(a)*hubR;
    const x2 = cx + Math.cos(a)*(r-2);
    const y2 = cy + Math.sin(a)*(r-2);
    s += `<line x1="${x1.toFixed(1)}" y1="${y1.toFixed(1)}" x2="${x2.toFixed(1)}" y2="${y2.toFixed(1)}" stroke="${INK}" stroke-width="1.5"/>`;
  }
  return s;
}

// connecting rod between two wheel centres
function rod(x1,y1,x2,y2,opts={}){
  const yo = opts.offset ?? 0;
  return `
    <line x1="${x1}" y1="${y1+yo}" x2="${x2}" y2="${y2+yo}" stroke="${INK}" stroke-width="3" stroke-linecap="round"/>
    <circle cx="${x1}" cy="${y1+yo}" r="4" fill="${INK}"/>
    <circle cx="${x2}" cy="${y2+yo}" r="4" fill="${INK}"/>
  `;
}

// modern bogie (low cylindrical block w/ two wheels)
function bogie(cx, baseY, r=32){
  return `
    <rect x="${cx-90}" y="${baseY-r-18}" width="180" height="${r+12}" rx="6" fill="none" stroke="${INK3}" stroke-width="1.5"/>
    ${wheel(cx-55, baseY, r, {spokes:0})}
    ${wheel(cx+55, baseY, r, {spokes:0})}
  `;
}

// dashed centre crosshair for steam
function steamPlume(x,y){
  return `
    <g stroke="${INK3}" stroke-width="1.2" fill="none" opacity=".55">
      <path d="M${x} ${y} Q ${x-30} ${y-40} ${x-10} ${y-80} T ${x-50} ${y-150} T ${x-30} ${y-220}" />
      <path d="M${x+20} ${y-10} Q ${x-5} ${y-50} ${x+15} ${y-100} T ${x-30} ${y-180}" stroke-dasharray="3 4"/>
    </g>
  `;
}

/* ============================================================== LOCOS == */
const LOCOS = {};

/* ── 1. Stirling Single 4-2-2 (GNR, c.1870) ─────────────────────────── */
LOCOS.stirling = `
<svg viewBox="0 0 1600 700" xmlns="http://www.w3.org/2000/svg" aria-label="Stirling Single 4-2-2">
  ${track()}
  ${steamPlume(1300, 220)}
  <g fill="none" stroke="${INK}" stroke-width="2" stroke-linejoin="round" stroke-linecap="round">
    <!-- Tender (left) -->
    <path d="M40 430 L40 600 L380 600 L380 430 Z" />
    <line x1="60" y1="450" x2="360" y2="450"/>
    <line x1="60" y1="470" x2="360" y2="470"/>
    <!-- coal heap -->
    <path d="M70 430 Q 200 395 350 425" stroke="${INK3}" stroke-width="1.5"/>
    <path d="M100 430 L 130 410 L 170 425 L 200 405 L 240 422 L 280 408 L 320 425" stroke="${INK3}" stroke-width="1"/>

    <!-- drawbar to cab -->
    <line x1="380" y1="560" x2="430" y2="560"/>

    <!-- Cab -->
    <path d="M430 600 L430 360 L460 360 L460 320 L600 320 L600 360 L640 360 L640 600 Z"/>
    <!-- Cab window/opening -->
    <rect x="475" y="375" width="120" height="115" stroke="${INK3}"/>
    <line x1="475" y1="430" x2="595" y2="430" stroke="${INK3}"/>

    <!-- Footplate / running board -->
    <line x1="430" y1="525" x2="1410" y2="525"/>

    <!-- Boiler (long, with dome and tall chimney) -->
    <path d="M640 360 L640 600 L1280 600 L1280 360 Z"/>
    <!-- boiler bands -->
    <line x1="720" y1="365" x2="720" y2="600" stroke="${INK3}" stroke-width="1"/>
    <line x1="820" y1="365" x2="820" y2="600" stroke="${INK3}" stroke-width="1"/>
    <line x1="920" y1="365" x2="920" y2="600" stroke="${INK3}" stroke-width="1"/>
    <line x1="1020" y1="365" x2="1020" y2="600" stroke="${INK3}" stroke-width="1"/>
    <line x1="1120" y1="365" x2="1120" y2="600" stroke="${INK3}" stroke-width="1"/>
    <line x1="1220" y1="365" x2="1220" y2="600" stroke="${INK3}" stroke-width="1"/>

    <!-- Brass dome (toward rear of boiler) -->
    <path d="M760 360 Q 780 290 820 290 Q 860 290 880 360 Z" />
    <ellipse cx="820" cy="295" rx="40" ry="10"/>

    <!-- Safety valve / second dome -->
    <rect x="980" y="320" width="40" height="40"/>

    <!-- Tall stovepipe chimney -->
    <path d="M1190 360 L1180 170 L1240 170 L1230 360 Z"/>
    <ellipse cx="1210" cy="170" rx="38" ry="9"/>
    <ellipse cx="1210" cy="170" rx="32" ry="6" fill="var(--paper)"/>

    <!-- Smokebox door (round) -->
    <circle cx="1340" cy="480" r="80"/>
    <circle cx="1340" cy="480" r="60" stroke="${INK3}"/>
    <circle cx="1340" cy="480" r="6" fill="${INK}"/>
    <!-- handles -->
    <line x1="1340" y1="430" x2="1340" y2="530" stroke="${INK3}"/>
    <line x1="1290" y1="480" x2="1390" y2="480" stroke="${INK3}"/>

    <!-- Buffers -->
    <rect x="1420" y="500" width="18" height="36"/>
    <rect x="1420" y="450" width="18" height="36"/>
    <circle cx="1448" cy="518" r="12" fill="var(--paper)"/>
    <circle cx="1448" cy="468" r="12" fill="var(--paper)"/>

    <!-- Splasher over single driver -->
    <path d="M820 525 Q 820 360 1040 360 Q 1040 525 1040 525"/>
  </g>

  <!-- Wheels -->
  ${wheel(150, 580, 38, {spokes:8, hub:8})}
  ${wheel(245, 580, 38, {spokes:8, hub:8})}
  ${wheel(340, 580, 38, {spokes:8, hub:8})}
  <!-- trailing under cab -->
  ${wheel(560, 590, 50, {spokes:10})}
  <!-- HUGE single driver -->
  ${wheel(930, 540, 150, {spokes:14, hub:22})}
  <!-- leading bogie -->
  ${wheel(1190, 590, 50, {spokes:10})}
  ${wheel(1290, 590, 50, {spokes:10})}

  <!-- connecting rod (drive) -->
  ${rod(560, 590, 930, 540, {offset:-20})}
</svg>`;


/* ── 2. NER/GNR Atlantic 4-4-2 (c.1903) ─────────────────────────────── */
LOCOS.atlantic = `
<svg viewBox="0 0 1600 700" xmlns="http://www.w3.org/2000/svg" aria-label="Ivatt Atlantic 4-4-2">
  ${track()}
  ${steamPlume(1340, 230)}
  <g fill="none" stroke="${INK}" stroke-width="2" stroke-linejoin="round" stroke-linecap="round">
    <!-- Tender -->
    <path d="M30 420 L30 600 L380 600 L380 420 Z"/>
    <line x1="50" y1="445" x2="360" y2="445"/>
    <path d="M50 420 Q 200 385 360 415" stroke="${INK3}" stroke-width="1.5"/>
    <line x1="380" y1="560" x2="420" y2="560"/>

    <!-- Cab -->
    <path d="M420 600 L420 340 L450 340 L450 305 L630 305 L630 340 L660 340 L660 600 Z"/>
    <rect x="465" y="360" width="155" height="120" stroke="${INK3}"/>
    <line x1="465" y1="420" x2="620" y2="420" stroke="${INK3}"/>

    <!-- Boiler (fatter than Stirling) -->
    <path d="M660 340 L660 600 L1290 600 L1290 340 Z"/>
    <!-- bands -->
    <line x1="760" y1="345" x2="760" y2="600" stroke="${INK3}" stroke-width="1"/>
    <line x1="880" y1="345" x2="880" y2="600" stroke="${INK3}" stroke-width="1"/>
    <line x1="1000" y1="345" x2="1000" y2="600" stroke="${INK3}" stroke-width="1"/>
    <line x1="1120" y1="345" x2="1120" y2="600" stroke="${INK3}" stroke-width="1"/>
    <line x1="1220" y1="345" x2="1220" y2="600" stroke="${INK3}" stroke-width="1"/>

    <!-- Dome -->
    <path d="M780 340 Q 800 270 840 270 Q 880 270 900 340 Z"/>
    <ellipse cx="840" cy="275" rx="50" ry="10"/>

    <!-- Safety valves -->
    <rect x="990" y="310" width="40" height="30"/>
    <line x1="995" y1="295" x2="995" y2="310"/>
    <line x1="1025" y1="295" x2="1025" y2="310"/>

    <!-- Chimney (shorter than Stirling) -->
    <path d="M1180 340 L1170 240 L1240 240 L1230 340 Z"/>
    <ellipse cx="1205" cy="240" rx="40" ry="8"/>
    <ellipse cx="1205" cy="240" rx="32" ry="5" fill="var(--paper)"/>

    <!-- Smokebox -->
    <circle cx="1360" cy="470" r="90"/>
    <circle cx="1360" cy="470" r="70" stroke="${INK3}"/>
    <circle cx="1360" cy="470" r="7" fill="${INK}"/>
    <line x1="1360" y1="410" x2="1360" y2="530" stroke="${INK3}"/>

    <!-- running board -->
    <line x1="420" y1="540" x2="1450" y2="540"/>

    <!-- splashers over the two drivers -->
    <path d="M780 540 Q 780 410 940 410 Q 940 540 940 540"/>
    <path d="M960 540 Q 960 410 1120 410 Q 1120 540 1120 540"/>

    <!-- Buffers -->
    <rect x="1456" y="490" width="18" height="36"/>
    <rect x="1456" y="440" width="18" height="36"/>
    <circle cx="1484" cy="508" r="12" fill="var(--paper)"/>
    <circle cx="1484" cy="458" r="12" fill="var(--paper)"/>
  </g>

  <!-- tender wheels -->
  ${wheel(130, 580, 36)}
  ${wheel(225, 580, 36)}
  ${wheel(320, 580, 36)}
  <!-- bogie under cab/firebox (4-wheel trailing? for Atlantic = 1 trailing axle = 1 pair) -->
  ${wheel(530, 595, 44)}
  <!-- drivers (2) -->
  ${wheel(860, 555, 95, {spokes:12, hub:16})}
  ${wheel(1040, 555, 95, {spokes:12, hub:16})}
  <!-- leading bogie 4-wheel -->
  ${wheel(1210, 595, 44)}
  ${wheel(1300, 595, 44)}

  <!-- coupling rod -->
  ${rod(860, 555, 1040, 555, {offset:-30})}
</svg>`;


/* ── 3. LNER A1/A3 Pacific 4-6-2 — "Flying Scotsman" (1923) ─────────── */
LOCOS.a3 = `
<svg viewBox="0 0 1600 700" xmlns="http://www.w3.org/2000/svg" aria-label="LNER A3 Pacific Flying Scotsman">
  ${track()}
  ${steamPlume(1370, 220)}
  <g fill="none" stroke="${INK}" stroke-width="2" stroke-linejoin="round" stroke-linecap="round">
    <!-- Corridor tender -->
    <path d="M20 380 L20 600 L390 600 L390 380 Z"/>
    <line x1="40" y1="405" x2="370" y2="405"/>
    <line x1="40" y1="500" x2="370" y2="500"/>
    <!-- corridor connection bellows -->
    <rect x="370" y="430" width="40" height="100" stroke="${INK3}"/>
    <line x1="375" y1="445" x2="405" y2="445" stroke="${INK3}"/>
    <line x1="375" y1="465" x2="405" y2="465" stroke="${INK3}"/>
    <line x1="375" y1="485" x2="405" y2="485" stroke="${INK3}"/>
    <line x1="375" y1="505" x2="405" y2="505" stroke="${INK3}"/>

    <!-- Cab -->
    <path d="M410 600 L410 320 L440 320 L450 295 L640 295 L650 320 L680 320 L680 600 Z"/>
    <rect x="465" y="335" width="170" height="120" stroke="${INK3}"/>
    <!-- side window dividers -->
    <line x1="520" y1="335" x2="520" y2="455" stroke="${INK3}"/>
    <line x1="580" y1="335" x2="580" y2="455" stroke="${INK3}"/>

    <!-- Boiler -->
    <path d="M680 320 L680 600 L1320 600 L1320 320 Z"/>
    <!-- boiler bands -->
    <line x1="780" y1="325" x2="780" y2="600" stroke="${INK3}" stroke-width="1"/>
    <line x1="900" y1="325" x2="900" y2="600" stroke="${INK3}" stroke-width="1"/>
    <line x1="1020" y1="325" x2="1020" y2="600" stroke="${INK3}" stroke-width="1"/>
    <line x1="1140" y1="325" x2="1140" y2="600" stroke="${INK3}" stroke-width="1"/>
    <line x1="1240" y1="325" x2="1240" y2="600" stroke="${INK3}" stroke-width="1"/>

    <!-- Dome (toward middle) -->
    <path d="M820 320 Q 840 256 880 256 Q 920 256 940 320 Z"/>
    <ellipse cx="880" cy="260" rx="50" ry="9"/>

    <!-- Safety valves on firebox top -->
    <rect x="1020" y="290" width="50" height="30"/>
    <line x1="1030" y1="275" x2="1030" y2="290"/>
    <line x1="1060" y1="275" x2="1060" y2="290"/>

    <!-- Stovepipe chimney (rear of smokebox top) -->
    <path d="M1210 320 L1205 240 L1260 240 L1255 320 Z"/>
    <ellipse cx="1232" cy="240" rx="32" ry="7"/>
    <ellipse cx="1232" cy="240" rx="26" ry="4" fill="var(--paper)"/>

    <!-- Smokebox -->
    <circle cx="1380" cy="465" r="100"/>
    <circle cx="1380" cy="465" r="80" stroke="${INK3}"/>
    <circle cx="1380" cy="465" r="8" fill="${INK}"/>
    <line x1="1380" y1="395" x2="1380" y2="535" stroke="${INK3}"/>
    <line x1="1310" y1="465" x2="1450" y2="465" stroke="${INK3}"/>

    <!-- running board -->
    <line x1="410" y1="540" x2="1480" y2="540"/>

    <!-- splashers (smaller — drivers cleared) -->
    <path d="M790 540 Q 790 470 880 470 Q 880 540 880 540"/>
    <path d="M970 540 Q 970 470 1060 470 Q 1060 540 1060 540"/>
    <path d="M1150 540 Q 1150 470 1240 470 Q 1240 540 1240 540"/>

    <!-- Number 4472 plate -->
    <rect x="495" y="488" width="60" height="22" stroke="${INK}" fill="${INK}"/>
    <text x="525" y="504" font-family="JetBrains Mono" font-size="14" fill="var(--paper)" text-anchor="middle" font-weight="700">4472</text>

    <!-- Buffers -->
    <rect x="1486" y="490" width="20" height="36"/>
    <rect x="1486" y="440" width="20" height="36"/>
    <circle cx="1518" cy="508" r="13" fill="var(--paper)"/>
    <circle cx="1518" cy="458" r="13" fill="var(--paper)"/>
  </g>

  <!-- tender wheels (8 wheel tender) -->
  ${wheel(75, 600, 30)}
  ${wheel(155, 600, 30)}
  ${wheel(235, 600, 30)}
  ${wheel(315, 600, 30)}
  <!-- trailing axle (Pacific = 1 trailing) -->
  ${wheel(540, 600, 38)}
  <!-- 3 drivers -->
  ${wheel(830, 555, 80, {spokes:14, hub:14})}
  ${wheel(1010, 555, 80, {spokes:14, hub:14})}
  ${wheel(1190, 555, 80, {spokes:14, hub:14})}
  <!-- leading bogie 4-wheel -->
  ${wheel(1310, 605, 36)}
  ${wheel(1400, 605, 36)}

  <!-- coupling rod across 3 drivers -->
  ${rod(830, 555, 1190, 555, {offset:-25})}
</svg>`;


/* ── 4. LNER A4 streamlined Pacific — "Mallard" (1935) ──────────────── */
LOCOS.a4 = `
<svg viewBox="0 0 1600 700" xmlns="http://www.w3.org/2000/svg" aria-label="LNER A4 Mallard">
  ${track()}
  ${steamPlume(1280, 230)}
  <g fill="none" stroke="${INK}" stroke-width="2" stroke-linejoin="round" stroke-linecap="round">
    <!-- Streamlined tender (matches loco shape, top curved) -->
    <path d="M30 380 Q 30 360 50 360 L380 360 L380 600 L30 600 Z"/>
    <line x1="50" y1="395" x2="380" y2="395" stroke="${INK3}"/>
    <line x1="50" y1="500" x2="380" y2="500" stroke="${INK3}"/>
    <!-- corridor connector -->
    <rect x="380" y="420" width="36" height="120" stroke="${INK3}"/>

    <!-- Cab (integrated into streamlining) -->
    <rect x="416" y="320" width="280" height="280"/>
    <!-- streamlined cab side window (small letterbox) -->
    <rect x="450" y="355" width="120" height="55" stroke="${INK3}"/>
    <line x1="510" y1="355" x2="510" y2="410" stroke="${INK3}"/>

    <!-- Streamlined body — the iconic curved nose with valance -->
    <path d="M696 320 L 696 600 L 1340 600 Q 1380 600 1395 575 L 1480 460 Q 1490 445 1485 425 Q 1470 380 1380 360 Q 1280 340 1180 330 Q 1000 318 696 320 Z"/>

    <!-- Valance (skirt) — distinctive of pre-1942 -->
    <path d="M696 600 L 696 580 L 1390 580 L 1395 575" stroke="${INK3}"/>
    <line x1="500" y1="600" x2="500" y2="580" stroke="${INK3}"/>
    <line x1="900" y1="600" x2="900" y2="580" stroke="${INK3}"/>
    <line x1="1100" y1="600" x2="1100" y2="580" stroke="${INK3}"/>
    <line x1="1300" y1="600" x2="1300" y2="580" stroke="${INK3}"/>

    <!-- Stainless steel side stripe (A4 livery line) -->
    <line x1="416" y1="455" x2="1430" y2="455" stroke="${INK3}" stroke-width="1.5"/>
    <line x1="416" y1="465" x2="1430" y2="465" stroke="${INK3}" stroke-width="0.6"/>

    <!-- "Garter" badge on side -->
    <circle cx="780" cy="510" r="22" stroke="${ACC}"/>
    <text x="780" y="516" font-family="JetBrains Mono" font-size="11" fill="${ACC}" text-anchor="middle" font-weight="700">A4</text>

    <!-- Buffers (small, behind valance) -->
    <rect x="1485" y="510" width="18" height="32"/>
    <rect x="1485" y="465" width="18" height="32"/>
    <circle cx="1513" cy="526" r="10" fill="var(--paper)"/>
    <circle cx="1513" cy="481" r="10" fill="var(--paper)"/>

    <!-- Smokebox door peek -->
    <circle cx="1450" cy="490" r="34" stroke="${INK3}"/>
    <circle cx="1450" cy="490" r="5" fill="${INK}"/>

    <!-- Number plate -->
    <rect x="950" y="498" width="80" height="22" stroke="${INK}" fill="${INK}"/>
    <text x="990" y="514" font-family="JetBrains Mono" font-size="14" fill="var(--paper)" text-anchor="middle" font-weight="700">MALLARD</text>
  </g>

  <!-- Wheels (visible below valance) -->
  ${wheel(75, 620, 22)}
  ${wheel(140, 620, 22)}
  ${wheel(205, 620, 22)}
  ${wheel(270, 620, 22)}
  ${wheel(335, 620, 22)}

  <!-- trailing -->
  ${wheel(540, 615, 28)}
  <!-- 3 drivers (only bottoms visible) -->
  ${wheel(830, 605, 38, {spokes:10})}
  ${wheel(990, 605, 38, {spokes:10})}
  ${wheel(1150, 605, 38, {spokes:10})}
  <!-- leading bogie -->
  ${wheel(1290, 620, 25)}
  ${wheel(1365, 620, 25)}

  <!-- coupling rod visible -->
  ${rod(830, 605, 1150, 605, {offset:-8})}
</svg>`;


/* ── 5. BR Class 40 (English Electric Type 4, 1958) ─────────────────── */
LOCOS.class40 = `
<svg viewBox="0 0 1600 700" xmlns="http://www.w3.org/2000/svg" aria-label="BR Class 40 diesel">
  ${track()}
  <g fill="none" stroke="${INK}" stroke-width="2" stroke-linejoin="round" stroke-linecap="round">
    <!-- Body silhouette: long box with rounded cab ends -->
    <path d="M70 600 L70 380 Q 70 340 110 320 L 180 290 L 230 285 L 280 295 L 330 320 Q 360 340 360 380 L 360 600 Z"/>
    <path d="M1530 600 L1530 380 Q 1530 340 1490 320 L 1420 290 L 1370 285 L 1320 295 L 1270 320 Q 1240 340 1240 380 L 1240 600 Z"/>

    <!-- Centre body block -->
    <rect x="360" y="320" width="880" height="280"/>

    <!-- nose-end gangway doors -->
    <rect x="200" y="350" width="80" height="180" stroke="${INK3}"/>
    <line x1="240" y1="350" x2="240" y2="530" stroke="${INK3}"/>
    <rect x="1320" y="350" width="80" height="180" stroke="${INK3}"/>
    <line x1="1360" y1="350" x2="1360" y2="530" stroke="${INK3}"/>

    <!-- cab windows -->
    <path d="M105 360 L 130 335 L 215 320 L 215 360 Z" stroke="${INK3}"/>
    <path d="M325 360 L 300 335 L 285 320 L 285 360 Z" stroke="${INK3}"/>
    <path d="M1495 360 L 1470 335 L 1385 320 L 1385 360 Z" stroke="${INK3}"/>
    <path d="M1275 360 L 1300 335 L 1315 320 L 1315 360 Z" stroke="${INK3}"/>

    <!-- Body side: engine room louvres -->
    <g stroke="${INK3}" stroke-width="1">
      <!-- frames -->
      <rect x="380" y="345" width="120" height="180"/>
      <rect x="520" y="345" width="80" height="180"/>
      <rect x="620" y="345" width="120" height="180"/>
      <rect x="760" y="345" width="120" height="180"/>
      <rect x="900" y="345" width="80" height="180"/>
      <rect x="1000" y="345" width="120" height="180"/>
      <rect x="1140" y="345" width="80" height="180"/>
      <!-- louvre lines inside each -->
      ${[0,1,2,3,4,5,6].map(i=>{
        const xs=[380,520,620,760,900,1000,1140][i];
        const ws=[120,80,120,120,80,120,80][i];
        let l='';
        for(let y=355;y<515;y+=14){
          l+=`<line x1="${xs+8}" y1="${y}" x2="${xs+ws-8}" y2="${y}"/>`;
        }
        return l;
      }).join('')}
    </g>

    <!-- Roof grilles -->
    <rect x="500" y="285" width="180" height="20" stroke="${INK3}"/>
    <rect x="780" y="285" width="180" height="20" stroke="${INK3}"/>
    <rect x="1020" y="285" width="180" height="20" stroke="${INK3}"/>

    <!-- roof boxes / fan -->
    <rect x="560" y="265" width="60" height="20" stroke="${INK3}"/>
    <rect x="820" y="265" width="60" height="20" stroke="${INK3}"/>
    <rect x="1060" y="265" width="60" height="20" stroke="${INK3}"/>

    <!-- skirt / underframe -->
    <line x1="70" y1="555" x2="1530" y2="555" stroke="${INK3}"/>

    <!-- bogie frames -->
    <rect x="190" y="555" width="280" height="20" stroke="${INK3}"/>
    <rect x="1130" y="555" width="280" height="20" stroke="${INK3}"/>
  </g>

  <!-- Bogies (1Co-Co1 — 3 axles per bogie + a small idler at each end) -->
  ${wheel(230, 605, 36)}
  ${wheel(330, 605, 36)}
  ${wheel(430, 605, 36)}
  ${wheel(1170, 605, 36)}
  ${wheel(1270, 605, 36)}
  ${wheel(1370, 605, 36)}
</svg>`;


/* ── 6. BR Class 55 Deltic (1961) ───────────────────────────────────── */
LOCOS.deltic = `
<svg viewBox="0 0 1600 700" xmlns="http://www.w3.org/2000/svg" aria-label="BR Class 55 Deltic">
  ${track()}
  <g fill="none" stroke="${INK}" stroke-width="2" stroke-linejoin="round" stroke-linecap="round">
    <!-- Distinctive Deltic profile: sloped nose at both ends w/ chunky body -->
    <path d="M50 600 L 50 430 L 130 360 L 220 340 L 250 320 L 280 320 L 310 340 L 360 360 L 360 600 Z"/>
    <path d="M1550 600 L 1550 430 L 1470 360 L 1380 340 L 1350 320 L 1320 320 L 1290 340 L 1240 360 L 1240 600 Z"/>

    <!-- Centre body -->
    <rect x="360" y="320" width="880" height="280"/>

    <!-- Cab windows (wraparound) -->
    <path d="M155 380 L 230 340 L 280 340 L 280 400 L 155 400 Z" stroke="${INK3}" />
    <line x1="225" y1="345" x2="225" y2="400" stroke="${INK3}"/>
    <path d="M335 380 L 320 360 L 295 350 L 295 400 L 335 400 Z" stroke="${INK3}"/>
    <path d="M1445 380 L 1370 340 L 1320 340 L 1320 400 L 1445 400 Z" stroke="${INK3}"/>
    <line x1="1375" y1="345" x2="1375" y2="400" stroke="${INK3}"/>
    <path d="M1265 380 L 1280 360 L 1305 350 L 1305 400 L 1265 400 Z" stroke="${INK3}"/>

    <!-- Nose front number panel -->
    <rect x="115" y="445" width="80" height="35" stroke="${INK3}"/>
    <rect x="1405" y="445" width="80" height="35" stroke="${INK3}"/>

    <!-- Bodyside grilles — Deltic's distinctive central panels -->
    <g stroke="${INK3}" stroke-width="1">
      <!-- main grille blocks -->
      <rect x="400" y="345" width="180" height="160"/>
      <rect x="600" y="345" width="80" height="160"/>
      <rect x="700" y="345" width="200" height="160"/>
      <rect x="920" y="345" width="80" height="160"/>
      <rect x="1020" y="345" width="180" height="160"/>
      <!-- horizontal louvre lines -->
      ${(() => {
        const blocks=[[400,180],[600,80],[700,200],[920,80],[1020,180]];
        let s='';
        for(const [bx,bw] of blocks){
          for(let y=355;y<500;y+=10){
            s+=`<line x1="${bx+6}" y1="${y}" x2="${bx+bw-6}" y2="${y}"/>`;
          }
        }
        return s;
      })()}
    </g>

    <!-- side window (engine room) -->
    <rect x="420" y="395" width="40" height="40" stroke="${INK}" stroke-width="2"/>
    <rect x="1140" y="395" width="40" height="40" stroke="${INK}" stroke-width="2"/>

    <!-- roof exhaust ports (4) - distinctive -->
    <g stroke="${INK}" stroke-width="2">
      <rect x="500" y="295" width="60" height="25"/>
      <rect x="720" y="295" width="60" height="25"/>
      <rect x="820" y="295" width="60" height="25"/>
      <rect x="1040" y="295" width="60" height="25"/>
    </g>

    <!-- roof line cap -->
    <line x1="280" y1="320" x2="1320" y2="320" stroke="${INK3}"/>

    <!-- skirt -->
    <line x1="50" y1="560" x2="1550" y2="560" stroke="${INK3}"/>

    <!-- nameplate -->
    <rect x="640" y="500" width="320" height="32" stroke="${INK}"/>
    <text x="800" y="523" font-family="JetBrains Mono" font-size="18" fill="${INK}" text-anchor="middle" font-weight="700">DELTIC · 55</text>

    <!-- bogie frames -->
    <rect x="170" y="565" width="320" height="22" stroke="${INK3}"/>
    <rect x="1110" y="565" width="320" height="22" stroke="${INK3}"/>
  </g>

  <!-- Bogies (Co-Co: 3 axles each, ~equal spacing) -->
  ${wheel(210, 605, 36)}
  ${wheel(330, 605, 36)}
  ${wheel(450, 605, 36)}
  ${wheel(1150, 605, 36)}
  ${wheel(1270, 605, 36)}
  ${wheel(1390, 605, 36)}
</svg>`;


/* ── 7. HST Class 43 / InterCity 125 (1978) ─────────────────────────── */
LOCOS.hst = `
<svg viewBox="0 0 1600 700" xmlns="http://www.w3.org/2000/svg" aria-label="HST InterCity 125 Class 43 power car">
  ${track()}
  <g fill="none" stroke="${INK}" stroke-width="2" stroke-linejoin="round" stroke-linecap="round">
    <!-- Trailer (Mk3 coach) — left -->
    <rect x="20" y="340" width="380" height="260"/>
    <line x1="20" y1="365" x2="400" y2="365" stroke="${INK3}"/>
    <line x1="20" y1="555" x2="400" y2="555" stroke="${INK3}"/>
    <!-- Mk3 windows (deep, flush) -->
    <g stroke="${INK3}">
      <rect x="45" y="395" width="60" height="100"/>
      <rect x="115" y="395" width="60" height="100"/>
      <rect x="185" y="395" width="60" height="100"/>
      <rect x="255" y="395" width="60" height="100"/>
      <rect x="325" y="395" width="60" height="100"/>
    </g>
    <!-- coach gangway -->
    <rect x="400" y="380" width="40" height="180" stroke="${INK3}"/>

    <!-- HST POWER CAR — iconic wedge shape -->
    <!-- profile: low long body, sloped front, high glazed cab -->
    <path d="M440 600
             L 440 400
             L 480 380
             L 700 360
             L 1100 345
             L 1380 340
             Q 1450 340 1500 370
             L 1565 460
             Q 1575 478 1570 495
             L 1565 510
             L 1565 600
             Z"/>

    <!-- Roof line cap -->
    <line x1="500" y1="375" x2="1380" y2="345" stroke="${INK3}"/>

    <!-- cab windscreens (two flat panels) -->
    <path d="M1390 358 L 1500 380 L 1550 460 L 1490 460 L 1430 425 L 1390 415 Z" stroke="${INK3}"/>
    <line x1="1470" y1="408" x2="1500" y2="380" stroke="${INK3}"/>
    <line x1="1500" y1="445" x2="1490" y2="460" stroke="${INK3}"/>

    <!-- yellow nose end panel (we render as accent fill) -->
    <path d="M1550 460 L 1565 495 L 1565 540 L 1500 540 L 1490 460 Z" stroke="${INK}" fill="${ACC}" fill-opacity=".18"/>

    <!-- headlight cluster -->
    <rect x="1520" y="510" width="30" height="20" stroke="${INK}"/>

    <!-- POWER CAR body side details: long louvres + windows -->
    <g stroke="${INK3}" stroke-width="1">
      <!-- engine room grilles -->
      <rect x="480" y="395" width="140" height="120"/>
      ${(()=>{ let s=''; for(let y=405;y<510;y+=10) s+=`<line x1="490" y1="${y}" x2="610" y2="${y}"/>`; return s; })()}
      <rect x="640" y="395" width="220" height="120"/>
      ${(()=>{ let s=''; for(let y=405;y<510;y+=10) s+=`<line x1="650" y1="${y}" x2="850" y2="${y}"/>`; return s; })()}
      <rect x="880" y="395" width="140" height="120"/>
      ${(()=>{ let s=''; for(let y=405;y<510;y+=10) s+=`<line x1="890" y1="${y}" x2="1010" y2="${y}"/>`; return s; })()}
      <rect x="1040" y="395" width="180" height="120"/>
      ${(()=>{ let s=''; for(let y=405;y<510;y+=10) s+=`<line x1="1050" y1="${y}" x2="1210" y2="${y}"/>`; return s; })()}
    </g>

    <!-- engineer side door / window -->
    <rect x="1250" y="395" width="40" height="80" stroke="${INK3}"/>
    <rect x="1300" y="395" width="40" height="80" stroke="${INK3}"/>

    <!-- skirt -->
    <line x1="20" y1="560" x2="1565" y2="560" stroke="${INK3}"/>

    <!-- "125" badge -->
    <rect x="800" y="540" width="70" height="22" stroke="${INK} " fill="${INK}"/>
    <text x="835" y="557" font-family="JetBrains Mono" font-size="14" fill="var(--paper)" text-anchor="middle" font-weight="700">125</text>

    <!-- bogie frames -->
    <rect x="60" y="565" width="120" height="20" stroke="${INK3}"/>
    <rect x="240" y="565" width="120" height="20" stroke="${INK3}"/>
    <rect x="460" y="565" width="160" height="20" stroke="${INK3}"/>
    <rect x="1340" y="565" width="160" height="20" stroke="${INK3}"/>
  </g>

  <!-- coach bogies -->
  ${wheel(95, 605, 28)}
  ${wheel(145, 605, 28)}
  ${wheel(275, 605, 28)}
  ${wheel(325, 605, 28)}
  <!-- power car bogies (Bo-Bo: 2 axles each) -->
  ${wheel(495, 605, 32)}
  ${wheel(585, 605, 32)}
  ${wheel(1370, 605, 32)}
  ${wheel(1460, 605, 32)}
</svg>`;


/* ── 8. Class 91 / IC225 "Electra" (1989) ───────────────────────────── */
LOCOS.class91 = `
<svg viewBox="0 0 1600 700" xmlns="http://www.w3.org/2000/svg" aria-label="Class 91 InterCity 225 Electra">
  ${track()}
  <g fill="none" stroke="${INK}" stroke-width="2" stroke-linejoin="round" stroke-linecap="round">
    <!-- Mk4 trailer (left) -->
    <rect x="20" y="340" width="380" height="260"/>
    <line x1="20" y1="555" x2="400" y2="555" stroke="${INK3}"/>
    <g stroke="${INK3}">
      <rect x="45" y="395" width="55" height="90"/>
      <rect x="110" y="395" width="55" height="90"/>
      <rect x="175" y="395" width="55" height="90"/>
      <rect x="240" y="395" width="55" height="90"/>
      <rect x="305" y="395" width="55" height="90"/>
    </g>
    <!-- DVT gangway / asymmetric end -->
    <rect x="400" y="380" width="40" height="180" stroke="${INK3}"/>

    <!-- CLASS 91 — distinctive asymmetric profile: one end SHARPLY sloped (the "right" / aerodynamic streamlined end),
         other end blunt. Body has straight sides with rooftop pantograph well. -->
    <path d="M440 600
             L 440 360
             L 1330 360
             L 1500 460
             Q 1525 478 1525 500
             L 1525 600 Z"/>

    <!-- streamlined nose detail -->
    <line x1="1330" y1="360" x2="1500" y2="460" stroke="${INK}"/>
    <path d="M1340 380 L 1470 460 L 1470 520 L 1380 520 L 1340 460 Z" stroke="${INK3}"/>
    <!-- windscreen -->
    <path d="M1350 395 L 1430 450 L 1430 460 L 1370 460 L 1345 425 Z" stroke="${INK3}" fill="var(--paper)"/>

    <!-- yellow nose panel -->
    <path d="M1430 460 L 1500 460 L 1525 500 L 1525 530 L 1470 530 L 1430 510 Z" stroke="${INK}" fill="${ACC}" fill-opacity=".18"/>

    <!-- Side body — flutes + windows + grille -->
    <g stroke="${INK3}" stroke-width="1">
      <!-- flutes -->
      <line x1="450" y1="395" x2="1300" y2="395"/>
      <line x1="450" y1="410" x2="1300" y2="410"/>
      <line x1="450" y1="510" x2="1300" y2="510"/>
      <line x1="450" y1="525" x2="1300" y2="525"/>
      <!-- engine room windows / louvre blocks -->
      <rect x="480" y="425" width="80" height="70"/>
      <rect x="580" y="425" width="180" height="70"/>
      <rect x="780" y="425" width="80" height="70"/>
      <rect x="880" y="425" width="180" height="70"/>
      <rect x="1080" y="425" width="80" height="70"/>
      <rect x="1180" y="425" width="100" height="70"/>
      <!-- louvre lines -->
      ${(()=>{ let s='';
        const blocks=[[580,180],[880,180]];
        for(const [bx,bw] of blocks){
          for(let y=435;y<490;y+=8){
            s+=`<line x1="${bx+10}" y1="${y}" x2="${bx+bw-10}" y2="${y}"/>`;
          }
        }
        return s;
      })()}
    </g>

    <!-- Pantograph (raised) -->
    <g stroke="${INK}" stroke-width="2" fill="none">
      <!-- base -->
      <rect x="780" y="345" width="120" height="15" stroke="${INK3}"/>
      <!-- pantograph diamond -->
      <line x1="810" y1="345" x2="790" y2="270"/>
      <line x1="870" y1="345" x2="890" y2="270"/>
      <line x1="790" y1="270" x2="840" y2="220"/>
      <line x1="890" y1="270" x2="840" y2="220"/>
      <line x1="730" y1="218" x2="950" y2="218" stroke-width="3"/>
    </g>
    <!-- overhead wire suggestion -->
    <line x1="0" y1="225" x2="1600" y2="225" stroke="${INK3}" stroke-width="0.6" stroke-dasharray="2 4"/>
    <line x1="0" y1="195" x2="1600" y2="195" stroke="${INK3}" stroke-width="0.6" stroke-dasharray="2 4"/>

    <!-- skirt -->
    <line x1="440" y1="560" x2="1525" y2="560" stroke="${INK3}"/>

    <!-- "InterCity 225" badge -->
    <rect x="900" y="540" width="100" height="22" stroke="${INK}" fill="${INK}"/>
    <text x="950" y="557" font-family="JetBrains Mono" font-size="13" fill="var(--paper)" text-anchor="middle" font-weight="700">IC 225</text>

    <!-- bogie frames -->
    <rect x="60" y="565" width="120" height="20" stroke="${INK3}"/>
    <rect x="240" y="565" width="120" height="20" stroke="${INK3}"/>
    <rect x="470" y="565" width="170" height="20" stroke="${INK3}"/>
    <rect x="1280" y="565" width="170" height="20" stroke="${INK3}"/>
  </g>

  <!-- bogies -->
  ${wheel(95, 605, 28)}
  ${wheel(145, 605, 28)}
  ${wheel(275, 605, 28)}
  ${wheel(325, 605, 28)}
  ${wheel(505, 605, 32)}
  ${wheel(605, 605, 32)}
  ${wheel(1315, 605, 32)}
  ${wheel(1415, 605, 32)}
</svg>`;


/* ── 9. Class 800/801 Azuma (2019) ──────────────────────────────────── */
LOCOS.azuma = `
<svg viewBox="0 0 1600 700" xmlns="http://www.w3.org/2000/svg" aria-label="Class 800 Azuma">
  ${track()}
  <g fill="none" stroke="${INK}" stroke-width="2" stroke-linejoin="round" stroke-linecap="round">
    <!-- Modern A-Train profile: gently sloped nose, plug doors, long windows -->
    <!-- Trailing car (left) -->
    <path d="M20 600 L 20 380 L 60 360 L 240 360 L 240 600 Z"/>
    <line x1="20" y1="555" x2="240" y2="555" stroke="${INK3}"/>
    <g stroke="${INK3}">
      <rect x="40" y="395" width="50" height="80"/>
      <rect x="100" y="395" width="50" height="80"/>
      <rect x="160" y="395" width="50" height="80"/>
    </g>

    <!-- intercar gap -->
    <rect x="240" y="380" width="24" height="180" stroke="${INK3}"/>

    <!-- Intermediate car -->
    <rect x="264" y="360" width="420" height="240"/>
    <line x1="264" y1="555" x2="684" y2="555" stroke="${INK3}"/>
    <g stroke="${INK3}">
      <!-- plug door + windows alternating -->
      <rect x="280" y="395" width="40" height="100"/>
      <rect x="332" y="395" width="80" height="80"/>
      <rect x="425" y="395" width="80" height="80"/>
      <rect x="518" y="395" width="80" height="80"/>
      <rect x="611" y="395" width="40" height="100"/>
    </g>

    <!-- intercar gap -->
    <rect x="684" y="380" width="24" height="180" stroke="${INK3}"/>

    <!-- Intermediate car w/ pantograph -->
    <rect x="708" y="360" width="420" height="240"/>
    <line x1="708" y1="555" x2="1128" y2="555" stroke="${INK3}"/>
    <g stroke="${INK3}">
      <rect x="725" y="395" width="40" height="100"/>
      <rect x="775" y="395" width="80" height="80"/>
      <rect x="865" y="395" width="80" height="80"/>
      <rect x="955" y="395" width="80" height="80"/>
      <rect x="1045" y="395" width="80" height="80"/>
    </g>

    <!-- Pantograph on this car -->
    <g stroke="${INK}" stroke-width="2">
      <rect x="850" y="345" width="120" height="14" stroke="${INK3}"/>
      <line x1="880" y1="345" x2="860" y2="280"/>
      <line x1="940" y1="345" x2="960" y2="280"/>
      <line x1="860" y1="280" x2="910" y2="240"/>
      <line x1="960" y1="280" x2="910" y2="240"/>
      <line x1="810" y1="238" x2="1010" y2="238" stroke-width="3"/>
    </g>
    <line x1="0" y1="225" x2="1600" y2="225" stroke="${INK3}" stroke-width="0.6" stroke-dasharray="2 4"/>
    <line x1="0" y1="200" x2="1600" y2="200" stroke="${INK3}" stroke-width="0.6" stroke-dasharray="2 4"/>

    <!-- intercar gap -->
    <rect x="1128" y="380" width="24" height="180" stroke="${INK3}"/>

    <!-- Leading driving car w/ sloped nose -->
    <path d="M1152 600
             L 1152 360
             L 1300 360
             Q 1380 360 1430 385
             L 1545 460
             Q 1565 475 1568 495
             L 1568 540
             L 1568 600 Z"/>

    <line x1="1152" y1="555" x2="1568" y2="555" stroke="${INK3}"/>

    <g stroke="${INK3}">
      <rect x="1172" y="395" width="50" height="100"/>
      <rect x="1235" y="395" width="80" height="80"/>
      <rect x="1330" y="395" width="60" height="80"/>
    </g>

    <!-- windscreen (large, raked) -->
    <path d="M1400 385 L 1545 460 L 1545 470 L 1430 470 L 1395 430 Z" stroke="${INK}" fill="var(--paper)"/>
    <line x1="1470" y1="430" x2="1490" y2="465" stroke="${INK3}"/>

    <!-- coupler housing nose tip -->
    <path d="M1545 470 L 1568 495 L 1568 540 L 1530 540 L 1500 470 Z" stroke="${INK}"/>

    <!-- headlight strip -->
    <rect x="1520" y="510" width="30" height="14" stroke="${INK}" fill="${INK}"/>

    <!-- "Azuma" accent line -->
    <line x1="20" y1="390" x2="1568" y2="390" stroke="${ACC}" stroke-width="2" stroke-opacity=".55"/>

    <!-- bogie frames -->
    <rect x="60" y="565" width="140" height="20" stroke="${INK3}"/>
    <rect x="290" y="565" width="160" height="20" stroke="${INK3}"/>
    <rect x="500" y="565" width="160" height="20" stroke="${INK3}"/>
    <rect x="730" y="565" width="160" height="20" stroke="${INK3}"/>
    <rect x="940" y="565" width="160" height="20" stroke="${INK3}"/>
    <rect x="1180" y="565" width="160" height="20" stroke="${INK3}"/>
    <rect x="1400" y="565" width="140" height="20" stroke="${INK3}"/>
  </g>

  <!-- bogies (one per car end roughly) -->
  ${wheel(95, 605, 28)}
  ${wheel(175, 605, 28)}
  ${wheel(325, 605, 28)}
  ${wheel(425, 605, 28)}
  ${wheel(535, 605, 28)}
  ${wheel(635, 605, 28)}
  ${wheel(765, 605, 28)}
  ${wheel(865, 605, 28)}
  ${wheel(975, 605, 28)}
  ${wheel(1075, 605, 28)}
  ${wheel(1215, 605, 28)}
  ${wheel(1315, 605, 28)}
  ${wheel(1435, 605, 28)}
  ${wheel(1515, 605, 28)}
</svg>`;

window.LOCOS = LOCOS;
