/* ── ECML scroll-driven stage controller ─────────────────────────── */
(function(){
  const $ = (s, r=document) => r.querySelector(s);
  const $$ = (s, r=document) => Array.from(r.querySelectorAll(s));

  if (window.matchMedia('(prefers-reduced-motion:reduce)').matches){
    document.body.classList.add('reduced-motion');
  }

  /* ── 1. Inject loco SVGs into the stage ─────────────────────── */
  const stack = $('#locoStack');
  const LOCO_ORDER = []; // unique loco keys in chapter order, first appearance index
  const locoEls = {};   // key → element
  CHAPTERS.forEach((c, i) => {
    if (c.loco && !locoEls[c.loco]) {
      const div = document.createElement('div');
      div.className = 'loco';
      div.dataset.loco = c.loco;
      div.innerHTML = LOCOS[c.loco] || '';
      // small caption
      const cap = document.createElement('div');
      cap.className = 'loco-label';
      cap.innerHTML = `<span><b>${c.locoLabel}</b></span><span>${c.locoSpec}</span>`;
      div.appendChild(cap);
      stack.appendChild(div);
      locoEls[c.loco] = div;
      LOCO_ORDER.push(c.loco);
    }
  });
  // start with the first one active
  if (LOCO_ORDER.length) locoEls[LOCO_ORDER[0]].classList.add('active');

  /* ── 2. Inject scroll panels ────────────────────────────────── */
  const panels = $('#panels');
  CHAPTERS.forEach((c, i) => {
    const sec = document.createElement('section');
    sec.className = 'panel';
    sec.dataset.idx = i;
    sec.dataset.screenLabel = `${String(i+1).padStart(2,'0')} ${c.year} ${c.era}`;
    sec.innerHTML = `
      <div class="panel-card">
        <div class="stamp">${String(i+1).padStart(2,'0')} / ${String(CHAPTERS.length).padStart(2,'0')}</div>
        <div class="kicker">${c.dateLabel}  ·  ${c.era}</div>
        <h2>${c.title}</h2>
        <p>${c.body}</p>
        <div class="meta-row">
          ${c.meta.map(([l,v]) => `<div><span class="lab">${l}</span><span class="val">${v}</span></div>`).join('')}
        </div>
      </div>
    `;
    panels.appendChild(sec);
  });

  /* ── 3. Timeline markers + event dots ──────────────────────── */
  const timeline = $('#timeline');
  // span
  const span = T_MAX - T_MIN;
  const yearPct = (y) => ((y - T_MIN) / span) * 100;

  // decade ticks
  for (let y = T_MIN; y <= T_MAX; y += 10){
    const m = document.createElement('div');
    m.className = 'marker' + (y % 50 === 0 ? ' major' : '');
    m.style.left = yearPct(y) + '%';
    if (y % 50 === 0) {
      const lab = document.createElement('div');
      lab.className = 'yr';
      lab.textContent = y;
      m.appendChild(lab);
    }
    timeline.appendChild(m);
  }

  // event dots
  const eventDots = [];
  CHAPTERS.forEach((c, i) => {
    const d = document.createElement('div');
    d.className = 'event-dot';
    d.style.left = yearPct(c.timelineYear) + '%';
    d.title = `${c.year} — ${c.era}`;
    timeline.appendChild(d);
    eventDots.push(d);
  });

  // cursor
  const cursor = document.createElement('div');
  cursor.className = 'cursor';
  cursor.style.left = yearPct(CHAPTERS[0].timelineYear) + '%';
  cursor.dataset.year = CHAPTERS[0].timelineYear;
  timeline.appendChild(cursor);

  /* ── 4. State setters ──────────────────────────────────────── */
  const Y_EL   = $('#year');
  const ERA_EL = $('#eraName');
  const TAG_EL = $('#eraTag');
  const CH_EL  = $('#chapNum');
  const CD_EL  = $('#chapDate');
  const CTX_T  = $('#ctxTitle');
  const CTX_B  = $('#ctxBody');
  const M_OP   = $('#mOp');
  const M_POW  = $('#mPow');
  const M_FARE = $('#mFare');
  const PROG   = $('#progPct');

  // Stat elements + max values for bar scaling
  const STAT_MAX = {
    time:   720,    // 12h, generous cap
    speed:  150,
    trains: 35,
    weight: 600,
  };
  const STAT_EL = {
    time:   { v: $('#vTime'),   bar: $('.stat[data-stat="time"] .bar'),   d: $('#dTime')   },
    speed:  { v: $('#vSpeed'),  bar: $('.stat[data-stat="speed"] .bar'),  d: $('#dSpeed')  },
    trains: { v: $('#vTrains'), bar: $('.stat[data-stat="trains"] .bar'), d: $('#dTrains') },
    weight: { v: $('#vWeight'), bar: $('.stat[data-stat="weight"] .bar'), d: $('#dWeight') },
  };

  function fmtTime(mins) {
    const total = Math.round(mins);
    const h = Math.floor(total / 60);
    const m = total % 60;
    return `${h}:${String(m).padStart(2,'0')}`;
  }
  function fmtSpeed(v){ return Math.round(v); }
  function fmtTrains(v){ return Math.round(v); }
  function fmtWeight(v){ return Math.round(v); }

  let prevValues = null;
  let currentIdx = -1;

  // Tween helper
  function tween(from, to, dur, ease, onUpdate, onDone){
    const start = performance.now();
    let raf;
    function frame(now){
      const t = Math.min(1, (now - start) / dur);
      const e = ease(t);
      onUpdate(from + (to - from) * e);
      if (t < 1) raf = requestAnimationFrame(frame);
      else onDone && onDone();
    }
    raf = requestAnimationFrame(frame);
    return () => cancelAnimationFrame(raf);
  }
  const easeOutCubic = t => 1 - Math.pow(1 - t, 3);

  // active tween refs (so we can cancel)
  const tweens = {};

  function setStat(key, target, fmt, fromVal){
    const slot = STAT_EL[key];
    if (!slot) return;
    const from = (fromVal !== undefined ? fromVal : parseFloat((slot.v._raw ?? target)));
    // Always commit final value synchronously so the stat is correct even if rAF is throttled
    slot.v._raw = target;
    slot.v.textContent = fmt(target);
    const pct = Math.min(100, (target / STAT_MAX[key]) * 100);
    slot.bar.style.setProperty('--p', pct + '%');
    if (tweens[key]) tweens[key]();
    // Then animate from→target as a visual enhancement
    if (Math.abs(from - target) > 0.1){
      tweens[key] = tween(from, target, 950, easeOutCubic, (v) => {
        slot.v._raw = v;
        slot.v.textContent = fmt(v);
        const p = Math.min(100, (v / STAT_MAX[key]) * 100);
        slot.bar.style.setProperty('--p', p + '%');
      }, () => {
        // ensure final state
        slot.v._raw = target;
        slot.v.textContent = fmt(target);
        slot.bar.style.setProperty('--p', pct + '%');
      });
    }
  }

  function delta(prev, cur, key, fmt, betterIsLess){
    const slot = STAT_EL[key];
    if (prev == null || cur === prev){
      slot.d.classList.remove('show');
      slot.d.textContent = '';
      return;
    }
    const diff = cur - prev;
    const better = betterIsLess ? diff < 0 : diff > 0;
    const sign = diff > 0 ? '+' : '−';
    let v;
    if (key === 'time'){
      const ad = Math.abs(diff);
      const h = Math.floor(ad/60), m = ad%60;
      v = (h?`${h}h `:'')+(m?`${m}m`:(h?'':'0m'));
    } else {
      v = Math.abs(Math.round(diff));
    }
    slot.d.textContent = `${sign} ${v} vs prev   ${better?'↓ FASTER':''}${!better && key==='time' ? '↑ slower' : ''}`;
    if (key !== 'time'){
      slot.d.textContent = `${diff>0?'+':'−'} ${Math.abs(Math.round(diff))} vs prev`;
    }
    slot.d.classList.toggle('show', true);
  }

  function setChapter(i, opts={}){
    if (i === currentIdx) return;
    const prev = currentIdx >= 0 ? CHAPTERS[currentIdx] : null;
    currentIdx = i;
    const c = CHAPTERS[i];

    // header
    Y_EL.textContent = c.year;
    ERA_EL.textContent = c.era;
    TAG_EL.textContent = c.tag;
    CH_EL.textContent = String(i+1).padStart(2,'0');
    CD_EL.textContent = c.dateLabel;

    // ctx
    CTX_T.innerHTML = c.title.replace(/<\/?i>/g,'');
    CTX_B.innerHTML = c.body;
    M_OP.innerHTML  = c.operator;
    M_POW.textContent = c.power;
    M_FARE.textContent = c.fare;

    // stats
    setStat('time',   c.time,   fmtTime,   prev?.time);
    setStat('speed',  c.speed,  fmtSpeed,  prev?.speed);
    setStat('trains', c.trains, fmtTrains, prev?.trains);
    setStat('weight', c.weight, fmtWeight, prev?.weight);

    delta(prev?.time,   c.time,   'time',   fmtTime,   true);
    delta(prev?.speed,  c.speed,  'speed',  fmtSpeed,  false);
    delta(prev?.trains, c.trains, 'trains', fmtTrains, false);
    delta(prev?.weight, c.weight, 'weight', fmtWeight, false);

    // loco swap
    Object.keys(locoEls).forEach(k => {
      const el = locoEls[k];
      el.classList.remove('active');
    });
    if (locoEls[c.loco]) locoEls[c.loco].classList.add('active');

    // timeline cursor + event dots
    cursor.style.left = yearPct(c.timelineYear) + '%';
    cursor.dataset.year = c.timelineYear;
    eventDots.forEach((dot, j) => {
      dot.classList.remove('current', 'passed');
      if (j < i) dot.classList.add('passed');
      else if (j === i) dot.classList.add('current');
    });

    // progress
    const pct = Math.round(((i+1)/CHAPTERS.length) * 100);
    PROG.textContent = pct + '%';
  }

  /* ── 5. Scroll handler picks the chapter closest to viewport centre ─ */
  const panelEls = $$('.panel');
  function computeBest(){
    const mid = innerHeight * 0.5;
    let best = -1, bestDist = Infinity;
    panelEls.forEach((p, i) => {
      const r = p.getBoundingClientRect();
      const c = r.top + r.height/2;
      const d = Math.abs(c - mid);
      if (d < bestDist) { bestDist = d; best = i; }
      if (r.top < innerHeight * 0.85 && r.bottom > innerHeight * 0.15){
        p.classList.add('in');
      }
    });
    if (best >= 0) setChapter(best);
  }
  const onScroll = computeBest;  // no throttle — setChapter is cheap and idempotent
  window.addEventListener('scroll', onScroll, {passive:true});
  window.addEventListener('resize', onScroll);
  setTimeout(computeBest, 80);

  // Initial state — set chapter 0 before any scroll
  setChapter(0);
  window.__setChapter = setChapter;
  window.__onScroll = onScroll;
  // Mark the first panel as "in" so its card animates on first view
  setTimeout(() => $('.panel')?.classList.add('in'), 200);
  /* ── 6. Optional: hash deep-link to a chapter ──────────────── */
  if (location.hash){
    const idx = parseInt(location.hash.replace('#c',''), 10);
    if (!isNaN(idx) && idx >= 0 && idx < CHAPTERS.length){
      const target = $$('.panel')[idx];
      target && target.scrollIntoView({block:'center'});
    }
  }

  /* ── 7. Year-flip subtle effect ────────────────────────────── */
  // (handled by direct text replace above — keep simple)

  /* ── 8. Keyboard nav ───────────────────────────────────────── */
  window.addEventListener('keydown', (e) => {
    if (e.target.matches('input,textarea')) return;
    if (e.key === 'ArrowDown' || e.key === 'PageDown'){
      const next = $$('.panel')[Math.min(CHAPTERS.length - 1, currentIdx + 1)];
      next && next.scrollIntoView({behavior:'smooth', block:'center'});
      e.preventDefault();
    } else if (e.key === 'ArrowUp' || e.key === 'PageUp'){
      const prev = $$('.panel')[Math.max(0, currentIdx - 1)];
      prev && prev.scrollIntoView({behavior:'smooth', block:'center'});
      e.preventDefault();
    }
  });

})();
